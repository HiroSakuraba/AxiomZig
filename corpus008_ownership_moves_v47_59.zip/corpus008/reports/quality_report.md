# Corpus 0008 S3 Ownership/Moves Quality Report

```json
{
  "acceptance_notes": "S3 ownership/moves bundle; owncheck-grounded against v47.59; skeleton cap <=20; negative ratio target >=40%.",
  "accepted": true,
  "attribute_records": 240,
  "bundle_name": "corpus008_ownership_moves_v47_59",
  "compiler_version": "v47.59",
  "corpus_id": "axiomzig_prepretrain_corpus_0008",
  "created_utc": "2026-04-27T05:14:20Z",
  "deduplication": {
    "exact_duplicates_rejected": 0,
    "formatted_duplicates_rejected": 0,
    "max_semantic_skeleton_cluster_size": 20,
    "semantic_skeleton_cluster_sizes": {
      "20": 12
    },
    "semantic_skeleton_clusters": 12,
    "skeleton_cap_rejected": 24
  },
  "diagnostic_code_counts": {
    "E_OWN_BORROW_LIVE": 40,
    "E_OWN_MOVED": 20,
    "E_OWN_UNDISCHARGED": 100
  },
  "document_records": 720,
  "label_agreement": {
    "full": 240,
    "mismatch": 0
  },
  "negative_ratio": 0.5,
  "outcome_counts": {
    "fail": 120,
    "pass": 120
  },
  "phase_counts": {
    "owncheck": 240
  },
  "source_records": 240,
  "split_counts": {
    "heldout": 12,
    "train": 216,
    "validation": 12
  }
}
```
