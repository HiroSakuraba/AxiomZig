# corpus008_ownership_moves_v47_59

S3 ownership/moves bundle generated against v47.59.

Source records: 240
Document records: 720
Attribute records: 240
