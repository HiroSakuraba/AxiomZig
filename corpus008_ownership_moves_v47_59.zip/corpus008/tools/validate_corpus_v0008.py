#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
errors=[]
labels=list(root.glob('labels/**/*.label.json'))
attrs=list(root.glob('attributes/**/*attribute.json'))
docs=root/'documents'/'all_documents.jsonl'
for lab in labels:
    data=json.loads(lab.read_text()); src=root/data['source_path']
    if not src.exists(): errors.append(f'missing source {src}'); continue
    if hashlib.sha256(src.read_text().encode()).hexdigest()!=data['source_sha256']: errors.append(f'hash mismatch {src}')
for attr in attrs:
    data=json.loads(attr.read_text())
    if data.get('label_agreement',{}).get('agreement')!='full': errors.append(f'non-full agreement {attr}')
    if data.get('quality',{}).get('semantic_skeleton_cluster_size',0)>20: errors.append(f'skeleton cap exceeded {attr}')
if not docs.exists(): errors.append('missing documents/all_documents.jsonl')
print(json.dumps({'labels':len(labels),'attributes':len(attrs),'documents_jsonl_exists':docs.exists(),'errors':errors,'ok':not errors},indent=2))
sys.exit(1 if errors else 0)
