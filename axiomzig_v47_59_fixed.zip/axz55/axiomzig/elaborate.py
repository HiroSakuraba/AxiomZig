from __future__ import annotations

from dataclasses import dataclass, field

from . import ast
from .formatter import format_expr_inline, format_type
from .semantic import sem_place_for_expr


INTEGER_NAMES = {"I8", "I16", "I32", "I64", "U8", "U16", "U32", "U64"}
BOOL_TYPE = ast.NamedType("Bool")
UNIT_TYPE = ast.NamedType("Unit")
STR_TYPE = ast.NamedType("Str")
I64_TYPE = ast.NamedType("I64")
U8_TYPE = ast.NamedType("U8")
U64_TYPE = ast.NamedType("U64")


@dataclass(frozen=True, slots=True)
class UnknownType:
    reason: str = "unknown"


@dataclass(frozen=True, slots=True)
class NoneLiteralType:
    pass


TypeLike = ast.Type | UnknownType | NoneLiteralType


@dataclass(slots=True)
class ElaborationIssue:
    level: str
    message: str
    context: str | None = None
    code: str | None = None


@dataclass(slots=True)
class BindingInfo:
    name: str
    type_text: str
    mutable: bool
    origin: str


@dataclass(slots=True)
class ExprTypeInfo:
    expr: str
    type_text: str
    note: str | None = None
    place: str | None = None
    ref_mode: str | None = None
    borrow_mode: str | None = None


@dataclass(slots=True)
class CallSiteInfo:
    callee: str
    target_kind: str
    return_type: str
    effects: list[str]
    arg_ref_modes: list[str | None] = field(default_factory=list)


@dataclass(slots=True)
class FunctionElaboration:
    name: str
    declared_return_type: str
    bindings: list[BindingInfo] = field(default_factory=list)
    expr_types: list[ExprTypeInfo] = field(default_factory=list)
    calls: list[CallSiteInfo] = field(default_factory=list)
    issues: list[ElaborationIssue] = field(default_factory=list)


@dataclass(slots=True)
class ModuleElaboration:
    module_path: str
    functions: list[FunctionElaboration]
    issues: list[ElaborationIssue]


@dataclass(slots=True)
class Scope:
    bindings: dict[str, TypeLike] = field(default_factory=dict)
    mutability: dict[str, bool] = field(default_factory=dict)


class Elaborator:
    def __init__(self, module: ast.Module):
        self.module = module
        self.issues: list[ElaborationIssue] = []
        self.const_types: dict[str, ast.Type] = {}
        self.functions: dict[str, ast.FnDecl] = {}
        self.structs: dict[str, ast.StructDecl] = {}
        self.resources: dict[str, ast.ResourceDecl] = {}
        self.enums: dict[str, ast.EnumDecl] = {}
        self.error_sets: dict[str, ast.ErrorSetDecl] = {}
        self.imports: dict[str, str] = {}
        self.collect_top_level()

    def collect_top_level(self) -> None:
        for imp in self.module.imports:
            self.imports[imp.path[-1]] = ".".join(imp.path)
        for decl in self.module.decls:
            if isinstance(decl, ast.ConstDecl):
                self.const_types[decl.name] = decl.typ
            elif isinstance(decl, ast.FnDecl):
                self.functions[decl.name] = decl
            elif isinstance(decl, ast.StructDecl):
                self.structs[decl.name] = decl
            elif isinstance(decl, ast.ResourceDecl):
                self.resources[decl.name] = decl
            elif isinstance(decl, ast.EnumDecl):
                self.enums[decl.name] = decl
            elif isinstance(decl, ast.ErrorSetDecl):
                self.error_sets[decl.name] = decl

    def elaborate(self) -> ModuleElaboration:
        functions: list[FunctionElaboration] = []
        for decl in self.module.decls:
            if isinstance(decl, ast.FnDecl):
                functions.append(self.elaborate_function(decl))
        return ModuleElaboration(
            module_path=".".join(self.module.path),
            functions=functions,
            issues=self.issues,
        )

    def issue(self, level: str, message: str, summary: FunctionElaboration | None = None, context: str | None = None, code: str | None = None) -> None:
        item = ElaborationIssue(level=level, message=message, context=context, code=code)
        self.issues.append(item)
        if summary is not None:
            summary.issues.append(item)

    def elaborate_function(self, fn: ast.FnDecl) -> FunctionElaboration:
        summary = FunctionElaboration(name=fn.name, declared_return_type=format_type(fn.return_type))
        scopes = [Scope()]
        for param in fn.params:
            scopes[-1].bindings[param.name] = param.typ
            scopes[-1].mutability[param.name] = False
            summary.bindings.append(BindingInfo(name=param.name, type_text=format_type(param.typ), mutable=False, origin="param"))
        self.elaborate_block(fn.body, scopes, fn, summary)
        summary.bindings.sort(key=lambda item: (item.origin, item.name))
        return summary

    def elaborate_block(self, block: ast.Block, scopes: list[Scope], fn: ast.FnDecl, summary: FunctionElaboration) -> None:
        scopes.append(Scope())
        for stmt in block.statements:
            self.elaborate_stmt(stmt, scopes, fn, summary)
        scopes.pop()

    def elaborate_stmt(self, stmt: ast.Stmt, scopes: list[Scope], fn: ast.FnDecl, summary: FunctionElaboration) -> None:
        if isinstance(stmt, ast.Block):
            self.elaborate_block(stmt, scopes, fn, summary)
            return
        if isinstance(stmt, ast.LetStmt):
            inferred = self.infer_expr(stmt.value, scopes, fn, summary, expected=stmt.typ)
            bound = stmt.typ if stmt.typ is not None else inferred
            if stmt.typ is not None and not self.compatible(inferred, stmt.typ):
                self.issue(
                    "error",
                    f"let {stmt.name} annotated as {format_type(stmt.typ)} but got {self.type_text(inferred)}",
                    summary,
                    code="E_TYPE_MISMATCH",
                )
            scopes[-1].bindings[stmt.name] = bound
            scopes[-1].mutability[stmt.name] = False
            summary.bindings.append(BindingInfo(name=stmt.name, type_text=self.type_text(bound), mutable=False, origin="let"))
            return
        if isinstance(stmt, ast.VarStmt):
            inferred = self.infer_expr(stmt.value, scopes, fn, summary, expected=stmt.typ)
            bound = stmt.typ if stmt.typ is not None else inferred
            if stmt.typ is not None and not self.compatible(inferred, stmt.typ):
                self.issue(
                    "error",
                    f"var {stmt.name} annotated as {format_type(stmt.typ)} but got {self.type_text(inferred)}",
                    summary,
                    code="E_TYPE_MISMATCH",
                )
            scopes[-1].bindings[stmt.name] = bound
            scopes[-1].mutability[stmt.name] = True
            summary.bindings.append(BindingInfo(name=stmt.name, type_text=self.type_text(bound), mutable=True, origin="var"))
            return
        if isinstance(stmt, ast.AssignStmt):
            target_type = self.infer_lvalue(stmt.target, scopes, fn, summary)
            value_type = self.infer_expr(stmt.value, scopes, fn, summary, expected=target_type if isinstance(target_type, ast.Type) else None)
            if not self.compatible(value_type, target_type):
                self.issue(
                    "error",
                    f"assignment {stmt.op} expects {self.type_text(target_type)} but got {self.type_text(value_type)}",
                    summary,
                )
            return
        if isinstance(stmt, ast.ExprStmt):
            self.infer_expr(stmt.expr, scopes, fn, summary, expected=None)
            return
        if isinstance(stmt, ast.ReturnStmt):
            value_type = UNIT_TYPE if stmt.expr is None else self.infer_expr(stmt.expr, scopes, fn, summary, expected=fn.return_type)
            if not self.return_compatible(value_type, fn.return_type):
                self.issue(
                    "error",
                    f"return in {fn.name} expects {format_type(fn.return_type)} but got {self.type_text(value_type)}",
                    summary,
                )
            return
        if isinstance(stmt, ast.IfStmt):
            cond_type = self.infer_expr(stmt.cond, scopes, fn, summary, expected=BOOL_TYPE)
            if not self.compatible(cond_type, BOOL_TYPE):
                self.issue("error", f"if condition must be Bool, got {self.type_text(cond_type)}", summary)
            self.elaborate_block(stmt.then_block, scopes, fn, summary)
            if stmt.else_branch is not None:
                if isinstance(stmt.else_branch, ast.Block):
                    self.elaborate_block(stmt.else_branch, scopes, fn, summary)
                else:
                    self.elaborate_stmt(stmt.else_branch, scopes, fn, summary)
            return
        if isinstance(stmt, ast.WhileStmt):
            cond_type = self.infer_expr(stmt.cond, scopes, fn, summary, expected=BOOL_TYPE)
            if not self.compatible(cond_type, BOOL_TYPE):
                self.issue("error", f"while condition must be Bool, got {self.type_text(cond_type)}", summary)
            self.elaborate_block(stmt.body, scopes, fn, summary)
            return
        if isinstance(stmt, ast.ForStmt):
            iterable_type = self.infer_expr(stmt.iterable, scopes, fn, summary, expected=None)
            elem_type = self.iterable_element_type(iterable_type)
            if isinstance(elem_type, UnknownType):
                self.issue("error", f"for iterable has non-iterable type {self.type_text(iterable_type)}", summary)
            elif not self.compatible(elem_type, stmt.typ):
                self.issue(
                    "error",
                    f"for binder {stmt.name}: {format_type(stmt.typ)} does not match iterable element type {self.type_text(elem_type)}",
                    summary,
                )
            scopes.append(Scope(bindings={stmt.name: stmt.typ}, mutability={stmt.name: False}))
            summary.bindings.append(BindingInfo(name=stmt.name, type_text=format_type(stmt.typ), mutable=False, origin="for"))
            for inner in stmt.body.statements:
                self.elaborate_stmt(inner, scopes, fn, summary)
            scopes.pop()
            return
        if isinstance(stmt, ast.DeferStmt | ast.ErrDeferStmt):
            self.elaborate_stmt(stmt.stmt, scopes, fn, summary)
            return
        if isinstance(stmt, ast.BreakStmt | ast.ContinueStmt):
            return
        raise TypeError(f"unsupported statement {type(stmt)!r}")

    def infer_lvalue(self, expr: ast.Expr, scopes: list[Scope], fn: ast.FnDecl, summary: FunctionElaboration) -> TypeLike:
        if isinstance(expr, ast.NameExpr):
            if expr.name == "_":
                return UnknownType("discard sink")
            if not self.lookup_mutable(expr.name, scopes):
                self.issue("error", f"assignment target {expr.name} is not mutable", summary)
            return self.lookup_name(expr.name, scopes)
        root_name = self.lvalue_root_name(expr)
        if root_name is not None:
            root_type = self.lookup_name(root_name, scopes)
            root_norm = self.normalize_type(root_type)
            if isinstance(root_norm, ast.GenericType) and root_norm.name == "Ref":
                return self.infer_expr(expr, scopes, fn, summary, expected=None)
            if isinstance(root_norm, ast.GenericType) and root_norm.name == "RefConst":
                self.issue("error", f"cannot assign through immutable reference {root_name}", summary)
                return self.infer_expr(expr, scopes, fn, summary, expected=None)
            if not self.lookup_mutable(root_name, scopes):
                self.issue("error", f"assignment target rooted at {root_name} is not mutable", summary)
        if isinstance(expr, ast.AttrExpr | ast.IndexExpr):
            return self.infer_expr(expr, scopes, fn, summary, expected=None)
        return self.infer_expr(expr, scopes, fn, summary, expected=None)

    def lvalue_root_name(self, expr: ast.Expr) -> str | None:
        if isinstance(expr, ast.NameExpr):
            return expr.name
        if isinstance(expr, ast.DottedExpr) and expr.parts:
            return expr.parts[0]
        if isinstance(expr, ast.AttrExpr):
            return self.lvalue_root_name(expr.obj)
        if isinstance(expr, ast.IndexExpr):
            return self.lvalue_root_name(expr.obj)
        if isinstance(expr, ast.SliceExpr):
            return self.lvalue_root_name(expr.obj)
        return None

    def infer_expr(
        self,
        expr: ast.Expr,
        scopes: list[Scope],
        fn: ast.FnDecl,
        summary: FunctionElaboration,
        expected: ast.Type | None,
    ) -> TypeLike:
        if isinstance(expr, ast.NameExpr):
            typ = self.lookup_name(expr.name, scopes)
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.DottedExpr):
            typ = self.lookup_dotted(expr.parts)
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.IntExpr):
            literal_expected = self.literal_expected_type(expected)
            typ = literal_expected if self.is_integer_type(literal_expected) else I64_TYPE
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.StringExpr):
            self.record_expr(summary, expr, STR_TYPE)
            return STR_TYPE
        if isinstance(expr, ast.BoolExpr):
            self.record_expr(summary, expr, BOOL_TYPE)
            return BOOL_TYPE
        if isinstance(expr, ast.UnitExpr):
            self.record_expr(summary, expr, UNIT_TYPE)
            return UNIT_TYPE
        if isinstance(expr, ast.NoneExpr):
            typ: TypeLike = expected if self.option_inner_type(expected) is not None else NoneLiteralType()
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.SomeExpr):
            inner_expected = self.option_inner_type(expected)
            inner = self.infer_expr(expr.value, scopes, fn, summary, expected=inner_expected)
            typ = expected if self.option_inner_type(expected) is not None else ast.GenericType("Option", [self.materialize(inner)])
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.UnaryExpr):
            inner = self.infer_expr(expr.expr, scopes, fn, summary, expected=None)
            if expr.op == "borrow":
                referent = self.materialize(self.unwrap_ref(inner))
                expected_norm = expected
                if isinstance(expected_norm, ast.GenericType) and expected_norm.name in {"Ref", "RefConst"} and expected_norm.args:
                    typ = expected_norm
                else:
                    typ = ast.GenericType("RefConst", [referent])
            elif expr.op in {"move", "copy"}:
                typ = inner
            elif expr.op == "not":
                if not self.compatible(inner, BOOL_TYPE):
                    self.issue("error", f"not expects Bool, got {self.type_text(inner)}", summary)
                typ = BOOL_TYPE
            elif expr.op == "-":
                if not self.is_integer_like(inner):
                    self.issue("error", f"unary - expects integer, got {self.type_text(inner)}", summary)
                typ = inner
            else:
                typ = UnknownType(f"unknown unary operator {expr.op}")
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.BinaryExpr):
            left = self.infer_expr(expr.left, scopes, fn, summary, expected=None)
            right = self.infer_expr(expr.right, scopes, fn, summary, expected=left if isinstance(left, ast.Type) else None)
            if expr.op in {"+", "-", "*", "/", "%"}:
                if not self.is_integer_like(left) or not self.compatible(right, left):
                    self.issue(
                        "error",
                        f"binary {expr.op} expects matching integer operands, got {self.type_text(left)} and {self.type_text(right)}",
                        summary,
                    )
                typ = left
            elif expr.op in {"<", "<=", ">", ">=", "==", "!="}:
                typ = BOOL_TYPE
            elif expr.op in {"and", "or"}:
                if not self.compatible(left, BOOL_TYPE) or not self.compatible(right, BOOL_TYPE):
                    self.issue(
                        "error",
                        f"logical {expr.op} expects Bool operands, got {self.type_text(left)} and {self.type_text(right)}",
                        summary,
                    )
                typ = BOOL_TYPE
            else:
                typ = UnknownType(f"unknown binary operator {expr.op}")
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.RangeExpr):
            start = self.infer_expr(expr.start, scopes, fn, summary, expected=None)
            stop = self.infer_expr(expr.stop, scopes, fn, summary, expected=start if isinstance(start, ast.Type) else None)
            if not self.is_integer_like(start) or not self.compatible(stop, start):
                self.issue("error", f"range expects matching integer bounds, got {self.type_text(start)} and {self.type_text(stop)}", summary)
            typ = ast.GenericType("Range", [self.materialize(start if self.is_integer_like(start) else I64_TYPE)])
            self.record_expr(summary, expr, typ, note=type(expr).__name__)
            return typ

        if isinstance(expr, ast.CallExpr):
            callee_type = self.infer_expr(expr.callee, scopes, fn, summary, expected=None)
            typ = UnknownType("unknown call return")
            if isinstance(expr.callee, ast.NameExpr) and expr.callee.name in self.functions:
                target = self.functions[expr.callee.name]
                for arg, param in zip(expr.args, target.params, strict=False):
                    self.infer_expr(arg, scopes, fn, summary, expected=param.typ)
                for arg in expr.args[len(target.params):]:
                    self.infer_expr(arg, scopes, fn, summary, expected=None)
                typ = target.return_type
                summary.calls.append(
                    CallSiteInfo(
                        callee=expr.callee.name,
                        target_kind="top_fn",
                        return_type=format_type(target.return_type),
                        effects=list(target.effects),
                        arg_ref_modes=[('mut' if isinstance(param.typ, ast.GenericType) and param.typ.name == 'Ref' else 'const' if isinstance(param.typ, ast.GenericType) and param.typ.name == 'RefConst' else None) for param in target.params],
                    )
                )
                if not set(target.effects).issubset(set(fn.effects)):
                    self.issue(
                        "error",
                        f"call to {target.name} requires effects {target.effects} not contained in caller {fn.name} effects {fn.effects}",
                        summary,
                        code="E_EFFECT_UNDER",
                    )
            else:
                for arg in expr.args:
                    self.infer_expr(arg, scopes, fn, summary, expected=None)
                callee_text = format_expr_inline(expr.callee)
                summary.calls.append(
                    CallSiteInfo(
                        callee=callee_text,
                        target_kind=self.call_target_kind(expr.callee),
                        return_type=self.type_text(typ),
                        effects=[],
                        arg_ref_modes=[None for _ in expr.args],
                    )
                )
            _ = callee_type
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.AttrExpr):
            obj_type = self.infer_expr(expr.obj, scopes, fn, summary, expected=None)
            typ = self.lookup_attr_type(obj_type, expr.name)
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.IndexExpr):
            obj_type = self.infer_expr(expr.obj, scopes, fn, summary, expected=None)
            self.infer_expr(expr.index, scopes, fn, summary, expected=U64_TYPE)
            typ = self.index_result_type(obj_type)
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.SliceExpr):
            obj_type = self.infer_expr(expr.obj, scopes, fn, summary, expected=None)
            if expr.start is not None:
                self.infer_expr(expr.start, scopes, fn, summary, expected=U64_TYPE)
            if expr.stop is not None:
                self.infer_expr(expr.stop, scopes, fn, summary, expected=U64_TYPE)
            typ = self.slice_result_type(obj_type)
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.TryExpr):
            inner = self.normalize_type(self.infer_expr(expr.expr, scopes, fn, summary, expected=None))
            declared_return = self.normalize_type(fn.return_type)
            if isinstance(inner, ast.ResultType):
                if isinstance(declared_return, ast.ResultType):
                    if not self.compatible(inner.err, declared_return.err):
                        self.issue("error", f"result propagation requires enclosing function to return a compatible result type, got {self.type_text(declared_return)}", summary)
                else:
                    self.issue("error", f"result propagation requires enclosing function to return a compatible result type, got {self.type_text(declared_return)}", summary)
                typ = inner.ok
            elif isinstance(inner, ast.OptionalType):
                if not isinstance(declared_return, ast.OptionalType):
                    self.issue("error", f"optional propagation requires enclosing function to return an optional type, got {self.type_text(declared_return)}", summary)
                typ = inner.inner
            else:
                self.issue("error", f"propagation operator expects a result or optional type, got {self.type_text(inner)}", summary)
                typ = UnknownType("try on non-propagating type")
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.CatchExpr):
            inner = self.normalize_type(self.infer_expr(expr.expr, scopes, fn, summary, expected=None))
            if isinstance(inner, ast.ResultType):
                if expr.binding is not None and expr.handler is not None:
                    err_type: ast.Type = inner.err if hasattr(inner, 'err') else ast.NamedType('_error')
                    inner_scopes = list(scopes) + [{expr.binding: err_type}]
                    for stmt in expr.handler.statements:
                        self.elaborate_stmt(stmt, inner_scopes, fn, summary)
                    typ = inner.ok
                else:
                    fallback = self.infer_expr(expr.fallback, scopes, fn, summary, expected=inner.ok)
                    if not self.compatible(fallback, inner.ok):
                        self.issue("error", f"catch fallback expects {self.type_text(inner.ok)} but got {self.type_text(fallback)}", summary)
                    typ = inner.ok
            else:
                self.issue("error", f"catch operator expects a result type, got {self.type_text(inner)}", summary)
                if expr.binding is None:
                    self.infer_expr(expr.fallback, scopes, fn, summary, expected=None)
                typ = UnknownType("catch on non-result")
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.CastExpr):
            self.infer_expr(expr.expr, scopes, fn, summary, expected=None)
            self.record_expr(summary, expr, expr.typ)
            return expr.typ
        if isinstance(expr, ast.StructLiteralExpr):
            field_types = self.lookup_record_fields(expr.name)
            for field_name, field_value in expr.fields:
                field_expected = field_types.get(field_name)
                self.infer_expr(field_value, scopes, fn, summary, expected=field_expected)
            typ = ast.NamedType(expr.name)
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.EnumLiteralExpr):
            enum_decl = self.enums.get(expr.enum_name)
            variant_fields = {f.name: f.typ for f in self.find_variant_fields(enum_decl, expr.variant_name)}
            for field_name, field_value in expr.fields:
                self.infer_expr(field_value, scopes, fn, summary, expected=variant_fields.get(field_name))
            typ = ast.NamedType(expr.enum_name)
            self.record_expr(summary, expr, typ)
            return typ
        if isinstance(expr, ast.MatchExpr):
            scrutinee_type = self.infer_expr(expr.expr, scopes, fn, summary, expected=None)
            arm_types: list[TypeLike] = []
            for arm in expr.arms:
                scopes.append(Scope())
                self.bind_pattern(arm.pattern, scrutinee_type, scopes, summary)
                arm_types.append(self.infer_expr(arm.expr, scopes, fn, summary, expected=expected))
                scopes.pop()
            typ = self.unify_arm_types(arm_types, expected)
            self.record_expr(summary, expr, typ)
            return typ
        raise TypeError(f"unsupported expression {type(expr)!r}")

    def bind_pattern(self, pattern: ast.Pattern, scrutinee: TypeLike, scopes: list[Scope], summary: FunctionElaboration) -> None:
        if isinstance(pattern, ast.WildcardPattern | ast.NonePattern | ast.ErrorPattern):
            return
        if isinstance(pattern, ast.NamePattern):
            scopes[-1].bindings[pattern.name] = scrutinee
            scopes[-1].mutability[pattern.name] = False
            summary.bindings.append(BindingInfo(name=pattern.name, type_text=self.type_text(scrutinee), mutable=False, origin="pattern"))
            return
        if isinstance(pattern, ast.LiteralPattern):
            return
        if isinstance(pattern, ast.SomePattern):
            inner = self.option_inner_type(scrutinee)
            if inner is not None:
                self.bind_pattern(pattern.inner, inner, scopes, summary)
            else:
                self.issue("error", f"some(...) pattern expects optional scrutinee, got {self.type_text(scrutinee)}", summary)
            return
        if isinstance(pattern, ast.OkPattern):
            if isinstance(scrutinee, ast.ResultType):
                self.bind_pattern(pattern.inner, scrutinee.ok, scopes, summary)
            else:
                self.issue("error", f"ok(...) pattern expects result scrutinee, got {self.type_text(scrutinee)}", summary)
            return
        if isinstance(pattern, ast.EnumPattern):
            if isinstance(scrutinee, ast.NamedType):
                enum_decl = self.enums.get(scrutinee.name)
            else:
                enum_decl = None
            parts = pattern.parts
            if enum_decl is None or not parts or parts[0] != enum_decl.name:
                self.issue("error", f"enum pattern {'.'.join(parts)} incompatible with scrutinee {self.type_text(scrutinee)}", summary)
                return
            fields = {f.name: f.typ for f in self.find_variant_fields(enum_decl, parts[1] if len(parts) > 1 else "")}
            for field_name, subpattern in pattern.fields:
                self.bind_pattern(subpattern, fields.get(field_name, UnknownType("unknown enum field")), scopes, summary)
            return
        raise TypeError(f"unsupported pattern {type(pattern)!r}")

    def unify_arm_types(self, arm_types: list[TypeLike], expected: ast.Type | None) -> TypeLike:
        if expected is not None and arm_types and all(self.return_compatible(arm, expected) for arm in arm_types):
            return expected
        if not arm_types:
            return UnknownType("empty match")
        current = arm_types[0]
        for arm in arm_types[1:]:
            if self.compatible(arm, current):
                continue
            if self.compatible(current, arm):
                current = arm
                continue
            return UnknownType("incompatible match arms")
        return current

    def lookup_name(self, name: str, scopes: list[Scope]) -> TypeLike:
        for scope in reversed(scopes):
            if name in scope.bindings:
                return scope.bindings[name]
        if name in self.const_types:
            return self.const_types[name]
        if name in self.functions:
            return UnknownType("function value")
        return UnknownType(f"unresolved name {name}")

    def lookup_mutable(self, name: str, scopes: list[Scope]) -> bool:
        for scope in reversed(scopes):
            if name in scope.mutability:
                return scope.mutability[name]
        return False

    def lookup_dotted(self, parts: list[str]) -> TypeLike:
        if len(parts) >= 2 and parts[0] in self.enums:
            enum_decl = self.enums[parts[0]]
            if any(v.name == parts[1] for v in enum_decl.variants):
                return ast.NamedType(enum_decl.name)
        if len(parts) >= 2 and parts[0] in self.error_sets:
            err_decl = self.error_sets[parts[0]]
            if parts[1] in err_decl.tags:
                return ast.NamedType(err_decl.name)
        dotted_name = '.'.join(parts)
        if parts and parts[0] in self.imports:
            return UnknownType("import member")
        if any(dotted_name == module_name or dotted_name.startswith(module_name + '.') for module_name in self.imports.values()):
            return UnknownType("import member")
        return UnknownType(f"unresolved dotted name {'.'.join(parts)}")

    def call_target_kind(self, callee: ast.Expr) -> str:
        if isinstance(callee, ast.NameExpr):
            return "unknown_name"
        if isinstance(callee, ast.DottedExpr) and callee.parts:
            dotted_name = '.'.join(callee.parts)
            if callee.parts[0] in self.imports:
                return "import_member"
            if any(dotted_name == module_name or dotted_name.startswith(module_name + '.') for module_name in self.imports.values()):
                return "import_member"
        if isinstance(callee, ast.AttrExpr):
            return "method_or_field_call"
        return "unknown"

    def lookup_attr_type(self, obj_type: TypeLike, attr: str) -> TypeLike:
        if attr == "len" and (obj_type == STR_TYPE or self.generic_name(obj_type) in {"Slice", "Array"}):
            return U64_TYPE
        if isinstance(obj_type, ast.NamedType):
            fields = self.lookup_record_fields(obj_type.name)
            if attr in fields:
                return fields[attr]
        return UnknownType(f"unknown attribute {attr}")

    def index_result_type(self, obj_type: TypeLike) -> TypeLike:
        if obj_type == STR_TYPE:
            return U8_TYPE
        if isinstance(obj_type, ast.GenericType) and obj_type.name in {"Slice", "Array"} and obj_type.args:
            arg0 = obj_type.args[0]
            if isinstance(arg0, ast.Type):
                return arg0
        return UnknownType("index on non-indexable value")

    def slice_result_type(self, obj_type: TypeLike) -> TypeLike:
        if obj_type == STR_TYPE:
            return STR_TYPE
        if isinstance(obj_type, ast.GenericType) and obj_type.name == "Slice":
            return obj_type
        if isinstance(obj_type, ast.GenericType) and obj_type.name == "Array" and obj_type.args:
            arg0 = obj_type.args[0]
            if isinstance(arg0, ast.Type):
                return ast.GenericType("Slice", [arg0])
        return UnknownType("slice on non-sliceable value")

    def iterable_element_type(self, typ: TypeLike) -> TypeLike:
        typ_norm = self.normalize_type(typ)
        if typ_norm == STR_TYPE:
            return U8_TYPE
        if isinstance(typ_norm, ast.GenericType) and typ_norm.name in {"Slice", "Array", "Range"} and typ_norm.args:
            arg0 = typ_norm.args[0]
            if isinstance(arg0, ast.Type):
                return self.normalize_type(arg0)
        return UnknownType("non-iterable")

    def lookup_record_fields(self, name: str) -> dict[str, ast.Type]:
        if name in self.structs:
            return {field.name: field.typ for field in self.structs[name].fields}
        if name in self.resources:
            return {field.name: field.typ for field in self.resources[name].fields}
        return {}

    def find_variant_fields(self, enum_decl: ast.EnumDecl | None, variant_name: str) -> list[ast.Field]:
        if enum_decl is None:
            return []
        for variant in enum_decl.variants:
            if variant.name == variant_name:
                return variant.fields
        return []

    def generic_name(self, typ: TypeLike) -> str | None:
        if isinstance(typ, ast.GenericType):
            return typ.name
        return None

    def literal_expected_type(self, typ: ast.Type | None) -> ast.Type | None:
        if typ is None:
            return None
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.ResultType):
            return typ_norm.ok
        return typ_norm

    def option_inner_type(self, typ: TypeLike | None) -> ast.Type | None:
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.OptionalType):
            return typ_norm.inner
        return None

    def is_integer_type(self, typ: ast.Type | None) -> bool:
        typ_norm = self.normalize_type(typ) if typ is not None else None
        return isinstance(typ_norm, ast.NamedType) and typ_norm.name in INTEGER_NAMES

    def is_integer_like(self, typ: TypeLike) -> bool:
        typ_norm = self.normalize_type(typ)
        return isinstance(typ_norm, ast.NamedType) and typ_norm.name in INTEGER_NAMES

    def unwrap_ref(self, typ: TypeLike | None) -> TypeLike | None:
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.GenericType) and typ_norm.name in {"Ref", "RefConst"} and typ_norm.args:
            arg0 = typ_norm.args[0]
            if isinstance(arg0, ast.Type):
                return self.normalize_type(arg0)
        return typ_norm

    def normalize_type(self, typ: TypeLike | None) -> TypeLike:
        if typ is None or isinstance(typ, (UnknownType, NoneLiteralType)):
            return typ
        if isinstance(typ, ast.OptionalType):
            return ast.OptionalType(self.materialize(self.normalize_type(typ.inner)))
        if isinstance(typ, ast.ResultType):
            return ast.ResultType(self.materialize(self.normalize_type(typ.ok)), self.materialize(self.normalize_type(typ.err)))
        if isinstance(typ, ast.GenericType):
            if typ.name == "Option" and len(typ.args) == 1 and isinstance(typ.args[0], ast.Type):
                return ast.OptionalType(self.materialize(self.normalize_type(typ.args[0])))
            args=[]
            for arg in typ.args:
                if isinstance(arg, ast.Type):
                    args.append(self.materialize(self.normalize_type(arg)))
                else:
                    args.append(arg)
            return ast.GenericType(typ.name, args)
        return typ

    def compatible(self, actual: TypeLike, expected: TypeLike) -> bool:
        if isinstance(actual, UnknownType) or isinstance(expected, UnknownType):
            return True
        if isinstance(actual, NoneLiteralType):
            return self.option_inner_type(expected) is not None
        if isinstance(expected, NoneLiteralType):
            return self.option_inner_type(actual) is not None
        return actual == expected

    def return_compatible(self, actual: TypeLike, declared: ast.Type) -> bool:
        if self.compatible(actual, declared):
            return True
        if isinstance(declared, ast.ResultType):
            return self.compatible(actual, declared.ok) or self.compatible(actual, declared.err)
        return False

    def materialize(self, typ: TypeLike) -> ast.Type:
        if isinstance(typ, ast.Type):
            return typ
        return ast.NamedType("_Unknown")

    def type_text(self, typ: TypeLike) -> str:
        if isinstance(typ, ast.Type):
            return format_type(typ)
        if isinstance(typ, NoneLiteralType):
            return "none"
        return f"<{typ.reason}>"

    def record_expr(self, summary: FunctionElaboration, expr: ast.Expr, typ: TypeLike, note: str | None = None) -> None:
        place = sem_place_for_expr(expr)
        ref_mode = None
        borrow_mode = None
        if isinstance(typ, ast.GenericType) and typ.name in {'Ref', 'RefConst'}:
            ref_mode = 'mut' if typ.name == 'Ref' else 'const'
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'borrow':
            borrow_mode = ref_mode or 'const'
            place = sem_place_for_expr(expr.expr)
        summary.expr_types.append(
            ExprTypeInfo(
                expr=format_expr_inline(expr),
                type_text=self.type_text(typ),
                note=note,
                place=place.to_path() if place is not None else None,
                ref_mode=ref_mode,
                borrow_mode=borrow_mode,
            )
        )



def elaborate_module(module: ast.Module) -> ModuleElaboration:
    return Elaborator(module).elaborate()
