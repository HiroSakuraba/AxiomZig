"""
axiomzig.diag — stable diagnostic codes for AxiomZig v1.1.

Codes are organized by phase prefix:
  E_PARSE_*    lexer / parser
  E_RESOLVE_*  name resolution
  E_TYPE_*     type checking
  E_EFFECT_*   effect checking
  E_OWN_*      ownership / borrow checking
  E_PROTO_*    protocol state checking
  E_DEFER_*    defer / errdefer restrictions
  R_TRAP_*     runtime traps (not static errors, but stable names for tests)

Every static check that the test suite covers should have a stable code here.
Prose messages may change across versions; codes must not.
"""

from __future__ import annotations


# ---------------------------------------------------------------------------
# Parse / lexer
# ---------------------------------------------------------------------------

E_PARSE_UNEXPECTED   = "E_PARSE_UNEXPECTED"    # unexpected token
E_PARSE_EXPECTED     = "E_PARSE_EXPECTED"      # expected X, got Y

# ---------------------------------------------------------------------------
# Name resolution
# ---------------------------------------------------------------------------

E_RESOLVE_SHADOW     = "E_RESOLVE_SHADOW"      # shadowing forbidden
E_RESOLVE_UNBOUND    = "E_RESOLVE_UNBOUND"     # unresolved name
E_RESOLVE_DUPLICATE  = "E_RESOLVE_DUPLICATE"   # duplicate top-level name / field / variant
E_RESOLVE_UNKNOWN_TYPE = "E_RESOLVE_UNKNOWN_TYPE"  # unknown type name

# ---------------------------------------------------------------------------
# Type checking
# ---------------------------------------------------------------------------

E_TYPE_MISMATCH      = "E_TYPE_MISMATCH"       # type does not match expected
E_TYPE_NONUNIT       = "E_TYPE_NONUNIT"        # non-Unit expression statement
E_TYPE_NO_EXHAUST    = "E_TYPE_NO_EXHAUST"     # match not exhaustive
E_TYPE_ARM_INCOMPAT  = "E_TYPE_ARM_INCOMPAT"   # match arms have incompatible types
E_TYPE_ASSIGN_CONST  = "E_TYPE_ASSIGN_CONST"   # assignment to immutable binding
E_TYPE_ASSIGN_LVALUE = "E_TYPE_ASSIGN_LVALUE"  # illegal assignment target
E_TYPE_SLICE_INDEX   = "E_TYPE_SLICE_INDEX"    # slice index type error
E_TYPE_ITER          = "E_TYPE_ITER"           # non-iterable type in for
E_TYPE_CAST          = "E_TYPE_CAST"           # invalid cast

# ---------------------------------------------------------------------------
# Effect checking
# ---------------------------------------------------------------------------

E_EFFECT_UNDER       = "E_EFFECT_UNDER"        # under-declared effect (callee needs more)
E_EFFECT_TRAP        = "E_EFFECT_TRAP"         # trap declared as an effect (not permitted)
E_EFFECT_RECURSE     = "E_EFFECT_RECURSE"      # missing recurse declaration
E_EFFECT_UNKNOWN     = "E_EFFECT_UNKNOWN"      # non-core effect tag warning

# ---------------------------------------------------------------------------
# Ownership / borrow
# ---------------------------------------------------------------------------

E_OWN_MOVED          = "E_OWN_MOVED"           # use / move of already-moved value
E_OWN_UNDISCHARGED   = "E_OWN_UNDISCHARGED"    # resource leaves scope non-terminal
E_OWN_BORROW_LIVE    = "E_OWN_BORROW_LIVE"     # operation blocked by live borrow
E_OWN_BORROW_EXCL    = "E_OWN_BORROW_EXCL"     # exclusive borrow conflict
E_OWN_BORROW_ALIAS   = "E_OWN_BORROW_ALIAS"    # aliased ref to incompatible params
E_OWN_MERGE_CONFLICT = "E_OWN_MERGE_CONFLICT"  # resource state differs at CFG join
E_OWN_ALIAS_MISSING  = "E_OWN_ALIAS_MISSING"   # ref alias has no live referent
E_OWN_IMPORT_BAD_PATH = "E_OWN_IMPORT_BAD_PATH"  # malformed imported ownership path
E_OWN_IMPORT_SUMMARY = "E_OWN_IMPORT_SUMMARY"  # malformed imported ownership summary

# ---------------------------------------------------------------------------
# Protocol state
# ---------------------------------------------------------------------------

E_PROTO_TRANSITION   = "E_PROTO_TRANSITION"    # illegal protocol transition
E_PROTO_TERMINAL     = "E_PROTO_TERMINAL"      # resource not in terminal state at scope exit

# ---------------------------------------------------------------------------
# Defer / errdefer
# ---------------------------------------------------------------------------

E_DEFER_FLOW         = "E_DEFER_FLOW"          # defer contains return/break/continue
E_DEFER_NESTED       = "E_DEFER_NESTED"        # nested defer inside defer

# ---------------------------------------------------------------------------
# Runtime traps (not static errors — used in conformance ledger)
# ---------------------------------------------------------------------------

R_TRAP_OVERFLOW      = "R_TRAP_OVERFLOW"       # integer overflow
R_TRAP_DIV_ZERO      = "R_TRAP_DIV_ZERO"       # division by zero
R_TRAP_BOUNDS        = "R_TRAP_BOUNDS"         # out-of-bounds index
R_TRAP_CAST          = "R_TRAP_CAST"           # cast value out of range
R_TRAP_IMPORT        = "R_TRAP_IMPORT"         # imported function / stub trap
