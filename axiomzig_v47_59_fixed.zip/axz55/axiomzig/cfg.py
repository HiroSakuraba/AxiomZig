from __future__ import annotations

from dataclasses import dataclass, field
import copy
from typing import Callable

from . import ast
from .formatter import format_expr_inline, format_type
from .ownership_signatures import parse_type_text
from .semantic import SemPlace, SemProjection, combine_sem_place, sem_place_for_expr, sem_place_from_path, sem_relative_place_for_expr, sem_relative_place_from_suffix
from .typecheck import Scope, TypeChecker, TypedFunction


@dataclass(frozen=True, slots=True)
class OwnershipOp:
    kind: str
    name: str | None = None
    aux_name: str | None = None
    type_name: str | None = None
    transition: str | None = None
    borrow_mode: str | None = None
    callee: str | None = None
    param_index: int | None = None
    source_name: str | None = None
    source_aux_name: str | None = None
    place: SemPlace | None = None
    aux_place: SemPlace | None = None
    source_place: SemPlace | None = None
    source_aux_place: SemPlace | None = None


@dataclass(frozen=True, slots=True)
class BorrowMark:
    path: str
    mode: str = 'const'
    place: SemPlace | None = None


@dataclass(frozen=True, slots=True)
class CleanupAction:
    text: str
    error_only: bool
    ops: tuple[OwnershipOp, ...] = ()
    alternative_ops: tuple[tuple[OwnershipOp, ...], ...] = ()


@dataclass(frozen=True, slots=True)
class RefAliasEntry:
    alias_name: str
    target_place: SemPlace
    mode: str


@dataclass(frozen=True, slots=True)
class ScopeFrame:
    cleanups: tuple[CleanupAction, ...] = ()
    bindings: tuple[tuple[str, str], ...] = ()
    borrows: tuple[BorrowMark, ...] = ()
    ref_aliases: tuple[RefAliasEntry, ...] = ()


@dataclass(frozen=True, slots=True)
class FlowState:
    node_id: int
    active_scopes: tuple[ScopeFrame, ...]


@dataclass(frozen=True, slots=True)
class RefAliasPlan:
    target_place: SemPlace
    mode: str
    source_alias: str | None = None
    transfer: bool = False
    from_borrow: bool = False


@dataclass(slots=True)
class CFGNode:
    id: int
    kind: str
    label: str
    ownership_ops: list[OwnershipOp] = field(default_factory=list)


@dataclass(slots=True)
class CFGEdge:
    src: int
    dst: int
    kind: str
    cleanup: list[str] = field(default_factory=list)
    cleanup_actions: list[CleanupAction] = field(default_factory=list)
    pre_cleanup_ops: list[OwnershipOp] = field(default_factory=list)
    post_cleanup_ops: list[OwnershipOp] = field(default_factory=list)
    pop_bindings: list[str] = field(default_factory=list)


@dataclass(slots=True)
class CFGFunction:
    name: str
    entry: int
    fallthrough_exit: int
    return_exit: int
    error_exit: int | None
    nodes: list[CFGNode]
    edges: list[CFGEdge]


@dataclass(slots=True)
class CFGModule:
    module_path: str
    functions: list[CFGFunction]


@dataclass(frozen=True, slots=True)
class LoopContext:
    break_target: int
    continue_target: int
    target_depth: int


@dataclass(frozen=True, slots=True)
class NestedMatchContext:
    match_expr: ast.MatchExpr
    replace: Callable[[ast.Expr], ast.Expr]
    prefix_safe: bool


class CFGBuilder:
    def __init__(self, module: ast.Module, imported_signatures: dict | None = None):
        self.module = module
        self._next_node_id = 0
        self._nodes: list[CFGNode] = []
        self._edges: list[CFGEdge] = []
        self._enums: dict[str, ast.EnumDecl] = {}
        self._structs: dict[str, ast.StructDecl] = {}
        self._resources: dict[str, ast.ResourceDecl] = {}
        self._functions: dict[str, ast.FnDecl] = {}
        self._import_aliases: dict[str, str] = {imp.path[-1]: ".".join(imp.path) for imp in module.imports if imp.path}
        self._imported_signatures: dict = imported_signatures or {}
        self._typechecker = TypeChecker(module, imported_signatures=self._imported_signatures)
        self._type_scopes: list[Scope] = []
        self._current_fn: ast.FnDecl | None = None
        self._type_summary: TypedFunction | None = None
        for decl in module.decls:
            if isinstance(decl, ast.EnumDecl):
                self._enums[decl.name] = decl
            elif isinstance(decl, ast.StructDecl):
                self._structs[decl.name] = decl
            elif isinstance(decl, ast.ResourceDecl):
                self._resources[decl.name] = decl
            elif isinstance(decl, ast.FnDecl):
                self._functions[decl.name] = decl

    def call_target_name(self, callee: ast.Expr) -> str | None:
        if isinstance(callee, ast.NameExpr):
            return callee.name
        if isinstance(callee, ast.DottedExpr) and callee.parts:
            if callee.parts[0] in self._import_aliases:
                suffix = '.'.join(callee.parts[1:])
                base = self._import_aliases[callee.parts[0]]
                return f'{base}.{suffix}' if suffix else base
            return '.'.join(callee.parts)
        return None

    def imported_function_signature(self, callee_name: str | None):
        if callee_name is None:
            return None
        return self._imported_signatures.get(callee_name)

    def imported_param_type(self, callee_name: str | None, param_index: int) -> ast.Type | None:
        sig = self.imported_function_signature(callee_name)
        if sig is None or param_index >= len(sig.param_types):
            return None
        return parse_type_text(sig.param_types[param_index])

    def imported_ref_param_signature(self, callee_name: str | None, param_index: int):
        if callee_name is None:
            return None
        sig = self._imported_signatures.get(callee_name)
        if sig is None:
            return None
        for item in sig.ref_params:
            if item.param_index == param_index:
                return item
        return None

    def build(self) -> CFGModule:
        functions: list[CFGFunction] = []
        for decl in self.module.decls:
            if isinstance(decl, ast.FnDecl):
                functions.append(self.build_function(decl))
        return CFGModule(module_path='.'.join(self.module.path), functions=functions)

    def build_function(self, fn: ast.FnDecl) -> CFGFunction:
        self._next_node_id = 0
        self._nodes = []
        self._edges = []
        self._current_fn = fn
        self._type_summary = TypedFunction(name=fn.name, declared_return_type=format_type(fn.return_type))
        self._type_scopes = [Scope()]
        for param in fn.params:
            self._type_scopes[-1].bindings[param.name] = param.typ
            self._type_scopes[-1].mutability[param.name] = False

        entry = self.new_node('entry', f'{fn.name}:entry')
        fallthrough_exit = self.new_node('exit', f'{fn.name}:fallthrough_exit')
        return_exit = self.new_node('exit', f'{fn.name}:return_exit')
        error_exit = self.new_node('exit', f'{fn.name}:error_exit') if isinstance(fn.return_type, ast.ResultType) else None

        initial_state = FlowState(node_id=entry, active_scopes=tuple())
        outgoing = self.compile_block(fn.body, [initial_state], error_exit=error_exit, loop_ctx=None)
        for state in outgoing:
            trimmed, cleanup, pops = self.leave_all_scopes(state.active_scopes, error_path=False)
            assert trimmed == tuple()
            self.add_edge(state.node_id, fallthrough_exit, 'fallthrough', cleanup, pop_ops=pops)

        return CFGFunction(
            name=fn.name,
            entry=entry,
            fallthrough_exit=fallthrough_exit,
            return_exit=return_exit,
            error_exit=error_exit,
            nodes=list(self._nodes),
            edges=list(self._edges),
        )

    def compile_block(
        self,
        block: ast.Block,
        incoming: list[FlowState],
        error_exit: int | None,
        loop_ctx: LoopContext | None,
    ) -> list[FlowState]:
        self._type_scopes.append(Scope())
        try:
            current = [FlowState(node_id=s.node_id, active_scopes=self.enter_scope(s.active_scopes)) for s in incoming]
            for stmt in block.statements:
                current = self.compile_stmt(stmt, current, error_exit=error_exit, loop_ctx=loop_ctx)
                if not current:
                    break
            return current
        finally:
            self._type_scopes.pop()

    def compile_stmt(
        self,
        stmt: ast.Stmt,
        incoming: list[FlowState],
        error_exit: int | None,
        loop_ctx: LoopContext | None,
    ) -> list[FlowState]:
        if not incoming:
            return []
        if isinstance(stmt, ast.Block):
            outgoing = self.compile_block(stmt, incoming, error_exit=error_exit, loop_ctx=loop_ctx)
            result: list[FlowState] = []
            for state in outgoing:
                trimmed, cleanup, pops = self.leave_one_scope(state.active_scopes, error_path=False)
                anchor = self.new_node('scope_exit', 'block:exit')
                self.add_edge(state.node_id, anchor, 'scope_exit', cleanup, pop_ops=pops)
                result.append(FlowState(node_id=anchor, active_scopes=trimmed))
            return result
        if isinstance(stmt, ast.LetStmt):
            if isinstance(stmt.value, ast.MatchExpr):
                return self.compile_match_binding_stmt(stmt, incoming, error_exit, loop_ctx)
            bound_type = self.infer_bound_type(stmt.value, stmt.typ)
            nested = self.find_rebuildable_nested_match(stmt.value, incoming, bound_type)
            if nested is not None and nested.prefix_safe:
                return self.compile_nested_match_binding_stmt(stmt, nested, incoming, error_exit, loop_ctx)
            result = self.simple_stmt_node('let', f'let {stmt.name}', stmt.value, incoming, error_exit, self.ownership_ops_for_stmt(stmt, incoming, inferred_type=bound_type))
            result = self.add_borrows_to_states(result, self.borrow_marks_in_expr(stmt.value, incoming, bound_type))
            self._type_scopes[-1].bindings[stmt.name] = bound_type
            self._type_scopes[-1].mutability[stmt.name] = False
            result = self.bind_states_for_type(stmt.name, bound_type, result)
            return self.bind_ref_alias_for_type(stmt.name, bound_type, stmt.value, result, source_states=incoming)
        if isinstance(stmt, ast.VarStmt):
            if isinstance(stmt.value, ast.MatchExpr):
                return self.compile_match_binding_stmt(stmt, incoming, error_exit, loop_ctx)
            bound_type = self.infer_bound_type(stmt.value, stmt.typ)
            nested = self.find_rebuildable_nested_match(stmt.value, incoming, bound_type)
            if nested is not None and nested.prefix_safe:
                return self.compile_nested_match_binding_stmt(stmt, nested, incoming, error_exit, loop_ctx)
            result = self.simple_stmt_node('var', f'var {stmt.name}', stmt.value, incoming, error_exit, self.ownership_ops_for_stmt(stmt, incoming, inferred_type=bound_type))
            result = self.add_borrows_to_states(result, self.borrow_marks_in_expr(stmt.value, incoming, bound_type))
            self._type_scopes[-1].bindings[stmt.name] = bound_type
            self._type_scopes[-1].mutability[stmt.name] = True
            result = self.bind_states_for_type(stmt.name, bound_type, result)
            return self.bind_ref_alias_for_type(stmt.name, bound_type, stmt.value, result, source_states=incoming)
        if isinstance(stmt, ast.AssignStmt):
            if isinstance(stmt.value, ast.MatchExpr):
                return self.compile_match_assignment_stmt(stmt, incoming, error_exit, loop_ctx)
            nested = self.find_rebuildable_nested_match(stmt.value, incoming)
            if nested is not None and nested.prefix_safe:
                return self.compile_nested_match_assignment_stmt(stmt, nested, incoming, error_exit, loop_ctx)
            expr = ast.BinaryExpr(stmt.target, stmt.op, stmt.value)
            result = self.simple_stmt_node('assign', f'{format_expr_inline(stmt.target)} {stmt.op} ...', expr, incoming, error_exit, self.ownership_ops_for_stmt(stmt, incoming))
            result = self.add_borrows_to_states(result, self.borrow_marks_in_expr(stmt.target, incoming) + self.borrow_marks_in_expr(stmt.value, incoming))
            return self.rebind_ref_alias_on_assignment(stmt.target, stmt.value, result, source_states=incoming)
        if isinstance(stmt, ast.ExprStmt):
            if isinstance(stmt.expr, ast.MatchExpr):
                return self.compile_expr_flow(stmt.expr, incoming, error_exit, label=format_expr_inline(stmt.expr))
            nested = self.find_rebuildable_nested_match(stmt.expr, incoming)
            if nested is not None and nested.prefix_safe:
                return self.compile_expr_flow(stmt.expr, incoming, error_exit, label=format_expr_inline(stmt.expr))
            result = self.simple_stmt_node('expr', format_expr_inline(stmt.expr), stmt.expr, incoming, error_exit, self.ownership_ops_for_stmt(stmt, incoming))
            return self.add_borrows_to_states(result, self.borrow_marks_in_expr(stmt.expr, incoming))
        if isinstance(stmt, ast.DeferStmt | ast.ErrDeferStmt):
            action = self.cleanup_action_for_stmt(
                stmt.stmt,
                incoming,
                error_only=isinstance(stmt, ast.ErrDeferStmt),
            )
            node = self.new_node('defer', ('errdefer ' if isinstance(stmt, ast.ErrDeferStmt) else 'defer ') + self.stmt_text(stmt.stmt))
            result: list[FlowState] = []
            for state in incoming:
                self.add_edge(state.node_id, node, 'next')
                result.append(
                    FlowState(
                        node_id=node,
                        active_scopes=self.add_cleanup(state.active_scopes, action),
                    )
                )
            return result
        if isinstance(stmt, ast.ReturnStmt):
            if isinstance(stmt.expr, ast.MatchExpr):
                return self.compile_match_return_stmt(stmt, incoming, error_exit)
            if stmt.expr is not None:
                nested = self.find_rebuildable_nested_match(stmt.expr, incoming)
                if nested is not None and nested.prefix_safe:
                    return self.compile_nested_match_return_stmt(stmt, nested, incoming, error_exit)
            ops = self.ownership_ops_for_stmt(stmt, incoming)
            node = self.new_node('return', 'return ' + (format_expr_inline(stmt.expr) if stmt.expr is not None else 'unit'), ops=ops)
            for state in incoming:
                self.add_edge(state.node_id, node, 'next')
                self.add_propagation_edges(node, stmt.expr, error_exit, state.active_scopes)
                if self.is_error_return(stmt.expr) and error_exit is not None:
                    _, cleanup, pops = self.leave_all_scopes(state.active_scopes, error_path=True)
                    self.add_edge(node, error_exit, 'return_error', cleanup, pop_ops=pops)
                else:
                    _, cleanup, pops = self.leave_all_scopes(state.active_scopes, error_path=False)
                    target = self.find_exit('return_exit')
                    self.add_edge(node, target, 'return', cleanup, pop_ops=pops)
            return []
        if isinstance(stmt, ast.IfStmt):
            cond_states: list[FlowState]
            cond_nested = None if isinstance(stmt.cond, ast.MatchExpr) else self.find_rebuildable_nested_match(stmt.cond, incoming)
            if isinstance(stmt.cond, ast.MatchExpr) or (cond_nested is not None and cond_nested.prefix_safe):
                cond_states = self.compile_expr_flow(stmt.cond, incoming, error_exit, label=f'if cond {format_expr_inline(stmt.cond)}')
                node = self.new_node('branch', f'if {format_expr_inline(stmt.cond)}')
                for state in cond_states:
                    self.add_edge(state.node_id, node, 'next')
                then_anchor = self.new_node('branch_entry', 'if:true')
                else_anchor = self.new_node('branch_entry', 'if:false')
                then_states = [FlowState(node_id=then_anchor, active_scopes=s.active_scopes) for s in cond_states]
                else_states = [FlowState(node_id=else_anchor, active_scopes=s.active_scopes) for s in cond_states]
            else:
                node = self.new_node('branch', f'if {format_expr_inline(stmt.cond)}', ops=self.expr_ownership_ops(stmt.cond, incoming))
                for state in incoming:
                    self.add_edge(state.node_id, node, 'next')
                    self.add_propagation_edges(node, stmt.cond, error_exit, state.active_scopes)
                borrowed = self.borrow_marks_in_expr(stmt.cond, incoming)
                then_anchor = self.new_node('branch_entry', 'if:true')
                else_anchor = self.new_node('branch_entry', 'if:false')
                then_states = [FlowState(node_id=then_anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
                else_states = [FlowState(node_id=else_anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for state in then_states:
                self.add_edge(node, state.node_id, 'true')
            for state in else_states:
                self.add_edge(node, state.node_id, 'false')
            then_out = self.compile_block(stmt.then_block, then_states, error_exit=error_exit, loop_ctx=loop_ctx)
            then_norm = self.exit_block_normally(then_out, label='if:true:exit')
            if stmt.else_branch is None:
                else_scoped = [FlowState(node_id=s.node_id, active_scopes=self.enter_scope(s.active_scopes)) for s in else_states]
                else_norm = self.exit_block_normally(else_scoped, label='if:false:empty')
            elif isinstance(stmt.else_branch, ast.Block):
                else_out = self.compile_block(stmt.else_branch, else_states, error_exit=error_exit, loop_ctx=loop_ctx)
                else_norm = self.exit_block_normally(else_out, label='if:false:exit')
            else:
                else_out = self.compile_stmt(stmt.else_branch, else_states, error_exit=error_exit, loop_ctx=loop_ctx)
                else_norm = else_out
            join = self.new_node('join', 'if:join')
            result: list[FlowState] = []
            for state in then_norm + else_norm:
                self.add_edge(state.node_id, join, 'join')
                result.append(FlowState(node_id=join, active_scopes=state.active_scopes))
            return result or []
        if isinstance(stmt, ast.WhileStmt):
            cond_states: list[FlowState]
            cond_entry = self.new_node('loop_entry', f'while:cond_entry {format_expr_inline(stmt.cond)}')
            for state in incoming:
                self.add_edge(state.node_id, cond_entry, 'next')
            cond_input = [FlowState(node_id=cond_entry, active_scopes=s.active_scopes) for s in incoming]
            cond_nested = None if isinstance(stmt.cond, ast.MatchExpr) else self.find_rebuildable_nested_match(stmt.cond, incoming)
            if isinstance(stmt.cond, ast.MatchExpr) or (cond_nested is not None and cond_nested.prefix_safe):
                cond_states = self.compile_expr_flow(stmt.cond, cond_input, error_exit, label=f'while cond {format_expr_inline(stmt.cond)}')
                cond = self.new_node('loop_test', f'while {format_expr_inline(stmt.cond)}')
                for state in cond_states:
                    self.add_edge(state.node_id, cond, 'next')
                body_anchor = self.new_node('branch_entry', 'while:body')
                body_states = [FlowState(node_id=body_anchor, active_scopes=s.active_scopes) for s in cond_states]
                after_states = [FlowState(node_id=cond, active_scopes=s.active_scopes) for s in cond_states]
            else:
                cond = self.new_node('loop_test', f'while {format_expr_inline(stmt.cond)}', ops=self.expr_ownership_ops(stmt.cond, cond_input))
                for state in cond_input:
                    self.add_edge(state.node_id, cond, 'next')
                    self.add_propagation_edges(cond, stmt.cond, error_exit, state.active_scopes)
                borrowed = self.borrow_marks_in_expr(stmt.cond, cond_input)
                body_anchor = self.new_node('branch_entry', 'while:body')
                body_states = [FlowState(node_id=body_anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in cond_input]
                after_states = [FlowState(node_id=cond, active_scopes=s.active_scopes) for s in cond_input]
            after = self.new_node('join', 'while:after')
            for _ in body_states:
                self.add_edge(cond, body_anchor, 'true')
            for state in after_states:
                self.add_edge(cond, after, 'false')
            outer_depth = len(incoming[0].active_scopes)
            body_out = self.compile_block(
                stmt.body,
                body_states,
                error_exit=error_exit,
                loop_ctx=LoopContext(break_target=after, continue_target=cond_entry, target_depth=outer_depth),
            )
            body_norm = self.exit_block_normally(body_out, label='while:body_exit')
            for state in body_norm:
                self.add_edge(state.node_id, cond_entry, 'loop')
            return [FlowState(node_id=after, active_scopes=s.active_scopes) for s in after_states]
        if isinstance(stmt, ast.ForStmt):
            iterable_type = self.infer_expr_type(stmt.iterable)
            iter_entry = self.new_node('loop_test', 'for:iter_entry')
            for state in incoming:
                self.add_edge(state.node_id, iter_entry, 'next')
            iter_input = [FlowState(node_id=iter_entry, active_scopes=s.active_scopes) for s in incoming]
            iter_nested = None if isinstance(stmt.iterable, ast.MatchExpr) else self.find_rebuildable_nested_match(stmt.iterable, iter_input, iterable_type)
            if isinstance(stmt.iterable, ast.MatchExpr) or (iter_nested is not None and iter_nested.prefix_safe):
                iter_states = self.compile_expr_flow(
                    stmt.iterable,
                    iter_input,
                    error_exit,
                    label=f'for iter {format_expr_inline(stmt.iterable)}',
                    expected_type=iterable_type,
                )
                loop_head = self.new_node('loop_test', f'for {stmt.name} in {format_expr_inline(stmt.iterable)}')
                for state in iter_states:
                    self.add_edge(state.node_id, loop_head, 'next')
                body_anchor = self.new_node('branch_entry', 'for:body')
                for _ in iter_states:
                    self.add_edge(loop_head, body_anchor, 'iterate')
                after = self.new_node('join', 'for:after')
                for _ in iter_states:
                    self.add_edge(loop_head, after, 'done')
                body_states = [FlowState(node_id=body_anchor, active_scopes=s.active_scopes) for s in iter_states]
                after_states = [FlowState(node_id=after, active_scopes=s.active_scopes) for s in iter_states]
            else:
                loop_head = self.new_node('loop_test', f'for {stmt.name} in {format_expr_inline(stmt.iterable)}', ops=self.expr_ownership_ops(stmt.iterable, incoming))
                after = self.new_node('join', 'for:after')
                for state in incoming:
                    self.add_edge(state.node_id, loop_head, 'next')
                    self.add_propagation_edges(loop_head, stmt.iterable, error_exit, state.active_scopes)
                body_anchor = self.new_node('branch_entry', 'for:body')
                for _ in incoming:
                    self.add_edge(loop_head, body_anchor, 'iterate')
                self.add_edge(loop_head, after, 'done')
                body_states = [FlowState(node_id=body_anchor, active_scopes=s.active_scopes) for s in incoming]
                after_states = [FlowState(node_id=after, active_scopes=s.active_scopes) for s in incoming]
            outer_depth = len(incoming[0].active_scopes)
            self._type_scopes.append(Scope(bindings={stmt.name: stmt.typ}, mutability={stmt.name: False}))
            try:
                body_out = self.compile_block(
                    stmt.body,
                    body_states,
                    error_exit=error_exit,
                    loop_ctx=LoopContext(break_target=after, continue_target=iter_entry, target_depth=outer_depth),
                )
            finally:
                self._type_scopes.pop()
            body_norm = self.exit_block_normally(body_out, label='for:body_exit')
            for state in body_norm:
                self.add_edge(state.node_id, iter_entry, 'loop')
            return [FlowState(node_id=after, active_scopes=s.active_scopes) for s in after_states]
        if isinstance(stmt, ast.BreakStmt):
            if loop_ctx is None:
                node = self.new_node('invalid_break', 'break')
                for state in incoming:
                    self.add_edge(state.node_id, node, 'next')
                return []
            node = self.new_node('break', 'break')
            for state in incoming:
                self.add_edge(state.node_id, node, 'next')
                _, cleanup, pops = self.leave_to_depth(state.active_scopes, loop_ctx.target_depth, error_path=False)
                self.add_edge(node, loop_ctx.break_target, 'break', cleanup, pop_ops=pops)
            return []
        if isinstance(stmt, ast.ContinueStmt):
            if loop_ctx is None:
                node = self.new_node('invalid_continue', 'continue')
                for state in incoming:
                    self.add_edge(state.node_id, node, 'next')
                return []
            node = self.new_node('continue', 'continue')
            for state in incoming:
                self.add_edge(state.node_id, node, 'next')
                _, cleanup, pops = self.leave_to_depth(state.active_scopes, loop_ctx.target_depth, error_path=False)
                self.add_edge(node, loop_ctx.continue_target, 'continue', cleanup, pop_ops=pops)
            return []
        raise TypeError(f'unsupported statement {type(stmt)!r}')


    def compile_expr_flow(
        self,
        expr: ast.Expr,
        incoming: list[FlowState],
        error_exit: int | None,
        label: str,
        expected_type: ast.Type | None = None,
    ) -> list[FlowState]:
        if isinstance(expr, ast.MatchExpr):
            return self.compile_match_expr_flow(expr, incoming, error_exit, label=label, expected_type=expected_type)
        nested = self.find_rebuildable_nested_match(expr, incoming, expected_type)
        if nested is not None and nested.prefix_safe:
            return self.compile_nested_match_expr_flow(nested, incoming, error_exit, label=label, expected_type=expected_type)
        result = self.simple_stmt_node('expr', label, expr, incoming, error_exit, self.expr_ownership_ops(expr, incoming, expected_type))
        return self.add_borrows_to_states(result, self.borrow_marks_in_expr(expr, incoming, expected_type))

    def expr_is_cfg_prefix_safe(self, expr: ast.Expr, states: list[FlowState], expected_type: ast.Type | None = None) -> bool:
        if isinstance(expr, ast.NameExpr) and expr.name in self._functions:
            return True
        if isinstance(expr, ast.DottedExpr) and self.call_target_name(expr) is not None:
            return True
        return (
            not self.expr_ownership_ops(expr, states, expected_type)
            and not self.borrow_marks_in_expr(expr, states, expected_type)
            and not self.propagation_kinds(expr)
        )

    def rebuild_nested_match_context(
        self,
        expr: ast.Expr,
        states: list[FlowState],
        expected_type: ast.Type | None = None,
    ) -> NestedMatchContext | None:
        if isinstance(expr, ast.MatchExpr):
            return NestedMatchContext(match_expr=expr, replace=lambda new_expr: new_expr, prefix_safe=True)
        if isinstance(expr, ast.SomeExpr):
            inner = self.rebuild_nested_match_context(expr.value, states)
            if inner is None:
                return None
            return NestedMatchContext(
                match_expr=inner.match_expr,
                replace=lambda new_expr, inner=inner: ast.SomeExpr(inner.replace(new_expr)),
                prefix_safe=inner.prefix_safe,
            )
        if isinstance(expr, ast.UnaryExpr):
            inner_expected = expected_type if expr.op == 'borrow' else None
            inner = self.rebuild_nested_match_context(expr.expr, states, inner_expected)
            if inner is None:
                return None
            return NestedMatchContext(
                match_expr=inner.match_expr,
                replace=lambda new_expr, expr=expr, inner=inner: ast.UnaryExpr(expr.op, inner.replace(new_expr)),
                prefix_safe=inner.prefix_safe,
            )
        if isinstance(expr, ast.BinaryExpr):
            left = self.rebuild_nested_match_context(expr.left, states)
            if left is not None:
                return NestedMatchContext(
                    match_expr=left.match_expr,
                    replace=lambda new_expr, expr=expr, left=left: ast.BinaryExpr(left.replace(new_expr), expr.op, expr.right),
                    prefix_safe=left.prefix_safe,
                )
            right = self.rebuild_nested_match_context(expr.right, states)
            if right is not None:
                return NestedMatchContext(
                    match_expr=right.match_expr,
                    replace=lambda new_expr, expr=expr, right=right: ast.BinaryExpr(expr.left, expr.op, right.replace(new_expr)),
                    prefix_safe=self.expr_is_cfg_prefix_safe(expr.left, states) and right.prefix_safe,
                )
            return None
        if isinstance(expr, ast.RangeExpr):
            start = self.rebuild_nested_match_context(expr.start, states)
            if start is not None:
                return NestedMatchContext(
                    match_expr=start.match_expr,
                    replace=lambda new_expr, expr=expr, start=start: ast.RangeExpr(start.replace(new_expr), expr.stop),
                    prefix_safe=start.prefix_safe,
                )
            stop = self.rebuild_nested_match_context(expr.stop, states)
            if stop is not None:
                return NestedMatchContext(
                    match_expr=stop.match_expr,
                    replace=lambda new_expr, expr=expr, stop=stop: ast.RangeExpr(expr.start, stop.replace(new_expr)),
                    prefix_safe=self.expr_is_cfg_prefix_safe(expr.start, states) and stop.prefix_safe,
                )
            return None
        if isinstance(expr, ast.CallExpr):
            callee = self.rebuild_nested_match_context(expr.callee, states)
            if callee is not None:
                return NestedMatchContext(
                    match_expr=callee.match_expr,
                    replace=lambda new_expr, expr=expr, callee=callee: ast.CallExpr(callee.replace(new_expr), list(expr.args)),
                    prefix_safe=callee.prefix_safe,
                )
            safe_prefix = self.expr_is_cfg_prefix_safe(expr.callee, states)
            target = self._functions.get(expr.callee.name) if isinstance(expr.callee, ast.NameExpr) else None
            for idx, arg in enumerate(expr.args):
                arg_expected = target.params[idx].typ if target is not None and idx < len(target.params) else None
                nested = self.rebuild_nested_match_context(arg, states, arg_expected)
                if nested is None:
                    safe_prefix = safe_prefix and self.expr_is_cfg_prefix_safe(arg, states, arg_expected)
                    continue
                return NestedMatchContext(
                    match_expr=nested.match_expr,
                    replace=lambda new_expr, expr=expr, idx=idx, nested=nested: ast.CallExpr(
                        expr.callee,
                        [nested.replace(new_expr) if j == idx else arg for j, arg in enumerate(expr.args)],
                    ),
                    prefix_safe=safe_prefix and nested.prefix_safe,
                )
            return None
        if isinstance(expr, ast.AttrExpr):
            inner = self.rebuild_nested_match_context(expr.obj, states)
            if inner is None:
                return None
            return NestedMatchContext(
                match_expr=inner.match_expr,
                replace=lambda new_expr, expr=expr, inner=inner: ast.AttrExpr(inner.replace(new_expr), expr.name),
                prefix_safe=inner.prefix_safe,
            )
        if isinstance(expr, ast.IndexExpr):
            obj = self.rebuild_nested_match_context(expr.obj, states)
            if obj is not None:
                return NestedMatchContext(
                    match_expr=obj.match_expr,
                    replace=lambda new_expr, expr=expr, obj=obj: ast.IndexExpr(obj.replace(new_expr), expr.index),
                    prefix_safe=obj.prefix_safe,
                )
            index = self.rebuild_nested_match_context(expr.index, states)
            if index is not None:
                return NestedMatchContext(
                    match_expr=index.match_expr,
                    replace=lambda new_expr, expr=expr, index=index: ast.IndexExpr(expr.obj, index.replace(new_expr)),
                    prefix_safe=self.expr_is_cfg_prefix_safe(expr.obj, states) and index.prefix_safe,
                )
            return None
        if isinstance(expr, ast.SliceExpr):
            obj = self.rebuild_nested_match_context(expr.obj, states)
            if obj is not None:
                return NestedMatchContext(
                    match_expr=obj.match_expr,
                    replace=lambda new_expr, expr=expr, obj=obj: ast.SliceExpr(obj.replace(new_expr), expr.start, expr.stop),
                    prefix_safe=obj.prefix_safe,
                )
            safe_prefix = self.expr_is_cfg_prefix_safe(expr.obj, states)
            if expr.start is not None:
                start = self.rebuild_nested_match_context(expr.start, states)
                if start is not None:
                    return NestedMatchContext(
                        match_expr=start.match_expr,
                        replace=lambda new_expr, expr=expr, start=start: ast.SliceExpr(expr.obj, start.replace(new_expr), expr.stop),
                        prefix_safe=safe_prefix and start.prefix_safe,
                    )
                safe_prefix = safe_prefix and self.expr_is_cfg_prefix_safe(expr.start, states)
            if expr.stop is not None:
                stop = self.rebuild_nested_match_context(expr.stop, states)
                if stop is not None:
                    return NestedMatchContext(
                        match_expr=stop.match_expr,
                        replace=lambda new_expr, expr=expr, stop=stop: ast.SliceExpr(expr.obj, expr.start, stop.replace(new_expr)),
                        prefix_safe=safe_prefix and stop.prefix_safe,
                    )
            return None
        if isinstance(expr, ast.TryExpr):
            inner = self.rebuild_nested_match_context(expr.expr, states)
            if inner is None:
                return None
            return NestedMatchContext(
                match_expr=inner.match_expr,
                replace=lambda new_expr, inner=inner: ast.TryExpr(inner.replace(new_expr)),
                prefix_safe=inner.prefix_safe,
            )
        if isinstance(expr, ast.CatchExpr):
            inner = self.rebuild_nested_match_context(expr.expr, states)
            if inner is not None:
                return NestedMatchContext(
                    match_expr=inner.match_expr,
                    replace=lambda new_expr, expr=expr, inner=inner: ast.CatchExpr(inner.replace(new_expr), expr.fallback),
                    prefix_safe=inner.prefix_safe,
                )
            fallback = self.rebuild_nested_match_context(expr.fallback, states)
            if fallback is not None:
                return NestedMatchContext(
                    match_expr=fallback.match_expr,
                    replace=lambda new_expr, expr=expr, fallback=fallback: ast.CatchExpr(expr.expr, fallback.replace(new_expr)),
                    prefix_safe=self.expr_is_cfg_prefix_safe(expr.expr, states) and fallback.prefix_safe,
                )
            return None
        if isinstance(expr, ast.CastExpr):
            inner = self.rebuild_nested_match_context(expr.expr, states)
            if inner is None:
                return None
            return NestedMatchContext(
                match_expr=inner.match_expr,
                replace=lambda new_expr, expr=expr, inner=inner: ast.CastExpr(expr.typ, inner.replace(new_expr)),
                prefix_safe=inner.prefix_safe,
            )
        if isinstance(expr, ast.StructLiteralExpr):
            safe_prefix = True
            for idx, (_, value) in enumerate(expr.fields):
                nested = self.rebuild_nested_match_context(value, states)
                if nested is None:
                    safe_prefix = safe_prefix and self.expr_is_cfg_prefix_safe(value, states)
                    continue
                return NestedMatchContext(
                    match_expr=nested.match_expr,
                    replace=lambda new_expr, expr=expr, idx=idx, nested=nested: ast.StructLiteralExpr(
                        expr.name,
                        [(field_name, nested.replace(new_expr) if j == idx else field_value) for j, (field_name, field_value) in enumerate(expr.fields)],
                    ),
                    prefix_safe=safe_prefix and nested.prefix_safe,
                )
            return None
        if isinstance(expr, ast.EnumLiteralExpr):
            safe_prefix = True
            for idx, (_, value) in enumerate(expr.fields):
                nested = self.rebuild_nested_match_context(value, states)
                if nested is None:
                    safe_prefix = safe_prefix and self.expr_is_cfg_prefix_safe(value, states)
                    continue
                return NestedMatchContext(
                    match_expr=nested.match_expr,
                    replace=lambda new_expr, expr=expr, idx=idx, nested=nested: ast.EnumLiteralExpr(
                        expr.enum_name,
                        expr.variant_name,
                        [(field_name, nested.replace(new_expr) if j == idx else field_value) for j, (field_name, field_value) in enumerate(expr.fields)],
                    ),
                    prefix_safe=safe_prefix and nested.prefix_safe,
                )
            return None
        return None

    def find_rebuildable_nested_match(
        self,
        expr: ast.Expr,
        states: list[FlowState],
        expected_type: ast.Type | None = None,
    ) -> NestedMatchContext | None:
        nested = self.rebuild_nested_match_context(expr, states, expected_type)
        if nested is None or isinstance(expr, ast.MatchExpr):
            return None
        return nested

    def compile_nested_match_expr_flow(
        self,
        nested: NestedMatchContext,
        incoming: list[FlowState],
        error_exit: int | None,
        label: str,
        expected_type: ast.Type | None = None,
    ) -> list[FlowState]:
        expr = nested.match_expr
        node = self.new_node('branch', f'match {format_expr_inline(expr.expr)}', ops=self.expr_ownership_ops(expr.expr, incoming))
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr.expr, error_exit, state.active_scopes)
        borrowed = self.borrow_marks_in_expr(expr.expr, incoming)
        scrutinee_type = self.infer_expr_type(expr.expr)
        join = self.new_node('join', f'{label}:nested_match_join')
        result: list[FlowState] = []
        for idx, arm in enumerate(expr.arms):
            anchor = self.new_node('branch_entry', f'nested_match:arm:{idx}')
            arm_states = [FlowState(node_id=anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for _ in incoming:
                self.add_edge(node, anchor, f'arm:{idx}')
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                rebuilt_expr = nested.replace(arm.expr)
                arm_out = self.compile_expr_flow(rebuilt_expr, arm_states, error_exit, label=f'{label}:arm:{idx}', expected_type=expected_type)
            finally:
                self._type_scopes.pop()
            for state in arm_out:
                self.add_edge(state.node_id, join, 'join')
                result.append(FlowState(node_id=join, active_scopes=state.active_scopes))
        return result

    def bind_match_arm_pattern(self, pattern: ast.Pattern, scrutinee_type: ast.Type) -> None:
        self._type_scopes.append(Scope())
        assert self._type_summary is not None
        self._typechecker.bind_pattern(pattern, scrutinee_type, self._type_scopes, self._type_summary)

    def compile_match_expr_flow(
        self,
        expr: ast.MatchExpr,
        incoming: list[FlowState],
        error_exit: int | None,
        label: str,
        expected_type: ast.Type | None = None,
    ) -> list[FlowState]:
        node = self.new_node('branch', f'match {format_expr_inline(expr.expr)}', ops=self.expr_ownership_ops(expr.expr, incoming))
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr.expr, error_exit, state.active_scopes)
        borrowed = self.borrow_marks_in_expr(expr.expr, incoming)
        scrutinee_type = self.infer_expr_type(expr.expr)
        join = self.new_node('join', f'{label}:match_join')
        result: list[FlowState] = []
        for idx, arm in enumerate(expr.arms):
            anchor = self.new_node('branch_entry', f'match:arm:{idx}')
            arm_states = [FlowState(node_id=anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for _ in incoming:
                self.add_edge(node, anchor, f'arm:{idx}')
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                arm_out = self.compile_expr_flow(arm.expr, arm_states, error_exit, label=f'match:arm:{idx}', expected_type=expected_type)
            finally:
                self._type_scopes.pop()
            for state in arm_out:
                self.add_edge(state.node_id, join, 'join')
                result.append(FlowState(node_id=join, active_scopes=state.active_scopes))
        return result


    def compile_match_binding_stmt(
        self,
        stmt: ast.LetStmt | ast.VarStmt,
        incoming: list[FlowState],
        error_exit: int | None,
        loop_ctx: LoopContext | None,
    ) -> list[FlowState]:
        expr = stmt.value
        assert isinstance(expr, ast.MatchExpr)
        node = self.new_node('branch', f'match {format_expr_inline(expr.expr)}', ops=self.expr_ownership_ops(expr.expr, incoming))
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr.expr, error_exit, state.active_scopes)
        borrowed = self.borrow_marks_in_expr(expr.expr, incoming)
        scrutinee_type = self.infer_expr_type(expr.expr)
        join = self.new_node('join', f'{stmt.name}:match_bind_join')
        result: list[FlowState] = []
        bound_type = self.infer_bound_type(stmt.value, stmt.typ)
        for idx, arm in enumerate(expr.arms):
            anchor = self.new_node('branch_entry', f'match:arm:{idx}')
            arm_states = [FlowState(node_id=anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for _ in incoming:
                self.add_edge(node, anchor, f'arm:{idx}')
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                arm_stmt = ast.LetStmt(stmt.name, stmt.typ, arm.expr) if isinstance(stmt, ast.LetStmt) else ast.VarStmt(stmt.name, stmt.typ, arm.expr)
                arm_out = self.compile_stmt(arm_stmt, arm_states, error_exit=error_exit, loop_ctx=loop_ctx)
            finally:
                self._type_scopes.pop()
            for state in arm_out:
                self.add_edge(state.node_id, join, 'join')
                result.append(FlowState(node_id=join, active_scopes=state.active_scopes))
        self._type_scopes[-1].bindings[stmt.name] = bound_type
        self._type_scopes[-1].mutability[stmt.name] = isinstance(stmt, ast.VarStmt)
        return result

    def compile_nested_match_binding_stmt(
        self,
        stmt: ast.LetStmt | ast.VarStmt,
        nested: NestedMatchContext,
        incoming: list[FlowState],
        error_exit: int | None,
        loop_ctx: LoopContext | None,
    ) -> list[FlowState]:
        expr = nested.match_expr
        node = self.new_node('branch', f'match {format_expr_inline(expr.expr)}', ops=self.expr_ownership_ops(expr.expr, incoming))
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr.expr, error_exit, state.active_scopes)
        borrowed = self.borrow_marks_in_expr(expr.expr, incoming)
        scrutinee_type = self.infer_expr_type(expr.expr)
        join = self.new_node('join', f'{stmt.name}:nested_match_bind_join')
        result: list[FlowState] = []
        bound_type = self.infer_bound_type(stmt.value, stmt.typ)
        for idx, arm in enumerate(expr.arms):
            anchor = self.new_node('branch_entry', f'nested_match:arm:{idx}')
            arm_states = [FlowState(node_id=anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for _ in incoming:
                self.add_edge(node, anchor, f'arm:{idx}')
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                rebuilt_stmt = ast.LetStmt(stmt.name, stmt.typ, nested.replace(arm.expr)) if isinstance(stmt, ast.LetStmt) else ast.VarStmt(stmt.name, stmt.typ, nested.replace(arm.expr))
                arm_out = self.compile_stmt(rebuilt_stmt, arm_states, error_exit=error_exit, loop_ctx=loop_ctx)
            finally:
                self._type_scopes.pop()
            for state in arm_out:
                self.add_edge(state.node_id, join, 'join')
                result.append(FlowState(node_id=join, active_scopes=state.active_scopes))
        self._type_scopes[-1].bindings[stmt.name] = bound_type
        self._type_scopes[-1].mutability[stmt.name] = isinstance(stmt, ast.VarStmt)
        return result

    def compile_nested_match_assignment_stmt(
        self,
        stmt: ast.AssignStmt,
        nested: NestedMatchContext,
        incoming: list[FlowState],
        error_exit: int | None,
        loop_ctx: LoopContext | None,
    ) -> list[FlowState]:
        expr = nested.match_expr
        node = self.new_node('branch', f'match {format_expr_inline(expr.expr)}', ops=self.expr_ownership_ops(expr.expr, incoming))
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr.expr, error_exit, state.active_scopes)
        borrowed = self.borrow_marks_in_expr(expr.expr, incoming)
        scrutinee_type = self.infer_expr_type(expr.expr)
        join = self.new_node('join', f'{format_expr_inline(stmt.target)}:nested_match_assign_join')
        result: list[FlowState] = []
        for idx, arm in enumerate(expr.arms):
            anchor = self.new_node('branch_entry', f'nested_match:arm:{idx}')
            arm_states = [FlowState(node_id=anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for _ in incoming:
                self.add_edge(node, anchor, f'arm:{idx}')
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                rebuilt_stmt = ast.AssignStmt(stmt.target, stmt.op, nested.replace(arm.expr))
                arm_out = self.compile_stmt(rebuilt_stmt, arm_states, error_exit=error_exit, loop_ctx=loop_ctx)
            finally:
                self._type_scopes.pop()
            for state in arm_out:
                self.add_edge(state.node_id, join, 'join')
                result.append(FlowState(node_id=join, active_scopes=state.active_scopes))
        return result

    def compile_nested_match_return_stmt(
        self,
        stmt: ast.ReturnStmt,
        nested: NestedMatchContext,
        incoming: list[FlowState],
        error_exit: int | None,
    ) -> list[FlowState]:
        expr = nested.match_expr
        node = self.new_node('branch', f'match {format_expr_inline(expr.expr)}', ops=self.expr_ownership_ops(expr.expr, incoming))
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr.expr, error_exit, state.active_scopes)
        borrowed = self.borrow_marks_in_expr(expr.expr, incoming)
        scrutinee_type = self.infer_expr_type(expr.expr)
        result: list[FlowState] = []
        for idx, arm in enumerate(expr.arms):
            anchor = self.new_node('branch_entry', f'nested_match:arm:{idx}')
            arm_states = [FlowState(node_id=anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for _ in incoming:
                self.add_edge(node, anchor, f'arm:{idx}')
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                rebuilt_stmt = ast.ReturnStmt(nested.replace(arm.expr))
                arm_out = self.compile_stmt(rebuilt_stmt, arm_states, error_exit=error_exit, loop_ctx=None)
            finally:
                self._type_scopes.pop()
            result.extend(arm_out)
        return result

    def compile_match_assignment_stmt(
        self,
        stmt: ast.AssignStmt,
        incoming: list[FlowState],
        error_exit: int | None,
        loop_ctx: LoopContext | None,
    ) -> list[FlowState]:
        expr = stmt.value
        assert isinstance(expr, ast.MatchExpr)
        node = self.new_node('branch', f'match {format_expr_inline(expr.expr)}', ops=self.expr_ownership_ops(expr.expr, incoming))
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr.expr, error_exit, state.active_scopes)
        borrowed = self.borrow_marks_in_expr(expr.expr, incoming)
        scrutinee_type = self.infer_expr_type(expr.expr)
        join = self.new_node('join', f'{format_expr_inline(stmt.target)}:match_assign_join')
        result: list[FlowState] = []
        for idx, arm in enumerate(expr.arms):
            anchor = self.new_node('branch_entry', f'match:arm:{idx}')
            arm_states = [FlowState(node_id=anchor, active_scopes=self.add_borrow_marks(s.active_scopes, borrowed)) for s in incoming]
            for _ in incoming:
                self.add_edge(node, anchor, f'arm:{idx}')
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                arm_stmt = ast.AssignStmt(stmt.target, stmt.op, arm.expr)
                arm_out = self.compile_stmt(arm_stmt, arm_states, error_exit=error_exit, loop_ctx=loop_ctx)
            finally:
                self._type_scopes.pop()
            for state in arm_out:
                self.add_edge(state.node_id, join, 'join')
                result.append(FlowState(node_id=join, active_scopes=state.active_scopes))
        return result

    def compile_match_return_stmt(
        self,
        stmt: ast.ReturnStmt,
        incoming: list[FlowState],
        error_exit: int | None,
    ) -> list[FlowState]:
        assert stmt.expr is not None
        match_states = self.compile_match_expr_flow(stmt.expr, incoming, error_exit, label='return_match')
        node = self.new_node('return', 'return ' + format_expr_inline(stmt.expr), ops=[])
        for state in match_states:
            self.add_edge(state.node_id, node, 'next')
            if self.is_error_return(stmt.expr) and error_exit is not None:
                _, cleanup, pops = self.leave_all_scopes(state.active_scopes, error_path=True)
                self.add_edge(node, error_exit, 'return_error', cleanup, pop_ops=pops)
            else:
                _, cleanup, pops = self.leave_all_scopes(state.active_scopes, error_path=False)
                target = self.find_exit('return_exit')
                self.add_edge(node, target, 'return', cleanup, pop_ops=pops)
        return []

    def simple_stmt_node(
        self,
        kind: str,
        label: str,
        expr: ast.Expr | None,
        incoming: list[FlowState],
        error_exit: int | None,
        ops: list[OwnershipOp] | None = None,
    ) -> list[FlowState]:
        node = self.new_node(kind, label, ops=ops)
        result: list[FlowState] = []
        for state in incoming:
            self.add_edge(state.node_id, node, 'next')
            self.add_propagation_edges(node, expr, error_exit, state.active_scopes)
            result.append(FlowState(node_id=node, active_scopes=state.active_scopes))
        return result

    def bind_states_for_type(self, name: str, bound_type: ast.Type | None, states: list[FlowState]) -> list[FlowState]:
        rtype = self.resource_type_from_type(bound_type)
        if rtype is None:
            return states
        return [FlowState(node_id=state.node_id, active_scopes=self.add_binding(state.active_scopes, name, rtype)) for state in states]

    def infer_bound_type(self, expr: ast.Expr, declared_type: ast.Type | None) -> ast.Type:
        if declared_type is not None:
            return declared_type
        return self.infer_expr_type(expr, expected=None)

    def infer_expr_type(self, expr: ast.Expr, expected: ast.Type | None = None) -> ast.Type:
        if self._current_fn is None or self._type_summary is None:
            return ast.NamedType('_Unknown')
        inferred = self._typechecker.type_of_expr(expr, self._type_scopes, self._current_fn, self._type_summary, expected)
        return self._typechecker.materialize(inferred)


    def sem_place_from_path(self, path: str | None) -> SemPlace | None:
        if path is None:
            return None
        return sem_place_from_path(path)

    def op_matches_place(self, op: OwnershipOp, place: SemPlace) -> bool:
        if op.place is not None:
            return op.place == place
        if op.name is None:
            return False
        return self.sem_place_from_path(op.name) == place

    def make_op(
        self,
        kind: str,
        name: str | None = None,
        aux_name: str | None = None,
        type_name: str | None = None,
        transition: str | None = None,
        borrow_mode: str | None = None,
        callee: str | None = None,
        param_index: int | None = None,
        source_name: str | None = None,
        source_aux_name: str | None = None,
        place: SemPlace | None = None,
        aux_place: SemPlace | None = None,
        source_place: SemPlace | None = None,
        source_aux_place: SemPlace | None = None,
    ) -> OwnershipOp:
        canonical_place = place if place is not None else self.sem_place_from_path(name)
        canonical_aux_place = aux_place if aux_place is not None else self.sem_place_from_path(aux_name)
        canonical_source_place = source_place if source_place is not None else self.sem_place_from_path(source_name)
        canonical_source_aux_place = source_aux_place if source_aux_place is not None else sem_relative_place_from_suffix(source_aux_name)

        place_primary_kinds = {
            'begin_borrow',
            'end_borrow',
            'read_resource',
            'move_resource',
            'transition',
            'bind_from',
            'bind_fresh',
            'call_ref_param',
        }

        rendered_name = name
        if rendered_name is None and canonical_place is not None and kind not in place_primary_kinds:
            rendered_name = canonical_place.to_path()
        elif kind in place_primary_kinds and canonical_place is not None:
            rendered_name = None

        rendered_aux_name = aux_name
        if rendered_aux_name is None and canonical_aux_place is not None and canonical_aux_place.root:
            rendered_aux_name = None

        rendered_source_name = source_name
        if rendered_source_name is None and canonical_source_place is not None:
            rendered_source_name = None

        rendered_source_aux_name = source_aux_name
        if rendered_source_aux_name is None and canonical_source_aux_place is not None and canonical_source_aux_place.root:
            rendered_source_aux_name = None

        return OwnershipOp(
            kind=kind,
            name=rendered_name,
            aux_name=rendered_aux_name,
            type_name=type_name,
            transition=transition,
            borrow_mode=borrow_mode,
            callee=callee,
            param_index=param_index,
            source_name=rendered_source_name,
            source_aux_name=rendered_source_aux_name,
            place=canonical_place,
            aux_place=canonical_aux_place,
            source_place=canonical_source_place,
            source_aux_place=canonical_source_aux_place,
        )


    def lookup_scoped_type(self, name: str) -> ast.Type | None:
        for scope in reversed(self._type_scopes):
            typ = scope.bindings.get(name)
            if isinstance(typ, ast.Type):
                return typ
        return None

    def expr_root_name(self, expr: ast.Expr) -> str | None:
        if isinstance(expr, ast.NameExpr):
            return expr.name
        if isinstance(expr, ast.AttrExpr):
            return self.expr_root_name(expr.obj)
        if isinstance(expr, ast.DottedExpr) and expr.parts:
            return expr.parts[0]
        if isinstance(expr, ast.IndexExpr):
            return self.expr_root_name(expr.obj)
        if isinstance(expr, ast.SliceExpr):
            return self.expr_root_name(expr.obj)
        return None


    def is_ref_param_name(self, name: str) -> bool:
        if self._current_fn is None:
            return False
        return any(param.name == name and self.ref_alias_mode_from_type(param.typ) is not None for param in self._current_fn.params)

    def ref_like_root_name(self, expr: ast.Expr) -> str | None:
        root_name = self.expr_root_name(expr)
        if root_name is None:
            return None
        root_type = self.lookup_scoped_type(root_name)
        if self.ref_alias_mode_from_type(root_type) is None:
            return None
        return root_name


    def ref_alias_relative_place(self, expr: ast.Expr, root_name: str) -> SemPlace:
        relative = sem_relative_place_for_expr(expr, root_name)
        if relative is not None:
            return relative
        place = sem_place_for_expr(expr)
        if place is not None and place.root == root_name:
            return SemPlace(root='', projections=place.projections)
        return SemPlace(root='')

    def ref_alias_resolution(self, name: str, states: list[FlowState], mutable_alias_only: bool = False) -> RefAliasEntry | None | bool:
        alias_targets: set[RefAliasEntry] = set()
        missing = False
        for state in states:
            found: RefAliasEntry | None = None
            for frame in reversed(state.active_scopes):
                for entry in reversed(frame.ref_aliases):
                    if entry.alias_name == name:
                        found = entry
                        break
                if found is not None:
                    break
            if found is None:
                missing = True
                continue
            alias_targets.add(found)
        if not alias_targets:
            return None
        if missing or len(alias_targets) != 1:
            return False
        resolved = next(iter(alias_targets))
        if mutable_alias_only and resolved.mode != 'mut':
            return None
        return resolved

    def invalid_ref_alias_ops(self, expr: ast.Expr, states: list[FlowState], mutable_alias_only: bool = False) -> list[OwnershipOp]:
        root_name = self.ref_like_root_name(expr)
        if root_name is None:
            return []
        resolution = self.ref_alias_resolution(root_name, states, mutable_alias_only=mutable_alias_only)
        if resolution is False or (resolution is None and not self.is_ref_param_name(root_name) and self.ref_alias_mode_from_type(self.lookup_scoped_type(root_name)) is not None):
            mode = 'mut' if mutable_alias_only else (self.ref_alias_mode_from_type(self.lookup_scoped_type(root_name)) or 'const')
            return [self.make_op(kind='invalid_ref_alias', name=root_name, borrow_mode=mode)]
        return []

    def normalized_resource_place(self, expr: ast.Expr, states: list[FlowState], mutable_alias_only: bool = False) -> SemPlace | None:
        return self.referent_place(expr, states, mutable_alias_only=mutable_alias_only)

    def alias_resource_op(self, kind: str, expr: ast.Expr, states: list[FlowState], mutable_alias_only: bool = False, borrow_mode: str | None = None, transition: str | None = None) -> list[OwnershipOp] | None:
        root_name = self.ref_like_root_name(expr)
        if root_name is None:
            return None
        relative_place = self.ref_alias_relative_place(expr, root_name)
        target_place = self.referent_place(expr, states, mutable_alias_only=mutable_alias_only)
        return [self.make_op(kind=kind, name=root_name, borrow_mode=borrow_mode, transition=transition, place=target_place, aux_place=relative_place)]

    def bind_ref_alias_for_type(
        self,
        name: str,
        bound_type: ast.Type | None,
        expr: ast.Expr,
        states: list[FlowState],
        source_states: list[FlowState],
    ) -> list[FlowState]:
        plan = self.ref_alias_info_from_binding(bound_type, expr, source_states)
        if plan is None:
            return states
        result: list[FlowState] = []
        for state in states:
            scopes = state.active_scopes
            if plan.transfer and plan.source_alias is not None and plan.source_alias != name:
                scopes = self.remove_ref_alias(scopes, plan.source_alias)
            scopes = self.add_ref_alias(scopes, name, plan.target_place, plan.mode)
            result.append(FlowState(node_id=state.node_id, active_scopes=scopes))
        return result

    def rebind_ref_alias_on_assignment(
        self,
        target: ast.Expr,
        value: ast.Expr,
        states: list[FlowState],
        source_states: list[FlowState],
    ) -> list[FlowState]:
        if not isinstance(target, ast.NameExpr):
            return states
        target_type = self.infer_expr_type(target)
        plan = self.ref_alias_info_from_binding(target_type, value, source_states)
        if plan is None:
            return [FlowState(node_id=state.node_id, active_scopes=self.remove_ref_alias(state.active_scopes, target.name)) for state in states]
        result: list[FlowState] = []
        for state in states:
            original_scope = self.find_ref_alias_scope_index(state.active_scopes, target.name)
            scopes = self.remove_ref_alias(state.active_scopes, target.name)
            if plan.transfer and plan.source_alias is not None and plan.source_alias != target.name:
                scopes = self.remove_ref_alias(scopes, plan.source_alias)
            scopes = self.add_ref_alias_at_scope(scopes, original_scope, target.name, plan.target_place, plan.mode)
            result.append(FlowState(node_id=state.node_id, active_scopes=scopes))
        return result

    def ref_rebind_borrow_ops(self, target: ast.Expr, value: ast.Expr, states: list[FlowState]) -> list[OwnershipOp]:
        if not isinstance(target, ast.NameExpr):
            return []
        target_type = self.lookup_scoped_type(target.name)
        mode = self.ref_alias_mode_from_type(target_type)
        if mode is None:
            return []
        ops: list[OwnershipOp] = []
        current_alias = self.ref_alias_resolution(target.name, states)
        if isinstance(current_alias, RefAliasEntry):
            ops.append(self.make_op(kind='end_borrow', name=current_alias.target_place.to_path(), borrow_mode=current_alias.mode, place=current_alias.target_place))
        elif current_alias is False:
            ops.append(self.make_op(kind='invalid_ref_alias', name=target.name, borrow_mode='mut' if mode == 'mut' else 'const'))
        if isinstance(value, ast.UnaryExpr) and value.op == 'borrow':
            new_place = self.referent_place(value.expr, states, mutable_alias_only=(mode == 'mut'))
            if new_place is not None:
                ops.append(self.make_op(kind='begin_borrow', name=new_place.to_path(), borrow_mode=mode, place=new_place))
            else:
                ops.extend(self.invalid_ref_alias_ops(value.expr, states, mutable_alias_only=(mode == 'mut')))
        return ops

    def ref_alias_info_from_binding(
        self,
        bound_type: ast.Type | None,
        expr: ast.Expr,
        states: list[FlowState],
    ) -> RefAliasPlan | None:
        mode = self.ref_alias_mode_from_type(bound_type)
        if mode is None:
            return None
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'borrow':
            target_place = self.referent_place(expr.expr, states, mutable_alias_only=(mode == 'mut'))
            if target_place is not None:
                return RefAliasPlan(target_place=target_place, mode=mode, from_borrow=True)
            return None
        root_name = self.ref_like_root_name(expr)
        if root_name is None:
            return None
        source = self.lookup_ref_alias(root_name, states, mutable_alias_only=(mode == 'mut'))
        if source is None:
            return None
        source_mode = source.mode
        if source_mode != mode:
            return None
        relative = self.ref_alias_relative_place(expr, root_name)
        return RefAliasPlan(target_place=combine_sem_place(source.target_place, relative), mode=mode, source_alias=root_name, transfer=(mode == 'mut'))


    def add_borrows_to_states(self, states: list[FlowState], borrow_marks: list[BorrowMark]) -> list[FlowState]:
        if not borrow_marks:
            return states
        return [FlowState(node_id=state.node_id, active_scopes=self.add_borrow_marks(state.active_scopes, borrow_marks)) for state in states]

    def exit_block_normally(self, states: list[FlowState], label: str) -> list[FlowState]:
        result: list[FlowState] = []
        for state in states:
            trimmed, cleanup, pops = self.leave_one_scope(state.active_scopes, error_path=False)
            node = self.new_node('scope_exit', label)
            self.add_edge(state.node_id, node, 'scope_exit', cleanup, pop_ops=pops)
            result.append(FlowState(node_id=node, active_scopes=trimmed))
        return result

    def borrow_marks_in_expr(self, expr: ast.Expr, states: list[FlowState], expected_type: ast.Type | None = None) -> list[BorrowMark]:
        marks: list[BorrowMark] = []
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'borrow':
            borrow_mode = self.borrow_mode_from_expected_type(expected_type)
            place = self.referent_place(expr.expr, states, mutable_alias_only=(borrow_mode == 'mut'))
            if place is not None:
                return [BorrowMark(path=place.to_path(), mode=borrow_mode, place=place)]
            return []
        if isinstance(expr, ast.SomeExpr):
            return self.borrow_marks_in_expr(expr.value, states)
        if isinstance(expr, ast.UnaryExpr):
            return self.borrow_marks_in_expr(expr.expr, states)
        if isinstance(expr, ast.BinaryExpr):
            return self.borrow_marks_in_expr(expr.left, states) + self.borrow_marks_in_expr(expr.right, states)
        if isinstance(expr, ast.RangeExpr):
            return self.borrow_marks_in_expr(expr.start, states) + self.borrow_marks_in_expr(expr.stop, states)
        if isinstance(expr, ast.CallExpr):
            marks.extend(self.borrow_marks_in_expr(expr.callee, states))
            target = self._functions.get(expr.callee.name) if isinstance(expr.callee, ast.NameExpr) else None
            for idx, arg in enumerate(expr.args):
                param_expected = target.params[idx].typ if target is not None and idx < len(target.params) else None
                marks.extend(self.borrow_marks_in_expr(arg, states, param_expected))
            return marks
        if isinstance(expr, ast.AttrExpr):
            return self.borrow_marks_in_expr(expr.obj, states)
        if isinstance(expr, ast.IndexExpr):
            return self.borrow_marks_in_expr(expr.obj, states) + self.borrow_marks_in_expr(expr.index, states)
        if isinstance(expr, ast.SliceExpr):
            marks = self.borrow_marks_in_expr(expr.obj, states)
            if expr.start is not None:
                marks.extend(self.borrow_marks_in_expr(expr.start, states))
            if expr.stop is not None:
                marks.extend(self.borrow_marks_in_expr(expr.stop, states))
            return marks
        if isinstance(expr, ast.TryExpr):
            return self.borrow_marks_in_expr(expr.expr, states)
        if isinstance(expr, ast.CatchExpr):
            return self.borrow_marks_in_expr(expr.expr, states) + self.borrow_marks_in_expr(expr.fallback, states)
        if isinstance(expr, ast.CastExpr):
            return self.borrow_marks_in_expr(expr.expr, states)
        if isinstance(expr, ast.StructLiteralExpr | ast.EnumLiteralExpr):
            for _, value in expr.fields:
                marks.extend(self.borrow_marks_in_expr(value, states))
            return marks
        if isinstance(expr, ast.MatchExpr):
            marks.extend(self.borrow_marks_in_expr(expr.expr, states))
            for arm in expr.arms:
                marks.extend(self.borrow_marks_in_expr(arm.expr, states))
            return marks
        return []

    def propagation_kinds(self, expr: ast.Expr) -> set[str]:
        kinds: set[str] = set()
        if isinstance(expr, ast.TryExpr):
            kinds |= self.propagation_kinds(expr.expr)
            inner = self._typechecker.normalize_type(self.infer_expr_type(expr.expr))
            if isinstance(inner, ast.ResultType):
                kinds.add('error')
            elif isinstance(inner, ast.OptionalType):
                kinds.add('optional')
            elif self._current_fn is not None:
                outer = self._typechecker.normalize_type(self._current_fn.return_type)
                if isinstance(outer, ast.ResultType):
                    kinds.add('error')
                elif isinstance(outer, ast.OptionalType):
                    kinds.add('optional')
            return kinds
        if isinstance(expr, ast.CatchExpr):
            return self.propagation_kinds(expr.expr) | self.propagation_kinds(expr.fallback)
        if isinstance(expr, ast.SomeExpr):
            return self.propagation_kinds(expr.value)
        if isinstance(expr, ast.UnaryExpr):
            return self.propagation_kinds(expr.expr)
        if isinstance(expr, ast.BinaryExpr):
            return self.propagation_kinds(expr.left) | self.propagation_kinds(expr.right)
        if isinstance(expr, ast.RangeExpr):
            return self.propagation_kinds(expr.start) | self.propagation_kinds(expr.stop)
        if isinstance(expr, ast.CallExpr):
            kinds = self.propagation_kinds(expr.callee)
            for arg in expr.args:
                kinds |= self.propagation_kinds(arg)
            return kinds
        if isinstance(expr, ast.AttrExpr):
            return self.propagation_kinds(expr.obj)
        if isinstance(expr, ast.IndexExpr):
            return self.propagation_kinds(expr.obj) | self.propagation_kinds(expr.index)
        if isinstance(expr, ast.SliceExpr):
            kinds = self.propagation_kinds(expr.obj)
            if expr.start is not None:
                kinds |= self.propagation_kinds(expr.start)
            if expr.stop is not None:
                kinds |= self.propagation_kinds(expr.stop)
            return kinds
        if isinstance(expr, ast.CastExpr):
            return self.propagation_kinds(expr.expr)
        if isinstance(expr, ast.StructLiteralExpr):
            for _, value in expr.fields:
                kinds |= self.propagation_kinds(value)
            return kinds
        if isinstance(expr, ast.EnumLiteralExpr):
            for _, value in expr.fields:
                kinds |= self.propagation_kinds(value)
            return kinds
        if isinstance(expr, ast.MatchExpr):
            kinds = self.propagation_kinds(expr.expr)
            for arm in expr.arms:
                kinds |= self.propagation_kinds(arm.expr)
            return kinds
        return kinds

    def add_propagation_edges(self, node: int, expr: ast.Expr | None, error_exit: int | None, active_scopes: list[ScopeFrame]) -> None:
        if expr is None:
            return
        kinds = self.propagation_kinds(expr)
        if 'error' in kinds and error_exit is not None:
            _, cleanup, pops = self.leave_all_scopes(active_scopes, error_path=True)
            self.add_edge(node, error_exit, 'error', cleanup, pop_ops=pops)
        if 'optional' in kinds:
            target = self.find_exit('return_exit')
            if target is not None:
                _, cleanup, pops = self.leave_all_scopes(active_scopes, error_path=False)
                self.add_edge(node, target, 'optional_return', cleanup, pop_ops=pops)

    def is_error_return(self, expr: ast.Expr | None) -> bool:
        if expr is None:
            return False
        if isinstance(expr, ast.DottedExpr) and len(expr.parts) >= 2:
            return expr.parts[0] not in self._enums and expr.parts[0] not in self._structs and expr.parts[0] not in self._resources
        return False

    def stmt_text(self, stmt: ast.Stmt) -> str:
        if isinstance(stmt, ast.ExprStmt):
            return format_expr_inline(stmt.expr)
        if isinstance(stmt, ast.ReturnStmt):
            return 'return ' + (format_expr_inline(stmt.expr) if stmt.expr is not None else 'unit')
        if isinstance(stmt, ast.AssignStmt):
            return f'{format_expr_inline(stmt.target)} {stmt.op} ...'
        if isinstance(stmt, ast.LetStmt):
            return f'let {stmt.name}'
        if isinstance(stmt, ast.VarStmt):
            return f'var {stmt.name}'
        return type(stmt).__name__

    def ref_alias_binding_ops(self, target_name: str, target_type: ast.Type | None, value: ast.Expr, states: list[FlowState], assignment: bool = False) -> list[OwnershipOp]:
        mode = self.ref_alias_mode_from_type(target_type)
        if mode is None:
            return []
        plan = self.ref_alias_info_from_binding(target_type, value, states)
        ops: list[OwnershipOp] = []
        if assignment:
            current_alias = self.ref_alias_resolution(target_name, states)
            if isinstance(current_alias, RefAliasEntry):
                ops.append(self.make_op(kind='end_borrow', name=current_alias.target_place.to_path(), borrow_mode=current_alias.mode, place=current_alias.target_place))
            elif current_alias is False:
                ops.append(self.make_op(kind='invalid_ref_alias', name=target_name, borrow_mode='mut' if mode == 'mut' else 'const'))
            ops.append(self.make_op(kind='clear_ref_alias', name=target_name))
        if plan is None:
            referent_expr = value.expr if isinstance(value, ast.UnaryExpr) and value.op == 'borrow' else value
            invalid = self.invalid_ref_alias_ops(referent_expr, states, mutable_alias_only=(mode == 'mut'))
            return ops + invalid
        if plan.transfer:
            if plan.source_alias is not None and plan.source_alias != target_name:
                ops.append(self.make_op(kind='clear_ref_alias', name=plan.source_alias))
        elif not plan.from_borrow:
            ops.append(self.make_op(kind='begin_borrow', name=plan.target_place.to_path(), borrow_mode=mode, place=plan.target_place))
        ops.append(self.make_op(kind='define_ref_alias', name=target_name, borrow_mode=mode, aux_place=plan.target_place))
        return ops

    def suppress_ref_alias_binding_value_ops(
        self,
        value_ops: list[OwnershipOp],
        plan: RefAliasPlan | None,
        ref_ops: list[OwnershipOp],
    ) -> list[OwnershipOp]:
        if plan is None:
            return value_ops
        filtered = value_ops
        if plan.source_alias is not None:
            filtered = [
                op for op in filtered
                if not (
                    op.name == plan.source_alias and op.kind in {'read_alias_resource', 'move_alias_resource'}
                )
            ]
        if plan.target_place is not None:
            filtered = [
                op for op in filtered
                if not (
                    op.kind in {'read_resource', 'move_resource'}
                    and self.op_matches_place(op, plan.target_place)
                )
            ]
        ref_begin_targets = {op.place for op in ref_ops if op.kind == 'begin_borrow' and op.place is not None}
        if ref_begin_targets:
            filtered = [
                op for op in filtered
                if not (op.kind == 'begin_borrow' and op.place in ref_begin_targets)
            ]
        return filtered

    def ownership_ops_for_stmt(self, stmt: ast.Stmt, states: list[FlowState], inferred_type: ast.Type | None = None) -> list[OwnershipOp]:
        if isinstance(stmt, ast.LetStmt | ast.VarStmt):
            bound_type = inferred_type if inferred_type is not None else stmt.typ
            ref_plan = self.ref_alias_info_from_binding(bound_type, stmt.value, states)
            ops = self.expr_ownership_ops(stmt.value, states, bound_type)
            ref_ops = self.ref_alias_binding_ops(stmt.name, bound_type, stmt.value, states, assignment=False)
            ops = self.suppress_ref_alias_binding_value_ops(ops, ref_plan, ref_ops)
            rtype = self.resource_type_from_type(bound_type)
            if rtype is not None:
                bind_ops = self.binding_ops(stmt.name, rtype, stmt.value, states)
                # avoid a pure read on direct move/bind expressions; the bind op already handles it
                if bind_ops:
                    suppressed = {'read_resource', 'move_resource'}
                    return [op for op in ops if not (op.kind in suppressed and op.name == bind_ops[0].aux_name)] + bind_ops + ref_ops
                ops.append(self.make_op(kind='bind_fresh', name=stmt.name, type_name=rtype))
            return ops + ref_ops
        if isinstance(stmt, ast.AssignStmt):
            bind_ops = self.assignment_binding_ops(stmt.target, stmt.value, states)
            target_type = self.infer_expr_type(stmt.target) if stmt.op == '=' and isinstance(stmt.target, ast.NameExpr) else None
            rebind_plan = self.ref_alias_info_from_binding(target_type, stmt.value, states) if target_type is not None else None
            rebind_ops = self.ref_alias_binding_ops(stmt.target.name, target_type, stmt.value, states, assignment=True) if stmt.op == '=' and isinstance(stmt.target, ast.NameExpr) else []
            if bind_ops and stmt.op == '=':
                bind_op = bind_ops[0]
                source_place = bind_op.aux_place if bind_op.kind == 'bind_from' else bind_op.source_place
                source_alias = bind_op.source_name if bind_op.kind in {'bind_alias_target_from_alias_source', 'bind_from_alias_source'} else None
                source_aux_place = bind_op.source_aux_place if bind_op.kind in {'bind_alias_target_from_alias_source', 'bind_from_alias_source'} else None
                value_ops = self.expr_ownership_ops(stmt.value, states, target_type)
                if source_place is not None or source_alias is not None:
                    value_ops = [
                        op for op in value_ops
                        if not (
                            (source_place is not None and op.kind in {'read_resource', 'move_resource'} and op.place == source_place)
                            or (
                                source_place is not None
                                and source_alias is None
                                and op.kind in {'read_alias_resource', 'move_alias_resource'}
                                and op.place == source_place
                            )
                            or (
                                source_alias is not None
                                and op.kind in {'read_alias_resource', 'move_alias_resource'}
                                and op.name == source_alias
                                and op.aux_place == source_aux_place
                            )
                        )
                    ]
                value_ops = self.suppress_ref_alias_binding_value_ops(value_ops, rebind_plan, rebind_ops)
                return rebind_ops + value_ops + bind_ops
            value_ops = self.expr_ownership_ops(stmt.value, states, target_type)
            value_ops = self.suppress_ref_alias_binding_value_ops(value_ops, rebind_plan, rebind_ops)
            target_ops = [] if rebind_ops else self.expr_ownership_ops(stmt.target, states)
            return rebind_ops + target_ops + value_ops
        if isinstance(stmt, ast.ExprStmt):
            return self.expr_ownership_ops(stmt.expr, states)
        if isinstance(stmt, ast.ReturnStmt):
            return [] if stmt.expr is None else self.expr_ownership_ops(stmt.expr, states)
        return []

    def binding_ops(self, target: str, rtype: str, expr: ast.Expr, states: list[FlowState]) -> list[OwnershipOp]:
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'move':
            alias_ops = self.alias_resource_op('bind_from_alias_source', expr.expr, states)
            if alias_ops is not None:
                op = alias_ops[0]
                return [self.make_op(kind='bind_from_alias_source', source_name=op.name, place=SemPlace(root=target), source_place=op.place, source_aux_place=op.aux_place)]
            source_place = self.referent_place(expr.expr, states, mutable_alias_only=False)
            if source_place is not None:
                return [self.make_op(kind='bind_from', name=target, type_name=rtype, place=SemPlace(root=target), aux_place=source_place)]
            invalid = self.invalid_ref_alias_ops(expr.expr, states)
            if invalid:
                return invalid
        alias_ops = self.alias_resource_op('bind_from_alias_source', expr, states)
        if alias_ops is not None:
            op = alias_ops[0]
            return [self.make_op(kind='bind_from_alias_source', source_name=op.name, place=SemPlace(root=target), source_place=op.place, source_aux_place=op.aux_place)]
        source_place = self.normalized_resource_place(expr, states, mutable_alias_only=False)
        if source_place is not None:
            return [self.make_op(kind='bind_from', name=target, type_name=rtype, place=SemPlace(root=target), aux_place=source_place)]
        invalid = self.invalid_ref_alias_ops(expr, states)
        if invalid:
            return invalid
        return [self.make_op(kind='bind_fresh', name=target, type_name=rtype, place=SemPlace(root=target))]

    def assignment_binding_ops(self, target: ast.Expr, value: ast.Expr, states: list[FlowState]) -> list[OwnershipOp]:
        alias_root = self.ref_like_root_name(target)
        target_relative_place = self.ref_alias_relative_place(target, alias_root) if alias_root is not None else None
        via_mut_ref = alias_root is not None and (self.uses_mutable_ref_alias(target, states) or self.is_ref_param_name(alias_root))

        if alias_root is not None and not via_mut_ref:
            # Do not flatten alias-rooted lvalues through CFG-time referent paths when the
            # root is not a live mutable reference. Let ownership resolve or reject the
            # target through the alias-state model instead.
            invalid = self.invalid_ref_alias_ops(target, states, mutable_alias_only=True)
            if invalid:
                return invalid

        target_place: SemPlace | None = None
        if not via_mut_ref:
            target_place = self.referent_place(target, states, mutable_alias_only=False)
            if target_place is None:
                target_place = self.resource_place(target)
        elif alias_root is not None:
            target_place = self.referent_place(target, states, mutable_alias_only=True)
        elif alias_root is None:
            target_place = self.resource_place(target)

        if via_mut_ref and alias_root is not None:
            target_mode = 'via_mut_ref'
            if isinstance(value, ast.UnaryExpr) and value.op == 'move':
                source_alias = self.ref_like_root_name(value.expr)
                if source_alias is not None:
                    source_relative_place = self.ref_alias_relative_place(value.expr, source_alias)
                    source_place = self.referent_place(value.expr, states, mutable_alias_only=False)
                    return [self.make_op(kind='bind_alias_target_from_alias_source', name=alias_root, borrow_mode=target_mode, source_name=source_alias, place=target_place, aux_place=target_relative_place, source_place=source_place, source_aux_place=source_relative_place)]
                source_place = self.referent_place(value.expr, states, mutable_alias_only=False)
                if source_place is not None:
                    return [self.make_op(kind='bind_alias_target_from', name=alias_root, borrow_mode=target_mode, place=target_place, aux_place=target_relative_place, source_place=source_place)]
                invalid = self.invalid_ref_alias_ops(value.expr, states)
                if invalid:
                    return invalid
            source_alias = self.ref_like_root_name(value)
            if source_alias is not None:
                source_relative_place = self.ref_alias_relative_place(value, source_alias)
                source_place = self.referent_place(value, states, mutable_alias_only=False)
                return [self.make_op(kind='bind_alias_target_from_alias_source', name=alias_root, borrow_mode=target_mode, source_name=source_alias, place=target_place, aux_place=target_relative_place, source_place=source_place, source_aux_place=source_relative_place)]
            source_place = self.normalized_resource_place(value, states, mutable_alias_only=False)
            if source_place is not None:
                return [self.make_op(kind='bind_alias_target_from', name=alias_root, borrow_mode=target_mode, place=target_place, aux_place=target_relative_place, source_place=source_place)]
            invalid = self.invalid_ref_alias_ops(value, states)
            if invalid:
                return invalid
            rtype = self.resource_type_from_type(self.infer_expr_type(value))
            if rtype is not None:
                return [self.make_op(kind='bind_fresh_alias_target', name=alias_root, type_name=rtype, borrow_mode=target_mode, place=target_place, aux_place=target_relative_place)]
            return []

        if target_place is None:
            invalid = self.invalid_ref_alias_ops(target, states, mutable_alias_only=via_mut_ref)
            if invalid:
                return invalid
            return []
        borrow_mode = 'via_mut_ref' if via_mut_ref else None
        if isinstance(value, ast.UnaryExpr) and value.op == 'move':
            source_place = self.referent_place(value.expr, states, mutable_alias_only=False)
            if source_place is not None:
                return [self.make_op(kind='bind_from', borrow_mode=borrow_mode, place=target_place, aux_place=source_place)]
            invalid = self.invalid_ref_alias_ops(value.expr, states)
            if invalid:
                return invalid
        source_place = self.normalized_resource_place(value, states, mutable_alias_only=False)
        if source_place is not None:
            return [self.make_op(kind='bind_from', borrow_mode=borrow_mode, place=target_place, aux_place=source_place)]
        invalid = self.invalid_ref_alias_ops(value, states)
        if invalid:
            return invalid
        rtype = self.resource_type_from_type(self.infer_expr_type(value))
        if rtype is not None:
            return [self.make_op(kind='bind_fresh', type_name=rtype, borrow_mode=borrow_mode, place=target_place)]
        return []

    def expr_ownership_ops(self, expr: ast.Expr, states: list[FlowState], expected_type: ast.Type | None = None) -> list[OwnershipOp]:
        if isinstance(expr, ast.NameExpr):
            alias_ops = self.alias_resource_op('read_alias_resource', expr, states)
            if alias_ops is not None:
                return alias_ops
            place = self.normalized_resource_place(expr, states, mutable_alias_only=False)
            if place is not None:
                return [self.make_op(kind='read_resource', place=place)]
            return self.invalid_ref_alias_ops(expr, states)
        if isinstance(expr, ast.AttrExpr):
            alias_ops = self.alias_resource_op('read_alias_resource', expr, states)
            if alias_ops is not None:
                return alias_ops
            place = self.normalized_resource_place(expr, states, mutable_alias_only=False)
            if place is not None:
                return [self.make_op(kind='read_resource', place=place)]
            invalid = self.invalid_ref_alias_ops(expr, states)
            if invalid:
                return invalid
            return self.expr_ownership_ops(expr.obj, states)
        if isinstance(expr, ast.DottedExpr):
            alias_ops = self.alias_resource_op('read_alias_resource', expr, states)
            if alias_ops is not None:
                return alias_ops
            place = self.normalized_resource_place(expr, states, mutable_alias_only=False)
            if place is not None:
                return [self.make_op(kind='read_resource', place=place)]
            return self.invalid_ref_alias_ops(expr, states)
        if isinstance(expr, ast.IntExpr | ast.StringExpr | ast.BoolExpr | ast.UnitExpr | ast.NoneExpr):
            return []
        if isinstance(expr, ast.SomeExpr):
            return self.expr_ownership_ops(expr.value, states)
        if isinstance(expr, ast.UnaryExpr):
            if expr.op == 'move':
                alias_ops = self.alias_resource_op('move_alias_resource', expr.expr, states)
                if alias_ops is not None:
                    return alias_ops
                place = self.referent_place(expr.expr, states, mutable_alias_only=False)
                if place is not None:
                    return [self.make_op(kind='move_resource', place=place)]
            if expr.op == 'borrow':
                alias_ops = self.alias_resource_op('begin_alias_borrow', expr.expr, states, borrow_mode=self.borrow_mode_from_expected_type(expected_type))
                if alias_ops is not None:
                    return alias_ops
                place = self.referent_place(expr.expr, states, mutable_alias_only=False)
                if place is not None:
                    return [self.make_op(kind='begin_borrow', borrow_mode=self.borrow_mode_from_expected_type(expected_type), place=place)]
            return self.expr_ownership_ops(expr.expr, states)
        if isinstance(expr, ast.BinaryExpr):
            return self.expr_ownership_ops(expr.left, states) + self.expr_ownership_ops(expr.right, states)
        if isinstance(expr, ast.RangeExpr):
            return self.expr_ownership_ops(expr.start, states) + self.expr_ownership_ops(expr.stop, states)
        if isinstance(expr, ast.CallExpr):
            ops: list[OwnershipOp] = []
            transition_target: tuple[str, str] | None = None
            receiver_expr_for_transition: ast.Expr | None = None
            if isinstance(expr.callee, ast.AttrExpr):
                receiver_expr_for_transition = expr.callee.obj
                if self.ref_like_root_name(receiver_expr_for_transition) is None:
                    receiver = self.referent_place(receiver_expr_for_transition, states, mutable_alias_only=False)
                    if receiver is not None:
                        transition_target = (receiver, expr.callee.name)
            elif isinstance(expr.callee, ast.DottedExpr) and len(expr.callee.parts) >= 2:
                receiver_expr_for_transition = ast.DottedExpr(expr.callee.parts[:-1])
                if self.ref_like_root_name(receiver_expr_for_transition) is None:
                    receiver = self.referent_place(receiver_expr_for_transition, states, mutable_alias_only=False)
                    if receiver is not None:
                        transition_target = (receiver, expr.callee.parts[-1])
            target = self._functions.get(expr.callee.name) if isinstance(expr.callee, ast.NameExpr) else None
            callee_name = self.call_target_name(expr.callee)
            if receiver_expr_for_transition is not None and self.ref_like_root_name(receiver_expr_for_transition) is not None:
                alias_transition = self.alias_resource_op(
                    'transition_alias',
                    receiver_expr_for_transition,
                    states,
                    mutable_alias_only=True,
                    borrow_mode='via_mut_ref',
                    transition=(expr.callee.name if isinstance(expr.callee, ast.AttrExpr) else expr.callee.parts[-1]),
                )
                if alias_transition is not None:
                    ops.extend(alias_transition)
                    for idx, arg in enumerate(expr.args):
                        param_expected = target.params[idx].typ if target is not None and idx < len(target.params) else self.imported_param_type(callee_name, idx)
                        imported_ref_sig = None if target is not None else self.imported_ref_param_signature(callee_name, idx)
                        ops.extend(self.arg_ownership_ops(arg, states, param_expected, imported_ref_mode=(imported_ref_sig.mode if imported_ref_sig is not None else None)))
                    ops.extend(self.call_ref_param_ops(expr, states, target, callee_name))
                    return ops
                invalid = self.invalid_ref_alias_ops(receiver_expr_for_transition, states, mutable_alias_only=True)
                if invalid:
                    return invalid
            if transition_target is not None:
                ops.append(self.make_op(kind='transition', transition=transition_target[1], place=transition_target[0]))
                for idx, arg in enumerate(expr.args):
                    param_expected = target.params[idx].typ if target is not None and idx < len(target.params) else self.imported_param_type(callee_name, idx)
                    imported_ref_sig = None if target is not None else self.imported_ref_param_signature(callee_name, idx)
                    ops.extend(self.arg_ownership_ops(arg, states, param_expected, imported_ref_mode=(imported_ref_sig.mode if imported_ref_sig is not None else None)))
                ops.extend(self.call_ref_param_ops(expr, states, target, callee_name))
                return ops
            ops.extend(self.expr_ownership_ops(expr.callee, states))
            for idx, arg in enumerate(expr.args):
                param_expected = target.params[idx].typ if target is not None and idx < len(target.params) else self.imported_param_type(callee_name, idx)
                imported_ref_sig = None if target is not None else self.imported_ref_param_signature(callee_name, idx)
                ops.extend(self.arg_ownership_ops(arg, states, param_expected, imported_ref_mode=(imported_ref_sig.mode if imported_ref_sig is not None else None)))
            ops.extend(self.call_ref_param_ops(expr, states, target, callee_name))
            return ops
        if isinstance(expr, ast.IndexExpr):
            return self.expr_ownership_ops(expr.obj, states) + self.expr_ownership_ops(expr.index, states)
        if isinstance(expr, ast.SliceExpr):
            ops = self.expr_ownership_ops(expr.obj, states)
            if expr.start is not None:
                ops.extend(self.expr_ownership_ops(expr.start, states))
            if expr.stop is not None:
                ops.extend(self.expr_ownership_ops(expr.stop, states))
            return ops
        if isinstance(expr, ast.TryExpr):
            return self.expr_ownership_ops(expr.expr, states)
        if isinstance(expr, ast.CatchExpr):
            return self.expr_ownership_ops(expr.expr, states) + self.expr_ownership_ops(expr.fallback, states)
        if isinstance(expr, ast.CastExpr):
            return self.expr_ownership_ops(expr.expr, states)
        if isinstance(expr, ast.StructLiteralExpr):
            ops: list[OwnershipOp] = []
            for _, value in expr.fields:
                ops.extend(self.expr_ownership_ops(value, states))
            return ops
        if isinstance(expr, ast.EnumLiteralExpr):
            ops: list[OwnershipOp] = []
            for _, value in expr.fields:
                ops.extend(self.expr_ownership_ops(value, states))
            return ops
        if isinstance(expr, ast.MatchExpr):
            ops = self.expr_ownership_ops(expr.expr, states)
            for arm in expr.arms:
                ops.extend(self.expr_ownership_ops(arm.expr, states))
            return ops
        return []


    def call_ref_param_ops(self, expr: ast.CallExpr, states: list[FlowState], target: ast.FnDecl | None, callee_name: str | None = None) -> list[OwnershipOp]:
        ops: list[OwnershipOp] = []
        for idx, arg in enumerate(expr.args):
            mode = None
            tracked_type = None
            call_name = callee_name
            if target is not None:
                if idx >= len(target.params):
                    break
                param = target.params[idx]
                mode = self.ref_alias_mode_from_type(param.typ)
                tracked_type = self.referent_tracked_type_from_ref_type(param.typ)
                call_name = target.name
            else:
                imported = self.imported_ref_param_signature(callee_name, idx)
                if imported is not None:
                    mode = imported.mode
                    tracked_type = imported.type_name
            if mode is None or tracked_type is None or call_name is None:
                continue
            referent_expr = arg.expr if isinstance(arg, ast.UnaryExpr) and arg.op == 'borrow' else arg
            alias_root = self.ref_like_root_name(referent_expr)
            if alias_root is not None:
                relative_place = self.ref_alias_relative_place(referent_expr, alias_root)
                referent_place = self.referent_place(referent_expr, states, mutable_alias_only=(mode == 'mut'))
                ops.append(self.make_op(kind='call_ref_alias_param', name=alias_root, type_name=tracked_type, borrow_mode=mode, callee=call_name, param_index=idx, place=referent_place, aux_place=relative_place))
                continue
            referent_place = self.referent_place(referent_expr, states, mutable_alias_only=False)
            if referent_place is None:
                invalid = self.invalid_ref_alias_ops(referent_expr, states, mutable_alias_only=(mode == 'mut'))
                if invalid:
                    ops.extend(invalid)
                continue
            ops.append(self.make_op(kind='call_ref_param', type_name=tracked_type, borrow_mode=mode, callee=call_name, param_index=idx, place=referent_place))
        return ops

    def arg_ownership_ops(self, expr: ast.Expr, states: list[FlowState], expected_type: ast.Type | None = None, imported_ref_mode: str | None = None) -> list[OwnershipOp]:
        expected_ref_mode = self.ref_alias_mode_from_type(expected_type) or imported_ref_mode
        if expected_ref_mode is not None and self.ref_like_root_name(expr) is not None:
            return []
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'borrow':
            return self.expr_ownership_ops(expr, states, expected_type)
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'move':
            alias_ops = self.alias_resource_op('move_alias_resource', expr.expr, states)
            if alias_ops is not None:
                return alias_ops
            place = self.referent_place(expr.expr, states, mutable_alias_only=False)
            if place is not None:
                return [self.make_op(kind='move_resource', place=place)]
            invalid = self.invalid_ref_alias_ops(expr.expr, states)
            if invalid:
                return invalid
        alias_kind = 'read_alias_resource' if expected_ref_mode is not None else 'move_alias_resource'
        alias_ops = self.alias_resource_op(alias_kind, expr, states)
        if alias_ops is not None:
            return alias_ops
        place = self.normalized_resource_place(expr, states, mutable_alias_only=False)
        if place is not None:
            if expected_ref_mode is not None:
                return [self.make_op(kind='read_resource', place=place)]
            return [self.make_op(kind='move_resource', place=place)]
        invalid = self.invalid_ref_alias_ops(expr, states)
        if invalid:
            return invalid
        return self.expr_ownership_ops(expr, states)



    def referent_tracked_type_from_ref_type(self, typ: ast.Type | None) -> str | None:
        if typ is None:
            return None
        inner = typ
        while isinstance(inner, ast.OptionalType | ast.ResultType):
            inner = inner.inner if isinstance(inner, ast.OptionalType) else inner.ok
        if isinstance(inner, ast.GenericType) and inner.name in {'Ref', 'RefConst'} and inner.args and isinstance(inner.args[0], ast.Type):
            return self.resource_type_from_type(inner.args[0])
        return None

    def ref_alias_mode_from_type(self, typ: ast.Type | None) -> str | None:
        if typ is None:
            return None
        inner = typ
        while isinstance(inner, ast.OptionalType | ast.ResultType):
            inner = inner.inner if isinstance(inner, ast.OptionalType) else inner.ok
        if isinstance(inner, ast.GenericType) and inner.name == 'Ref':
            return 'mut'
        if isinstance(inner, ast.GenericType) and inner.name == 'RefConst':
            return 'const'
        return None

    def lookup_ref_alias(self, name: str, states: list[FlowState], mutable_alias_only: bool = False) -> RefAliasEntry | None:
        resolution = self.ref_alias_resolution(name, states, mutable_alias_only=mutable_alias_only)
        return resolution if isinstance(resolution, RefAliasEntry) else None

    def paths_conflict(self, left: str, right: str) -> bool:
        return left == right or left.startswith(right + '.') or right.startswith(left + '.')

    def referent_place(self, expr: ast.Expr, states: list[FlowState], mutable_alias_only: bool = False) -> SemPlace | None:
        if isinstance(expr, ast.NameExpr):
            resolution = self.ref_alias_resolution(expr.name, states, mutable_alias_only=mutable_alias_only)
            if isinstance(resolution, RefAliasEntry):
                return resolution.target_place
            if resolution is False:
                return None
            if self.ref_like_root_name(expr) is not None:
                return SemPlace(root=expr.name) if self.is_ref_param_name(expr.name) else None
            return sem_place_for_expr(expr)
        if isinstance(expr, ast.AttrExpr):
            root = self.referent_place(expr.obj, states, mutable_alias_only=mutable_alias_only)
            if root is not None:
                return combine_sem_place(root, SemPlace(root='', projections=(SemProjection('field', expr.name),)))
            if self.ref_like_root_name(expr.obj) is not None:
                root_name = self.ref_like_root_name(expr.obj)
                return sem_place_for_expr(expr) if root_name is not None and self.is_ref_param_name(root_name) else None
            return sem_place_for_expr(expr)
        if isinstance(expr, ast.DottedExpr) and expr.parts:
            resolution = self.ref_alias_resolution(expr.parts[0], states, mutable_alias_only=mutable_alias_only)
            if isinstance(resolution, RefAliasEntry):
                relative = SemPlace(root='', projections=tuple(SemProjection('field', part) for part in expr.parts[1:]))
                return combine_sem_place(resolution.target_place, relative)
            if resolution is False:
                return None
            if self.ref_like_root_name(expr) is not None:
                return sem_place_for_expr(expr) if self.is_ref_param_name(expr.parts[0]) else None
            return sem_place_for_expr(expr)
        return sem_place_for_expr(expr)

    def uses_mutable_ref_alias(self, expr: ast.Expr, states: list[FlowState]) -> bool:
        root_name: str | None = None
        if isinstance(expr, ast.NameExpr):
            root_name = expr.name
        elif isinstance(expr, ast.AttrExpr):
            cur = expr
            while isinstance(cur, ast.AttrExpr):
                if isinstance(cur.obj, ast.NameExpr):
                    root_name = cur.obj.name
                    break
                cur = cur.obj
        elif isinstance(expr, ast.DottedExpr) and expr.parts:
            root_name = expr.parts[0]
        if root_name is None:
            return False
        return self.lookup_ref_alias(root_name, states, mutable_alias_only=True) is not None

    def resource_place(self, expr: ast.Expr) -> SemPlace | None:
        return sem_place_for_expr(expr)

    def receiver_place(self, expr: ast.Expr) -> SemPlace | None:
        return self.resource_place(expr)

    def tracked_type_from_expr(self, expr: ast.Expr, states: list[FlowState]) -> str | None:
        rtype = self.resource_ctor_type(expr)
        if rtype is not None:
            return rtype
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'borrow':
            return None
        if isinstance(expr, ast.UnaryExpr) and expr.op in {'move', 'copy'}:
            return self.tracked_type_from_expr(expr.expr, states)
        place = self.normalized_resource_place(expr, states, mutable_alias_only=False)
        if place is not None:
            return self.lookup_tracked_binding(place, states)
        return None

    def lookup_tracked_binding(self, place: str | SemPlace, states: list[FlowState]) -> str | None:
        sem_place = self.sem_place_from_path(place) if isinstance(place, str) else place
        if sem_place is None:
            return None
        root = sem_place.root
        field_parts = [proj.value for proj in sem_place.projections if proj.kind == 'field']
        for state in states:
            for frame in reversed(state.active_scopes):
                for binding_name, binding_type in reversed(frame.bindings):
                    if binding_name == root:
                        current_type: str | None = binding_type
                        for part in field_parts:
                            current_type = self.field_tracked_type(current_type, str(part))
                            if current_type is None:
                                break
                        return current_type
        return None

    def field_tracked_type(self, owner_type: str | None, field_name: str) -> str | None:
        if owner_type is None:
            return None
        if owner_type in self._structs:
            for field in self._structs[owner_type].fields:
                if field.name == field_name:
                    return self._typechecker.resource_type_name(field.typ)
        if owner_type in self._resources:
            for field in self._resources[owner_type].fields:
                if field.name == field_name:
                    return self._typechecker.resource_type_name(field.typ)
        return None

    def type_contains_tracked_ownership(self, typ: ast.Type, seen: set[str] | None = None) -> bool:
        _ = seen
        return self._typechecker.type_contains_tracked_ownership(typ)

    def resource_type_from_type(self, typ: ast.Type | None) -> str | None:
        return self._typechecker.resource_type_name(typ)

    def borrow_mode_from_expected_type(self, typ: ast.Type | None) -> str:
        if typ is None:
            return 'const'
        return self._typechecker.type_facts_for_type(typ).ref_mode or 'const'

    def resource_ctor_type(self, expr: ast.Expr) -> str | None:
        if isinstance(expr, ast.StructLiteralExpr):
            if expr.name in self._resources:
                return expr.name
            if expr.name in self._structs and self.type_contains_tracked_ownership(ast.NamedType(expr.name)):
                return expr.name
        if isinstance(expr, ast.CallExpr):
            if isinstance(expr.callee, ast.NameExpr) and expr.callee.name in self._functions:
                return self.resource_type_from_type(self._functions[expr.callee.name].return_type)
        return None

    def enter_scope(self, scopes: tuple[ScopeFrame, ...]) -> tuple[ScopeFrame, ...]:
        return scopes + (ScopeFrame(),)

    def add_cleanup(self, scopes: tuple[ScopeFrame, ...], action: CleanupAction) -> tuple[ScopeFrame, ...]:
        if not scopes:
            return (ScopeFrame(cleanups=(action,)),)
        top = scopes[-1]
        updated = ScopeFrame(cleanups=top.cleanups + (action,), bindings=top.bindings, borrows=top.borrows, ref_aliases=top.ref_aliases)
        return scopes[:-1] + (updated,)

    def add_binding(self, scopes: tuple[ScopeFrame, ...], name: str, type_name: str) -> tuple[ScopeFrame, ...]:
        if not scopes:
            return (ScopeFrame(bindings=((name, type_name),)),)
        top = scopes[-1]
        updated = ScopeFrame(cleanups=top.cleanups, bindings=top.bindings + ((name, type_name),), borrows=top.borrows, ref_aliases=top.ref_aliases)
        return scopes[:-1] + (updated,)


    def find_ref_alias_scope_index(self, scopes: tuple[ScopeFrame, ...], alias_name: str) -> int | None:
        for idx in range(len(scopes) - 1, -1, -1):
            if any(entry.alias_name == alias_name for entry in scopes[idx].ref_aliases):
                return idx
        return None

    def add_ref_alias_at_scope(self, scopes: tuple[ScopeFrame, ...], scope_index: int | None, alias_name: str, target_place: SemPlace, mode: str) -> tuple[ScopeFrame, ...]:
        if not scopes:
            return (ScopeFrame(ref_aliases=(RefAliasEntry(alias_name=alias_name, target_place=target_place, mode=mode),)),)
        idx = len(scopes) - 1 if scope_index is None or scope_index < 0 or scope_index >= len(scopes) else scope_index
        frames = list(scopes)
        frame = frames[idx]
        aliases = [entry for entry in frame.ref_aliases if entry.alias_name != alias_name]
        aliases.append(RefAliasEntry(alias_name=alias_name, target_place=target_place, mode=mode))
        frames[idx] = ScopeFrame(cleanups=frame.cleanups, bindings=frame.bindings, borrows=frame.borrows, ref_aliases=tuple(aliases))
        return tuple(frames)

    def add_ref_alias(self, scopes: tuple[ScopeFrame, ...], alias_name: str, target_place: SemPlace, mode: str) -> tuple[ScopeFrame, ...]:
        if not scopes:
            return (ScopeFrame(ref_aliases=(RefAliasEntry(alias_name=alias_name, target_place=target_place, mode=mode),)),)
        top = scopes[-1]
        aliases = [entry for entry in top.ref_aliases if entry.alias_name != alias_name]
        aliases.append(RefAliasEntry(alias_name=alias_name, target_place=target_place, mode=mode))
        updated = ScopeFrame(cleanups=top.cleanups, bindings=top.bindings, borrows=top.borrows, ref_aliases=tuple(aliases))
        return scopes[:-1] + (updated,)

    def remove_ref_alias(self, scopes: tuple[ScopeFrame, ...], alias_name: str) -> tuple[ScopeFrame, ...]:
        if not scopes:
            return scopes
        top = scopes[-1]
        aliases = tuple(entry for entry in top.ref_aliases if entry.alias_name != alias_name)
        if aliases == top.ref_aliases:
            return scopes
        updated = ScopeFrame(cleanups=top.cleanups, bindings=top.bindings, borrows=top.borrows, ref_aliases=aliases)
        return scopes[:-1] + (updated,)

    def add_borrow_marks(self, scopes: tuple[ScopeFrame, ...], borrow_marks: list[BorrowMark]) -> tuple[ScopeFrame, ...]:
        if not borrow_marks:
            return scopes
        if not scopes:
            return (ScopeFrame(borrows=tuple(borrow_marks)),)
        top = scopes[-1]
        merged = list(top.borrows)
        merged.extend(borrow_marks)
        updated = ScopeFrame(cleanups=top.cleanups, bindings=top.bindings, borrows=tuple(merged), ref_aliases=top.ref_aliases)
        return scopes[:-1] + (updated,)

    def pop_ops_for_frame(self, frame: ScopeFrame) -> list[OwnershipOp]:
        borrow_ops = [self.make_op(kind='end_borrow', name=mark.path, borrow_mode=mark.mode, place=mark.place) for mark in reversed(frame.borrows)]
        alias_ops = [self.make_op(kind='clear_ref_alias', name=entry.alias_name) for entry in reversed(frame.ref_aliases)]
        binding_ops = [self.make_op(kind='scope_pop', name=name, type_name=type_name) for name, type_name in reversed(frame.bindings)]
        return borrow_ops + alias_ops + binding_ops

    def leave_one_scope(
        self,
        scopes: tuple[ScopeFrame, ...],
        error_path: bool,
    ) -> tuple[tuple[ScopeFrame, ...], list[CleanupAction], list[OwnershipOp]]:
        if not scopes:
            return tuple(), [], []
        top = scopes[-1]
        cleanup = [action for action in reversed(top.cleanups) if error_path or not action.error_only]
        pops = self.pop_ops_for_frame(top)
        return scopes[:-1], cleanup, pops

    def leave_to_depth(
        self,
        scopes: tuple[ScopeFrame, ...],
        depth: int,
        error_path: bool,
    ) -> tuple[tuple[ScopeFrame, ...], list[CleanupAction], list[OwnershipOp]]:
        cleanup: list[CleanupAction] = []
        pops: list[OwnershipOp] = []
        current = scopes
        while len(current) > depth:
            current, inner_cleanup, inner_pops = self.leave_one_scope(current, error_path)
            cleanup.extend(inner_cleanup)
            pops.extend(inner_pops)
        return current, cleanup, pops

    def leave_all_scopes(
        self,
        scopes: tuple[ScopeFrame, ...],
        error_path: bool,
    ) -> tuple[tuple[ScopeFrame, ...], list[CleanupAction], list[OwnershipOp]]:
        return self.leave_to_depth(scopes, 0, error_path)

    def new_node(self, kind: str, label: str, ops: list[OwnershipOp] | None = None) -> int:
        node_id = self._next_node_id
        self._next_node_id += 1
        self._nodes.append(CFGNode(id=node_id, kind=kind, label=label, ownership_ops=list(ops or [])))
        return node_id

    def add_edge(
        self,
        src: int,
        dst: int,
        kind: str,
        cleanup: list[CleanupAction] | None = None,
        pop_ops: list[OwnershipOp] | None = None,
    ) -> None:
        cleanup = list(cleanup or [])
        pop_ops = list(pop_ops or [])
        pre_cleanup_ops = [op for op in pop_ops if op.kind == 'end_borrow']
        post_cleanup_ops = [op for op in pop_ops if op.kind != 'end_borrow']
        self._edges.append(
            CFGEdge(
                src=src,
                dst=dst,
                kind=kind,
                cleanup=[action.text for action in cleanup],
                cleanup_actions=cleanup,
                pre_cleanup_ops=pre_cleanup_ops,
                post_cleanup_ops=post_cleanup_ops,
                pop_bindings=[op.name for op in post_cleanup_ops if op.name is not None],
            )
        )

    def pattern_binds_names(self, pattern: ast.Pattern) -> bool:
        if isinstance(pattern, ast.NamePattern):
            return pattern.name != '_'
        if isinstance(pattern, ast.SomePattern | ast.OkPattern):
            return self.pattern_binds_names(pattern.inner)
        if isinstance(pattern, ast.EnumPattern):
            return any(self.pattern_binds_names(inner) for _, inner in pattern.fields)
        return False

    def pattern_bound_names(self, pattern: ast.Pattern) -> set[str]:
        names: set[str] = set()
        if isinstance(pattern, ast.NamePattern):
            if pattern.name != '_':
                names.add(pattern.name)
            return names
        if isinstance(pattern, ast.SomePattern | ast.OkPattern):
            return self.pattern_bound_names(pattern.inner)
        if isinstance(pattern, ast.EnumPattern):
            for _, inner in pattern.fields:
                names.update(self.pattern_bound_names(inner))
        return names

    def cleanup_pattern_binding_context(
        self,
        pattern: ast.Pattern,
        scrutinee_expr: ast.Expr,
        scrutinee_type: ast.Type,
        states: list[FlowState],
    ) -> tuple[list[FlowState], dict[str, ast.Expr], tuple[OwnershipOp, ...], tuple[OwnershipOp, ...]] | None:
        pattern_scope: tuple[ScopeFrame, ...] = (ScopeFrame(),)
        setup_ops: list[OwnershipOp] = []

        def walk(
            current_pattern: ast.Pattern,
            current_expr: ast.Expr,
            current_type: ast.Type,
            current_scope: tuple[ScopeFrame, ...],
        ) -> tuple[tuple[ScopeFrame, ...], dict[str, ast.Expr]] | None:
            if isinstance(current_pattern, ast.WildcardPattern | ast.NonePattern | ast.LiteralPattern | ast.ErrorPattern):
                return current_scope, {}
            if isinstance(current_pattern, ast.NamePattern):
                if current_pattern.name == '_':
                    return current_scope, {}
                mode = self.ref_alias_mode_from_type(current_type)
                if mode is not None:
                    referent_expr = current_expr.expr if isinstance(current_expr, ast.UnaryExpr) and current_expr.op == 'borrow' else current_expr
                    target_place = self.referent_place(referent_expr, states, mutable_alias_only=(mode == 'mut'))
                    if target_place is None:
                        return None
                    setup_ops.append(self.make_op(kind='define_ref_alias', name=current_pattern.name, borrow_mode=mode, aux_place=target_place))
                    return self.add_ref_alias(current_scope, current_pattern.name, target_place, mode), {}
                return current_scope, {current_pattern.name: copy.deepcopy(current_expr)}
            if isinstance(current_pattern, ast.SomePattern):
                if not isinstance(current_expr, ast.SomeExpr):
                    return None
                inner_type = self._typechecker.option_inner_type(current_type)
                if inner_type is None:
                    return None
                return walk(current_pattern.inner, current_expr.value, inner_type, current_scope)
            if isinstance(current_pattern, ast.OkPattern):
                return None
            if isinstance(current_pattern, ast.EnumPattern):
                if not isinstance(current_expr, ast.EnumLiteralExpr):
                    return None
                current_norm = self._typechecker.normalize_type(current_type)
                enum_decl = self._typechecker.enums.get(current_norm.name) if isinstance(current_norm, ast.NamedType) else None
                if enum_decl is None:
                    return None
                if current_pattern.parts:
                    if current_pattern.parts[0] != enum_decl.name:
                        return None
                    if len(current_pattern.parts) > 1 and current_pattern.parts[1] != current_expr.variant_name:
                        return None
                field_types = {field.name: field.typ for field in self._typechecker.find_variant_fields(enum_decl, current_expr.variant_name)}
                field_values = {name: value for name, value in current_expr.fields}
                substitutions: dict[str, ast.Expr] = {}
                scope_state = current_scope
                for field_name, inner_pattern in current_pattern.fields:
                    if field_name not in field_values or field_name not in field_types:
                        return None
                    inner_result = walk(inner_pattern, field_values[field_name], field_types[field_name], scope_state)
                    if inner_result is None:
                        return None
                    scope_state, inner_subst = inner_result
                    substitutions.update(inner_subst)
                return scope_state, substitutions
            return None

        result = walk(pattern, scrutinee_expr, scrutinee_type, pattern_scope)
        if result is None:
            return None
        scoped_pattern, substitutions = result
        frame = scoped_pattern[-1] if scoped_pattern else ScopeFrame()
        pattern_states = [FlowState(node_id=state.node_id, active_scopes=state.active_scopes + (frame,)) for state in states] if (frame.bindings or frame.borrows or frame.ref_aliases) else states
        pop_ops = tuple(self.pop_ops_for_frame(frame)) if (frame.bindings or frame.borrows or frame.ref_aliases) else ()
        return pattern_states, substitutions, tuple(setup_ops), pop_ops

    def cleanup_pattern_can_match(self, pattern: ast.Pattern, scrutinee_expr: ast.Expr) -> bool | None:
        if isinstance(pattern, ast.WildcardPattern | ast.NamePattern):
            return True
        if isinstance(pattern, ast.SomePattern):
            if isinstance(scrutinee_expr, ast.SomeExpr):
                return True
            if isinstance(scrutinee_expr, ast.NoneExpr):
                return False
            return None
        if isinstance(pattern, ast.NonePattern):
            if isinstance(scrutinee_expr, ast.NoneExpr):
                return True
            if isinstance(scrutinee_expr, ast.SomeExpr):
                return False
            return None
        if isinstance(pattern, ast.LiteralPattern):
            if isinstance(pattern.value, ast.BoolExpr) and isinstance(scrutinee_expr, ast.BoolExpr):
                return pattern.value.value == scrutinee_expr.value
            if isinstance(pattern.value, ast.UnitExpr) and isinstance(scrutinee_expr, ast.UnitExpr):
                return True
            return None
        if isinstance(pattern, ast.EnumPattern):
            if not isinstance(scrutinee_expr, ast.EnumLiteralExpr):
                return None
            if pattern.parts:
                if pattern.parts[0] != scrutinee_expr.enum_name:
                    return False
                if len(pattern.parts) > 1 and pattern.parts[1] != scrutinee_expr.variant_name:
                    return False
            return True
        return None

    def substitute_cleanup_pattern_names(self, expr: ast.Expr, substitutions: dict[str, ast.Expr]) -> ast.Expr:
        if not substitutions:
            return expr
        if isinstance(expr, ast.NameExpr):
            if expr.name in substitutions:
                return copy.deepcopy(substitutions[expr.name])
            return expr
        if isinstance(expr, ast.SomeExpr):
            return ast.SomeExpr(self.substitute_cleanup_pattern_names(expr.value, substitutions))
        if isinstance(expr, ast.UnaryExpr):
            return ast.UnaryExpr(expr.op, self.substitute_cleanup_pattern_names(expr.expr, substitutions))
        if isinstance(expr, ast.BinaryExpr):
            return ast.BinaryExpr(
                self.substitute_cleanup_pattern_names(expr.left, substitutions),
                expr.op,
                self.substitute_cleanup_pattern_names(expr.right, substitutions),
            )
        if isinstance(expr, ast.RangeExpr):
            return ast.RangeExpr(
                self.substitute_cleanup_pattern_names(expr.start, substitutions),
                self.substitute_cleanup_pattern_names(expr.stop, substitutions),
            )
        if isinstance(expr, ast.CallExpr):
            return ast.CallExpr(
                self.substitute_cleanup_pattern_names(expr.callee, substitutions),
                [self.substitute_cleanup_pattern_names(arg, substitutions) for arg in expr.args],
            )
        if isinstance(expr, ast.AttrExpr):
            return ast.AttrExpr(self.substitute_cleanup_pattern_names(expr.obj, substitutions), expr.name)
        if isinstance(expr, ast.IndexExpr):
            return ast.IndexExpr(
                self.substitute_cleanup_pattern_names(expr.obj, substitutions),
                self.substitute_cleanup_pattern_names(expr.index, substitutions),
            )
        if isinstance(expr, ast.SliceExpr):
            return ast.SliceExpr(
                self.substitute_cleanup_pattern_names(expr.obj, substitutions),
                None if expr.start is None else self.substitute_cleanup_pattern_names(expr.start, substitutions),
                None if expr.stop is None else self.substitute_cleanup_pattern_names(expr.stop, substitutions),
            )
        if isinstance(expr, ast.TryExpr):
            return ast.TryExpr(self.substitute_cleanup_pattern_names(expr.expr, substitutions))
        if isinstance(expr, ast.CatchExpr):
            return ast.CatchExpr(
                self.substitute_cleanup_pattern_names(expr.expr, substitutions),
                self.substitute_cleanup_pattern_names(expr.fallback, substitutions),
            )
        if isinstance(expr, ast.CastExpr):
            return ast.CastExpr(expr.typ, self.substitute_cleanup_pattern_names(expr.expr, substitutions))
        if isinstance(expr, ast.StructLiteralExpr):
            return ast.StructLiteralExpr(
                expr.name,
                [(name, self.substitute_cleanup_pattern_names(value, substitutions)) for name, value in expr.fields],
            )
        if isinstance(expr, ast.EnumLiteralExpr):
            return ast.EnumLiteralExpr(
                expr.enum_name,
                expr.variant_name,
                [(name, self.substitute_cleanup_pattern_names(value, substitutions)) for name, value in expr.fields],
            )
        if isinstance(expr, ast.MatchExpr):
            rebuilt_arms: list[ast.MatchArm] = []
            for arm in expr.arms:
                shadowed = self.pattern_bound_names(arm.pattern)
                inner_subst = {name: value for name, value in substitutions.items() if name not in shadowed}
                rebuilt_arms.append(ast.MatchArm(arm.pattern, self.substitute_cleanup_pattern_names(arm.expr, inner_subst)))
            return ast.MatchExpr(self.substitute_cleanup_pattern_names(expr.expr, substitutions), rebuilt_arms)
        return expr

    def cleanup_alternatives_for_expr_stmt(
        self,
        stmt: ast.ExprStmt,
        states: list[FlowState],
    ) -> tuple[tuple[OwnershipOp, ...], ...] | None:
        expr = stmt.expr
        direct_match = expr if isinstance(expr, ast.MatchExpr) else None
        nested = None if direct_match is not None else self.find_rebuildable_nested_match(expr, states)
        if direct_match is None and (nested is None or not nested.prefix_safe):
            return None
        match_expr = direct_match or nested.match_expr
        assert match_expr is not None
        scrutinee_ops = tuple(self.expr_ownership_ops(match_expr.expr, states))
        scrutinee_type = self.infer_expr_type(match_expr.expr)
        alternatives: list[tuple[OwnershipOp, ...]] = []
        for arm in match_expr.arms:
            arm_possible = self.cleanup_pattern_can_match(arm.pattern, match_expr.expr)
            if arm_possible is False:
                continue
            rebuilt = arm.expr if direct_match is not None else nested.replace(arm.expr)
            arm_states = states
            pattern_setup_ops: tuple[OwnershipOp, ...] = ()
            pattern_pop_ops: tuple[OwnershipOp, ...] = ()
            self.bind_match_arm_pattern(arm.pattern, scrutinee_type)
            try:
                if self.pattern_binds_names(arm.pattern):
                    binding_context = self.cleanup_pattern_binding_context(arm.pattern, match_expr.expr, scrutinee_type, states)
                    if binding_context is None:
                        return None
                    arm_states, substitutions, pattern_setup_ops, pattern_pop_ops = binding_context
                    rebuilt = self.substitute_cleanup_pattern_names(rebuilt, substitutions)
                arm_stmt = ast.ExprStmt(rebuilt)
                nested_alternatives = self.cleanup_alternatives_for_expr_stmt(arm_stmt, arm_states)
                if nested_alternatives is not None:
                    for alt in nested_alternatives:
                        alternatives.append(scrutinee_ops + pattern_setup_ops + alt + pattern_pop_ops)
                else:
                    alternatives.append(scrutinee_ops + pattern_setup_ops + tuple(self.ownership_ops_for_stmt(arm_stmt, arm_states)) + pattern_pop_ops)
            finally:
                self._type_scopes.pop()
        return tuple(alternatives)

    def cleanup_action_for_stmt(
        self,
        stmt: ast.Stmt,
        states: list[FlowState],
        error_only: bool,
    ) -> CleanupAction:
        alternatives: tuple[tuple[OwnershipOp, ...], ...] = ()
        if isinstance(stmt, ast.ExprStmt):
            derived = self.cleanup_alternatives_for_expr_stmt(stmt, states)
            if derived is not None:
                alternatives = derived
        return CleanupAction(
            text=self.stmt_text(stmt),
            error_only=error_only,
            ops=tuple(self.ownership_ops_for_stmt(stmt, states)),
            alternative_ops=alternatives,
        )

    def find_exit(self, suffix: str) -> int:
        for node in self._nodes:
            if node.kind == 'exit' and node.label.endswith(suffix):
                return node.id
        raise KeyError(suffix)


def build_cfg(module: ast.Module, imported_signatures: dict | None = None) -> CFGModule:
    return CFGBuilder(module, imported_signatures=imported_signatures).build()
