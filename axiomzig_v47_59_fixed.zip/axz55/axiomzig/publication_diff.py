from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

CLASS_ORDER = {'metadata-only': 0, 'compatible': 1, 'incompatible': 2}

@dataclass(slots=True)
class ManifestDiffIssue:
    category: str
    classification: str
    code: str
    path: str
    message: str
    old: Any = None
    new: Any = None

@dataclass(slots=True)
class ManifestDiffResult:
    classification: str = 'metadata-only'
    issues: list[ManifestDiffIssue] = field(default_factory=list)

def _join(a: str, b: str) -> str:
    return a if CLASS_ORDER[a] >= CLASS_ORDER[b] else b

def _get(m: dict[str, Any], k: str, d: Any = None) -> Any:
    return m.get(k, d)

def _module_decl_map(m: dict[str, Any], key: str) -> dict[str, list[str]]:
    raw = _get(m, key, {}) or {}
    if not raw and isinstance(_get(m, 'package_interface', None), dict):
        raw = _get(m['package_interface'], key.replace('exported_', 'public_'), {}) or {}
    return {str(mod): sorted(str(item) for item in items) for mod, items in raw.items()}


def _module_functions(m: dict[str, Any]) -> dict[str, list[str]]:
    return _module_decl_map(m, 'exported_functions')


def _module_resources(m: dict[str, Any]) -> dict[str, list[str]]:
    return _module_decl_map(m, 'exported_resources')


def _module_protocols(m: dict[str, Any]) -> dict[str, list[str]]:
    return _module_decl_map(m, 'exported_protocols')


def _signature_map(m: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for _mod, bundle in (_get(m, 'internal_signatures', {}) or {}).items():
        if not isinstance(bundle, dict):
            continue
        for fn in bundle.get('functions', []) or []:
            if isinstance(fn, dict) and fn.get('name'):
                out[str(fn['name'])] = fn
    return out


def _metadata_map(m: dict[str, Any], key: str = 'public_function_metadata') -> dict[str, Any]:
    raw = _get(m, key, {}) or {}
    if not raw and isinstance(_get(m, 'package_interface', None), dict):
        raw = _get(m['package_interface'], key, {}) or {}
    out: dict[str, Any] = {}
    for _mod, items in raw.items():
        if isinstance(items, dict):
            for name, meta in items.items():
                out[str(name)] = meta
    return out




def _shape_map(m: dict[str, Any], key: str) -> dict[str, Any]:
    raw = _get(m, key, {}) or {}
    if not raw and isinstance(_get(m, 'package_interface', None), dict):
        raw = _get(m['package_interface'], key, {}) or {}
    out: dict[str, Any] = {}
    for _mod, items in raw.items():
        if isinstance(items, dict):
            for name, shape in items.items():
                out[str(name)] = shape
    return out


def _field_map(shape: Any) -> dict[str, str]:
    if not isinstance(shape, dict):
        return {}
    out: dict[str, str] = {}
    for item in shape.get('fields', []) or []:
        if isinstance(item, dict) and item.get('name'):
            out[str(item['name'])] = str(item.get('type', ''))
    return out


def _transition_map(shape: Any) -> dict[str, tuple[str, str]]:
    if not isinstance(shape, dict):
        return {}
    out: dict[str, tuple[str, str]] = {}
    for item in shape.get('transitions', []) or []:
        if isinstance(item, dict) and item.get('name'):
            out[str(item['name'])] = (str(item.get('source', '')), str(item.get('target', '')))
    return out


def _sorted_strings(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return sorted(str(item) for item in value)


def _diff_resource_shapes(result: ManifestDiffResult, old: dict[str, Any], new: dict[str, Any]) -> None:
    old_shapes = _shape_map(old, 'public_resource_shapes')
    new_shapes = _shape_map(new, 'public_resource_shapes')
    for name in sorted(set(old_shapes) & set(new_shapes)):
        old_shape = old_shapes.get(name) or {}
        new_shape = new_shapes.get(name) or {}
        old_protocol = old_shape.get('protocol') if isinstance(old_shape, dict) else None
        new_protocol = new_shape.get('protocol') if isinstance(new_shape, dict) else None
        if old_protocol != new_protocol:
            _add(result, category='resource_shape', classification='incompatible', code='E_PUBLIC_RESOURCE_PROTOCOL_CHANGED', path=f'public_resource_shapes.{name}.protocol', message=f'public resource protocol binding changed: {name}', old=old_protocol, new=new_protocol)
        old_fields = _field_map(old_shape)
        new_fields = _field_map(new_shape)
        for field in sorted(set(old_fields) - set(new_fields)):
            _add(result, category='resource_shape', classification='incompatible', code='E_PUBLIC_RESOURCE_FIELD_REMOVED', path=f'public_resource_shapes.{name}.fields.{field}', message=f'public resource field removed: {name}.{field}', old=old_fields[field], new=None)
        for field in sorted(set(new_fields) - set(old_fields)):
            _add(result, category='resource_shape', classification='compatible', code='C_PUBLIC_RESOURCE_FIELD_ADDED', path=f'public_resource_shapes.{name}.fields.{field}', message=f'public resource field added: {name}.{field}', old=None, new=new_fields[field])
        for field in sorted(set(old_fields) & set(new_fields)):
            if old_fields[field] != new_fields[field]:
                _add(result, category='resource_shape', classification='incompatible', code='E_PUBLIC_RESOURCE_FIELD_TYPE_CHANGED', path=f'public_resource_shapes.{name}.fields.{field}', message=f'public resource field type changed: {name}.{field}', old=old_fields[field], new=new_fields[field])


def _diff_protocol_shapes(result: ManifestDiffResult, old: dict[str, Any], new: dict[str, Any]) -> None:
    old_shapes = _shape_map(old, 'public_protocol_shapes')
    new_shapes = _shape_map(new, 'public_protocol_shapes')
    for name in sorted(set(old_shapes) & set(new_shapes)):
        old_shape = old_shapes.get(name) or {}
        new_shape = new_shapes.get(name) or {}
        old_init = old_shape.get('init') if isinstance(old_shape, dict) else None
        new_init = new_shape.get('init') if isinstance(new_shape, dict) else None
        if old_init != new_init:
            _add(result, category='protocol_shape', classification='incompatible', code='E_PUBLIC_PROTOCOL_INIT_CHANGED', path=f'public_protocol_shapes.{name}.init', message=f'public protocol init state changed: {name}', old=old_init, new=new_init)
        old_states = set(_sorted_strings(old_shape.get('states', []) if isinstance(old_shape, dict) else []))
        new_states = set(_sorted_strings(new_shape.get('states', []) if isinstance(new_shape, dict) else []))
        for state in sorted(old_states - new_states):
            _add(result, category='protocol_shape', classification='incompatible', code='E_PUBLIC_PROTOCOL_STATE_REMOVED', path=f'public_protocol_shapes.{name}.states.{state}', message=f'public protocol state removed: {name}.{state}', old=state, new=None)
        for state in sorted(new_states - old_states):
            _add(result, category='protocol_shape', classification='compatible', code='C_PUBLIC_PROTOCOL_STATE_ADDED', path=f'public_protocol_shapes.{name}.states.{state}', message=f'public protocol state added: {name}.{state}', old=None, new=state)
        old_terminal = set(_sorted_strings(old_shape.get('terminal', []) if isinstance(old_shape, dict) else []))
        new_terminal = set(_sorted_strings(new_shape.get('terminal', []) if isinstance(new_shape, dict) else []))
        for state in sorted(old_terminal - new_terminal):
            _add(result, category='protocol_shape', classification='incompatible', code='E_PUBLIC_PROTOCOL_TERMINAL_REMOVED', path=f'public_protocol_shapes.{name}.terminal.{state}', message=f'public protocol terminal state removed: {name}.{state}', old=state, new=None)
        for state in sorted(new_terminal - old_terminal):
            _add(result, category='protocol_shape', classification='compatible', code='C_PUBLIC_PROTOCOL_TERMINAL_ADDED', path=f'public_protocol_shapes.{name}.terminal.{state}', message=f'public protocol terminal state added: {name}.{state}', old=None, new=state)
        old_transitions = _transition_map(old_shape)
        new_transitions = _transition_map(new_shape)
        for transition in sorted(set(old_transitions) - set(new_transitions)):
            _add(result, category='protocol_shape', classification='incompatible', code='E_PUBLIC_PROTOCOL_TRANSITION_REMOVED', path=f'public_protocol_shapes.{name}.transitions.{transition}', message=f'public protocol transition removed: {name}.{transition}', old=old_transitions[transition], new=None)
        for transition in sorted(set(new_transitions) - set(old_transitions)):
            _add(result, category='protocol_shape', classification='compatible', code='C_PUBLIC_PROTOCOL_TRANSITION_ADDED', path=f'public_protocol_shapes.{name}.transitions.{transition}', message=f'public protocol transition added: {name}.{transition}', old=None, new=new_transitions[transition])
        for transition in sorted(set(old_transitions) & set(new_transitions)):
            if old_transitions[transition] != new_transitions[transition]:
                _add(result, category='protocol_shape', classification='incompatible', code='E_PUBLIC_PROTOCOL_TRANSITION_CHANGED', path=f'public_protocol_shapes.{name}.transitions.{transition}', message=f'public protocol transition changed: {name}.{transition}', old=old_transitions[transition], new=new_transitions[transition])

def _dep_refs(m: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for idx, item in enumerate(_get(m, 'dependency_publication_refs', []) or []):
        if isinstance(item, dict):
            key = str(item.get('package_id') or item.get('package_name') or idx)
            out[key] = item
    return out

def _dep_closure_records(m: dict[str, Any]) -> dict[str, Any]:
    raw = _get(m, 'dependency_publication_closure', []) or []
    if not raw:
        raw = _get(m, 'dependency_publication_refs', []) or []
    out: dict[str, Any] = {}
    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            continue
        package_id = str(item.get('package_id') or idx)
        package_name = str(item.get('package_name') or package_id.rsplit('@', 1)[0])
        key = package_name or package_id
        out[key] = item
    return out


def _surface_publication_manifest(record: Any) -> dict[str, Any] | None:
    if not isinstance(record, dict):
        return None
    surface = record.get('public_surface')
    if not isinstance(surface, dict):
        return None
    package_name = str(record.get('package_name') or record.get('package_id') or 'dependency')
    package_version = str(record.get('package_version') or '')
    package_id = str(record.get('package_id') or (f'{package_name}@{package_version}' if package_version else package_name))
    manifest: dict[str, Any] = {
        'schema_version': 'axiomzig.publication_manifest.v1',
        'package_name': package_name,
        'package_version': package_version,
        'package_id': package_id,
        'manifest_hash': str(record.get('manifest_hash') or record.get('public_surface_digest') or ''),
    }
    manifest.update(surface)
    return manifest


def _diff_dependency_closure(result: ManifestDiffResult, old: dict[str, Any], new: dict[str, Any]) -> None:
    old_closure = _dep_closure_records(old)
    new_closure = _dep_closure_records(new)
    for package_name in sorted(set(old_closure) - set(new_closure)):
        item = old_closure[package_name]
        package_id = item.get('package_id') if isinstance(item, dict) else package_name
        _add(result, category='dependency_closure', classification='incompatible', code='E_DEPENDENCY_CLOSURE_REMOVED', path=f'dependency_publication_closure.{package_name}', message=f'dependency closure package removed: {package_id}', old=item, new=None)
    for package_name in sorted(set(new_closure) - set(old_closure)):
        item = new_closure[package_name]
        package_id = item.get('package_id') if isinstance(item, dict) else package_name
        _add(result, category='dependency_closure', classification='compatible', code='C_DEPENDENCY_CLOSURE_ADDED', path=f'dependency_publication_closure.{package_name}', message=f'dependency closure package added: {package_id}', old=None, new=item)
    for package_name in sorted(set(old_closure) & set(new_closure)):
        old_item = old_closure[package_name]
        new_item = new_closure[package_name]
        old_id = str(old_item.get('package_id', '')) if isinstance(old_item, dict) else ''
        new_id = str(new_item.get('package_id', '')) if isinstance(new_item, dict) else ''
        old_digest = str(old_item.get('public_surface_digest') or old_item.get('manifest_hash') or '') if isinstance(old_item, dict) else ''
        new_digest = str(new_item.get('public_surface_digest') or new_item.get('manifest_hash') or '') if isinstance(new_item, dict) else ''
        old_surface = _surface_publication_manifest(old_item)
        new_surface = _surface_publication_manifest(new_item)
        if old_surface is not None and new_surface is not None and old_surface != new_surface:
            nested = diff_publication_manifests(old_surface, new_surface)
            for issue in nested.get('issues', []):
                if issue.get('category') == 'metadata' and issue.get('path') in {'package_version', 'package_id', 'manifest_hash'}:
                    continue
                _add(
                    result,
                    category='dependency_closure_api',
                    classification=str(issue.get('classification', 'metadata-only')),
                    code=f'DEP_{issue.get("code", "PUBLIC_API_CHANGED")}',
                    path=f'dependency_publication_closure.{package_name}.{issue.get("path", "surface")}',
                    message=f'dependency public surface changed for {package_name}: {issue.get("message", "public surface changed")}',
                    old=issue.get('old'),
                    new=issue.get('new'),
                )
        if old_id != new_id or old_digest != new_digest:
            _add(
                result,
                category='dependency_closure',
                classification='compatible',
                code='C_DEPENDENCY_CLOSURE_PIN_CHANGED',
                path=f'dependency_publication_closure.{package_name}',
                message=f'dependency closure pin changed: {package_name}',
                old={'package_id': old_id, 'digest': old_digest},
                new={'package_id': new_id, 'digest': new_digest},
            )

def _add(r: ManifestDiffResult, *, category: str, classification: str, code: str, path: str, message: str, old: Any = None, new: Any = None) -> None:
    r.classification = _join(r.classification, classification)
    r.issues.append(ManifestDiffIssue(category, classification, code, path, message, old, new))

def _dep_policy(m: dict[str, Any]) -> dict[str, Any]:
    compat = _get(m, 'api_compatibility', {}) or {}
    if not isinstance(compat, dict):
        return {}
    return {
        'language_version': compat.get('language_version'),
        'dependency_version_ranges': compat.get('dependency_version_ranges', {}) or {},
    }

def _stability(meta: Any) -> str | None:
    return str(meta.get('stability')) if isinstance(meta, dict) and meta.get('stability') is not None else None

def _diff_decl_set(
    result: ManifestDiffResult,
    old_items: set[str],
    new_items: set[str],
    *,
    kind: str,
    category: str,
    exported_key: str,
) -> None:
    upper = kind.upper()
    for item in sorted(old_items - new_items):
        _add(result, category=category, classification='incompatible', code=f'E_PUBLIC_{upper}_REMOVED', path=f'{exported_key}.{item}', message=f'public {kind} removed: {item}', old=item, new=None)
    for item in sorted(new_items - old_items):
        _add(result, category=category, classification='compatible', code=f'C_PUBLIC_{upper}_ADDED', path=f'{exported_key}.{item}', message=f'public {kind} added: {item}', old=None, new=item)


def _diff_metadata_map(
    result: ManifestDiffResult,
    old: dict[str, Any],
    new: dict[str, Any],
    *,
    kind: str,
    metadata_key: str,
) -> None:
    old_meta = _metadata_map(old, metadata_key)
    new_meta = _metadata_map(new, metadata_key)
    for name in sorted(set(old_meta) | set(new_meta)):
        if old_meta.get(name) == new_meta.get(name):
            continue
        old_stab = _stability(old_meta.get(name))
        new_stab = _stability(new_meta.get(name))
        if old_stab != new_stab:
            if old_stab == 'stable' and new_stab in {'deprecated', 'experimental'}:
                cls, code = 'compatible', 'C_API_LIFECYCLE_NARROWED'
            elif old_stab == 'deprecated' and new_stab == 'stable':
                cls, code = 'compatible', 'C_API_LIFECYCLE_RESTORED'
            else:
                cls, code = 'metadata-only', 'M_API_LIFECYCLE_CHANGED'
            _add(result, category='api_lifecycle', classification=cls, code=code, path=f'{metadata_key}.{name}.stability', message=f'API lifecycle changed for public {kind} {name}: {old_stab!r} -> {new_stab!r}', old=old_meta.get(name), new=new_meta.get(name))
        else:
            _add(result, category='api_lifecycle', classification='metadata-only', code='M_API_LIFECYCLE_METADATA_CHANGED', path=f'{metadata_key}.{name}', message=f'API lifecycle metadata changed for public {kind} {name}', old=old_meta.get(name), new=new_meta.get(name))


def diff_publication_manifests(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    # Validate schema versions.  pubdiff operates on publication manifests only;
    # package-interface files (axiomzig.package_interface.v1) silently have no
    # exported_functions and would produce misleading empty diffs.
    _ACCEPTED = {'axiomzig.publication_manifest.v1'}
    for label, m in [('old', old), ('new', new)]:
        sv = m.get('schema_version', '')
        if sv and sv not in _ACCEPTED:
            raise ValueError(
                f'pubdiff requires axiomzig.publication_manifest.v1 manifests; '
                f'{label} manifest has schema_version {sv!r}.  '
                f'Generate publication manifests with \'conform --publication-out\'.'
            )
    result = ManifestDiffResult()

    old_modules = set(str(x) for x in (_get(old, 'exported_modules', []) or []))
    new_modules = set(str(x) for x in (_get(new, 'exported_modules', []) or []))
    for module in sorted(old_modules - new_modules):
        _add(result, category='public_api_module', classification='incompatible', code='E_PUBLIC_MODULE_REMOVED', path=f'exported_modules.{module}', message=f'public module removed: {module}', old=module, new=None)
    for module in sorted(new_modules - old_modules):
        _add(result, category='public_api_module', classification='compatible', code='C_PUBLIC_MODULE_ADDED', path=f'exported_modules.{module}', message=f'public module added: {module}', old=None, new=module)

    old_fns_by_module = _module_functions(old)
    new_fns_by_module = _module_functions(new)
    old_fns = {fn for fns in old_fns_by_module.values() for fn in fns}
    new_fns = {fn for fns in new_fns_by_module.values() for fn in fns}
    _diff_decl_set(
        result,
        old_fns,
        new_fns,
        kind='function',
        category='public_api_function',
        exported_key='exported_functions',
    )

    old_resources = {item for items in _module_resources(old).values() for item in items}
    new_resources = {item for items in _module_resources(new).values() for item in items}
    _diff_decl_set(
        result,
        old_resources,
        new_resources,
        kind='resource',
        category='public_api_resource',
        exported_key='exported_resources',
    )

    old_protocols = {item for items in _module_protocols(old).values() for item in items}
    new_protocols = {item for items in _module_protocols(new).values() for item in items}
    _diff_decl_set(
        result,
        old_protocols,
        new_protocols,
        kind='protocol',
        category='public_api_protocol',
        exported_key='exported_protocols',
    )

    old_sigs = _signature_map(old)
    new_sigs = _signature_map(new)
    for fn in sorted((old_fns & new_fns) | (set(old_sigs) & set(new_sigs))):
        if old_sigs.get(fn) != new_sigs.get(fn):
            _add(result, category='ownership_signature', classification='incompatible', code='E_OWNERSHIP_SIGNATURE_CHANGED', path=f'internal_signatures.{fn}', message=f'ownership signature changed for public function: {fn}', old=old_sigs.get(fn), new=new_sigs.get(fn))

    _diff_metadata_map(result, old, new, kind='function', metadata_key='public_function_metadata')
    _diff_metadata_map(result, old, new, kind='resource', metadata_key='public_resource_metadata')
    _diff_metadata_map(result, old, new, kind='protocol', metadata_key='public_protocol_metadata')
    _diff_resource_shapes(result, old, new)
    _diff_protocol_shapes(result, old, new)
    _diff_dependency_closure(result, old, new)

    if _dep_policy(old) != _dep_policy(new):
        _add(result, category='dependency_policy', classification='compatible', code='C_DEPENDENCY_POLICY_CHANGED', path='api_compatibility', message='dependency/language compatibility policy changed', old=_dep_policy(old), new=_dep_policy(new))
    if _get(old, 'dependency_lock_digest') != _get(new, 'dependency_lock_digest'):
        _add(result, category='dependency_lock', classification='compatible', code='C_DEPENDENCY_LOCK_CHANGED', path='dependency_lock_digest', message='dependency lock digest changed', old=_get(old, 'dependency_lock_digest'), new=_get(new, 'dependency_lock_digest'))
    if _dep_refs(old) != _dep_refs(new):
        _add(result, category='dependency_lock', classification='compatible', code='C_DEPENDENCY_PUBLICATION_REFS_CHANGED', path='dependency_publication_refs', message='dependency publication refs changed', old=_dep_refs(old), new=_dep_refs(new))

    for key in ['package_name', 'package_version', 'package_id', 'workspace_source_digest', 'manifest_hash']:
        if _get(old, key) != _get(new, key):
            _add(result, category='metadata', classification='metadata-only', code='M_PUBLICATION_METADATA_CHANGED', path=key, message=f'publication metadata changed: {key}', old=_get(old, key), new=_get(new, key))

    return {
        'schema_version': 'axiomzig.publication_diff.v1',
        'classification': result.classification,
        'summary': {
            'compatible': sum(1 for i in result.issues if i.classification == 'compatible'),
            'incompatible': sum(1 for i in result.issues if i.classification == 'incompatible'),
            'metadata_only': sum(1 for i in result.issues if i.classification == 'metadata-only'),
            'total': len(result.issues),
        },
        'categories': {cat: sum(1 for i in result.issues if i.category == cat) for cat in sorted({i.category for i in result.issues})},
        'issues': [
            {'category': i.category, 'classification': i.classification, 'code': i.code, 'path': i.path, 'message': i.message, 'old': i.old, 'new': i.new}
            for i in result.issues
        ],
    }

def diff_publication_manifest_text(old_text: str, new_text: str) -> dict[str, Any]:
    return diff_publication_manifests(json.loads(old_text), json.loads(new_text))
