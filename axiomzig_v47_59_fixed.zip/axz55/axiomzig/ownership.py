from __future__ import annotations

from dataclasses import dataclass, field

from . import ast
from .cfg import CFGFunction, CFGNode, OwnershipOp, build_cfg
from .formatter import format_type
from .ownership_signatures import FunctionOwnershipSignature, OwnershipSignatureBundle, RefParamOwnershipSignature, normalize_imported_contracts, parse_type_text
from .semantic import SemPlace, combine_sem_place, sem_place_from_path, sem_places_conflict, sem_relative_place_from_suffix
from .typecheck import TypeChecker
from .diag import *  # noqa: F401,F403 — stable diagnostic codes

TERMINAL_MERGED_STATE = '<terminal>'


DEFAULT_PROTOCOL = ast.ProtocolDecl(
    name='DefaultProtocol',
    states=['Allocated', 'Borrowed', 'Moved', 'Freed', 'Consumed'],
    init='Allocated',
    terminal=['Freed', 'Consumed', 'Moved'],
    transitions=[
        ast.ProtocolTransition('borrow', 'Allocated', 'Borrowed'),
        ast.ProtocolTransition('return', 'Borrowed', 'Allocated'),
        ast.ProtocolTransition('move', 'Allocated', 'Moved'),
        ast.ProtocolTransition('free', 'Allocated', 'Freed'),
        ast.ProtocolTransition('consume', 'Allocated', 'Consumed'),
    ],
)


@dataclass(slots=True)
class OwnershipIssue:
    level: str
    message: str
    context: str | None = None
    code: str | None = None


@dataclass(slots=True)
class ResourceState:
    type_name: str
    state: str
    members: dict[str, 'ResourceState'] = field(default_factory=dict)


@dataclass(slots=True)
class BorrowLedger:
    const_count: int = 0
    mut_count: int = 0


@dataclass(slots=True)
class RefAliasBinding:
    place: SemPlace | None
    mode: str
    ambiguous: bool = False


@dataclass(slots=True)
class AnalysisState:
    resources: dict[str, ResourceState] = field(default_factory=dict)
    borrows: dict[SemPlace, BorrowLedger] = field(default_factory=dict)
    ref_aliases: dict[str, RefAliasBinding] = field(default_factory=dict)


@dataclass(slots=True)
class FunctionOwnership:
    name: str
    resource_states: dict[str, str] = field(default_factory=dict)
    ref_param_states: dict[str, str] = field(default_factory=dict)
    ref_param_effects: dict[str, dict[str, str]] = field(default_factory=dict)
    issues: list[OwnershipIssue] = field(default_factory=list)


@dataclass(slots=True)
class OwnershipSummary:
    module_path: str
    functions: list[FunctionOwnership]
    issues: list[OwnershipIssue]


class CFGOwnershipAnalyzer:
    def __init__(self, module: ast.Module, imported_signatures: dict[str, FunctionOwnershipSignature] | None = None):
        self.module = module
        self.issues: list[OwnershipIssue] = []
        self.protocols: dict[str, ast.ProtocolDecl] = {'DefaultProtocol': DEFAULT_PROTOCOL}
        self.resources: dict[str, ast.ResourceDecl] = {}
        self.functions: dict[str, ast.FnDecl] = {}
        self.structs: dict[str, ast.StructDecl] = {}
        self.enums: dict[str, ast.EnumDecl] = {}
        self._issued_merge_messages: set[tuple[str, int, str, str, str]] = set()
        self._issued_alias_merge_messages: set[tuple[str, int, str, str, str]] = set()
        self._function_ref_effect_summaries: dict[str, dict[int, dict[str, ResourceState]]] = {}
        self.imported_signatures = imported_signatures or {}
        self.imported_contracts = {}
        self._import_contract_errors: list[str] = []
        try:
            self.imported_contracts = normalize_imported_contracts(self.imported_signatures)
        except ValueError as exc:
            # Preserve malformed imported-summary diagnostics across the
            # fixed-point ownership pass.  analyze() resets self.issues
            # during each iteration, so constructor-only diagnostics would
            # otherwise disappear before the final summary is returned.
            self._import_contract_errors.append(str(exc))
        self._typechecker = TypeChecker(module, imported_signatures=self.imported_signatures)
        self.collect_top_level()
        for name, contract in self.imported_contracts.items():
            converted: dict[int, dict[str, ResourceState]] = {}
            for effect in contract.ref_effects:
                effects = converted.setdefault(effect.param_index, {})
                effect_type = effect.type_name if effect.path == '' else self.resolve_effect_type(effect.type_name, effect.path)
                effects[effect.path] = self.parse_state_text(effect_type, effect.state)
            self._function_ref_effect_summaries[name] = converted

    def collect_top_level(self) -> None:
        for decl in self.module.decls:
            if isinstance(decl, ast.ProtocolDecl):
                self.protocols[decl.name] = decl
            elif isinstance(decl, ast.ResourceDecl):
                self.resources[decl.name] = decl
            elif isinstance(decl, ast.FnDecl):
                self.functions[decl.name] = decl
            elif isinstance(decl, ast.StructDecl):
                self.structs[decl.name] = decl
            elif isinstance(decl, ast.EnumDecl):
                self.enums[decl.name] = decl

    def analyze(self) -> OwnershipSummary:
        cfg_module = build_cfg(self.module, imported_signatures=self.imported_signatures)
        cfg_functions = {fn.name: fn for fn in cfg_module.functions}
        fn_decls = [decl for decl in self.module.decls if isinstance(decl, ast.FnDecl)]

        for _ in range(max(1, len(fn_decls)) + 4):
            changed = False
            self.issues = []
            self._issued_merge_messages = set()
            self._issued_alias_merge_messages = set()
            for decl in fn_decls:
                _, ref_effects = self.analyze_function(decl, cfg_functions[decl.name])
                existing = self._function_ref_effect_summaries.get(decl.name, {})
                if not self.ref_effect_maps_equal(existing, ref_effects):
                    self._function_ref_effect_summaries[decl.name] = self.clone_effect_map(ref_effects)
                    changed = True
            if not changed:
                break

        self.issues = [OwnershipIssue('error', message) for message in self._import_contract_errors]
        self._issued_merge_messages = set()
        self._issued_alias_merge_messages = set()
        functions: list[FunctionOwnership] = []
        for decl in fn_decls:
            summary, ref_effects = self.analyze_function(decl, cfg_functions[decl.name])
            if not self.ref_effect_maps_equal(self._function_ref_effect_summaries.get(decl.name, {}), ref_effects):
                self._function_ref_effect_summaries[decl.name] = self.clone_effect_map(ref_effects)
            functions.append(summary)
        return OwnershipSummary(module_path='.'.join(self.module.path), functions=functions, issues=self.issues)

    def analyze_function(self, fn: ast.FnDecl, cfg_fn: CFGFunction) -> tuple[FunctionOwnership, dict[int, dict[str, ResourceState]]]:
        summary = FunctionOwnership(name=fn.name)
        entry_resources: dict[str, ResourceState] = {}
        ref_param_indices: dict[int, str] = {}
        ref_param_initial_states: dict[int, ResourceState] = {}
        for idx, param in enumerate(fn.params):
            rtype = self.as_resource_type(param.typ)
            if rtype is not None:
                entry_resources[param.name] = self.fresh_state(rtype)
                continue
            ref_type = self.ref_referent_type(param.typ)
            if ref_type is not None:
                initial = self.fresh_state(ref_type)
                entry_resources[param.name] = self.clone_state(initial)
                ref_param_indices[idx] = param.name
                ref_param_initial_states[idx] = initial

        entry_aliases: dict[str, RefAliasBinding] = {}
        for idx, name in ref_param_indices.items():
            param = fn.params[idx]
            inner = self.unwrap_type(param.typ)
            mode = 'mut' if isinstance(inner, ast.GenericType) and inner.name == 'Ref' else 'const'
            entry_aliases[name] = RefAliasBinding(place=SemPlace(root=name), mode=mode, ambiguous=False)

        node_map: dict[int, CFGNode] = {node.id: node for node in cfg_fn.nodes}
        outgoing: dict[int, list] = {node.id: [] for node in cfg_fn.nodes}
        incoming: dict[int, AnalysisState | None] = {node.id: None for node in cfg_fn.nodes}
        for edge in cfg_fn.edges:
            outgoing.setdefault(edge.src, []).append(edge)
        incoming[cfg_fn.entry] = self.clone_env(AnalysisState(resources=entry_resources, borrows={}, ref_aliases=entry_aliases))
        worklist: list[int] = [cfg_fn.entry]
        cleanup_join_node = CFGNode(id=-1, kind='join', label='cleanup:join')

        while worklist:
            node_id = worklist.pop(0)
            before = incoming[node_id]
            if before is None:
                continue
            after_node = self.apply_ops(self.clone_env(before), node_map[node_id].ownership_ops, summary)
            for edge in outgoing.get(node_id, []):
                edge_envs = [self.apply_ops(self.clone_env(after_node), edge.pre_cleanup_ops, summary)]
                for action in getattr(edge, 'cleanup_actions', []):
                    next_envs: list[AnalysisState] = []
                    for env in edge_envs:
                        if action.alternative_ops:
                            merged_action_env: AnalysisState | None = None
                            for alt_ops in action.alternative_ops:
                                alt_env = self.apply_ops(self.clone_env(env), list(alt_ops), summary)
                                if merged_action_env is None:
                                    merged_action_env = alt_env
                                else:
                                    merged_action_env, _ = self.merge_envs(merged_action_env, alt_env, summary, cfg_fn, cleanup_join_node)
                            if merged_action_env is not None:
                                next_envs.append(merged_action_env)
                        else:
                            next_envs.append(self.apply_ops(self.clone_env(env), list(action.ops), summary))
                    edge_envs = next_envs
                if not edge_envs:
                    edge_envs = [self.clone_env(after_node)]
                for cleanup_env in edge_envs:
                    after_edge = self.apply_ops(self.clone_env(cleanup_env), edge.post_cleanup_ops, summary)
                    merged, changed = self.merge_envs(incoming.get(edge.dst), after_edge, summary, cfg_fn, node_map[edge.dst])
                    if changed:
                        incoming[edge.dst] = merged
                        worklist.append(edge.dst)

        self.check_exit_state(cfg_fn, incoming, summary, exempt_names=set(ref_param_indices.values()))
        final_env = incoming.get(cfg_fn.return_exit) or incoming.get(cfg_fn.fallthrough_exit) or AnalysisState(resources=entry_resources, borrows={}, ref_aliases=entry_aliases)
        summary.resource_states = {name: slot.state for name, slot in final_env.resources.items()}
        ref_effects: dict[int, dict[str, ResourceState]] = {}
        for idx, name in ref_param_indices.items():
            slot = final_env.resources.get(name)
            if slot is None:
                continue
            summary.ref_param_states[name] = self.describe_state(slot)
            effects = self.diff_ref_effects(ref_param_initial_states[idx], slot)
            ref_effects[idx] = effects
            summary.ref_param_effects[name] = {path: self.describe_state(effect) for path, effect in sorted(effects.items())}
        return summary, ref_effects

    def op_place(self, op: OwnershipOp) -> SemPlace | None:
        if op.place is not None:
            return op.place
        if op.name is None:
            return None
        return sem_place_from_path(op.name)

    def op_aux_place(self, op: OwnershipOp) -> SemPlace | None:
        if op.aux_place is not None:
            return op.aux_place
        if op.aux_name is None:
            return None
        return sem_place_from_path(op.aux_name)

    def op_source_place(self, op: OwnershipOp) -> SemPlace | None:
        if op.source_place is not None:
            return op.source_place
        if op.source_name is None:
            return None
        return sem_place_from_path(op.source_name)

    def op_source_aux_place(self, op: OwnershipOp) -> SemPlace | None:
        if getattr(op, 'source_aux_place', None) is not None:
            return op.source_aux_place
        return sem_relative_place_from_suffix(op.source_aux_name)

    def display_path_text(self, path: str) -> str:
        if not path or path == '<unknown>':
            return path
        parts = path.split('.')
        if not parts:
            return path
        pieces = [parts[0]]
        for part in parts[1:]:
            if part.startswith('[') and part.endswith(']'):
                pieces.append(part)
            elif part.isdigit():
                pieces.append(f'[{part}]')
            else:
                pieces.append(f'.{part}')
        return ''.join(pieces)

    def place_text(self, place: SemPlace | None) -> str:
        if place is None:
            return '<unknown>'
        pieces = [place.root] if place.root else []
        for projection in place.projections:
            if projection.kind == 'field' and projection.value is not None:
                pieces.append(f'.{projection.value}')
            elif projection.kind == 'index':
                pieces.append(f'[{projection.value}]' if projection.value is not None else '[*]')
            elif projection.kind == 'slice':
                pieces.append('[..]')
            else:
                pieces.append(f'[{projection.kind}]')
        return ''.join(pieces) if pieces else '<unknown>'

    def combine_place(self, base: SemPlace, suffix: SemPlace | None) -> SemPlace:
        if suffix is None:
            return base
        return combine_sem_place(base, suffix)

    def apply_ops(self, env: AnalysisState, ops: list[OwnershipOp], summary: FunctionOwnership) -> AnalysisState:
        current_call: str | None = None
        call_ref_args: list[tuple[SemPlace, str, int]] = []
        for op in ops:
            op_place = self.op_place(op)
            op_aux_place = self.op_aux_place(op)
            if op.kind == 'begin_borrow' and op_place is not None:
                self.apply_begin_borrow_place(env, op_place, op.borrow_mode or 'const', summary)
            elif op.kind == 'begin_alias_borrow' and op.name is not None:
                require_mut = (op.borrow_mode == 'mut')
                target_place = self.op_target_place(env, op, summary, require_mut=require_mut)
                if target_place is None:
                    continue
                self.apply_begin_borrow_place(env, target_place, op.borrow_mode or 'const', summary)
            elif op.kind == 'end_borrow' and op_place is not None:
                self.remove_borrow(env.borrows, op_place, op.borrow_mode or 'const')
            elif op.kind == 'define_ref_alias' and op.name is not None:
                env.ref_aliases[op.name] = RefAliasBinding(place=op_aux_place, mode=op.borrow_mode or 'const', ambiguous=False)
            elif op.kind == 'clear_ref_alias' and op.name is not None:
                env.ref_aliases.pop(op.name, None)
            elif op.kind == 'read_resource' and op_place is not None:
                self.apply_read_place(env, op_place, summary)
            elif op.kind == 'read_alias_resource' and op.name is not None:
                target_place = self.op_target_place(env, op, summary, require_mut=False)
                if target_place is None:
                    continue
                self.apply_read_place(env, target_place, summary)
            elif op.kind == 'move_resource' and op_place is not None:
                self.apply_move_place(env, op_place, summary)
            elif op.kind == 'move_alias_resource' and op.name is not None:
                target_place = self.op_target_place(env, op, summary, require_mut=True)
                if target_place is None:
                    continue
                self.apply_move_place(env, target_place, summary)
            elif op.kind == 'transition' and op_place is not None and op.transition is not None:
                self.apply_transition_place(env, op_place, op.transition, summary, via_mut_ref=(op.borrow_mode == 'via_mut_ref'))
            elif op.kind == 'transition_alias' and op.name is not None and op.transition is not None:
                target_place = self.op_target_place(env, op, summary, require_mut=True)
                if target_place is None:
                    continue
                self.apply_transition_place(env, target_place, op.transition, summary, via_mut_ref=True)
            elif op.kind == 'bind_from' and op_place is not None and op_aux_place is not None:
                self.apply_bind_from_places(env, op_place, op_aux_place, summary, via_mut_ref=(op.borrow_mode == 'via_mut_ref'), fresh_type=op.type_name)
            elif op.kind == 'bind_from_alias_source' and op_place is not None:
                source_place = self.resolve_alias_place(env, op.source_name, self.op_source_aux_place(op), summary, require_mut=True) if op.source_name is not None else op.source_place
                if source_place is None:
                    continue
                self.apply_bind_from_places(env, op_place, source_place, summary, via_mut_ref=(op.borrow_mode == 'via_mut_ref'))
            elif op.kind == 'bind_fresh' and op_place is not None and op.type_name is not None:
                self.apply_bind_from_places(env, op_place, None, summary, via_mut_ref=(op.borrow_mode == 'via_mut_ref'), fresh_type=op.type_name)
            elif op.kind == 'bind_fresh_alias_target' and op.name is not None and op.type_name is not None:
                target_place = self.op_target_place(env, op, summary, require_mut=True)
                if target_place is None:
                    continue
                self.apply_bind_from_places(env, target_place, None, summary, via_mut_ref=True, fresh_type=op.type_name)
            elif op.kind == 'bind_alias_target_from' and op.name is not None and op.source_place is not None:
                target_place = self.op_target_place(env, op, summary, require_mut=True)
                if target_place is None:
                    continue
                self.apply_bind_from_places(env, target_place, op.source_place, summary, via_mut_ref=True)
            elif op.kind == 'bind_alias_target_from_alias_source' and op.name is not None and op.source_name is not None:
                target_place = self.op_target_place(env, op, summary, require_mut=True)
                if target_place is None:
                    continue
                source_place = self.resolve_alias_place(env, op.source_name, self.op_source_aux_place(op), summary, require_mut=True) if op.source_name is not None else op.source_place
                if source_place is None:
                    continue
                self.apply_bind_from_places(env, target_place, source_place, summary, via_mut_ref=True)
            elif op.kind in {'call_ref_param', 'call_ref_alias_param'} and op.callee is not None and op.param_index is not None:
                if current_call != op.callee or op.param_index == 0:
                    current_call = op.callee
                    call_ref_args = []
                target_place = op_place
                if op.kind == 'call_ref_alias_param':
                    target_place = self.op_target_place(
                        env,
                        op,
                        summary,
                        require_mut=(op.borrow_mode == 'mut'),
                    )
                if target_place is None:
                    continue
                target_path = self.place_text(target_place)
                if self.place_has_abstract_index(target_place):
                    self.issue('error', f'non-literal indexed resource path {target_path} is not supported for reference ownership summaries', summary, code="E_OWN_IMPORT_BAD_PATH")
                    continue
                mode = op.borrow_mode or 'const'
                conflict = None
                for prior_place, prior_mode, prior_idx in call_ref_args:
                    if self.paths_conflict(prior_place, target_place) and ('mut' in {prior_mode, mode}):
                        conflict = (prior_place, prior_idx)
                        break
                if conflict is not None:
                    prior_place, prior_idx = conflict
                    prior_path = self.place_text(prior_place)
                    if prior_path == target_path:
                        self.issue('error', f'call to {op.callee} passes aliased reference {target_path} to incompatible ref parameters {prior_idx + 1} and {op.param_index + 1}', summary, code="E_OWN_BORROW_ALIAS")
                    else:
                        self.issue('error', f'call to {op.callee} passes overlapping references {prior_path} and {target_path} to incompatible ref parameters {prior_idx + 1} and {op.param_index + 1}', summary, code="E_OWN_BORROW_ALIAS")
                else:
                    call_ref_args.append((target_place, mode, op.param_index))
                slot = self.resolve_slot(env.resources, target_place)
                if slot is None:
                    continue
                if op.type_name is not None and slot.type_name != op.type_name:
                    self.issue('error', f'call to {op.callee} parameter {op.param_index + 1} expects referent type {op.type_name} but got {slot.type_name} at {target_path}', summary, code="E_OWN_IMPORT_SUMMARY")
                    continue
                effects = self._function_ref_effect_summaries.get(op.callee, {}).get(op.param_index)
                if effects is None:
                    continue
                abstract_effects = [rel_path for rel_path in effects if self.effect_full_place_has_abstract_index(target_place, rel_path)]
                if abstract_effects:
                    rendered = ', '.join(self.display_path_text(path) for path in sorted(abstract_effects))
                    self.issue('error', f'imported/reference ownership summary for {op.callee} uses unsupported non-literal indexed path(s): {rendered}', summary, code="E_OWN_IMPORT_BAD_PATH")
                    continue
                self.apply_ref_effects(env.resources, target_place, effects)
            elif op.kind == 'ref_alias_conflict' and op.name is not None and op.callee is not None and op.param_index is not None:
                prior = op.aux_name or '?'
                if op.type_name is not None and op.type_name != op.name:
                    self.issue('error', f'call to {op.callee} passes overlapping references {op.type_name} and {op.name} to incompatible ref parameters {prior} and {op.param_index + 1}', summary, code="E_OWN_BORROW_ALIAS")
                else:
                    self.issue('error', f'call to {op.callee} passes aliased reference {op.name} to incompatible ref parameters {prior} and {op.param_index + 1}', summary, code="E_OWN_BORROW_ALIAS")
            elif op.kind == 'invalid_ref_alias' and op.name is not None:
                qualifier = 'mutable ' if op.borrow_mode in {'mut', 'via_mut_ref'} else ''
                self.issue('error', f'{qualifier}reference alias {op.name} does not have a live unique referent', summary, code="E_OWN_ALIAS_MISSING")
            elif op.kind == 'scope_pop' and op.name is not None:
                slot = env.resources.get(op.name)
                if slot is None:
                    continue
                if not self.is_terminal(slot):
                    self.issue('error', self.scope_pop_message(op.name, slot.type_name, self.describe_state(slot)), summary, code='E_OWN_UNDISCHARGED')
                env.resources.pop(op.name, None)
        return env

    def merge_envs(
        self,
        existing: AnalysisState | None,
        incoming: AnalysisState,
        summary: FunctionOwnership,
        cfg_fn: CFGFunction,
        join_node: CFGNode,
    ) -> tuple[AnalysisState, bool]:
        if existing is None:
            return self.clone_env(incoming), True
        changed = False
        merged_resources: dict[str, ResourceState] = {}
        shared_names = set(existing.resources) & set(incoming.resources)
        conflicting_resource_roots: set[str] = set()
        for name in shared_names:
            left = existing.resources[name]
            right = incoming.resources[name]
            merged_slot, merge_issue = self.join_resource_states(name, left, right)
            merged_resources[name] = merged_slot
            if merge_issue:
                conflicting_resource_roots.add(name)
                # Diagnostic-only refinement: the join decision is still made solely by
                # join_resource_states above.  Nested paths are emitted only as
                # additional context so array/container members like hs[0].inner can
                # explain why the root resource failed to merge.
                for path_text, left_desc, right_desc in self.collect_resource_merge_descriptions(name, left, right):
                    key = (cfg_fn.name, join_node.id, path_text, left_desc, right_desc)
                    if key not in self._issued_merge_messages:
                        self._issued_merge_messages.add(key)
                        self.issue('error', self.merge_message(join_node, path_text, left_desc, right_desc), summary)
            if left.type_name != merged_slot.type_name or left.state != merged_slot.state or left.members != merged_slot.members:
                changed = True
        if set(existing.resources) != set(merged_resources):
            changed = True
        if set(incoming.resources) - set(existing.resources):
            changed = True
        merged_borrows = {path: BorrowLedger(const_count=ledger.const_count, mut_count=ledger.mut_count) for path, ledger in existing.borrows.items()}
        for path, ledger in incoming.borrows.items():
            prev = merged_borrows.get(path)
            if prev is None:
                merged_borrows[path] = BorrowLedger(const_count=ledger.const_count, mut_count=ledger.mut_count)
                changed = True
            else:
                merged_const = max(prev.const_count, ledger.const_count)
                merged_mut = max(prev.mut_count, ledger.mut_count)
                if merged_const != prev.const_count or merged_mut != prev.mut_count:
                    prev.const_count = merged_const
                    prev.mut_count = merged_mut
                    changed = True
        if conflicting_resource_roots:
            filtered_borrows = {
                path: ledger
                for path, ledger in merged_borrows.items()
                if path.root not in conflicting_resource_roots
            }
            if len(filtered_borrows) != len(merged_borrows):
                changed = True
            merged_borrows = filtered_borrows
        merged_aliases: dict[str, RefAliasBinding] = {}
        alias_names = set(existing.ref_aliases) | set(incoming.ref_aliases)
        for alias_name in alias_names:
            left_binding = existing.ref_aliases.get(alias_name)
            right_binding = incoming.ref_aliases.get(alias_name)
            merged_binding, alias_issue = self.join_ref_alias_bindings(alias_name, left_binding, right_binding)
            effective_binding = merged_binding
            if merged_binding is not None and merged_binding.place is not None and merged_binding.place.root in conflicting_resource_roots:
                effective_binding = None
            if effective_binding is not None:
                merged_aliases[alias_name] = effective_binding
            existing_binding = existing.ref_aliases.get(alias_name)
            if not self.ref_alias_binding_equal(existing_binding, effective_binding):
                changed = True
            if alias_issue:
                left_text = self.describe_ref_alias(left_binding)
                right_text = self.describe_ref_alias(right_binding)
                key = (cfg_fn.name, join_node.id, alias_name, left_text, right_text)
                if key not in self._issued_alias_merge_messages:
                    self._issued_alias_merge_messages.add(key)
                    self.issue('error', self.alias_merge_message(join_node, alias_name, left_text, right_text), summary)
        return AnalysisState(resources=merged_resources, borrows=merged_borrows, ref_aliases=merged_aliases), changed

    def join_resource_states(
        self,
        _name: str,
        left: ResourceState,
        right: ResourceState,
    ) -> tuple[ResourceState, bool]:
        if left.type_name != right.type_name:
            return self.clone_state(left), True
        if self.is_terminal(left) and self.is_terminal(right):
            return ResourceState(type_name=left.type_name, state=TERMINAL_MERGED_STATE), False
        merge_issue = left.state != right.state
        merged_members: dict[str, ResourceState] = {}
        shared = set(left.members) & set(right.members)
        if set(left.members) != set(right.members):
            merge_issue = True
        for key in shared:
            child, child_issue = self.join_resource_states(key, left.members[key], right.members[key])
            merged_members[key] = child
            merge_issue = merge_issue or child_issue
        return ResourceState(type_name=left.type_name, state=left.state, members=merged_members), merge_issue


    def join_ref_alias_bindings(
        self,
        _name: str,
        left: RefAliasBinding | None,
        right: RefAliasBinding | None,
    ) -> tuple[RefAliasBinding | None, bool]:
        if left is None and right is None:
            return None, False
        if left is None or right is None:
            binding = left or right
            assert binding is not None
            return RefAliasBinding(place=None, mode=binding.mode, ambiguous=True), True
        if (not left.ambiguous) and (not right.ambiguous) and left.place == right.place and left.mode == right.mode:
            return RefAliasBinding(place=left.place, mode=left.mode, ambiguous=False), False
        merged_mode = left.mode if left.mode == right.mode else 'mut'
        if left.ambiguous and right.ambiguous and merged_mode == left.mode == right.mode:
            return RefAliasBinding(place=None, mode=merged_mode, ambiguous=True), False
        return RefAliasBinding(place=None, mode=merged_mode, ambiguous=True), True

    def ref_alias_binding_equal(self, left: RefAliasBinding | None, right: RefAliasBinding | None) -> bool:
        if left is None or right is None:
            return left is right
        return left.place == right.place and left.mode == right.mode and left.ambiguous == right.ambiguous

    def describe_ref_alias(self, binding: RefAliasBinding | None) -> str:
        if binding is None:
            return '<missing>'
        mode = 'Ref' if binding.mode == 'mut' else 'RefConst'
        if binding.ambiguous or binding.place is None:
            return f'{mode}:<ambiguous>'
        return f'{mode}:{binding.place.to_path()}'

    def check_exit_state(self, cfg_fn: CFGFunction, incoming: dict[int, dict[str, ResourceState] | None], summary: FunctionOwnership, exempt_names: set[str] | None = None) -> None:
        exit_nodes = [cfg_fn.fallthrough_exit, cfg_fn.return_exit]
        if cfg_fn.error_exit is not None:
            exit_nodes.append(cfg_fn.error_exit)
        exempt_names = exempt_names or set()
        seen: set[tuple[int, str]] = set()
        for node_id in exit_nodes:
            env = incoming.get(node_id)
            if env is None:
                continue
            for name, slot in env.resources.items():
                if name in exempt_names:
                    continue
                if not self.is_terminal(slot):
                    key = (node_id, name)
                    if key in seen:
                        continue
                    seen.add(key)
                    exit_kind = 'error exit' if node_id == cfg_fn.error_exit else 'function exit'
                    self.issue('error', self.exit_message(name, slot.type_name, self.describe_state(slot), exit_kind), summary, code='E_OWN_UNDISCHARGED')



    def ref_referent_type(self, typ: ast.Type | None) -> str | None:
        if typ is None:
            return None
        inner = self.unwrap_type(typ)
        if isinstance(inner, ast.GenericType) and inner.name in {'Ref', 'RefConst'} and inner.args and isinstance(inner.args[0], ast.Type):
            return self.as_resource_type(inner.args[0])
        return None

    def state_equal(self, left: ResourceState, right: ResourceState) -> bool:
        if left.type_name != right.type_name or left.state != right.state or set(left.members) != set(right.members):
            return False
        return all(self.state_equal(left.members[name], right.members[name]) for name in left.members)

    def ref_param_state_maps_equal(self, left: dict[int, ResourceState], right: dict[int, ResourceState]) -> bool:
        if set(left) != set(right):
            return False
        return all(self.state_equal(left[idx], right[idx]) for idx in left)

    def ref_effect_maps_equal(self, left: dict[int, dict[str, ResourceState]], right: dict[int, dict[str, ResourceState]]) -> bool:
        if set(left) != set(right):
            return False
        for idx in left:
            if not self.ref_effects_equal(left[idx], right[idx]):
                return False
        return True

    def ref_effects_equal(self, left: dict[str, ResourceState], right: dict[str, ResourceState]) -> bool:
        if set(left) != set(right):
            return False
        return all(self.state_equal(left[path], right[path]) for path in left)

    def clone_effect_map(self, effects: dict[int, dict[str, ResourceState]]) -> dict[int, dict[str, ResourceState]]:
        return {idx: {path: self.clone_state(slot) for path, slot in path_map.items()} for idx, path_map in effects.items()}

    def diff_ref_effects(self, initial: ResourceState, final: ResourceState, prefix: str = '') -> dict[str, ResourceState]:
        if initial.type_name != final.type_name or initial.state != final.state or set(initial.members) != set(final.members):
            return {prefix: self.clone_state(final)}
        effects: dict[str, ResourceState] = {}
        for name in sorted(initial.members):
            child_prefix = f'{prefix}.{name}' if prefix else name
            effects.update(self.diff_ref_effects(initial.members[name], final.members[name], child_prefix))
        return effects

    def apply_ref_effects(self, env: dict[str, ResourceState], root_place: SemPlace, effects: dict[str, ResourceState]) -> None:
        for rel_path, slot in sorted(effects.items(), key=lambda item: (item[0] != '', item[0].count('.'))):
            full_place = root_place if rel_path == '' else self.combine_place(root_place, sem_relative_place_from_suffix(rel_path))
            self.set_slot(env, full_place, self.clone_state(slot))

    def resolve_alias_place(self, env: AnalysisState, alias_name: str, suffix: SemPlace | None, summary: FunctionOwnership, require_mut: bool = False) -> SemPlace | None:
        binding = env.ref_aliases.get(alias_name)
        qualifier = 'mutable ' if require_mut else ''
        if binding is None or binding.ambiguous or binding.place is None or (require_mut and binding.mode != 'mut'):
            self.issue('error', f'{qualifier}reference alias {alias_name} does not have a live unique referent', summary, code="E_OWN_ALIAS_MISSING")
            return None
        return self.combine_place(binding.place, suffix)

    def op_target_place(self, env: AnalysisState, op: OwnershipOp, summary: FunctionOwnership, require_mut: bool = False) -> SemPlace | None:
        alias_kinds = {
            'begin_alias_borrow',
            'read_alias_resource',
            'move_alias_resource',
            'transition_alias',
            'bind_fresh_alias_target',
            'bind_alias_target_from',
            'bind_alias_target_from_alias_source',
            'call_ref_alias_param',
        }
        if op.place is not None:
            if not (
                op.kind in alias_kinds
                and op.name is not None
                and op.place.root == op.name
                and (require_mut or len(op.place.projections) == 0)
            ):
                return op.place
        if op.name is None:
            return None
        return self.resolve_alias_place(env, op.name, self.op_aux_place(op), summary, require_mut=require_mut)

    def apply_read_place(self, env: AnalysisState, place: SemPlace, summary: FunctionOwnership) -> None:
        path = self.place_text(place)
        slot = self.resolve_slot(env.resources, place)
        if slot is None:
            return
        if slot.state == 'Moved':
            self.issue('error', f'use of moved resource {path}', summary, code="E_OWN_MOVED")
        elif self.is_terminal(slot):
            self.issue('error', f'use of terminal resource {path} in state {self.describe_state(slot)}', summary)
        elif self.has_conflicting_mut_borrow(env.borrows, place):
            self.issue('error', f'cannot read resource {path} while mutable borrow is live', summary)

    def apply_move_place(self, env: AnalysisState, place: SemPlace, summary: FunctionOwnership) -> None:
        path = self.place_text(place)
        slot = self.resolve_slot(env.resources, place)
        if slot is None:
            return
        if self.has_conflicting_borrow(env.borrows, place):
            self.issue('error', f'cannot move borrowed resource {path} while borrow is live', summary, code="E_OWN_BORROW_LIVE")
        elif self.is_terminal(slot):
            self.issue('error', f'cannot move resource {path} from terminal state {self.describe_state(slot)}', summary, code="E_OWN_MOVED")
        else:
            slot.state = 'Moved'
            slot.members = {}

    def apply_begin_borrow_place(self, env: AnalysisState, place: SemPlace, mode: str, summary: FunctionOwnership) -> None:
        path = self.place_text(place)
        slot = self.resolve_slot(env.resources, place)
        if slot is None:
            return
        if slot.state == 'Moved':
            self.issue('error', f'cannot borrow moved resource {path}', summary, code="E_OWN_MOVED")
        elif self.is_terminal(slot):
            self.issue('error', f'cannot borrow terminal resource {path} in state {self.describe_state(slot)}', summary)
        elif mode == 'mut' and self.has_conflicting_borrow(env.borrows, place):
            self.issue('error', f'cannot mutably borrow resource {path} while borrow is live', summary, code="E_OWN_BORROW_EXCL")
        elif mode != 'mut' and self.has_conflicting_mut_borrow(env.borrows, place):
            self.issue('error', f'cannot immutably borrow resource {path} while mutable borrow is live', summary, code="E_OWN_BORROW_EXCL")
        else:
            self.add_borrow(env.borrows, place, mode)

    def apply_transition_place(self, env: AnalysisState, place: SemPlace, transition_name: str, summary: FunctionOwnership, via_mut_ref: bool = False) -> None:
        path = self.place_text(place)
        slot = self.resolve_slot(env.resources, place)
        if slot is None:
            return
        transition = self.transition_for(slot.type_name, transition_name)
        if (not via_mut_ref) and self.has_conflicting_borrow(env.borrows, place):
            self.issue('error', f'cannot transition borrowed resource {path} while borrow is live', summary, code="E_OWN_BORROW_LIVE")
        elif slot.state == 'Moved':
            self.issue('error', f'cannot call {path}.{transition_name} on moved resource', summary, code="E_OWN_MOVED")
        elif transition is None or transition.source != slot.state:
            expected = transition.source if transition is not None else '<none>'
            self.issue('error', f'illegal transition {transition_name} on {path}: expected {expected}, got {self.describe_state(slot)}', summary, code="E_PROTO_TRANSITION")
        else:
            slot.state = transition.target
            if self.is_terminal(slot):
                slot.members = {}

    def apply_bind_from_places(self, env: AnalysisState, target_place: SemPlace, source_place: SemPlace | None, summary: FunctionOwnership, via_mut_ref: bool = False, fresh_type: str | None = None) -> None:
        target_path = self.place_text(target_place)
        if source_place is None:
            if (not via_mut_ref) and self.has_conflicting_borrow(env.borrows, target_place):
                self.issue('error', f'cannot assign to borrowed resource {target_path} while borrow is live', summary, code="E_OWN_BORROW_LIVE")
                return
            target = self.resolve_slot(env.resources, target_place)
            if target is not None and not self.is_terminal(target):
                self.issue('error', f'cannot assign to resource {target_path} while it is in non-terminal state {self.describe_state(target)}', summary)
                return
            assert fresh_type is not None
            self.set_slot(env.resources, target_place, self.fresh_state(fresh_type))
            return
        source_path = self.place_text(source_place)
        source = self.resolve_slot(env.resources, source_place)
        if source is None:
            self.set_slot(env.resources, target_place, self.fresh_state(fresh_type or '<unknown>'))
            return
        if self.has_conflicting_borrow(env.borrows, source_place):
            self.issue('error', f'cannot move borrowed resource {source_path} while borrow is live', summary, code="E_OWN_BORROW_LIVE")
            return
        if (not via_mut_ref) and self.has_conflicting_borrow(env.borrows, target_place):
            self.issue('error', f'cannot assign to borrowed resource {target_path} while borrow is live', summary, code="E_OWN_BORROW_LIVE")
            return
        if self.is_terminal(source):
            self.issue('error', f'cannot bind {target_path} from terminal resource {source_path} in state {self.describe_state(source)}', summary)
            return
        target = self.resolve_slot(env.resources, target_place)
        if target is not None and not self.is_terminal(target):
            self.issue('error', f'cannot assign to resource {target_path} while it is in non-terminal state {self.describe_state(target)}', summary)
            return
        self.set_slot(env.resources, target_place, self.clone_state(source))
        source.state = 'Moved'
        source.members = {}

    def add_borrow(self, borrows: dict[SemPlace, BorrowLedger], place: SemPlace, mode: str) -> None:
        ledger = borrows.setdefault(place, BorrowLedger())
        if mode == 'mut':
            ledger.mut_count += 1
        else:
            ledger.const_count += 1

    def remove_borrow(self, borrows: dict[SemPlace, BorrowLedger], place: SemPlace, mode: str) -> None:
        ledger = borrows.get(place)
        if ledger is None:
            return
        if mode == 'mut':
            ledger.mut_count = max(0, ledger.mut_count - 1)
        else:
            ledger.const_count = max(0, ledger.const_count - 1)
        if ledger.const_count == 0 and ledger.mut_count == 0:
            borrows.pop(place, None)

    def place_has_abstract_index(self, place: SemPlace | None) -> bool:
        return place is not None and any(proj.kind == 'index' and proj.value is None for proj in place.projections)

    def effect_full_place_has_abstract_index(self, root_place: SemPlace, rel_path: str) -> bool:
        full_place = root_place if rel_path == '' else self.combine_place(root_place, sem_relative_place_from_suffix(rel_path))
        return self.place_has_abstract_index(full_place)

    def paths_conflict(self, left: SemPlace, right: SemPlace) -> bool:
        return sem_places_conflict(left, right)

    def has_conflicting_borrow(self, borrows: dict[SemPlace, BorrowLedger], place: SemPlace) -> bool:
        return any(self.paths_conflict(place, borrow) and (ledger.const_count > 0 or ledger.mut_count > 0) for borrow, ledger in borrows.items())

    def has_conflicting_mut_borrow(self, borrows: dict[SemPlace, BorrowLedger], place: SemPlace) -> bool:
        return any(self.paths_conflict(place, borrow) and ledger.mut_count > 0 for borrow, ledger in borrows.items())

    def type_contains_tracked_ownership(self, typ: ast.Type, seen: set[str] | None = None) -> bool:
        _ = seen
        return self._typechecker.type_contains_tracked_ownership(typ)

    def as_resource_type(self, typ: ast.Type | None) -> str | None:
        return self._typechecker.resource_type_name(typ)

    def unwrap_type(self, typ: ast.Type) -> ast.Type:
        if isinstance(typ, ast.OptionalType):
            return self.unwrap_type(typ.inner)
        if isinstance(typ, ast.ResultType):
            return self.unwrap_type(typ.ok)
        return typ

    def protocol_for_resource(self, name: str) -> ast.ProtocolDecl:
        if name not in self.resources:
            return DEFAULT_PROTOCOL
        decl = self.resources[name]
        if decl.protocol is None:
            return DEFAULT_PROTOCOL
        return self.protocols.get(decl.protocol, DEFAULT_PROTOCOL)

    def transition_for(self, resource_name: str, transition_name: str) -> ast.ProtocolTransition | None:
        proto = self.protocol_for_resource(resource_name)
        for tr in proto.transitions:
            if tr.name == transition_name:
                return tr
        return None

    def is_terminal(self, slot: ResourceState) -> bool:
        proto = self.protocol_for_resource(slot.type_name)
        if slot.state in {'Moved', TERMINAL_MERGED_STATE} or slot.state in proto.terminal:
            return True
        if slot.members:
            return all(self.is_terminal(child) for child in slot.members.values())
        return False

    def fresh_state(self, type_name: str) -> ResourceState:
        if type_name in self.resources:
            return ResourceState(type_name=type_name, state=self.protocol_for_resource(type_name).init)
        if type_name in self.structs:
            members: dict[str, ResourceState] = {}
            for field in self.structs[type_name].fields:
                child_type = self.as_resource_type(field.typ)
                if child_type is not None:
                    members[field.name] = self.fresh_state(child_type)
            return ResourceState(type_name=type_name, state='Allocated', members=members)
        try:
            parsed = parse_type_text(type_name)
        except Exception:
            parsed = None
        if (
            isinstance(parsed, ast.GenericType)
            and parsed.name == 'Array'
            and len(parsed.args) == 2
            and isinstance(parsed.args[0], ast.Type)
            and isinstance(parsed.args[1], int)
        ):
            members: dict[str, ResourceState] = {}
            child_type = self.as_resource_type(parsed.args[0])
            if child_type is not None:
                for idx in range(parsed.args[1]):
                    members[str(idx)] = self.fresh_state(child_type)
            return ResourceState(type_name=type_name, state='Allocated', members=members)
        return ResourceState(type_name=type_name, state='Allocated')


    def place_parts(self, place: SemPlace) -> list[str] | None:
        parts = [place.root]
        for proj in place.projections:
            if proj.kind == 'field' and proj.value is not None:
                parts.append(str(proj.value))
            elif proj.kind == 'index' and proj.value is not None:
                parts.append(str(proj.value))
            else:
                return None
        return parts

    def resolve_slot(self, env: dict[str, ResourceState], place: SemPlace) -> ResourceState | None:
        parts = self.place_parts(place)
        if parts is None:
            return None
        slot = env.get(parts[0])
        if slot is None:
            return None
        for part in parts[1:]:
            if slot.state == 'Moved':
                return slot
            slot = slot.members.get(part)
            if slot is None:
                return None
        return slot

    def set_slot(self, env: dict[str, ResourceState], place: SemPlace, value: ResourceState) -> None:
        parts = self.place_parts(place)
        if parts is None:
            return
        if len(parts) == 1:
            env[parts[0]] = value
            return
        parent_place = SemPlace(root=place.root, projections=place.projections[:-1])
        parent = self.resolve_slot(env, parent_place)
        if parent is None:
            env[parts[0]] = value
            return
        parent.members[parts[-1]] = value

    def clone_state(self, slot: ResourceState) -> ResourceState:
        return ResourceState(
            type_name=slot.type_name,
            state=slot.state,
            members={name: self.clone_state(child) for name, child in slot.members.items()},
        )

    def clone_env(self, env: AnalysisState) -> AnalysisState:
        return AnalysisState(
            resources={name: self.clone_state(slot) for name, slot in env.resources.items()},
            borrows={place: BorrowLedger(const_count=ledger.const_count, mut_count=ledger.mut_count) for place, ledger in env.borrows.items()},
            ref_aliases={name: RefAliasBinding(place=binding.place, mode=binding.mode, ambiguous=binding.ambiguous) for name, binding in env.ref_aliases.items()},
        )

    def field_type_name(self, parent_type: str, field_name: str) -> str | None:
        if parent_type in self.structs:
            for field in self.structs[parent_type].fields:
                if field.name == field_name:
                    return self.as_resource_type(field.typ)
        try:
            parsed = parse_type_text(parent_type)
        except Exception:
            parsed = None
        if (
            isinstance(parsed, ast.GenericType)
            and parsed.name == 'Array'
            and len(parsed.args) == 2
            and isinstance(parsed.args[0], ast.Type)
            and isinstance(parsed.args[1], int)
            and field_name.isdigit()
        ):
            index = int(field_name)
            if 0 <= index < parsed.args[1]:
                return self.as_resource_type(parsed.args[0])
        return None

    def resolve_effect_type(self, root_type: str, rel_path: str) -> str:
        current = root_type
        if rel_path == '':
            return current
        for part in rel_path.split('.'):
            next_type = self.field_type_name(current, part)
            if next_type is None:
                return current
            current = next_type
        return current

    def parse_state_text(self, type_name: str, text: str) -> ResourceState:
        if '{' not in text or not text.endswith('}'):
            return ResourceState(type_name=type_name, state=text)
        state, rest = text.split('{', 1)
        inner = rest[:-1]
        members: dict[str, ResourceState] = {}
        if inner:
            depth = 0
            start = 0
            parts: list[str] = []
            for i, ch in enumerate(inner):
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                elif ch == ',' and depth == 0:
                    parts.append(inner[start:i].strip())
                    start = i + 1
            parts.append(inner[start:].strip())
            for item in parts:
                if not item:
                    continue
                name, value_text = item.split('=', 1)
                child_type = self.field_type_name(type_name, name.strip()) or type_name
                members[name.strip()] = self.parse_state_text(child_type, value_text.strip())
        return ResourceState(type_name=type_name, state=state, members=members)

    def describe_state(self, slot: ResourceState) -> str:
        if not slot.members:
            return slot.state
        inner = ', '.join(f'{name}={self.describe_state(child)}' for name, child in slot.members.items())
        return f'{slot.state}{{{inner}}}'

    def issue(self, level: str, message: str, summary: FunctionOwnership, context: str | None = None, code: str | None = None) -> None:
        item = OwnershipIssue(level=level, message=message, context=context, code=code)
        self.issues.append(item)
        summary.issues.append(item)

    def merge_message(self, node: CFGNode, name: str, left: str, right: str) -> str:
        if node.label == 'if:join':
            return f'if branches leave resource {name} in different states: {right} vs {left}'
        if node.label == 'cleanup:join':
            return f'cleanup branches leave resource {name} in different states: {right} vs {left}'
        return f'CFG merge leaves resource {name} in different states at node {node.id}: {left} vs {right}'

    def collect_resource_merge_descriptions(
        self,
        root_name: str,
        left: ResourceState,
        right: ResourceState,
    ) -> list[tuple[str, str, str]]:
        """Return root-first diagnostic descriptions for a resource merge issue.

        This must not decide whether a merge is legal.  The semantic join result is
        already computed by join_resource_states(); this helper only expands the
        resulting root-level failure into stable nested context for arrays, structs,
        and resource fields.
        """
        descriptions: list[tuple[str, str, str]] = []

        def visit(path: str, lhs: ResourceState, rhs: ResourceState) -> None:
            left_desc = self.describe_state(lhs)
            right_desc = self.describe_state(rhs)
            differs_here = (
                lhs.type_name != rhs.type_name
                or lhs.state != rhs.state
                or set(lhs.members) != set(rhs.members)
            )
            if differs_here:
                descriptions.append((self.display_path_text(path), left_desc, right_desc))
            if lhs.type_name != rhs.type_name or set(lhs.members) != set(rhs.members):
                return
            for child_name in sorted(lhs.members):
                visit(f'{path}.{child_name}', lhs.members[child_name], rhs.members[child_name])

        visit(root_name, left, right)
        root = (self.display_path_text(root_name), self.describe_state(left), self.describe_state(right))
        if not descriptions:
            descriptions.append(root)
        elif descriptions[0] != root:
            descriptions.insert(0, root)
        return descriptions

    def alias_merge_message(self, node: CFGNode, name: str, left: str, right: str) -> str:
        if node.label == 'if:join':
            return f'if branches leave reference alias {name} without a unique referent: {right} vs {left}'
        if node.label == 'cleanup:join':
            return f'cleanup branches leave reference alias {name} without a unique referent: {right} vs {left}'
        return f'CFG merge leaves reference alias {name} without a unique referent at node {node.id}: {left} vs {right}'

    def exit_message(self, name: str, type_name: str, state: str, exit_kind: str) -> str:
        if exit_kind == 'function exit':
            return f'resource {name}: {type_name} leaves scope in non-terminal state {state}'
        return f'resource {name}: {type_name} reaches {exit_kind} in non-terminal state {state}'

    def scope_pop_message(self, name: str, type_name: str, state: str) -> str:
        return f'resource {name}: {type_name} leaves block scope in non-terminal state {state}'


def analyze_ownership(module: ast.Module, imported_signatures: dict[str, FunctionOwnershipSignature] | None = None) -> OwnershipSummary:
    return CFGOwnershipAnalyzer(module, imported_signatures=imported_signatures).analyze()


def export_ownership_signatures(module: ast.Module, imported_signatures: dict[str, FunctionOwnershipSignature] | None = None) -> OwnershipSignatureBundle:
    summary = analyze_ownership(module, imported_signatures=imported_signatures)
    fn_map = {decl.name: decl for decl in module.decls if isinstance(decl, ast.FnDecl)}
    analyzer = CFGOwnershipAnalyzer(module, imported_signatures=imported_signatures)
    exported = []
    module_path = '.'.join(module.path)
    for fn in summary.functions:
        decl = fn_map.get(fn.name)
        ref_params = []
        if decl is not None:
            for idx, param in enumerate(decl.params):
                ref_type = analyzer.ref_referent_type(param.typ)
                if ref_type is None:
                    continue
                inner = analyzer.unwrap_type(param.typ)
                mode = 'mut' if isinstance(inner, ast.GenericType) and inner.name == 'Ref' else 'const'
                ref_params.append(RefParamOwnershipSignature(param_index=idx, mode=mode, type_name=ref_type, effects=dict(fn.ref_param_effects.get(param.name, {}))))
        exported.append(FunctionOwnershipSignature(name=f'{module_path}.{fn.name}', ref_params=ref_params, param_types=[format_type(param.typ) for param in decl.params] if decl is not None else [], return_type=format_type(decl.return_type) if decl is not None else 'Unit', effects=list(decl.effects) if decl is not None else []))
    return OwnershipSignatureBundle(module_path=module_path, functions=exported)
