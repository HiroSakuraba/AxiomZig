from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json

from . import ast
from .lexer import lex
from .parser import Parser


@dataclass(slots=True)
class RefParamOwnershipSignature:
    param_index: int
    mode: str
    type_name: str
    effects: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class FunctionOwnershipSignature:
    name: str
    ref_params: list[RefParamOwnershipSignature] = field(default_factory=list)
    param_types: list[str] = field(default_factory=list)
    return_type: str = 'Unit'
    effects: list[str] = field(default_factory=list)


@dataclass(slots=True)
class OwnershipSignatureBundle:
    module_path: str
    functions: list[FunctionOwnershipSignature] = field(default_factory=list)


@dataclass(slots=True, frozen=True)
class PathSegment:
    kind: str
    value: str | int


CanonicalPath = tuple[PathSegment, ...]


def field_segment(name: str) -> PathSegment:
    if not name:
        raise ValueError('empty field segment')
    return PathSegment('field', name)


def index_segment(index: int) -> PathSegment:
    if index < 0:
        raise ValueError('negative index segment')
    return PathSegment('index', index)


def canonical_path_to_runtime_parts(path: CanonicalPath) -> tuple[str | int, ...]:
    return tuple(seg.value for seg in path)


def canonical_path_to_summary_text(path: CanonicalPath) -> str:
    return '.'.join(str(seg.value) for seg in path)


def canonical_path_to_display_text(path: CanonicalPath) -> str:
    pieces: list[str] = []
    for seg in path:
        if seg.kind == 'field':
            if pieces:
                pieces.append(f'.{seg.value}')
            else:
                pieces.append(str(seg.value))
        elif seg.kind == 'index':
            pieces.append(f'[{seg.value}]')
        else:
            pieces.append(f'[{seg.kind}:{seg.value}]')
    return ''.join(pieces) if pieces else '<root>'


def parse_canonical_path(path: str | tuple[str | int, ...] | list[str | int]) -> CanonicalPath:
    """Parse an imported ownership path into the sole canonical representation.

    Accepted text forms are deliberately small: ``inner``, ``0.inner``,
    ``hs.0.inner``, and bracketed literal indexes such as ``hs[0].inner``.
    Dynamic/wildcard indexes, slices, empty segments, negative indexes, and
    disguised symbolic indexes are rejected here before ownership or runtime
    layers can interpret them differently.
    """
    if isinstance(path, (tuple, list)):
        segments: list[PathSegment] = []
        for raw in path:
            if isinstance(raw, int):
                segments.append(index_segment(raw))
            elif isinstance(raw, str):
                if raw in {'', '*', '[*]'} or raw.startswith('[') or raw.endswith(']'):
                    raise ValueError(f'unsupported imported ownership path {path!r}: dynamic/wildcard indexes are not canonical')
                segments.append(index_segment(int(raw)) if raw.isdigit() else field_segment(raw))
            else:
                raise ValueError(f'malformed imported ownership path {path!r}: unsupported segment {raw!r}')
        return tuple(segments)
    if path == '':
        return ()
    segments: list[PathSegment] = []
    i = 0
    token = ''
    def flush_token() -> None:
        nonlocal token
        if token == '':
            raise ValueError(f'malformed imported ownership path {path!r}: empty segment')
        segments.append(index_segment(int(token)) if token.isdigit() else field_segment(token))
        token = ''
    while i < len(path):
        ch = path[i]
        if ch == '.':
            if token:
                flush_token()
            elif i == 0 or path[i - 1] != ']':
                raise ValueError(f'malformed imported ownership path {path!r}: empty segment')
            i += 1
            continue
        if ch == '[':
            if token:
                flush_token()
            j = path.find(']', i + 1)
            if j == -1:
                raise ValueError(f'malformed imported ownership path {path!r}: missing closing bracket')
            inner = path[i + 1:j]
            if not inner.isdigit():
                raise ValueError(f'unsupported imported ownership path {path!r}: dynamic/wildcard indexes are not canonical')
            segments.append(index_segment(int(inner)))
            i = j + 1
            if i < len(path) and path[i] not in '.[':
                raise ValueError(f'malformed imported ownership path {path!r}: expected separator after index')
            continue
        if ch == ']' or ch == '*':
            raise ValueError(f'unsupported imported ownership path {path!r}: dynamic/wildcard indexes are not canonical')
        token += ch
        i += 1
    if token or path.endswith('.'):
        flush_token()
    return tuple(segments)


# Backward-compatible name used by older code/tests.  It now goes through the
# canonical representation and returns only a legacy projection tuple at API
# boundaries that still need tuple[str|int].
def split_effect_path(path: str) -> tuple[str | int, ...]:
    return canonical_path_to_runtime_parts(parse_canonical_path(path))


@dataclass(slots=True, frozen=True)
class NormalizedRefEffect:
    param_index: int
    mode: str
    type_name: str
    path: str
    canonical_path: CanonicalPath
    state: str

    @property
    def path_parts(self) -> tuple[str | int, ...]:
        return canonical_path_to_runtime_parts(self.canonical_path)

    @property
    def display_path(self) -> str:
        return canonical_path_to_display_text(self.canonical_path)


@dataclass(slots=True, frozen=True)
class NormalizedImportedFunctionContract:
    name: str
    param_types: tuple[str, ...]
    return_type: str
    effects: tuple[str, ...]
    ref_params: tuple[RefParamOwnershipSignature, ...]
    ref_effects: tuple[NormalizedRefEffect, ...]

    def paths_for_ref_param(self, param_index: int) -> set[tuple[str | int, ...]]:
        return {effect.path_parts for effect in self.ref_effects if effect.param_index == param_index}

    def canonical_paths_for_ref_param(self, param_index: int) -> set[CanonicalPath]:
        return {effect.canonical_path for effect in self.ref_effects if effect.param_index == param_index}

    def state_text_for_ref_effect(self, param_index: int, path: CanonicalPath) -> str | None:
        for effect in self.ref_effects:
            if effect.param_index == param_index and effect.canonical_path == path:
                return effect.state
        return None


def _paths_overlap(left: CanonicalPath, right: CanonicalPath) -> bool:
    shared = min(len(left), len(right))
    return left[:shared] == right[:shared]


def normalize_imported_function_contract(sig: FunctionOwnershipSignature) -> NormalizedImportedFunctionContract:
    ref_effects: list[NormalizedRefEffect] = []
    seen_params: set[int] = set()
    seen_effects: dict[tuple[int, CanonicalPath], str] = {}
    for ref in sig.ref_params:
        if ref.param_index < 0:
            raise ValueError(f'imported function {sig.name} has negative ref param index {ref.param_index}')
        if ref.param_index in seen_params:
            raise ValueError(f'imported function {sig.name} has duplicate ref param index {ref.param_index}')
        seen_params.add(ref.param_index)
        if ref.param_index >= len(sig.param_types):
            raise ValueError(f'imported function {sig.name} ref param {ref.param_index + 1} exceeds parameter list')
        if ref.mode not in {'mut', 'const'}:
            raise ValueError(f'imported function {sig.name} ref param {ref.param_index + 1} has unsupported mode {ref.mode!r}')
        declared_type = sig.param_types[ref.param_index]
        if ref.mode == 'mut' and not declared_type.startswith('Ref<'):
            raise ValueError(f'imported function {sig.name} ref param {ref.param_index + 1} is declared mut but parameter type is {declared_type!r}')
        if ref.mode == 'const' and not (declared_type.startswith('Ref<') or declared_type.startswith('RefConst<')):
            raise ValueError(f'imported function {sig.name} ref param {ref.param_index + 1} is declared const but parameter type is {declared_type!r}')
        for raw_path, state in sorted(ref.effects.items()):
            try:
                canonical = parse_canonical_path(raw_path)
            except ValueError:
                bad = [p for p in ref.effects if '[' in p or '*' in p or (p != '' and '..' in p)]
                rendered = ', '.join(sorted(bad)) or raw_path
                raise ValueError(
                    f'imported/reference ownership summary for {sig.name} '
                    f'uses unsupported non-literal indexed path(s): {rendered}'
                )
            key = (ref.param_index, canonical)
            prior_state = seen_effects.get(key)
            if prior_state is not None and prior_state != state:
                raise ValueError(
                    f'imported function {sig.name} has conflicting summaries for '
                    f'{canonical_path_to_display_text(canonical)}: {prior_state} vs {state}'
                )
            for (prior_idx, prior_path), prior_state in seen_effects.items():
                if prior_idx == ref.param_index and prior_path != canonical and _paths_overlap(prior_path, canonical):
                    raise ValueError(
                        f'imported function {sig.name} has overlapping ownership summaries '
                        f'{canonical_path_to_display_text(prior_path)} and {canonical_path_to_display_text(canonical)}'
                    )
            seen_effects[key] = state
            ref_effects.append(
                NormalizedRefEffect(
                    ref.param_index,
                    ref.mode,
                    ref.type_name,
                    canonical_path_to_summary_text(canonical),
                    canonical,
                    state,
                )
            )
    return NormalizedImportedFunctionContract(
        name=sig.name,
        param_types=tuple(sig.param_types),
        return_type=sig.return_type,
        effects=tuple(sig.effects),
        ref_params=tuple(sig.ref_params),
        ref_effects=tuple(ref_effects),
    )


def normalize_imported_contracts(signatures: dict[str, FunctionOwnershipSignature] | None) -> dict[str, NormalizedImportedFunctionContract]:
    return {name: normalize_imported_function_contract(sig) for name, sig in (signatures or {}).items()}


def parse_type_text(text: str) -> ast.Type:
    parser = Parser(lex(text))
    typ = parser.parse_type()
    if parser.peek().kind != 'EOF':
        raise ValueError(f'unconsumed type text: {text!r}')
    return typ


def bundle_from_dict(data: dict) -> OwnershipSignatureBundle:
    functions: list[FunctionOwnershipSignature] = []
    for fn in data.get('functions', []):
        ref_params = [
            RefParamOwnershipSignature(
                param_index=item['param_index'],
                mode=item['mode'],
                type_name=item['type_name'],
                effects=dict(item.get('effects', {})),
            )
            for item in fn.get('ref_params', [])
        ]
        functions.append(
            FunctionOwnershipSignature(
                name=fn['name'],
                ref_params=ref_params,
                param_types=list(fn.get('param_types', [])),
                return_type=fn.get('return_type', 'Unit'),
                effects=list(fn.get('effects', [])),
            )
        )
    return OwnershipSignatureBundle(module_path=data['module_path'], functions=functions)




def _manifest_hash(payload: dict) -> str:
    body = {key: value for key, value in payload.items() if key != 'manifest_hash'}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()


def dependency_lock_digest(lock: dict) -> str:
    return hashlib.sha256(json.dumps(lock, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()


def dependency_manifest_identity_from_dict(data: dict) -> tuple[str, str, str]:
    package_name = str(data.get('package_name', '')).strip()
    if not package_name:
        raise ValueError('dependency manifest is missing package_name')
    package_version = str(data.get('package_version', '')).strip()
    if not package_version:
        raise ValueError('dependency manifest is missing package_version')
    package_id = str(data.get('package_id', '')).strip()
    expected_package_id = f'{package_name}@{package_version}'
    if not package_id:
        raise ValueError('dependency manifest is missing package_id')
    if package_id != expected_package_id:
        raise ValueError(
            f'dependency manifest package_id mismatch: expected {expected_package_id!r}, got {package_id!r}'
        )
    return package_name, package_version, package_id


def validate_dependency_manifest_dict(data: dict) -> None:
    schema = str(data.get('schema_version', '')).strip()
    if not (schema.startswith('axiomzig.conformance.') or schema == 'axiomzig.publication_manifest.v1'):
        raise ValueError('dependency manifest must be an axiomzig conformance or publication manifest')
    dependency_manifest_identity_from_dict(data)
    status = data.get('status')
    if status != 'ok':
        raise ValueError(f"dependency manifest status must be 'ok', got {status!r}")
    internal = data.get('internal_signatures')
    if not isinstance(internal, dict):
        raise ValueError('dependency manifest is missing internal_signatures')
    algo = str(data.get('manifest_hash_algorithm', '')).strip()
    if algo != 'sha256':
        raise ValueError("dependency manifest must declare manifest_hash_algorithm='sha256'")
    actual_hash = str(data.get('manifest_hash', '')).strip()
    if not actual_hash:
        raise ValueError('dependency manifest is missing manifest_hash')
    expected_hash = _manifest_hash(data)
    if actual_hash != expected_hash:
        raise ValueError('dependency manifest hash does not match manifest body')


def validate_dependency_lock_dict(data: dict) -> dict[str, dict]:
    schema = str(data.get('schema_version', ''))
    if schema != 'axiomzig.dependency_lock.v1':
        raise ValueError("dependency lock must use schema_version='axiomzig.dependency_lock.v1'")
    deps = data.get('dependencies')
    if not isinstance(deps, list):
        raise ValueError('dependency lock is missing dependencies list')
    entries: dict[str, dict] = {}
    seen_modules: dict[str, str] = {}
    for item in deps:
        if not isinstance(item, dict):
            raise ValueError('dependency lock dependency entries must be objects')
        package_name = str(item.get('package_name', '')).strip()
        package_version = str(item.get('package_version', '')).strip()
        package_id = str(item.get('package_id', '')).strip()
        if not package_name or not package_version or not package_id:
            raise ValueError('dependency lock entries must define package_name, package_version, and package_id')
        expected_package_id = f'{package_name}@{package_version}'
        if package_id != expected_package_id:
            raise ValueError(
                f'dependency lock entry package_id mismatch: expected {expected_package_id!r}, got {package_id!r}'
            )
        manifest_hash = str(item.get('manifest_hash', '')).strip()
        if not manifest_hash:
            raise ValueError(f'dependency lock entry {package_id} is missing manifest_hash')
        modules = item.get('modules')
        if not isinstance(modules, list) or not modules:
            raise ValueError(f'dependency lock entry {package_id} is missing modules list')
        if package_id in entries:
            raise ValueError(f'dependency lock has duplicate package_id {package_id}')
        normalized_modules = sorted({str(module) for module in modules})
        for module_name in normalized_modules:
            prior = seen_modules.get(module_name)
            if prior is not None:
                raise ValueError(
                    f'dependency lock module {module_name} is pinned by multiple packages: {prior} and {package_id}'
                )
            seen_modules[module_name] = package_id
        entries[package_id] = {
            'package_name': package_name,
            'package_version': package_version,
            'package_id': package_id,
            'manifest_hash': manifest_hash,
            'modules': normalized_modules,
        }
    return entries


def bundles_from_dependency_manifest_dict(data: dict) -> list[OwnershipSignatureBundle]:
    validate_dependency_manifest_dict(data)
    internal = data.get('internal_signatures')
    bundles: list[OwnershipSignatureBundle] = []
    for module_name, bundle in sorted(internal.items()):
        item = dict(bundle)
        item.setdefault('module_path', module_name)
        bundles.append(bundle_from_dict(item))
    return bundles


def dependency_module_names_from_manifest_dict(data: dict) -> set[str]:
    validate_dependency_manifest_dict(data)
    internal = data.get('internal_signatures')
    exported = data.get('exported_modules')
    if isinstance(exported, list) and exported:
        return {str(item) for item in exported}
    return {str(name) for name in internal}


def dependency_manifest_record_from_dict(data: dict) -> dict[str, object]:
    package_name, package_version, package_id = dependency_manifest_identity_from_dict(data)
    modules = sorted(dependency_module_names_from_manifest_dict(data))
    return {
        'package_name': package_name,
        'package_version': package_version,
        'package_id': package_id,
        'manifest_hash': str(data.get('manifest_hash', '')).strip(),
        'modules': modules,
        'export_scope': data.get('export_scope'),
    }


_PUBLIC_DEPENDENCY_SURFACE_KEYS = (
    'exported_modules',
    'exported_functions',
    'exported_resources',
    'exported_protocols',
    'public_function_metadata',
    'public_resource_metadata',
    'public_protocol_metadata',
    'public_resource_shapes',
    'public_protocol_shapes',
    'internal_signatures',
    'api_compatibility',
)


def dependency_public_surface_from_manifest_dict(data: dict) -> dict[str, object]:
    validate_dependency_manifest_dict(data)
    surface: dict[str, object] = {}
    for key in _PUBLIC_DEPENDENCY_SURFACE_KEYS:
        value = data.get(key)
        if value not in (None, {}, []):
            surface[key] = value
    return surface


def dependency_public_surface_digest_from_manifest_dict(data: dict) -> str:
    surface = dependency_public_surface_from_manifest_dict(data)
    return hashlib.sha256(json.dumps(surface, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()


def _split_package_id(package_id: str) -> tuple[str, str]:
    text = str(package_id).strip()
    if '@' not in text:
        return text, ''
    name, version = text.rsplit('@', 1)
    return name, version


def _normalize_dependency_closure_record(raw: dict, *, direct: bool, depth: int, required_by: str) -> dict[str, object]:
    package_id = str(raw.get('package_id', '')).strip()
    package_name = str(raw.get('package_name', '')).strip()
    package_version = str(raw.get('package_version', '')).strip()
    if not package_name or not package_version:
        inferred_name, inferred_version = _split_package_id(package_id)
        package_name = package_name or inferred_name
        package_version = package_version or inferred_version
    if not package_id and package_name and package_version:
        package_id = f'{package_name}@{package_version}'
    if not package_id or not package_name or not package_version:
        raise ValueError(f'dependency publication closure record is missing identity: {raw!r}')
    manifest_hash = str(raw.get('manifest_hash', '')).strip()
    modules = sorted({str(item) for item in (raw.get('modules') or [])})
    public_surface = raw.get('public_surface') if isinstance(raw.get('public_surface'), dict) else None
    public_surface_digest = str(raw.get('public_surface_digest', '')).strip()
    if public_surface is not None and not public_surface_digest:
        public_surface_digest = hashlib.sha256(json.dumps(public_surface, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()
    record: dict[str, object] = {
        'package_name': package_name,
        'package_version': package_version,
        'package_id': package_id,
        'manifest_hash': manifest_hash,
        'modules': modules,
        'export_scope': raw.get('export_scope'),
        'direct': bool(direct),
        'depth': int(depth),
        'required_by': [required_by],
    }
    if public_surface_digest:
        record['public_surface_digest'] = public_surface_digest
    if public_surface is not None:
        record['public_surface'] = public_surface
    return record


def _merge_dependency_closure_record(records: dict[str, dict[str, object]], record: dict[str, object]) -> None:
    package_id = str(record['package_id'])
    prior = records.get(package_id)
    if prior is None:
        records[package_id] = record
        return
    prior_hash = str(prior.get('manifest_hash', '')).strip()
    new_hash = str(record.get('manifest_hash', '')).strip()
    if prior_hash and new_hash and prior_hash != new_hash:
        raise ValueError(
            f'transitive dependency closure conflict for {package_id}: manifest hashes {prior_hash} and {new_hash}'
        )
    prior_digest = str(prior.get('public_surface_digest', '')).strip()
    new_digest = str(record.get('public_surface_digest', '')).strip()
    if prior_digest and new_digest and prior_digest != new_digest:
        raise ValueError(
            f'transitive dependency closure conflict for {package_id}: public surface digests {prior_digest} and {new_digest}'
        )
    prior['direct'] = bool(prior.get('direct')) or bool(record.get('direct'))
    prior['depth'] = min(int(prior.get('depth', 999)), int(record.get('depth', 999)))
    prior_required = {str(item) for item in prior.get('required_by', [])}
    prior_required.update(str(item) for item in record.get('required_by', []))
    prior['required_by'] = sorted(prior_required)
    if not prior.get('manifest_hash') and record.get('manifest_hash'):
        prior['manifest_hash'] = record['manifest_hash']
    if not prior.get('public_surface_digest') and record.get('public_surface_digest'):
        prior['public_surface_digest'] = record['public_surface_digest']
    if not prior.get('public_surface') and record.get('public_surface'):
        prior['public_surface'] = record['public_surface']


def dependency_publication_closure_from_manifest_inputs(items: list[tuple[str, dict]]) -> list[dict[str, object]]:
    records: dict[str, dict[str, object]] = {}
    for _label, data in items:
        validate_dependency_manifest_dict(data)
        direct_record = dependency_manifest_record_from_dict(data)
        direct_record['public_surface'] = dependency_public_surface_from_manifest_dict(data)
        direct_record['public_surface_digest'] = dependency_public_surface_digest_from_manifest_dict(data)
        direct_id = str(direct_record['package_id'])
        _merge_dependency_closure_record(
            records,
            _normalize_dependency_closure_record(direct_record, direct=True, depth=1, required_by='<root>'),
        )
        raw_closure = data.get('dependency_publication_closure')
        if isinstance(raw_closure, list) and raw_closure:
            transitive_items = raw_closure
        else:
            transitive_items = data.get('dependency_publication_refs') if isinstance(data.get('dependency_publication_refs'), list) else []
        for raw in transitive_items or []:
            if not isinstance(raw, dict):
                continue
            raw_depth = raw.get('depth')
            try:
                depth = int(raw_depth) + 1 if raw_depth is not None else 2
            except (TypeError, ValueError):
                depth = 2
            record = _normalize_dependency_closure_record(raw, direct=False, depth=depth, required_by=direct_id)
            _merge_dependency_closure_record(records, record)
    return [
        records[key]
        for key in sorted(records, key=lambda item: (str(records[item].get('package_name')), int(records[item].get('depth', 0)), item))
    ]


def dependency_lock_from_manifest_inputs(items: list[tuple[str, dict]]) -> dict[str, object]:
    records: list[dict[str, object]] = []
    for _label, data in items:
        validate_dependency_manifest_dict(data)
        records.append(dependency_manifest_record_from_dict(data))
    records.sort(key=lambda item: str(item['package_id']))
    return {
        'schema_version': 'axiomzig.dependency_lock.v1',
        'dependencies': records,
    }


def load_dependency_manifest_inputs(
    items: list[tuple[str, dict]],
    *,
    dependency_lock: dict | None = None,
) -> tuple[list[OwnershipSignatureBundle], set[str]]:
    bundles: list[OwnershipSignatureBundle] = []
    dependency_modules: set[str] = set()
    seen_modules: dict[str, str] = {}
    lock_entries = validate_dependency_lock_dict(dependency_lock) if dependency_lock is not None else None
    seen_packages: set[str] = set()
    for label, data in items:
        validate_dependency_manifest_dict(data)
        _, _, package_id = dependency_manifest_identity_from_dict(data)
        current_modules = dependency_module_names_from_manifest_dict(data)
        if lock_entries is not None:
            entry = lock_entries.get(package_id)
            if entry is None:
                raise ValueError(f'dependency manifest {label} with package_id {package_id} is not present in dependency lock')
            actual_hash = str(data.get('manifest_hash', '')).strip()
            if actual_hash != entry['manifest_hash']:
                raise ValueError(
                    f'dependency manifest {label} hash does not match locked hash for {package_id}'
                )
            if sorted(current_modules) != entry['modules']:
                raise ValueError(
                    f'dependency manifest {label} exports modules {sorted(current_modules)!r}, '
                    f'but dependency lock pins {entry["modules"]!r} for {package_id}'
                )
        seen_packages.add(package_id)
        for module_name in sorted(current_modules):
            prior = seen_modules.get(module_name)
            if prior is not None:
                raise ValueError(
                    f'dependency module {module_name} provided by multiple manifests: {prior} and {label}'
                )
            seen_modules[module_name] = label
        bundles.extend(bundles_from_dependency_manifest_dict(data))
        dependency_modules.update(current_modules)
    if lock_entries is not None:
        missing_packages = sorted(set(lock_entries) - seen_packages)
        if missing_packages:
            raise ValueError(
                f'dependency lock expects manifests for packages {missing_packages!r}, but they were not provided'
            )
    return bundles, dependency_modules

def canonical_path_to_jsonable(path: CanonicalPath) -> list[dict[str, str | int]]:
    return [{'kind': seg.kind, 'value': seg.value} for seg in path]


def normalized_contract_to_jsonable(contract: NormalizedImportedFunctionContract) -> dict:
    return {
        'name': contract.name,
        'param_types': list(contract.param_types),
        'return_type': contract.return_type,
        'effects': sorted(contract.effects),
        'ref_params': [
            {
                'param_index': ref.param_index,
                'mode': ref.mode,
                'type_name': ref.type_name,
                'effects': {
                    canonical_path_to_summary_text(effect.canonical_path): effect.state
                    for effect in sorted(
                        (item for item in contract.ref_effects if item.param_index == ref.param_index),
                        key=lambda item: (item.param_index, item.path_parts),
                    )
                },
            }
            for ref in sorted(contract.ref_params, key=lambda item: item.param_index)
        ],
        'ref_effects': [
            {
                'param_index': effect.param_index,
                'mode': effect.mode,
                'type_name': effect.type_name,
                'path': effect.path,
                'display_path': effect.display_path,
                'canonical_path': canonical_path_to_jsonable(effect.canonical_path),
                'state': effect.state,
            }
            for effect in sorted(contract.ref_effects, key=lambda item: (item.param_index, item.path_parts))
        ],
    }


def signature_bundle_to_jsonable(bundle: OwnershipSignatureBundle) -> dict:
    normalized = [normalize_imported_function_contract(fn) for fn in bundle.functions]
    return {
        'module_path': bundle.module_path,
        'functions': [
            normalized_contract_to_jsonable(contract)
            for contract in sorted(normalized, key=lambda item: item.name)
        ],
    }


def bundle_index(bundle: OwnershipSignatureBundle) -> dict[str, FunctionOwnershipSignature]:
    return {fn.name: fn for fn in bundle.functions}


def _function_signature_fingerprint(fn: FunctionOwnershipSignature) -> str:
    contract = normalize_imported_function_contract(fn)
    return json.dumps(normalized_contract_to_jsonable(contract), sort_keys=True, separators=(",", ":"))


def merge_signature_bundles(bundles: list[OwnershipSignatureBundle]) -> dict[str, FunctionOwnershipSignature]:
    merged: dict[str, FunctionOwnershipSignature] = {}
    fingerprints: dict[str, str] = {}
    for bundle in bundles:
        for fn in bundle.functions:
            fingerprint = _function_signature_fingerprint(fn)
            prior = fingerprints.get(fn.name)
            if prior is not None and prior != fingerprint:
                raise ValueError(f'conflicting ownership summaries for imported function {fn.name}')
            merged.setdefault(fn.name, fn)
            fingerprints.setdefault(fn.name, fingerprint)
    return merged
