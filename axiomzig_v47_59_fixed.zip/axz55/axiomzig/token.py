from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Token:
    kind: str
    value: str
    line: int
    column: int

    def short(self) -> str:
        return f"{self.kind}({self.value!r})@{self.line}:{self.column}"
