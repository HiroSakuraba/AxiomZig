from __future__ import annotations

from dataclasses import dataclass

from . import ast


def _parse_int_literal(raw: str) -> int | None:
    if not raw:
        return None
    text = raw.replace('_', '')
    try:
        value = int(text, 10)
    except ValueError:
        return None
    return value if value >= 0 else None
from .formatter import format_type


@dataclass(frozen=True, slots=True)
class SemProjection:
    kind: str
    value: str | int | None = None


@dataclass(frozen=True, slots=True)
class SemPlace:
    root: str
    projections: tuple[SemProjection, ...] = ()

    def to_path(self) -> str:
        pieces = [self.root] if self.root else []
        for projection in self.projections:
            if projection.kind == 'field' and projection.value is not None:
                pieces.append(str(projection.value))
            elif projection.kind == 'index':
                pieces.append(f'[{projection.value}]' if projection.value is not None else '[*]')
            elif projection.kind == 'slice':
                pieces.append('[..]')
            else:
                pieces.append(f'[{projection.kind}]')
        return '.'.join(pieces)


@dataclass(frozen=True, slots=True)
class TypeFacts:
    type_text: str
    normalized_type_text: str
    is_ref: bool
    ref_mode: str | None
    is_tracked: bool
    is_protocol_resource: bool
    protocol_name: str | None
    tracked_children: tuple[tuple[str, ...], ...]
    terminal_states: tuple[str, ...]
    copyable: bool
    resource_type_name: str | None = None


def sem_place_for_expr(expr: ast.Expr) -> SemPlace | None:
    if isinstance(expr, ast.NameExpr):
        return SemPlace(root=expr.name)
    if isinstance(expr, ast.DottedExpr):
        if not expr.parts:
            return None
        return SemPlace(root=expr.parts[0], projections=tuple(SemProjection('field', part) for part in expr.parts[1:]))
    if isinstance(expr, ast.AttrExpr):
        base = sem_place_for_expr(expr.obj)
        if base is None:
            return None
        return SemPlace(root=base.root, projections=base.projections + (SemProjection('field', expr.name),))
    if isinstance(expr, ast.IndexExpr):
        base = sem_place_for_expr(expr.obj)
        if base is None:
            return None
        index_value = _parse_int_literal(expr.index.raw) if isinstance(expr.index, ast.IntExpr) else None
        return SemPlace(root=base.root, projections=base.projections + (SemProjection('index', index_value),))
    if isinstance(expr, ast.SliceExpr):
        base = sem_place_for_expr(expr.obj)
        if base is None:
            return None
        return SemPlace(root=base.root, projections=base.projections + (SemProjection('slice', None),))
    return None


def sem_place_from_path(path: str) -> SemPlace:
    if not path:
        return SemPlace(root='')
    parts = path.split('.')
    root = parts[0]
    projections: list[SemProjection] = []
    for part in parts[1:]:
        if part == '[*]':
            projections.append(SemProjection('index', None))
        elif part.startswith('[') and part.endswith(']') and part[1:-1].lstrip('-').isdigit():
            projections.append(SemProjection('index', int(part[1:-1])))
        elif part == '[..]':
            projections.append(SemProjection('slice', None))
        elif part.lstrip('-').isdigit():
            value = int(part)
            projections.append(SemProjection('index', value if value >= 0 else None))
        else:
            projections.append(SemProjection('field', part))
    return SemPlace(root=root, projections=tuple(projections))


def sem_relative_place_from_suffix(suffix: str | None) -> SemPlace | None:
    if not suffix:
        return SemPlace(root='')
    place = sem_place_from_path(f'__rel__.{suffix}')
    return SemPlace(root='', projections=place.projections)


def sem_relative_place_for_expr(expr: ast.Expr, root_name: str) -> SemPlace | None:
    place = sem_place_for_expr(expr)
    if place is None or place.root != root_name:
        return None
    return SemPlace(root='', projections=place.projections)


def combine_sem_place(base: SemPlace, relative: SemPlace | None) -> SemPlace:
    if relative is None:
        return base
    if relative.root not in {'', base.root}:
        return relative
    return SemPlace(root=base.root, projections=base.projections + relative.projections)


def sem_places_conflict(left: SemPlace, right: SemPlace) -> bool:
    if left.root != right.root:
        return False
    shared = min(len(left.projections), len(right.projections))
    for idx in range(shared):
        lproj = left.projections[idx]
        rproj = right.projections[idx]
        if lproj.kind != rproj.kind:
            return False
        if lproj.kind == 'field' and lproj.value != rproj.value:
            return False
        if lproj.kind == 'index':
            if lproj.value is None or rproj.value is None or lproj.value == rproj.value:
                continue
            return False
        if lproj.kind == 'slice':
            return True
    return True



def type_text_for_semantic(typ: ast.Type | None, default: str = '<unknown>') -> str:
    if typ is None:
        return default
    return format_type(typ)
