from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from typing import Literal

from . import ast
from .ownership import export_ownership_signatures
from .ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature, NormalizedImportedFunctionContract, CanonicalPath, canonical_path_to_runtime_parts, normalize_imported_contracts, normalize_imported_function_contract, parse_canonical_path, parse_type_text


class InterpreterUnsupportedError(Exception):
    pass


class TrapError(Exception):
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


class ReturnSignal(Exception):
    def __init__(self, value: 'Value'):
        super().__init__("return")
        self.value = value


class BreakSignal(Exception):
    pass


class ContinueSignal(Exception):
    pass


class PropagateErrSignal(Exception):
    def __init__(self, err: 'ErrVal'):
        super().__init__("propagate_err")
        self.err = err


@dataclass(slots=True, frozen=True)
class RuntimePlace:
    root_cell: int
    path: tuple[str | int, ...] = ()


@dataclass(slots=True, frozen=True)
class RuntimeAccess:
    place: RuntimePlace
    mutable: bool


@dataclass(slots=True)
class UnitVal:
    pass


@dataclass(slots=True)
class BoolVal:
    value: bool


@dataclass(slots=True)
class IntVal:
    value: int
    width: int = 64
    signed: bool = True
    contextual: bool = False


@dataclass(slots=True)
class StrVal:
    value: str


@dataclass(slots=True)
class SomeVal:
    inner: 'Value'


@dataclass(slots=True)
class NoneVal:
    pass


@dataclass(slots=True)
class OkVal:
    inner: 'Value'


@dataclass(slots=True)
class ErrVal:
    tag: str


@dataclass(slots=True)
class StructVal:
    name: str
    fields: dict[str, 'Value']


@dataclass(slots=True)
class ResourceVal:
    name: str
    protocol_name: str | None
    protocol_state: str | None
    fields: dict[str, 'Value']


@dataclass(slots=True)
class MovedVal:
    pass


@dataclass(slots=True)
class EnumVal:
    enum_name: str
    variant_name: str
    fields: dict[str, 'Value'] = field(default_factory=dict)


@dataclass(slots=True)
class RangeVal:
    start: int
    stop: int


@dataclass(slots=True)
class ArrayVal:
    elements: list['Value']


@dataclass(slots=True)
class SliceVal:
    base_place: RuntimePlace
    start: int
    length: int


@dataclass(slots=True)
class RefVal:
    place: RuntimePlace
    mutable: bool


@dataclass(slots=True)
class ImportWrite:
    ref_param_index: int
    path: CanonicalPath | tuple[str | int, ...] = ()
    value: 'Value | None' = None
    source_arg_index: int | None = None
    move: bool = False
    allow_live_resource_replace: bool = False


@dataclass(slots=True)
class ImportStub:
    """Deterministic runtime stub for an imported function.

    Imported execution is intentionally closed over a fixed interpreter-side
    registry.  Callers may supply:

    - a builtin name understood by the interpreter, or
    - declarative ref writes and/or a preconstructed return value.

    No arbitrary host callback is ever executed.  Argument coercion happens
    before stub evaluation, and return coercion happens afterwards.
    """

    builtin: str | None = None
    writes: list[ImportWrite] = field(default_factory=list)
    return_value: 'Value | None' = None


Value = UnitVal | BoolVal | IntVal | StrVal | SomeVal | NoneVal | OkVal | ErrVal | StructVal | ResourceVal | EnumVal | RangeVal | ArrayVal | SliceVal | RefVal | MovedVal


@dataclass(slots=True)
class Binding:
    mutable: bool
    cell_id: int
    typ: ast.Type | None = None


@dataclass(slots=True)
class DeferEntry:
    stmt: ast.Stmt
    mode: Literal["always", "error"]


@dataclass(slots=True)
class ScopeRuntime:
    bindings: dict[str, Binding] = field(default_factory=dict)
    defer_entries: list[DeferEntry] = field(default_factory=list)


@dataclass(slots=True)
class Frame:
    fn: ast.FnDecl
    scopes: list[ScopeRuntime] = field(default_factory=lambda: [ScopeRuntime()])


@dataclass(slots=True)
class InterpreterState:
    frames: list[Frame]
    store: dict[int, Value] = field(default_factory=dict)
    own_map: dict[str, str] = field(default_factory=dict)
    proto_map: dict[str, str] = field(default_factory=dict)
    next_alloc_id: int = 1


class Interpreter:
    def __init__(self, module: ast.Module, imported_signatures: dict[str, FunctionOwnershipSignature] | None = None, import_stubs: dict[str, ImportStub] | None = None):
        self.module = module
        self.imported_signatures = imported_signatures or {}
        self.imported_contracts = normalize_imported_contracts(self.imported_signatures)
        self.import_stubs = import_stubs or {}
        self.import_aliases: dict[str, str] = {}
        self.module_path = ".".join(self.module.path)
        self.functions: dict[str, ast.FnDecl] = {}
        self.consts: dict[str, ast.ConstDecl] = {}
        self.error_sets: dict[str, ast.ErrorSetDecl] = {}
        self.enums: dict[str, ast.EnumDecl] = {}
        self.structs: dict[str, ast.StructDecl] = {}
        self.resources: dict[str, ast.ResourceDecl] = {}
        self.protocols: dict[str, ast.ProtocolDecl] = {}
        self.const_cache: dict[str, Value] = {}
        self.collect_top_level()
        self.local_function_signatures = self.collect_local_function_signatures()
        bootstrap = ast.FnDecl(name="<bootstrap>", params=[], return_type=ast.NamedType("Unit"), effects=[], body=ast.Block([]))
        self.state = InterpreterState(frames=[Frame(bootstrap)])

    def collect_local_function_signatures(self) -> dict[str, FunctionOwnershipSignature]:
        bundle = export_ownership_signatures(self.module, imported_signatures=self.imported_signatures)
        signatures: dict[str, FunctionOwnershipSignature] = {}
        for fn in bundle.functions:
            signatures[fn.name] = fn
            short_name = fn.name.rsplit(".", 1)[-1]
            signatures.setdefault(short_name, fn)
        return signatures

    def local_function_signature(self, name: str) -> FunctionOwnershipSignature | None:
        if name in self.local_function_signatures:
            return self.local_function_signatures[name]
        if self.module_path:
            return self.local_function_signatures.get(f"{self.module_path}.{name}")
        return None

    def collect_top_level(self) -> None:
        for imp in self.module.imports:
            if imp.path:
                self.import_aliases[imp.path[-1]] = ".".join(imp.path)
        for decl in self.module.decls:
            if isinstance(decl, ast.FnDecl):
                self.functions[decl.name] = decl
            elif isinstance(decl, ast.ConstDecl):
                self.consts[decl.name] = decl
            elif isinstance(decl, ast.ErrorSetDecl):
                self.error_sets[decl.name] = decl
            elif isinstance(decl, ast.EnumDecl):
                self.enums[decl.name] = decl
            elif isinstance(decl, ast.StructDecl):
                self.structs[decl.name] = decl
            elif isinstance(decl, ast.ResourceDecl):
                self.resources[decl.name] = decl
            elif isinstance(decl, ast.ProtocolDecl):
                self.protocols[decl.name] = decl

    def render_value(self, value: Value) -> str:
        if isinstance(value, UnitVal):
            return "unit"
        if isinstance(value, BoolVal):
            return "true" if value.value else "false"
        if isinstance(value, IntVal):
            return str(value.value)
        if isinstance(value, StrVal):
            return repr(value.value)
        if isinstance(value, SomeVal):
            return f"some({self.render_value(value.inner)})"
        if isinstance(value, NoneVal):
            return "none"
        if isinstance(value, OkVal):
            return f"ok({self.render_value(value.inner)})"
        if isinstance(value, ErrVal):
            return value.tag
        if isinstance(value, (StructVal, ResourceVal)):
            inner = ", ".join(f"{k}: {self.render_value(v)}" for k, v in value.fields.items())
            return f"{value.name} {{ {inner} }}"
        if isinstance(value, EnumVal):
            if not value.fields:
                return f"{value.enum_name}.{value.variant_name}"
            inner = ", ".join(f"{k}: {self.render_value(v)}" for k, v in value.fields.items())
            return f"{value.enum_name}.{value.variant_name} {{ {inner} }}"
        if isinstance(value, RangeVal):
            return f"range({value.start}..{value.stop})"
        if isinstance(value, ArrayVal):
            inner = ", ".join(self.render_value(v) for v in value.elements)
            return f"[{inner}]"
        if isinstance(value, SliceVal):
            rendered = ", ".join(self.render_value(v) for v in self.materialize_slice_elements(value))
            return f"slice[{rendered}]"
        if isinstance(value, RefVal):
            path = ".".join(str(part) for part in value.place.path)
            suffix = f".{path}" if path else ""
            return f"ref(@{value.place.root_cell}{suffix})"
        if isinstance(value, MovedVal):
            return "<moved>"
        raise InterpreterUnsupportedError(f"cannot render value of type {type(value).__name__}")

    def interpret(self, entry: str = "main") -> Value:
        fn = self.functions.get(entry)
        if fn is None:
            raise InterpreterUnsupportedError(f"entry function {entry} not found")
        return self.call_function(fn, [])

    def call_function(self, fn: ast.FnDecl, args: list[Value]) -> Value:
        if len(args) != len(fn.params):
            raise InterpreterUnsupportedError(f"function {fn.name} expected {len(fn.params)} args but got {len(args)}")
        frame = Frame(fn)
        self.state.frames.append(frame)
        for param, arg in zip(fn.params, args):
            coerced = self.coerce_value_to_type(param.typ, arg, context=f"parameter {param.name}")
            frame.scopes[-1].bindings[param.name] = Binding(mutable=False, cell_id=self.allocate_cell(coerced), typ=param.typ)
        try:
            self.exec_block(fn.body)
        except ReturnSignal as signal:
            return self.coerce_return(fn.return_type, signal.value)
        except PropagateErrSignal as signal:
            return self.coerce_return(fn.return_type, signal.err)
        finally:
            self.state.frames.pop()
        return self.coerce_return(fn.return_type, UnitVal())

    def current_frame(self) -> Frame:
        return self.state.frames[-1]

    def allocate_cell(self, value: Value) -> int:
        cell_id = self.state.next_alloc_id
        self.state.next_alloc_id += 1
        self.state.store[cell_id] = value
        return cell_id

    def load_cell(self, cell_id: int) -> Value:
        value = self.state.store[cell_id]
        if isinstance(value, MovedVal):
            raise TrapError("read of moved value")
        return value

    def store_cell(self, cell_id: int, value: Value) -> None:
        self.state.store[cell_id] = value

    def render_place(self, place: RuntimePlace) -> str:
        suffix = "".join(f"[{part}]" if isinstance(part, int) else f".{part}" for part in place.path)
        return f"@{place.root_cell}{suffix}"

    def protocol_terminal_states(self, value: ResourceVal) -> set[str]:
        if value.protocol_name is None:
            return set()
        protocol = self.protocols.get(value.protocol_name)
        if protocol is None:
            return set()
        return set(protocol.terminal)

    def resource_is_terminal(self, value: ResourceVal) -> bool:
        if value.protocol_name is None or value.protocol_state is None:
            return True
        return value.protocol_state in self.protocol_terminal_states(value)

    def assert_value_replaceable(self, value: Value, place: RuntimePlace) -> None:
        if isinstance(value, MovedVal):
            return
        if isinstance(value, ResourceVal):
            if not self.resource_is_terminal(value):
                raise TrapError(
                    f"cannot overwrite non-terminal resource at {self.render_place(place)}: "
                    f"{value.name} is in state {value.protocol_state}"
                )
            for field_name, field_value in value.fields.items():
                self.assert_value_replaceable(field_value, RuntimePlace(place.root_cell, place.path + (field_name,)))
            return
        if isinstance(value, StructVal):
            for field_name, field_value in value.fields.items():
                self.assert_value_replaceable(field_value, RuntimePlace(place.root_cell, place.path + (field_name,)))
            return
        if isinstance(value, ArrayVal):
            for index, elem in enumerate(value.elements):
                self.assert_value_replaceable(elem, RuntimePlace(place.root_cell, place.path + (index,)))
            return
        if isinstance(value, SliceVal):
            for index in range(value.length):
                elem_place = self.slice_element_place(value, index)
                self.assert_value_replaceable(self.read_runtime_place(elem_place), elem_place)
            return

    def assert_readable_value(self, value: Value) -> None:
        if isinstance(value, MovedVal):
            raise TrapError("read of moved value")

    def array_length(self, value: ArrayVal | SliceVal) -> int:
        if isinstance(value, ArrayVal):
            return len(value.elements)
        return value.length

    def slice_element_place(self, value: SliceVal, index: int) -> RuntimePlace:
        if index < 0 or index >= value.length:
            raise TrapError("index out of bounds")
        return RuntimePlace(value.base_place.root_cell, value.base_place.path + (value.start + index,))

    def materialize_slice_elements(self, value: SliceVal) -> list[Value]:
        return [self.read_runtime_place(self.slice_element_place(value, i)) for i in range(value.length)]

    def make_slice_view(self, access: RuntimeAccess | None, value: Value, start: int, stop: int) -> Value:
        if isinstance(value, StrVal):
            if start < 0 or stop < 0 or start > len(value.value) or stop > len(value.value) or start > stop:
                raise TrapError("slice out of bounds")
            return StrVal(value.value[start:stop])
        if isinstance(value, ArrayVal):
            if start < 0 or stop < 0 or start > len(value.elements) or stop > len(value.elements) or start > stop:
                raise TrapError("slice out of bounds")
            if access is None:
                temp_cell = self.allocate_cell(deepcopy(value))
                base_place = RuntimePlace(temp_cell, ())
            else:
                base_place = access.place
            return SliceVal(base_place=base_place, start=start, length=stop - start)
        if isinstance(value, SliceVal):
            if start < 0 or stop < 0 or start > value.length or stop > value.length or start > stop:
                raise TrapError("slice out of bounds")
            return SliceVal(base_place=value.base_place, start=value.start + start, length=stop - start)
        raise InterpreterUnsupportedError("slice expressions are implemented only for Str, Array, and Slice")

    def maybe_resolve_access_expr(self, expr: ast.Expr) -> RuntimeAccess | None:
        try:
            return self.resolve_access_expr(expr)
        except InterpreterUnsupportedError:
            return None

    def read_runtime_place(self, place: RuntimePlace) -> Value:
        value = self.load_cell(place.root_cell)
        self.assert_readable_value(value)
        for part in place.path:
            if isinstance(value, RefVal):
                value = self.read_runtime_place(value.place)
            self.assert_readable_value(value)
            if isinstance(part, int):
                if isinstance(value, StrVal):
                    if part < 0 or part >= len(value.value):
                        raise TrapError("index out of bounds")
                    value = IntVal(ord(value.value[part]), width=8, signed=False)
                    continue
                if isinstance(value, ArrayVal):
                    if part < 0 or part >= len(value.elements):
                        raise TrapError("index out of bounds")
                    value = value.elements[part]
                    continue
                if isinstance(value, SliceVal):
                    value = self.read_runtime_place(self.slice_element_place(value, part))
                    continue
                raise InterpreterUnsupportedError("integer indexing is not implemented for this value")
            if not isinstance(value, (StructVal, ResourceVal)):
                raise InterpreterUnsupportedError("field access only supported on struct/resource values")
            if part not in value.fields:
                raise InterpreterUnsupportedError(f"field {part} missing on {value.name}")
            value = value.fields[part]
        if isinstance(value, RefVal):
            value = self.read_runtime_place(value.place)
        self.assert_readable_value(value)
        return value

    def write_runtime_place(self, place: RuntimePlace, value: Value, *, allow_live_resource_replace: bool = False) -> None:
        if not place.path:
            old = self.load_cell(place.root_cell)
            if not allow_live_resource_replace and not isinstance(value, MovedVal):
                self.assert_value_replaceable(old, place)
            self.store_cell(place.root_cell, value)
            return

        parent_place = RuntimePlace(place.root_cell, place.path[:-1])
        parent = self.read_runtime_place(parent_place)
        if isinstance(parent, RefVal):
            parent = self.read_runtime_place(parent.place)
        self.assert_readable_value(parent)
        leaf = place.path[-1]
        leaf_place = RuntimePlace(place.root_cell, place.path)

        if isinstance(leaf, int):
            if isinstance(parent, ArrayVal):
                if leaf < 0 or leaf >= len(parent.elements):
                    raise TrapError("index out of bounds")
                if not allow_live_resource_replace and not isinstance(value, MovedVal):
                    self.assert_value_replaceable(parent.elements[leaf], leaf_place)
                parent.elements[leaf] = value
                return
            if isinstance(parent, SliceVal):
                self.write_runtime_place(self.slice_element_place(parent, leaf), value, allow_live_resource_replace=allow_live_resource_replace)
                return
            if isinstance(parent, StrVal):
                raise InterpreterUnsupportedError("cannot assign through immutable Str index at runtime")
            raise InterpreterUnsupportedError("index assignment only supported on array/slice values")

        if not isinstance(parent, (StructVal, ResourceVal)):
            raise InterpreterUnsupportedError("field assignment only supported on struct/resource values")
        if leaf in parent.fields and not allow_live_resource_replace and not isinstance(value, MovedVal):
            self.assert_value_replaceable(parent.fields[leaf], leaf_place)
        parent.fields[leaf] = value

    def access_for_name(self, name: str) -> RuntimeAccess:
        binding = self.lookup_binding(name)
        value = self.load_cell(binding.cell_id)
        if isinstance(value, RefVal):
            return RuntimeAccess(value.place, value.mutable)
        return RuntimeAccess(RuntimePlace(binding.cell_id, ()), True)

    def resolve_access_expr(self, expr: ast.Expr) -> RuntimeAccess:
        if isinstance(expr, ast.NameExpr):
            return self.access_for_name(expr.name)
        if isinstance(expr, ast.AttrExpr):
            base_access = self.resolve_access_expr(expr.obj)
            return RuntimeAccess(RuntimePlace(base_access.place.root_cell, base_access.place.path + (expr.name,)), base_access.mutable)
        if isinstance(expr, ast.IndexExpr):
            base_access = self.resolve_access_expr(expr.obj)
            idx = self.expect_int(self.eval_expr(expr.index))
            base_value = self.read_runtime_place(base_access.place)
            if isinstance(base_value, StrVal):
                if idx < 0 or idx >= len(base_value.value):
                    raise TrapError("index out of bounds")
                return RuntimeAccess(RuntimePlace(base_access.place.root_cell, base_access.place.path + (idx,)), False)
            if isinstance(base_value, ArrayVal):
                if idx < 0 or idx >= len(base_value.elements):
                    raise TrapError("index out of bounds")
                return RuntimeAccess(RuntimePlace(base_access.place.root_cell, base_access.place.path + (idx,)), base_access.mutable)
            if isinstance(base_value, SliceVal):
                return RuntimeAccess(self.slice_element_place(base_value, idx), base_access.mutable)
            raise InterpreterUnsupportedError("index place expressions are supported only on Str, Array, and Slice")
        if isinstance(expr, ast.DottedExpr):
            return self.resolve_access_from_parts(expr.parts)
        raise InterpreterUnsupportedError(f"unsupported place expression {type(expr).__name__}")

    def resolve_place_expr(self, expr: ast.Expr) -> RuntimePlace:
        return self.resolve_access_expr(expr).place

    def resolve_access_from_parts(self, parts: list[str]) -> RuntimeAccess:
        if not parts:
            raise InterpreterUnsupportedError("empty dotted expression")
        if len(parts) == 2 and parts[0] in self.error_sets:
            raise InterpreterUnsupportedError("error-set tags are not places")
        if len(parts) == 2 and parts[0] in self.enums:
            raise InterpreterUnsupportedError("enum variants are not places")
        access = self.access_for_name(parts[0])
        for part in parts[1:]:
            access = RuntimeAccess(RuntimePlace(access.place.root_cell, access.place.path + (part,)), access.mutable)
        return access

    def resolve_place_from_parts(self, parts: list[str]) -> RuntimePlace:
        return self.resolve_access_from_parts(parts).place

    def push_scope(self) -> None:
        self.current_frame().scopes.append(ScopeRuntime())

    def pop_scope(self) -> ScopeRuntime:
        return self.current_frame().scopes.pop()

    def cleanup_ref_arg_place(self, expr: ast.Expr, receiver_ref: bool = False) -> RuntimePlace | None:
        if isinstance(expr, ast.UnaryExpr) and expr.op == "borrow":
            try:
                return self.resolve_place_expr(expr.expr)
            except InterpreterUnsupportedError:
                return None
        access = self.maybe_resolve_access_expr(expr)
        if access is None:
            return None
        try:
            value = self.read_runtime_place(access.place)
        except TrapError as exc:
            if exc.reason == "read of moved value":
                return None
            raise
        if isinstance(value, RefVal):
            return value.place
        if receiver_ref:
            return access.place
        return None

    def effect_target_already_discharged(self, place: RuntimePlace, state_text: str) -> bool:
        current = self.maybe_read_cleanup_target_value(place)
        if isinstance(current, MovedVal):
            return True
        if state_text == "Moved":
            return isinstance(current, MovedVal)
        if not isinstance(current, ResourceVal):
            return False
        target_state = state_text.split("{", 1)[0].strip()
        return current.protocol_state == target_state and self.resource_is_terminal(current)

    def cleanup_call_signature_and_roots(self, expr: ast.CallExpr) -> tuple[FunctionOwnershipSignature | None, list[RuntimePlace | None]]:
        imported_name = self.imported_target_name(expr.callee)
        if imported_name is not None:
            return self.imported_signatures.get(imported_name), [self.cleanup_ref_arg_place(arg) for arg in expr.args]
        if isinstance(expr.callee, ast.NameExpr) and expr.callee.name in self.functions:
            return self.local_function_signature(expr.callee.name), [self.cleanup_ref_arg_place(arg) for arg in expr.args]
        if isinstance(expr.callee, ast.DottedExpr):
            parts = expr.callee.parts
            if len(parts) == 1 and parts[0] in self.functions:
                return self.local_function_signature(parts[0]), [self.cleanup_ref_arg_place(arg) for arg in expr.args]
            if len(parts) >= 2 and parts[-1] in self.functions:
                roots: list[RuntimePlace | None] = [self.cleanup_ref_arg_place(expr.callee, receiver_ref=True)]
                roots.extend(self.cleanup_ref_arg_place(arg) for arg in expr.args)
                return self.local_function_signature(parts[-1]), roots
        if isinstance(expr.callee, ast.AttrExpr) and expr.callee.name in self.functions:
            roots = [self.cleanup_ref_arg_place(expr.callee.obj, receiver_ref=True)]
            roots.extend(self.cleanup_ref_arg_place(arg) for arg in expr.args)
            return self.local_function_signature(expr.callee.name), roots
        return None, []

    def should_skip_cleanup_via_signature(self, expr: ast.CallExpr) -> bool:
        sig, roots = self.cleanup_call_signature_and_roots(expr)
        if sig is None or not sig.ref_params:
            return False
        any_effect = False
        for ref_sig in sig.ref_params:
            if ref_sig.param_index >= len(roots):
                return False
            root = roots[ref_sig.param_index]
            if root is None:
                return False
            for rel_path, state_text in sorted(ref_sig.effects.items(), key=lambda item: (item[0] != "", item[0].count("."))):
                any_effect = True
                target = RuntimePlace(root.root_cell, root.path + self.split_import_effect_path(rel_path))
                if not self.effect_target_already_discharged(target, state_text):
                    return False
        return any_effect

    def maybe_cleanup_target_place(self, stmt: ast.Stmt) -> RuntimePlace | None:
        if not isinstance(stmt, ast.ExprStmt):
            return None
        expr = stmt.expr
        if not isinstance(expr, ast.CallExpr):
            return None
        callee = expr.callee
        if isinstance(callee, ast.AttrExpr):
            try:
                return self.resolve_place_expr(callee.obj)
            except InterpreterUnsupportedError:
                return None
        if isinstance(callee, ast.DottedExpr) and len(callee.parts) >= 2:
            try:
                return self.resolve_place_from_parts(callee.parts[:-1])
            except InterpreterUnsupportedError:
                return None
        return None

    def maybe_read_cleanup_target_value(self, place: RuntimePlace) -> Value | None:
        try:
            return self.read_runtime_place(place)
        except TrapError as exc:
            if exc.reason == "read of moved value":
                return MovedVal()
            raise

    def validate_imported_cleanup_helper(self, expr: ast.CallExpr) -> None:
        target_name = self.imported_target_name(expr.callee)
        if target_name is None:
            return
        if target_name not in self.imported_contracts:
            raise TrapError(
                f"imported cleanup helper {target_name} has no ownership signature"
            )
        if target_name not in self.import_stubs:
            raise TrapError(
                f"imported cleanup helper {target_name} has ownership signature but no runtime stub"
            )

    def should_skip_cleanup(self, stmt: ast.Stmt) -> bool:
        if not isinstance(stmt, ast.ExprStmt):
            return False
        expr = stmt.expr
        if not isinstance(expr, ast.CallExpr):
            return False
        self.validate_imported_cleanup_helper(expr)
        place = self.maybe_cleanup_target_place(stmt)
        if place is not None:
            callee = expr.callee
            if isinstance(callee, ast.AttrExpr):
                method_name = callee.name
            elif isinstance(callee, ast.DottedExpr) and callee.parts:
                method_name = callee.parts[-1]
            else:
                method_name = None
            if method_name is not None:
                target = self.maybe_read_cleanup_target_value(place)
                if isinstance(target, MovedVal):
                    return True
                if isinstance(target, ResourceVal):
                    protocol_name = target.protocol_name
                    if protocol_name is not None and protocol_name in self.protocols:
                        protocol = self.protocols[protocol_name]
                        transition = next((t for t in protocol.transitions if t.name == method_name), None)
                        if transition is not None:
                            return target.protocol_state == transition.target and self.resource_is_terminal(target)
        return self.should_skip_cleanup_via_signature(expr)

    def run_scope_cleanup(self, scope: ScopeRuntime, exit_kind: str) -> None:
        for entry in reversed(scope.defer_entries):
            if entry.mode == "error" and exit_kind != "error":
                continue
            if self.should_skip_cleanup(entry.stmt):
                continue
            self.exec_stmt(entry.stmt)

    def builtin_int_info(self, name: str) -> tuple[int, bool] | None:
        mapping = {
            "I8": (8, True),
            "I16": (16, True),
            "I32": (32, True),
            "I64": (64, True),
            "U8": (8, False),
            "U16": (16, False),
            "U32": (32, False),
            "U64": (64, False),
        }
        return mapping.get(name)

    def bounds_for_int(self, width: int, signed: bool) -> tuple[int, int]:
        if signed:
            return -(2 ** (width - 1)), 2 ** (width - 1) - 1
        return 0, 2 ** width - 1

    def normalize_int(self, value: int, width: int, signed: bool, context: str) -> IntVal:
        low, high = self.bounds_for_int(width, signed)
        if value < low or value > high:
            raise TrapError(f"integer overflow in {context}")
        return IntVal(value, width=width, signed=signed, contextual=False)

    def coerce_value_to_type(self, typ: ast.Type | None, value: Value, context: str) -> Value:
        if typ is None:
            return value
        if isinstance(typ, ast.NamedType):
            info = self.builtin_int_info(typ.name)
            if info is not None:
                if not isinstance(value, IntVal):
                    raise InterpreterUnsupportedError(f"{context} expected integer value")
                width, signed = info
                return self.normalize_int(value.value, width, signed, context)
        if isinstance(typ, ast.ResultType):
            if isinstance(value, ErrVal):
                return value
            if isinstance(value, OkVal):
                inner = self.coerce_value_to_type(typ.ok, value.inner, context)
                return OkVal(inner)
            inner = self.coerce_value_to_type(typ.ok, value, context)
            return OkVal(inner)
        if isinstance(typ, ast.OptionalType):
            if isinstance(value, NoneVal):
                return value
            if isinstance(value, SomeVal):
                inner = self.coerce_value_to_type(typ.inner, value.inner, context)
                return SomeVal(inner)
            inner = self.coerce_value_to_type(typ.inner, value, context)
            return SomeVal(inner)
        if isinstance(typ, ast.GenericType) and typ.args and isinstance(typ.args[0], ast.Type):
            if typ.name == 'Ref':
                if not isinstance(value, RefVal):
                    raise InterpreterUnsupportedError(f"{context} expected Ref value")
                if not value.mutable:
                    raise InterpreterUnsupportedError(f"{context} expected mutable Ref value")
                return RefVal(value.place, mutable=True)
            if typ.name == 'RefConst':
                if not isinstance(value, RefVal):
                    raise InterpreterUnsupportedError(f"{context} expected RefConst value")
                return RefVal(value.place, mutable=False)
            if typ.name == 'Array':
                if not isinstance(value, ArrayVal):
                    raise InterpreterUnsupportedError(f"{context} expected Array value")
                elem_type = typ.args[0]
                if not isinstance(elem_type, ast.Type):
                    raise InterpreterUnsupportedError(f"{context} expected Array element type")
                if len(typ.args) < 2 or not isinstance(typ.args[1], int):
                    raise InterpreterUnsupportedError(f"{context} expected concrete Array length")
                if len(value.elements) != typ.args[1]:
                    raise InterpreterUnsupportedError(f"{context} expected Array length {typ.args[1]} but got {len(value.elements)}")
                return ArrayVal([self.coerce_value_to_type(elem_type, elem, context) for elem in value.elements])
            if typ.name == 'Slice':
                if not isinstance(value, SliceVal):
                    raise InterpreterUnsupportedError(f"{context} expected Slice value")
                return value
        return value

    def select_arithmetic_type(self, left: IntVal, right: IntVal) -> tuple[int, bool]:
        if left.contextual and not right.contextual:
            return right.width, right.signed
        if right.contextual and not left.contextual:
            return left.width, left.signed
        if not left.contextual and not right.contextual:
            if (left.width, left.signed) != (right.width, right.signed):
                raise InterpreterUnsupportedError(
                    f"runtime arithmetic for mixed integer widths/types is not implemented: "
                    f"{left.width}{'s' if left.signed else 'u'} vs {right.width}{'s' if right.signed else 'u'}"
                )
            return left.width, left.signed
        return 64, True

    def truncating_division(self, left: int, right: int) -> tuple[int, int]:
        if right == 0:
            raise TrapError("division by zero")
        q = abs(left) // abs(right)
        if (left < 0) ^ (right < 0):
            q = -q
        r = left - q * right
        return q, r

    def bind_name(self, name: str, value: Value, mutable: bool, typ: ast.Type | None = None) -> None:
        stored = self.coerce_value_to_type(typ, value, context=f"binding {name}") if typ is not None else value
        self.current_frame().scopes[-1].bindings[name] = Binding(mutable=mutable, cell_id=self.allocate_cell(stored), typ=typ)

    def lookup_binding(self, name: str) -> Binding:
        for scope in reversed(self.current_frame().scopes):
            if name in scope.bindings:
                return scope.bindings[name]
        raise InterpreterUnsupportedError(f"name {name} not found at runtime")

    def eval_const(self, name: str) -> Value:
        if name in self.const_cache:
            return self.const_cache[name]
        decl = self.consts[name]
        value = self.coerce_value_to_type(decl.typ, self.eval_expr(decl.value), context=f"const {name}")
        self.const_cache[name] = value
        return value

    def read_place(self, expr: ast.Expr) -> tuple[Binding | None, str | None, Value]:
        if isinstance(expr, ast.NameExpr) and expr.name in self.consts:
            return None, None, self.eval_const(expr.name)
        if isinstance(expr, (ast.NameExpr, ast.AttrExpr, ast.DottedExpr, ast.IndexExpr)):
            place = self.resolve_place_expr(expr)
            return None, None, self.read_runtime_place(place)
        raise InterpreterUnsupportedError(f"unsupported lvalue expression {type(expr).__name__}")

    def assign_place(self, expr: ast.Expr, value: Value) -> None:
        if isinstance(expr, ast.NameExpr):
            if expr.name == "_":
                return
            binding = self.lookup_binding(expr.name)
            if not binding.mutable:
                raise InterpreterUnsupportedError(f"assignment target {expr.name} is not mutable at runtime")
            stored = self.coerce_value_to_type(binding.typ, value, context=f"assignment to {expr.name}") if binding.typ is not None else value
            self.store_cell(binding.cell_id, stored)
            return
        if isinstance(expr, (ast.AttrExpr, ast.DottedExpr, ast.IndexExpr)):
            access = self.resolve_access_expr(expr)
            if not access.mutable:
                raise InterpreterUnsupportedError("cannot assign through immutable reference at runtime")
            self.write_runtime_place(access.place, value)
            return
        raise InterpreterUnsupportedError(f"unsupported assignment target {type(expr).__name__}")

    def exec_block(self, block: ast.Block) -> None:
        self.push_scope()
        exit_kind = "normal"
        try:
            for stmt in block.statements:
                self.exec_stmt(stmt)
        except PropagateErrSignal:
            exit_kind = "error"
            raise
        except ReturnSignal:
            exit_kind = "return"
            raise
        except BreakSignal:
            exit_kind = "break"
            raise
        except ContinueSignal:
            exit_kind = "continue"
            raise
        except TrapError:
            exit_kind = "trap"
            raise
        finally:
            scope = self.current_frame().scopes[-1]
            self.run_scope_cleanup(scope, exit_kind)
            self.pop_scope()

    def exec_stmt(self, stmt: ast.Stmt) -> None:
        if isinstance(stmt, ast.Block):
            self.exec_block(stmt)
            return
        if isinstance(stmt, ast.LetStmt):
            value = self.eval_expr(stmt.value)
            self.bind_name(stmt.name, value, mutable=False, typ=stmt.typ)
            return
        if isinstance(stmt, ast.VarStmt):
            value = self.eval_expr(stmt.value)
            self.bind_name(stmt.name, value, mutable=True, typ=stmt.typ)
            return
        if isinstance(stmt, ast.AssignStmt):
            if stmt.op != "=":
                raise InterpreterUnsupportedError(f"assignment operator {stmt.op} not implemented")
            value = self.eval_expr(stmt.value)
            self.assign_place(stmt.target, value)
            return
        if isinstance(stmt, ast.ExprStmt):
            self.eval_expr(stmt.expr)
            return
        if isinstance(stmt, ast.ReturnStmt):
            value = UnitVal() if stmt.expr is None else self.eval_expr(stmt.expr)
            raise ReturnSignal(value)
        if isinstance(stmt, ast.IfStmt):
            cond = self.eval_expr(stmt.cond)
            if not isinstance(cond, BoolVal):
                raise InterpreterUnsupportedError("if condition did not evaluate to Bool")
            if cond.value:
                self.exec_block(stmt.then_block)
            elif stmt.else_branch is not None:
                if isinstance(stmt.else_branch, ast.Block):
                    self.exec_block(stmt.else_branch)
                else:
                    self.exec_stmt(stmt.else_branch)
            return
        if isinstance(stmt, ast.WhileStmt):
            while True:
                cond = self.eval_expr(stmt.cond)
                if not isinstance(cond, BoolVal):
                    raise InterpreterUnsupportedError("while condition did not evaluate to Bool")
                if not cond.value:
                    break
                try:
                    self.exec_block(stmt.body)
                except ContinueSignal:
                    continue
                except BreakSignal:
                    break
            return
        if isinstance(stmt, ast.ForStmt):
            iterable = self.eval_expr(stmt.iterable)
            if isinstance(iterable, RangeVal):
                items = [IntVal(i, contextual=True) for i in range(iterable.start, iterable.stop)]
            elif isinstance(iterable, StrVal):
                items = [IntVal(ord(ch), width=8, signed=False) for ch in iterable.value]
            elif isinstance(iterable, ArrayVal):
                items = [deepcopy(elem) for elem in iterable.elements]
            elif isinstance(iterable, SliceVal):
                items = [deepcopy(elem) for elem in self.materialize_slice_elements(iterable)]
            else:
                raise InterpreterUnsupportedError("for currently supports range, Str, Array, and Slice iterables")
            for item in items:
                self.push_scope()
                self.bind_name(stmt.name, item, mutable=False, typ=stmt.typ)
                exit_kind = "normal"
                try:
                    for body_stmt in stmt.body.statements:
                        self.exec_stmt(body_stmt)
                except ContinueSignal:
                    exit_kind = "continue"
                except BreakSignal:
                    exit_kind = "break"
                except PropagateErrSignal:
                    exit_kind = "error"
                    raise
                except ReturnSignal:
                    exit_kind = "return"
                    raise
                finally:
                    scope = self.current_frame().scopes[-1]
                    self.run_scope_cleanup(scope, exit_kind)
                    self.pop_scope()
                if exit_kind == "break":
                    break
            return
        if isinstance(stmt, ast.BreakStmt):
            raise BreakSignal()
        if isinstance(stmt, ast.ContinueStmt):
            raise ContinueSignal()
        if isinstance(stmt, ast.DeferStmt):
            self.current_frame().scopes[-1].defer_entries.append(DeferEntry(stmt=stmt.stmt, mode="always"))
            return
        if isinstance(stmt, ast.ErrDeferStmt):
            self.current_frame().scopes[-1].defer_entries.append(DeferEntry(stmt=stmt.stmt, mode="error"))
            return
        raise InterpreterUnsupportedError(f"statement {type(stmt).__name__} not implemented")

    def eval_expr(self, expr: ast.Expr) -> Value:
        if isinstance(expr, ast.NameExpr):
            if expr.name == "true":
                return BoolVal(True)
            if expr.name == "false":
                return BoolVal(False)
            if expr.name in self.consts:
                return self.eval_const(expr.name)
            return self.load_cell(self.lookup_binding(expr.name).cell_id)
        if isinstance(expr, ast.DottedExpr):
            return self.eval_dotted_expr(expr)
        if isinstance(expr, ast.IntExpr):
            return IntVal(int(expr.raw, 10), contextual=True)
        if isinstance(expr, ast.StringExpr):
            return StrVal(expr.value)
        if isinstance(expr, ast.BoolExpr):
            return BoolVal(expr.value)
        if isinstance(expr, ast.UnitExpr):
            return UnitVal()
        if isinstance(expr, ast.NoneExpr):
            return NoneVal()
        if isinstance(expr, ast.SomeExpr):
            return SomeVal(self.eval_expr(expr.value))
        if isinstance(expr, ast.UnaryExpr):
            return self.eval_unary(expr)
        if isinstance(expr, ast.BinaryExpr):
            return self.eval_binary(expr)
        if isinstance(expr, ast.RangeExpr):
            start = self.expect_int(self.eval_expr(expr.start))
            stop = self.expect_int(self.eval_expr(expr.stop))
            return RangeVal(start, stop)
        if isinstance(expr, ast.CallExpr):
            return self.eval_call(expr)
        if isinstance(expr, ast.AttrExpr):
            return self.eval_attr(expr)
        if isinstance(expr, ast.IndexExpr):
            return self.eval_index(expr)
        if isinstance(expr, ast.SliceExpr):
            return self.eval_slice(expr)
        if isinstance(expr, ast.TryExpr):
            inner = self.eval_expr(expr.expr)
            if isinstance(inner, ErrVal):
                raise PropagateErrSignal(inner)
            if isinstance(inner, OkVal):
                return inner.inner
            raise InterpreterUnsupportedError("try expression expected result-like value")
        if isinstance(expr, ast.CatchExpr):
            inner = self.eval_expr(expr.expr)
            if isinstance(inner, OkVal):
                return inner.inner
            if isinstance(inner, ErrVal):
                if expr.binding is not None and expr.handler is not None:
                    # catch |e| { body } — bind e to the ErrVal in a new scope and run block
                    self.push_scope()
                    self.bind_name(expr.binding, inner, mutable=False)
                    try:
                        for stmt in expr.handler.statements:
                            self.exec_stmt(stmt)
                        handler_result: Value = UnitVal()
                    finally:
                        self.pop_scope()
                    return handler_result
                return self.eval_expr(expr.fallback)
            raise InterpreterUnsupportedError("catch expression expected result-like value")
        if isinstance(expr, ast.CastExpr):
            return self.eval_cast(expr)
        if isinstance(expr, ast.StructLiteralExpr):
            fields = {name: self.eval_expr(value) for name, value in expr.fields}
            if expr.name in self.resources:
                protocol_name = self.resources[expr.name].protocol
                protocol_state = self.protocols[protocol_name].init if protocol_name in self.protocols else None
                return ResourceVal(expr.name, protocol_name, protocol_state, fields)
            return StructVal(expr.name, fields)
        if isinstance(expr, ast.EnumLiteralExpr):
            return EnumVal(expr.enum_name, expr.variant_name, {name: self.eval_expr(value) for name, value in expr.fields})
        if isinstance(expr, ast.MatchExpr):
            return self.eval_match(expr)
        raise InterpreterUnsupportedError(f"expression {type(expr).__name__} not implemented")

    def eval_dotted_expr(self, expr: ast.DottedExpr) -> Value:
        if len(expr.parts) == 2 and expr.parts[0] in self.error_sets:
            return ErrVal(f"{expr.parts[0]}.{expr.parts[1]}")
        if len(expr.parts) == 2 and expr.parts[0] in self.enums:
            return EnumVal(expr.parts[0], expr.parts[1], {})
        if len(expr.parts) >= 2 and expr.parts[-1] == "len":
            access = self.resolve_access_from_parts(expr.parts[:-1])
            base = self.read_runtime_place(access.place)
            if isinstance(base, StrVal):
                return IntVal(len(base.value), width=64, signed=False)
            if isinstance(base, (ArrayVal, SliceVal)):
                return IntVal(self.array_length(base), width=64, signed=False)
        place = self.resolve_place_from_parts(expr.parts)
        value = self.read_runtime_place(place)
        return value

    def eval_unary(self, expr: ast.UnaryExpr) -> Value:
        if expr.op == "borrow":
            access = self.resolve_access_expr(expr.expr)
            return RefVal(access.place, mutable=access.mutable)
        if expr.op == "move":
            access = self.resolve_access_expr(expr.expr)
            if not access.mutable:
                raise InterpreterUnsupportedError("cannot move through immutable reference at runtime")
            value = self.read_runtime_place(access.place)
            self.write_runtime_place(access.place, MovedVal())
            return value
        inner = self.eval_expr(expr.expr)
        if expr.op == "-":
            inner_int = self.expect_int_value(inner)
            width, signed = (inner_int.width, inner_int.signed) if not inner_int.contextual else (64, True)
            if not signed and not inner_int.contextual:
                raise TrapError("integer overflow in unary -")
            return self.normalize_int(-inner_int.value, width, signed, "unary -")
        if expr.op == "not":
            return BoolVal(not self.expect_bool(inner))
        if expr.op == "copy":
            copied = deepcopy(inner)
            if isinstance(copied, IntVal):
                copied.contextual = False
            return copied
        raise InterpreterUnsupportedError(f"unary operator {expr.op} not implemented")

    def eval_binary(self, expr: ast.BinaryExpr) -> Value:
        if expr.op == "and":
            left = self.expect_bool(self.eval_expr(expr.left))
            if not left:
                return BoolVal(False)
            return BoolVal(self.expect_bool(self.eval_expr(expr.right)))
        if expr.op == "or":
            left = self.expect_bool(self.eval_expr(expr.left))
            if left:
                return BoolVal(True)
            return BoolVal(self.expect_bool(self.eval_expr(expr.right)))
        left = self.eval_expr(expr.left)
        right = self.eval_expr(expr.right)
        if expr.op in {"+", "-", "*", "/", "%"}:
            li = self.expect_int_value(left)
            ri = self.expect_int_value(right)
            width, signed = self.select_arithmetic_type(li, ri)
            if expr.op == "+":
                return self.normalize_int(li.value + ri.value, width, signed, "binary +")
            if expr.op == "-":
                return self.normalize_int(li.value - ri.value, width, signed, "binary -")
            if expr.op == "*":
                return self.normalize_int(li.value * ri.value, width, signed, "binary *")
            if expr.op == "/":
                q, _ = self.truncating_division(li.value, ri.value)
                return self.normalize_int(q, width, signed, "binary /")
            if expr.op == "%":
                _, r = self.truncating_division(li.value, ri.value)
                return self.normalize_int(r, width, signed, "binary %")
        if expr.op in {"==", "!=", "<", "<=", ">", ">="}:
            lv = self.compare_key(left)
            rv = self.compare_key(right)
            if expr.op == "==":
                return BoolVal(lv == rv)
            if expr.op == "!=":
                return BoolVal(lv != rv)
            if expr.op == "<":
                return BoolVal(lv < rv)
            if expr.op == "<=":
                return BoolVal(lv <= rv)
            if expr.op == ">":
                return BoolVal(lv > rv)
            if expr.op == ">=":
                return BoolVal(lv >= rv)
        raise InterpreterUnsupportedError(f"binary operator {expr.op} not implemented")

    def imported_target_name_from_parts(self, parts: list[str]) -> str | None:
        if not parts:
            return None
        if parts[0] in self.import_aliases:
            suffix = ".".join(parts[1:])
            base = self.import_aliases[parts[0]]
            return f"{base}.{suffix}" if suffix else base
        candidate = ".".join(parts)
        imported_modules = set(self.import_aliases.values())
        if candidate in self.imported_contracts or candidate in self.import_stubs:
            return candidate
        if any(candidate == module_name or candidate.startswith(module_name + ".") for module_name in imported_modules):
            return candidate
        return None

    def imported_target_name(self, callee: ast.Expr) -> str | None:
        if isinstance(callee, ast.DottedExpr):
            return self.imported_target_name_from_parts(callee.parts)
        if isinstance(callee, ast.NameExpr):
            name = callee.name
            if name in self.imported_contracts or name in self.import_stubs:
                return name
        return None

    def imported_param_type(self, sig: FunctionOwnershipSignature, idx: int) -> ast.Type | None:
        if idx >= len(sig.param_types):
            return None
        return parse_type_text(sig.param_types[idx])

    def default_value_for_type(self, typ: ast.Type | None) -> Value:
        if typ is None:
            return UnitVal()
        if isinstance(typ, ast.NamedType):
            info = self.builtin_int_info(typ.name)
            if info is not None:
                width, signed = info
                return IntVal(0, width=width, signed=signed)
            if typ.name == "Bool":
                return BoolVal(False)
            if typ.name == "Unit":
                return UnitVal()
            if typ.name == "Str":
                return StrVal("")
        if isinstance(typ, ast.OptionalType):
            return NoneVal()
        if isinstance(typ, ast.ResultType):
            return OkVal(self.default_value_for_type(typ.ok))
        raise InterpreterUnsupportedError(f"import stub needs explicit return value for {typ}")

    def ref_signature_for_param(self, sig: FunctionOwnershipSignature, idx: int) -> RefParamOwnershipSignature | None:
        for ref_sig in sig.ref_params:
            if ref_sig.param_index == idx:
                return ref_sig
        return None

    def runtime_place_for_import_ref_arg(self, arg: Value, ref_sig: RefParamOwnershipSignature) -> RuntimePlace:
        if not isinstance(arg, RefVal):
            raise InterpreterUnsupportedError("imported ref parameter expected runtime Ref value")
        if ref_sig.mode == "mut" and not arg.mutable:
            raise InterpreterUnsupportedError("imported mutable ref parameter received immutable RefConst")
        return arg.place

    def split_import_effect_path(self, path: str) -> tuple[str | int, ...]:
        return canonical_path_to_runtime_parts(parse_canonical_path(path))

    def value_with_import_state(self, value: Value, state_text: str) -> Value:
        if state_text == "Moved":
            return MovedVal()
        state = state_text.split("{", 1)[0].strip()
        if isinstance(value, ResourceVal):
            return ResourceVal(value.name, value.protocol_name, state, value.fields)
        if isinstance(value, StructVal):
            # A whole-struct state summary can arise for imported Ref<Struct>
            # effects.  Runtime support is intentionally conservative: nested
            # resource effects should be emitted at field paths, not as opaque
            # struct replacement strings.
            raise InterpreterUnsupportedError("opaque struct import-state replacement is not implemented; use nested field effects")
        raise InterpreterUnsupportedError(f"cannot apply import ownership state {state_text!r} to {type(value).__name__}")

    def apply_import_ref_effects(self, args: list[Value], sig: FunctionOwnershipSignature) -> None:
        contract = self.imported_contracts.get(sig.name)
        ref_params = {ref.param_index: ref for ref in (contract.ref_params if contract is not None else tuple(sig.ref_params))}
        for effect in (contract.ref_effects if contract is not None else tuple()):
            ref_sig = ref_params[effect.param_index]
            if ref_sig.param_index >= len(args):
                raise InterpreterUnsupportedError(f"imported function {sig.name} missing ref argument {ref_sig.param_index + 1}")
            root = self.runtime_place_for_import_ref_arg(args[ref_sig.param_index], ref_sig)
            target = RuntimePlace(root.root_cell, root.path + canonical_path_to_runtime_parts(effect.canonical_path))
            old = self.read_runtime_place(target)
            new_value = self.value_with_import_state(old, effect.state)
            self.write_runtime_place(target, new_value, allow_live_resource_replace=True)

    def imported_stub_write_value(self, args: list[Value], write: ImportWrite) -> Value:
        if write.move:
            return MovedVal()
        if write.source_arg_index is not None:
            if write.source_arg_index >= len(args):
                raise InterpreterUnsupportedError(
                    f"import stub source arg {write.source_arg_index + 1} out of range"
                )
            return deepcopy(args[write.source_arg_index])
        if write.value is not None:
            return deepcopy(write.value)
        return UnitVal()

    def import_summary_paths_for_ref_param(self, sig: FunctionOwnershipSignature, param_index: int) -> set[CanonicalPath]:
        contract = normalize_imported_function_contract(sig)
        return contract.canonical_paths_for_ref_param(param_index)

    def import_summary_state_for_ref_path(self, sig: FunctionOwnershipSignature, param_index: int, path: CanonicalPath) -> str | None:
        contract = normalize_imported_function_contract(sig)
        return contract.state_text_for_ref_effect(param_index, path)

    def runtime_ownership_state_text(self, value: Value) -> str | None:
        if isinstance(value, MovedVal):
            return "Moved"
        if isinstance(value, ResourceVal):
            return value.protocol_state
        return None

    def audit_import_stub_declared_effect(self, sig: FunctionOwnershipSignature, write: ImportWrite, canonical_path: CanonicalPath, final_value: Value) -> None:
        declared = self.import_summary_state_for_ref_path(sig, write.ref_param_index, canonical_path)
        if declared is None:
            return
        actual = self.runtime_ownership_state_text(final_value)
        if actual is None:
            return
        declared_head = declared.split("{", 1)[0].strip()
        if actual != declared_head:
            rendered_path = ".".join(str(part) for part in canonical_path_to_runtime_parts(canonical_path)) if canonical_path else "<root>"
            raise InterpreterUnsupportedError(
                f"import stub for {sig.name} leaves ownership path {rendered_path} in state {actual}, "
                f"but declared summary requires {declared_head}"
            )

    def value_contains_resource(self, value: Value) -> bool:
        if isinstance(value, ResourceVal):
            return True
        if isinstance(value, StructVal):
            return any(self.value_contains_resource(field) for field in value.fields.values())
        if isinstance(value, ArrayVal):
            return any(self.value_contains_resource(elem) for elem in value.elements)
        if isinstance(value, SliceVal):
            return any(self.value_contains_resource(elem) for elem in self.materialize_slice_elements(value))
        if isinstance(value, (SomeVal, OkVal)):
            return self.value_contains_resource(value.inner)
        if isinstance(value, EnumVal):
            return any(self.value_contains_resource(field) for field in value.fields.values())
        return False

    def import_stub_write_needs_ownership_summary(self, old_value: Value, new_value: Value, write: ImportWrite) -> bool:
        if write.move:
            return self.value_contains_resource(old_value)
        return self.value_contains_resource(old_value) or self.value_contains_resource(new_value) or isinstance(new_value, MovedVal)

    def apply_import_stub_writes(self, args: list[Value], stub: ImportStub, sig: FunctionOwnershipSignature | None = None) -> None:
        for write in stub.writes:
            if write.ref_param_index >= len(args):
                raise InterpreterUnsupportedError(
                    f"import stub missing ref argument {write.ref_param_index + 1}"
                )
            arg = args[write.ref_param_index]
            if not isinstance(arg, RefVal):
                raise InterpreterUnsupportedError(
                    "import stub write expected runtime Ref value"
                )
            if not arg.mutable:
                raise InterpreterUnsupportedError(
                    "import stub write expected mutable Ref value"
                )
            summary_paths = self.import_summary_paths_for_ref_param(sig, write.ref_param_index) if sig is not None else set()
            canonical_write_path = parse_canonical_path(write.path)
            relative_path = canonical_path_to_runtime_parts(canonical_write_path)
            target = RuntimePlace(arg.place.root_cell, arg.place.path + relative_path)
            new_value = self.imported_stub_write_value(args, write)
            try:
                old_value = self.read_runtime_place(target)
            except TrapError as exc:
                if exc.reason == "read of moved value":
                    old_value = MovedVal()
                else:
                    raise
            if self.import_stub_write_needs_ownership_summary(old_value, new_value, write) and canonical_write_path not in summary_paths:
                rendered_path = ".".join(str(part) for part in relative_path) if relative_path else "<root>"
                fn_name = sig.name if sig is not None else "<unknown>"
                raise InterpreterUnsupportedError(
                    f"import stub for {fn_name} writes resource/ownership path {rendered_path} "
                    "without a matching imported ownership summary"
                )
            allow_live_resource_replace = write.allow_live_resource_replace or canonical_write_path in summary_paths
            self.write_runtime_place(
                target,
                new_value,
                allow_live_resource_replace=allow_live_resource_replace,
            )
            if sig is not None:
                final_value = self.read_runtime_place(target)
                # Skip the declared-effect audit only for the move-then-reinitialize
                # pattern: declared effect is "Moved" (the original value was consumed)
                # but the stub also wrote a fresh replacement to the same path.  In
                # that case the write is authoritative for the final state; auditing
                # against "Moved" would always fail for the newly written resource.
                # For all other declared states (e.g. "Closed") the audit still runs
                # so that stub/summary mismatches are caught.
                declared_for_path = self.import_summary_state_for_ref_path(sig, write.ref_param_index, canonical_write_path)
                is_move_then_reinit = (
                    declared_for_path is not None
                    and declared_for_path.split("{", 1)[0].strip() == "Moved"
                    and write.value is not None
                    and not isinstance(write.value, MovedVal)
                    and not write.move
                )
                if not is_move_then_reinit:
                    self.audit_import_stub_declared_effect(sig, write, canonical_write_path, final_value)

    def run_import_stub_builtin(self, stub: ImportStub, args: list[Value], sig: FunctionOwnershipSignature, target_name: str) -> Value | None:
        if stub.builtin is None:
            return None
        if stub.builtin == "i64_add":
            if len(args) != 2:
                raise InterpreterUnsupportedError(f"import stub builtin i64_add expects 2 args in {target_name}")
            lhs = self.expect_int(args[0])
            rhs = self.expect_int(args[1])
            return IntVal(lhs + rhs, width=64, signed=True)
        raise InterpreterUnsupportedError(f"unknown import stub builtin {stub.builtin!r} for {target_name}")

    def eval_imported_call(self, target_name: str, expr: ast.CallExpr) -> Value:
        sig = self.imported_signatures.get(target_name)
        stub = self.import_stubs.get(target_name)
        if sig is None:
            raise InterpreterUnsupportedError(
                f"unsupported imported function {target_name}: no ownership/type signature"
            )
        if len(expr.args) != len(sig.param_types):
            raise InterpreterUnsupportedError(f"imported function {target_name} expected {len(sig.param_types)} args but got {len(expr.args)}")
        args: list[Value] = []
        for idx, arg_expr in enumerate(expr.args):
            value = self.eval_expr(arg_expr)
            param_type = self.imported_param_type(sig, idx)
            coerced = self.coerce_value_to_type(param_type, value, context=f"imported parameter {idx + 1} of {target_name}") if param_type is not None else value
            args.append(coerced)
        if stub is None:
            if not sig.ref_params:
                raise TrapError(f"imported pure function {target_name} has no runtime stub")
            raise InterpreterUnsupportedError(
                f"imported function {target_name} has ownership signature but no runtime stub"
            )
        self.apply_import_ref_effects(args, sig)
        self.apply_import_stub_writes(args, stub, sig)
        builtin_value = self.run_import_stub_builtin(stub, args, sig, target_name)
        if builtin_value is not None:
            return self.coerce_value_to_type(parse_type_text(sig.return_type), builtin_value, context=f"imported return of {target_name}")
        if stub.return_value is not None:
            return self.coerce_value_to_type(parse_type_text(sig.return_type), deepcopy(stub.return_value), context=f"imported return of {target_name}")
        return self.default_value_for_type(parse_type_text(sig.return_type))

    def first_param_expects_ref(self, fn: ast.FnDecl) -> str | None:
        if not fn.params:
            return None
        typ = fn.params[0].typ
        if isinstance(typ, ast.GenericType) and typ.name in {"Ref", "RefConst"}:
            return typ.name
        return None

    def receiver_arg_for_method(self, fn: ast.FnDecl, access: RuntimeAccess) -> Value:
        ref_kind = self.first_param_expects_ref(fn)
        if ref_kind == "Ref":
            if not access.mutable:
                raise InterpreterUnsupportedError("cannot pass immutable receiver to method expecting Ref at runtime")
            return RefVal(access.place, mutable=True)
        if ref_kind == "RefConst":
            return RefVal(access.place, mutable=False)
        return self.read_runtime_place(access.place)

    def eval_call(self, expr: ast.CallExpr) -> Value:
        imported_name = self.imported_target_name(expr.callee)
        if imported_name is not None:
            return self.eval_imported_call(imported_name, expr)
        if isinstance(expr.callee, ast.NameExpr) and expr.callee.name in self.functions:
            fn = self.functions[expr.callee.name]
            args = [self.eval_expr(arg) for arg in expr.args]
            return self.call_function(fn, args)
        if isinstance(expr.callee, ast.DottedExpr):
            parts = expr.callee.parts
            if parts and parts[0] in self.functions and len(parts) == 1:
                fn = self.functions[parts[0]]
                args = [self.eval_expr(arg) for arg in expr.args]
                return self.call_function(fn, args)
            if len(parts) >= 2:
                receiver_access = self.resolve_access_from_parts(parts[:-1])
                method_name = parts[-1]
                receiver = self.read_runtime_place(receiver_access.place)
                if isinstance(receiver, ResourceVal):
                    protocol = self.protocols.get(receiver.protocol_name) if receiver.protocol_name is not None else None
                    has_transition = protocol is not None and any(t.name == method_name for t in protocol.transitions)
                    if has_transition:
                        if expr.args:
                            raise InterpreterUnsupportedError("resource transition methods do not take arguments")
                        if not receiver_access.mutable:
                            raise InterpreterUnsupportedError("cannot call mutating resource transition through immutable reference at runtime")
                        self.apply_resource_transition(receiver_access.place, receiver, method_name)
                        return UnitVal()
                if method_name in self.functions:
                    fn = self.functions[method_name]
                    receiver_arg = self.receiver_arg_for_method(fn, receiver_access)
                    args = [receiver_arg] + [self.eval_expr(arg) for arg in expr.args]
                    return self.call_function(fn, args)
        raise InterpreterUnsupportedError("only direct calls to local functions, receiver-dispatched local methods, and resource transition calls are implemented")

    def eval_attr(self, expr: ast.AttrExpr) -> Value:
        obj = self.eval_expr(expr.obj)
        if isinstance(obj, RefVal):
            obj = self.read_runtime_place(obj.place)
        if expr.name == "len" and isinstance(obj, StrVal):
            return IntVal(len(obj.value), width=64, signed=False)
        if expr.name == "len" and isinstance(obj, (ArrayVal, SliceVal)):
            return IntVal(self.array_length(obj), width=64, signed=False)
        if isinstance(obj, (StructVal, ResourceVal)):
            if expr.name not in obj.fields:
                raise InterpreterUnsupportedError(f"field {expr.name} missing on {obj.name}")
            return obj.fields[expr.name]
        raise InterpreterUnsupportedError("attribute access only supported on struct/resource/string values")

    def eval_index(self, expr: ast.IndexExpr) -> Value:
        access = self.maybe_resolve_access_expr(expr.obj)
        obj = self.read_runtime_place(access.place) if access is not None else self.eval_expr(expr.obj)
        idx = self.expect_int(self.eval_expr(expr.index))
        if isinstance(obj, RefVal):
            access = RuntimeAccess(obj.place, obj.mutable)
            obj = self.read_runtime_place(obj.place)
        if isinstance(obj, StrVal):
            if idx < 0 or idx >= len(obj.value):
                raise TrapError("index out of bounds")
            return IntVal(ord(obj.value[idx]), width=8, signed=False)
        if isinstance(obj, ArrayVal):
            if idx < 0 or idx >= len(obj.elements):
                raise TrapError("index out of bounds")
            if access is not None:
                return self.read_runtime_place(RuntimePlace(access.place.root_cell, access.place.path + (idx,)))
            return obj.elements[idx]
        if isinstance(obj, SliceVal):
            return self.read_runtime_place(self.slice_element_place(obj, idx))
        raise InterpreterUnsupportedError("index expressions are implemented only for Str, Array, and Slice")

    def eval_slice(self, expr: ast.SliceExpr) -> Value:
        access = self.maybe_resolve_access_expr(expr.obj)
        obj = self.read_runtime_place(access.place) if access is not None else self.eval_expr(expr.obj)
        if isinstance(obj, RefVal):
            access = RuntimeAccess(obj.place, obj.mutable)
            obj = self.read_runtime_place(obj.place)
        start = 0 if expr.start is None else self.expect_int(self.eval_expr(expr.start))
        if isinstance(obj, StrVal):
            default_stop = len(obj.value)
        elif isinstance(obj, ArrayVal):
            default_stop = len(obj.elements)
        elif isinstance(obj, SliceVal):
            default_stop = obj.length
        else:
            raise InterpreterUnsupportedError("slice expressions are implemented only for Str, Array, and Slice")
        stop = default_stop if expr.stop is None else self.expect_int(self.eval_expr(expr.stop))
        return self.make_slice_view(access, obj, start, stop)

    def apply_resource_transition(self, place: RuntimePlace, resource: ResourceVal, method_name: str) -> None:
        protocol_name = resource.protocol_name
        if protocol_name is None or protocol_name not in self.protocols:
            raise InterpreterUnsupportedError(f"resource {resource.name} has no runtime protocol")
        protocol = self.protocols[protocol_name]
        transition = next((t for t in protocol.transitions if t.name == method_name), None)
        if transition is None:
            raise InterpreterUnsupportedError(f"unknown protocol transition {method_name} on {resource.name}")
        if resource.protocol_state != transition.source:
            raise TrapError(f"invalid protocol transition {method_name} from {resource.protocol_state}")
        updated = ResourceVal(resource.name, resource.protocol_name, transition.target, resource.fields)
        self.write_runtime_place(place, updated, allow_live_resource_replace=True)

    def eval_cast(self, expr: ast.CastExpr) -> Value:
        inner = self.eval_expr(expr.expr)
        if not isinstance(expr.typ, ast.NamedType):
            raise InterpreterUnsupportedError("only named builtin casts are implemented")
        info = self.builtin_int_info(expr.typ.name)
        if info is None:
            raise InterpreterUnsupportedError(f"cast target {expr.typ.name} not implemented")
        value = self.expect_int(inner)
        width, signed = info
        try:
            return self.normalize_int(value, width, signed, f"cast to {expr.typ.name}")
        except TrapError:
            raise TrapError(f"cast value {value} out of range for {expr.typ.name}")

    def eval_match(self, expr: ast.MatchExpr) -> Value:
        scrutinee = self.eval_expr(expr.expr)
        for arm in expr.arms:
            matched, bindings = self.match_pattern(arm.pattern, scrutinee)
            if not matched:
                continue
            self.push_scope()
            try:
                for name, value in bindings.items():
                    self.bind_name(name, value, mutable=False)
                return self.eval_expr(arm.expr)
            finally:
                self.run_scope_cleanup(self.current_frame().scopes[-1], "normal")
                self.pop_scope()
        raise InterpreterUnsupportedError("match expression had no matching arm at runtime")

    def match_pattern(self, pattern: ast.Pattern, value: Value) -> tuple[bool, dict[str, Value]]:
        if isinstance(pattern, ast.WildcardPattern):
            return True, {}
        if isinstance(pattern, ast.NamePattern):
            if pattern.name == "_":
                return True, {}
            return True, {pattern.name: value}
        if isinstance(pattern, ast.LiteralPattern):
            return self.compare_key(self.eval_expr(pattern.value)) == self.compare_key(value), {}
        if isinstance(pattern, ast.SomePattern):
            if isinstance(value, SomeVal):
                return self.match_pattern(pattern.inner, value.inner)
            return False, {}
        if isinstance(pattern, ast.NonePattern):
            return isinstance(value, NoneVal), {}
        if isinstance(pattern, ast.OkPattern):
            if isinstance(value, OkVal):
                return self.match_pattern(pattern.inner, value.inner)
            return False, {}
        if isinstance(pattern, ast.ErrorPattern):
            if not isinstance(value, ErrVal):
                return False, {}
            if pattern.parts is None:
                return True, {}
            return value.tag == ".".join(pattern.parts), {}
        if isinstance(pattern, ast.EnumPattern):
            if not isinstance(value, EnumVal):
                return False, {}
            if [value.enum_name, value.variant_name] != pattern.parts:
                return False, {}
            bindings: dict[str, Value] = {}
            for field_name, field_pattern in pattern.fields:
                if field_name not in value.fields:
                    return False, {}
                matched, inner_bindings = self.match_pattern(field_pattern, value.fields[field_name])
                if not matched:
                    return False, {}
                bindings.update(inner_bindings)
            return True, bindings
        raise InterpreterUnsupportedError(f"pattern {type(pattern).__name__} not implemented")

    def compare_key(self, value: Value):
        if isinstance(value, UnitVal):
            return ("unit",)
        if isinstance(value, BoolVal):
            return ("bool", value.value)
        if isinstance(value, IntVal):
            return ("int", value.value)
        if isinstance(value, StrVal):
            return ("str", value.value)
        if isinstance(value, NoneVal):
            return ("none",)
        if isinstance(value, SomeVal):
            return ("some", self.compare_key(value.inner))
        if isinstance(value, OkVal):
            return ("ok", self.compare_key(value.inner))
        if isinstance(value, ErrVal):
            return ("err", value.tag)
        if isinstance(value, EnumVal):
            return ("enum", value.enum_name, value.variant_name, tuple(sorted((k, self.compare_key(v)) for k, v in value.fields.items())))
        if isinstance(value, ArrayVal):
            return ("array", tuple(self.compare_key(v) for v in value.elements))
        if isinstance(value, SliceVal):
            return ("slice", tuple(self.compare_key(v) for v in self.materialize_slice_elements(value)))
        if isinstance(value, StructVal):
            return ("struct", value.name, tuple(sorted((k, self.compare_key(v)) for k, v in value.fields.items())))
        if isinstance(value, ResourceVal):
            return ("resource", value.name, value.protocol_state, tuple(sorted((k, self.compare_key(v)) for k, v in value.fields.items())))
        raise InterpreterUnsupportedError(f"cannot compare value of type {type(value).__name__}")

    def expect_bool(self, value: Value) -> bool:
        if not isinstance(value, BoolVal):
            raise InterpreterUnsupportedError("expected Bool value")
        return value.value

    def expect_int_value(self, value: Value) -> IntVal:
        if not isinstance(value, IntVal):
            raise InterpreterUnsupportedError("expected integer value")
        return value

    def expect_int(self, value: Value) -> int:
        return self.expect_int_value(value).value

    def coerce_return(self, return_type: ast.Type, value: Value) -> Value:
        return self.coerce_value_to_type(return_type, value, context="return")


def interpret_module(module: ast.Module, entry: str = "main", imported_signatures: dict[str, FunctionOwnershipSignature] | None = None, import_stubs: dict[str, ImportStub] | None = None) -> Value:
    return Interpreter(module, imported_signatures=imported_signatures, import_stubs=import_stubs).interpret(entry)
