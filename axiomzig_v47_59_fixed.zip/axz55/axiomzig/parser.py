from __future__ import annotations

from dataclasses import asdict
from typing import Sequence

from . import ast
from .lexer import lex
from .token import Token


class ParseError(ValueError):
    pass


BINARY_PRECEDENCE = {
    "catch": 5,
    "or": 10,
    "and": 20,
    "==": 30,
    "!=": 30,
    "<": 40,
    "<=": 40,
    ">": 40,
    ">=": 40,
    "+": 50,
    "-": 50,
    "*": 60,
    "/": 60,
    "%": 60,
    "..": 15,
}
UNARY_OPS = {"-", "not", "move", "borrow", "copy"}


class Parser:
    def __init__(self, tokens: Sequence[Token]):
        self.tokens = list(tokens)
        self.i = 0
        self.allow_brace_literals = True

    def peek(self, offset: int = 0) -> Token:
        idx = self.i + offset
        if idx >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[idx]

    def at(self, *kinds: str) -> bool:
        return self.peek().kind in kinds

    def take(self) -> Token:
        tok = self.peek()
        self.i += 1
        return tok

    def expect(self, kind: str) -> Token:
        tok = self.peek()
        if tok.kind != kind:
            raise ParseError(f"expected {kind}, got {tok.short()}")
        self.i += 1
        return tok

    def accept(self, kind: str) -> Token | None:
        if self.at(kind):
            return self.take()
        return None

    def expect_word(self, value: str) -> Token:
        tok = self.peek()
        if tok.kind == value or (tok.kind == "IDENT" and tok.value == value):
            self.i += 1
            return tok
        raise ParseError(f"expected {value}, got {tok.short()}")


    def parse_module(self) -> ast.Module:
        self.expect("module")
        path = self.parse_dotted_identifiers()
        self.expect(";")
        imports: list[ast.ImportDecl] = []
        while self.at("import"):
            self.take()
            imports.append(ast.ImportDecl(path=self.parse_dotted_identifiers()))
            self.expect(";")
        decls: list[ast.TopDecl] = []
        while not self.at("EOF"):
            decls.append(self.parse_top_decl())
        self.expect("EOF")
        return ast.Module(path=path, imports=imports, decls=decls)

    def parse_dotted_identifiers(self) -> list[str]:
        parts = [self.expect("IDENT").value]
        while self.accept("."):
            parts.append(self.expect("IDENT").value)
        return parts

    def parse_top_decl(self) -> ast.TopDecl:
        attrs = self.parse_decl_attributes()
        is_public = self.accept("pub") is not None
        if attrs or is_public:
            if self.at("fn"):
                return self.parse_fn_decl(is_public=is_public, attrs=attrs)
            if self.at("resource"):
                return self.parse_resource_decl(is_public=is_public, attrs=attrs)
            if self.at("protocol"):
                return self.parse_protocol_decl(is_public=is_public, attrs=attrs)
            raise ParseError("top-level pub/attribute annotations currently apply only to fn, resource, or protocol declarations")
        if self.at("const"):
            return self.parse_const_decl()
        if self.at("struct"):
            return self.parse_struct_decl()
        if self.at("enum"):
            return self.parse_enum_decl()
        if self.at("error_set"):
            return self.parse_error_set_decl()
        if self.at("protocol"):
            return self.parse_protocol_decl()
        if self.at("resource"):
            return self.parse_resource_decl()
        if self.at("fn"):
            return self.parse_fn_decl()
        if self.at("alias"):
            raise ParseError("top-level alias declarations are not part of AxiomZig v1.1; use a supported declaration form")
        raise ParseError(f"unexpected top-level token {self.peek().short()}")

    def parse_const_decl(self) -> ast.ConstDecl:
        self.expect("const")
        name = self.expect("IDENT").value
        self.expect(":")
        typ = self.parse_type()
        self.expect("=")
        value = self.parse_expr()
        self.expect(";")
        return ast.ConstDecl(name=name, typ=typ, value=value)

    def parse_struct_decl(self) -> ast.StructDecl:
        self.expect("struct")
        name = self.expect("IDENT").value
        fields = self.parse_field_block()
        return ast.StructDecl(name=name, fields=fields)

    def parse_field_block(self) -> list[ast.Field]:
        self.expect("{")
        fields: list[ast.Field] = []
        while not self.at("}"):
            field_name = self.expect("IDENT").value
            self.expect(":")
            field_type = self.parse_type()
            self.expect(";")
            fields.append(ast.Field(name=field_name, typ=field_type))
        self.expect("}")
        return fields

    def parse_enum_decl(self) -> ast.EnumDecl:
        self.expect("enum")
        name = self.expect("IDENT").value
        self.expect("{")
        variants: list[ast.EnumVariant] = []
        while not self.at("}"):
            variant_name = self.expect("IDENT").value
            fields: list[ast.Field] = []
            if self.at("{"):
                fields = self.parse_field_block()
            self.expect(";")
            variants.append(ast.EnumVariant(name=variant_name, fields=fields))
        self.expect("}")
        return ast.EnumDecl(name=name, variants=variants)

    def parse_error_set_decl(self) -> ast.ErrorSetDecl:
        self.expect("error_set")
        name = self.expect("IDENT").value
        self.expect("{")
        tags: list[str] = []
        while not self.at("}"):
            tags.append(self.expect("IDENT").value)
            self.expect(";")
        self.expect("}")
        return ast.ErrorSetDecl(name=name, tags=tags)

    def parse_protocol_decl(self, *, is_public: bool = False, attrs: list[tuple[str, dict[str, str]]] | None = None) -> ast.ProtocolDecl:
        self.expect("protocol")
        stability, since, deprecated_reason, replacement = self.parse_public_api_metadata(attrs or [], 'protocol')
        name = self.expect("IDENT").value
        self.expect("{")
        self.expect_word("states")
        states = self.parse_identifier_brace_list()
        self.expect_word("init")
        init = self.expect("IDENT").value
        self.expect(";")
        self.expect_word("terminal")
        terminal = self.parse_identifier_brace_list()
        self.expect_word("transitions")
        self.expect("{")
        transitions: list[ast.ProtocolTransition] = []
        while not self.at("}"):
            t_name = self.expect("IDENT").value
            self.expect(":")
            source = self.expect("IDENT").value
            self.expect("->")
            target = self.expect("IDENT").value
            self.expect(";")
            transitions.append(ast.ProtocolTransition(name=t_name, source=source, target=target))
        self.expect("}")
        self.expect("}")
        return ast.ProtocolDecl(
            name=name,
            states=states,
            init=init,
            terminal=terminal,
            transitions=transitions,
            is_public=is_public,
            stability=stability,
            since=since,
            deprecated_reason=deprecated_reason,
            replacement=replacement,
        )

    def parse_identifier_brace_list(self) -> list[str]:
        self.expect("{")
        items = [self.expect("IDENT").value]
        while self.accept(","):
            items.append(self.expect("IDENT").value)
        self.expect("}")
        return items

    def parse_decl_attributes(self) -> list[tuple[str, dict[str, str]]]:
        attrs: list[tuple[str, dict[str, str]]] = []
        while self.peek().kind.startswith("@"):
            attrs.append(self.parse_decl_attribute())
        return attrs

    def parse_decl_attribute(self) -> tuple[str, dict[str, str]]:
        tok = self.take()
        kind = tok.kind
        if kind == "@experimental":
            return "experimental", {}
        if kind == "@since":
            self.expect("(")
            value = self.expect("STRING").value
            self.expect(")")
            return "since", {"value": value}
        if kind == "@deprecated":
            self.expect("(")
            args: dict[str, str] = {}
            if not self.at(")"):
                while True:
                    key = self.expect("IDENT").value
                    if key not in {"reason", "replacement"}:
                        raise ParseError(f"unsupported @deprecated argument {key!r}")
                    self.expect("=")
                    value = self.expect("STRING").value
                    if key in args:
                        raise ParseError(f"duplicate @deprecated argument {key!r}")
                    args[key] = value
                    if not self.accept(","):
                        break
            self.expect(")")
            if not args.get("reason", "").strip():
                raise ParseError('@deprecated requires non-empty reason="..."')
            return "deprecated", args
        raise ParseError(f"unsupported annotation {kind}")


    def parse_public_api_metadata(
        self,
        attrs: list[tuple[str, dict[str, str]]],
        decl_kind: str,
    ) -> tuple[str, str | None, str | None, str | None]:
        stability = 'stable'
        since: str | None = None
        deprecated_reason: str | None = None
        replacement: str | None = None
        for attr_name, attr_args in attrs:
            if attr_name == 'experimental':
                if stability != 'stable':
                    raise ParseError(f'duplicate or conflicting lifecycle annotations on {decl_kind} declaration')
                stability = 'experimental'
            elif attr_name == 'deprecated':
                if stability != 'stable':
                    raise ParseError(f'duplicate or conflicting lifecycle annotations on {decl_kind} declaration')
                stability = 'deprecated'
                deprecated_reason = attr_args.get('reason', '').strip() or None
                replacement = attr_args.get('replacement', '').strip() or None
            elif attr_name == 'since':
                value = attr_args.get('value', '').strip()
                if not value:
                    raise ParseError('@since requires a non-empty version string')
                if since is not None:
                    raise ParseError(f'duplicate @since annotation on {decl_kind} declaration')
                since = value
            else:
                raise ParseError(f'unsupported {decl_kind} annotation {attr_name!r}')
        return stability, since, deprecated_reason, replacement


    def parse_resource_decl(self, *, is_public: bool = False, attrs: list[tuple[str, dict[str, str]]] | None = None) -> ast.ResourceDecl:
        self.expect("resource")
        stability, since, deprecated_reason, replacement = self.parse_public_api_metadata(attrs or [], 'resource')
        name = self.expect("IDENT").value
        self.expect("{")
        protocol: str | None = None
        if self.at("protocol"):
            self.take()
            self.expect(":")
            protocol = self.expect("IDENT").value
            self.expect(";")
        self.expect_word("fields")
        fields = self.parse_field_block()
        self.expect("}")
        return ast.ResourceDecl(
            name=name,
            protocol=protocol,
            fields=fields,
            is_public=is_public,
            stability=stability,
            since=since,
            deprecated_reason=deprecated_reason,
            replacement=replacement,
        )


    def parse_effect_name(self) -> str:
        tok = self.peek()
        if tok.kind == "IDENT" or tok.kind in {"error"}:
            self.take()
            return tok.value
        raise ParseError(f"expected effect name, got {tok.short()}")

    def parse_fn_decl(self, *, is_public: bool = False, attrs: list[tuple[str, dict[str, str]]] | None = None) -> ast.FnDecl:
        self.expect("fn")
        stability, since, deprecated_reason, replacement = self.parse_public_api_metadata(list(attrs or []), 'fn')
        name = self.expect("IDENT").value
        self.expect("(")
        params: list[ast.Param] = []
        if not self.at(")"):
            while True:
                param_name = self.expect("IDENT").value
                self.expect(":")
                param_type = self.parse_type()
                params.append(ast.Param(name=param_name, typ=param_type))
                if not self.accept(","):
                    break
        self.expect(")")
        self.expect("->")
        return_type = self.parse_type()
        self.expect("effects")
        self.expect("(")
        effects: list[str] = []
        if not self.at(")"):
            effects.append(self.parse_effect_name())
            while self.accept(","):
                effects.append(self.parse_effect_name())
        self.expect(")")
        body = self.parse_block()
        return ast.FnDecl(
            name=name,
            params=params,
            return_type=return_type,
            effects=effects,
            body=body,
            is_public=is_public,
            stability=stability,
            since=since,
            deprecated_reason=deprecated_reason,
            replacement=replacement,
        )

    def parse_type(self) -> ast.Type:
        tok = self.peek()
        if tok.kind != "IDENT":
            raise ParseError(f"expected type, got {tok.short()}")

        base_name = self.take().value
        if base_name in {"Option", "Slice", "Array", "Ref", "RefConst"}:
            self.expect("<")
            args: list[ast.Type | int] = [self.parse_type()]
            if base_name == "Array":
                self.expect(",")
                args.append(int(self.expect("INT").value.replace("_", ""), 0))
            self.expect(">")
            typ: ast.Type = ast.GenericType(base_name, args)
        else:
            typ = ast.NamedType(base_name)

        while True:
            if self.accept("?"):
                typ = ast.OptionalType(typ)
                continue
            if self.accept("!"):
                err_type = self.parse_type()
                typ = ast.ResultType(typ, err_type)
                continue
            break
        return typ

    def parse_block(self) -> ast.Block:
        self.expect("{")
        statements: list[ast.Stmt] = []
        while not self.at("}"):
            statements.append(self.parse_stmt())
        self.expect("}")
        return ast.Block(statements=statements)

    def parse_stmt(self) -> ast.Stmt:
        if self.at("let"):
            self.take()
            name = self.expect("IDENT").value
            typ = None
            if self.accept(":"):
                typ = self.parse_type()
            self.expect("=")
            value = self.parse_expr()
            self.expect(";")
            return ast.LetStmt(name=name, typ=typ, value=value)
        if self.at("var"):
            self.take()
            name = self.expect("IDENT").value
            typ = None
            if self.accept(":"):
                typ = self.parse_type()
            self.expect("=")
            value = self.parse_expr()
            self.expect(";")
            return ast.VarStmt(name=name, typ=typ, value=value)
        if self.at("return"):
            self.take()
            expr = None if self.at(";") else self.parse_expr()
            self.expect(";")
            return ast.ReturnStmt(expr=expr)
        if self.at("if"):
            self.take()
            self.expect("(")
            cond = self.parse_expr()
            self.expect(")")
            then_block = self.parse_block()
            else_branch = None
            if self.accept("else"):
                if self.at("if"):
                    else_branch = self.parse_stmt()
                else:
                    else_branch = self.parse_block()
            return ast.IfStmt(cond=cond, then_block=then_block, else_branch=else_branch)
        if self.at("while"):
            self.take()
            self.expect("(")
            cond = self.parse_expr()
            self.expect(")")
            body = self.parse_block()
            return ast.WhileStmt(cond=cond, body=body)
        if self.at("for"):
            self.take()
            self.expect("(")
            name = self.expect("IDENT").value
            self.expect(":")
            typ = self.parse_type()
            self.expect("in")
            iterable = self.parse_expr()
            self.expect(")")
            body = self.parse_block()
            return ast.ForStmt(name=name, typ=typ, iterable=iterable, body=body)
        if self.at("break"):
            self.take()
            self.expect(";")
            return ast.BreakStmt()
        if self.at("continue"):
            self.take()
            self.expect(";")
            return ast.ContinueStmt()
        if self.at("defer"):
            self.take()
            return ast.DeferStmt(stmt=self.parse_stmt())
        if self.at("errdefer"):
            self.take()
            return ast.ErrDeferStmt(stmt=self.parse_stmt())
        if self.at("{"):
            return self.parse_block()

        expr = self.parse_expr()
        if self.at("=", "+=", "-=", "*=", "/=", "%="):
            op = self.take().kind
            value = self.parse_expr()
            self.expect(";")
            return ast.AssignStmt(target=expr, op=op, value=value)
        self.expect(";")
        return ast.ExprStmt(expr=expr)

    def parse_expr(self, min_prec: int = 0) -> ast.Expr:
        if self.at("match"):
            self.take()
            old_allow_brace_literals = self.allow_brace_literals
            self.allow_brace_literals = False
            scrutinee = self.parse_expr()
            self.allow_brace_literals = old_allow_brace_literals
            self.expect("{")
            arms: list[ast.MatchArm] = []
            while not self.at("}"):
                pattern = self.parse_pattern()
                self.expect("->")
                expr = self.parse_expr()
                self.accept(",")
                arms.append(ast.MatchArm(pattern=pattern, expr=expr))
            self.expect("}")
            left: ast.Expr = ast.MatchExpr(expr=scrutinee, arms=arms)
        else:
            left = self.parse_unary()

        while self.peek().kind in BINARY_PRECEDENCE and BINARY_PRECEDENCE[self.peek().kind] >= min_prec:
            op = self.take().kind
            prec = BINARY_PRECEDENCE[op]
            if op == "catch" and self.at("|"):
                # catch |e| { body } — binding form
                self.take()  # consume |
                name = self.expect("IDENT").value
                self.expect("|")
                handler = self.parse_block()
                # Synthesise a UnitExpr fallback so the AST is always well-formed;
                # the real result comes from the block.
                left = ast.CatchExpr(
                    expr=left,
                    fallback=ast.UnitExpr(),
                    binding=name,
                    handler=handler,
                )
                continue
            right = self.parse_expr(prec + 1)
            if op == "..":
                left = ast.RangeExpr(start=left, stop=right)
            elif op == "catch":
                left = ast.CatchExpr(expr=left, fallback=right)
            else:
                left = ast.BinaryExpr(left=left, op=op, right=right)
        return left

    def parse_unary(self) -> ast.Expr:
        if self.at("try"):
            self.take()
            return ast.TryExpr(expr=self.parse_unary())
        if self.peek().kind in UNARY_OPS:
            op = self.take().kind
            return ast.UnaryExpr(op=op, expr=self.parse_unary())
        if self.at("@cast"):
            self.take()
            self.expect("(")
            typ = self.parse_type()
            self.expect(",")
            expr = self.parse_expr()
            self.expect(")")
            return ast.CastExpr(typ=typ, expr=expr)
        return self.parse_postfix()

    def parse_postfix(self) -> ast.Expr:
        expr = self.parse_primary()
        while True:
            if self.accept("("):
                args: list[ast.Expr] = []
                if not self.at(")"):
                    args.append(self.parse_expr())
                    while self.accept(","):
                        args.append(self.parse_expr())
                self.expect(")")
                expr = ast.CallExpr(callee=expr, args=args)
                continue
            if self.accept("."):
                name = self.expect("IDENT").value
                if isinstance(expr, ast.NameExpr):
                    expr = ast.DottedExpr(parts=[expr.name, name])
                elif isinstance(expr, ast.DottedExpr):
                    expr.parts.append(name)
                else:
                    expr = ast.AttrExpr(obj=expr, name=name)
                continue
            if self.allow_brace_literals and self.at("{") and isinstance(expr, ast.DottedExpr) and len(expr.parts) == 2:
                expr = ast.EnumLiteralExpr(
                    enum_name=expr.parts[0],
                    variant_name=expr.parts[1],
                    fields=self.parse_named_init_block(),
                )
                continue
            if self.accept("["):
                if self.accept(".."):
                    stop = None if self.at("]") else self.parse_expr()
                    self.expect("]")
                    expr = ast.SliceExpr(obj=expr, start=None, stop=stop)
                    continue
                first = None if self.at("]") else self.parse_expr(BINARY_PRECEDENCE[".."] + 1)
                if self.accept(".."):
                    stop = None if self.at("]") else self.parse_expr()
                    self.expect("]")
                    expr = ast.SliceExpr(obj=expr, start=first, stop=stop)
                else:
                    self.expect("]")
                    if first is None:
                        raise ParseError("index expression cannot be empty")
                    expr = ast.IndexExpr(obj=expr, index=first)
                continue
            if self.accept("?"):
                expr = ast.TryExpr(expr=expr)
                continue
            break
        return expr

    def parse_primary(self) -> ast.Expr:
        tok = self.peek()
        if tok.kind == "INT":
            self.take()
            return ast.IntExpr(raw=tok.value)
        if tok.kind == "STRING":
            self.take()
            return ast.StringExpr(value=tok.value)
        if tok.kind == "true":
            self.take()
            return ast.BoolExpr(value=True)
        if tok.kind == "false":
            self.take()
            return ast.BoolExpr(value=False)
        if tok.kind == "unit":
            self.take()
            return ast.UnitExpr()
        if tok.kind == "none":
            self.take()
            return ast.NoneExpr()
        if tok.kind == "some":
            self.take()
            self.expect("(")
            expr = self.parse_expr()
            self.expect(")")
            return ast.SomeExpr(value=expr)
        if tok.kind == "IDENT":
            name = self.take().value
            if self.allow_brace_literals and self.at("{") and self.peek(1).kind in {"IDENT", "}"}:
                return ast.StructLiteralExpr(name=name, fields=self.parse_named_init_block())
            return ast.NameExpr(name=name)
        if tok.kind == "(":
            self.take()
            expr = self.parse_expr()
            self.expect(")")
            return expr
        raise ParseError(f"expected primary expression, got {tok.short()}")

    def parse_named_init_block(self) -> list[tuple[str, ast.Expr]]:
        self.expect("{")
        items: list[tuple[str, ast.Expr]] = []
        if not self.at("}"):
            while True:
                name = self.expect("IDENT").value
                self.expect(":")
                expr = self.parse_expr()
                items.append((name, expr))
                if not self.accept(","):
                    break
        self.expect("}")
        return items

    def parse_pattern(self) -> ast.Pattern:
        tok = self.peek()
        if tok.kind == "IDENT" and tok.value == "_":
            self.take()
            return ast.WildcardPattern()
        if tok.kind == "none":
            self.take()
            return ast.NonePattern()
        if tok.kind == "some":
            self.take()
            self.expect("(")
            inner = self.parse_pattern()
            self.expect(")")
            return ast.SomePattern(inner=inner)
        if tok.kind == "ok":
            self.take()
            self.expect("(")
            inner = self.parse_pattern()
            self.expect(")")
            return ast.OkPattern(inner=inner)
        if tok.kind == "error":
            self.take()
            self.expect("(")
            if self.at("IDENT") and self.peek().value == "_":
                self.take()
                self.expect(")")
                return ast.ErrorPattern(parts=None)
            parts = self.parse_dotted_identifiers()
            self.expect(")")
            return ast.ErrorPattern(parts=parts)
        if tok.kind == "INT":
            self.take()
            return ast.LiteralPattern(value=ast.IntExpr(raw=tok.value))
        if tok.kind == "STRING":
            self.take()
            return ast.LiteralPattern(value=ast.StringExpr(value=tok.value))
        if tok.kind == "true":
            self.take()
            return ast.LiteralPattern(value=ast.BoolExpr(value=True))
        if tok.kind == "false":
            self.take()
            return ast.LiteralPattern(value=ast.BoolExpr(value=False))
        if tok.kind == "unit":
            self.take()
            return ast.LiteralPattern(value=ast.UnitExpr())
        if tok.kind == "IDENT":
            parts = self.parse_dotted_identifiers()
            if self.at("{") and len(parts) >= 2:
                self.expect("{")
                fields: list[tuple[str, ast.Pattern]] = []
                if not self.at("}"):
                    while True:
                        name = self.expect("IDENT").value
                        self.expect(":")
                        fields.append((name, self.parse_pattern()))
                        if not self.accept(","):
                            break
                self.expect("}")
                return ast.EnumPattern(parts=parts, fields=fields)
            if len(parts) >= 2:
                return ast.EnumPattern(parts=parts, fields=[])
            return ast.NamePattern(name=parts[0])
        raise ParseError(f"expected pattern, got {tok.short()}")


def parse_module(text: str) -> ast.Module:
    return Parser(lex(text)).parse_module()
