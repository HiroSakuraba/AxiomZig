from __future__ import annotations

import argparse
import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
import sys

from .cfg import build_cfg
from .checker import check_module
from .elaborate import elaborate_module
from .formatter import format_module
from .interpreter import (
    ArrayVal,
    BoolVal,
    ErrVal,
    ImportStub,
    ImportWrite,
    IntVal,
    InterpreterUnsupportedError,
    MovedVal,
    NoneVal,
    OkVal,
    ResourceVal,
    SomeVal,
    StrVal,
    StructVal,
    TrapError,
    UnitVal,
    interpret_module,
)
from .ir import lower_module
from .lexer import LexError, lex
from .parser import ParseError, parse_module
from .ownership import analyze_ownership, export_ownership_signatures
from .ownership_signatures import (
    bundle_from_dict,
    dependency_lock_digest,
    dependency_lock_from_manifest_inputs,
    dependency_manifest_record_from_dict,
    dependency_publication_closure_from_manifest_inputs,
    load_dependency_manifest_inputs,
    merge_signature_bundles,
    validate_dependency_lock_dict,
)
from .publication_diff import diff_publication_manifests
from .module_graph import (
    auto_discover_workspace_signatures,
    build_publication_digest_record,
    verify_publication_digest_record,
    build_publication_manifest,
    build_workspace_manifest,
    check_package_interface_compatibility,
    check_workspace_conformance,
    collect_workspace_export_bundles,
    collect_workspace_ownership_signatures,
    emit_package_interface_for_workspace,
    package_interface_from_dict,
)
from .resolve import resolve_module
from .typecheck import typecheck_module


def dataclass_to_jsonable(obj):
    if is_dataclass(obj):
        return {k: dataclass_to_jsonable(v) for k, v in asdict(obj).items()}
    if isinstance(obj, list):
        return [dataclass_to_jsonable(v) for v in obj]
    if isinstance(obj, dict):
        return {k: dataclass_to_jsonable(v) for k, v in obj.items()}
    return obj


def json_to_runtime_value(data):
    if isinstance(data, bool):
        return BoolVal(data)
    if isinstance(data, int):
        return IntVal(data)
    if isinstance(data, str):
        return StrVal(data)
    if isinstance(data, list):
        return ArrayVal([json_to_runtime_value(item) for item in data])
    if not isinstance(data, dict):
        raise ValueError(f"unsupported runtime stub value {data!r}")
    if data.get("unit") is True:
        return UnitVal()
    if data.get("none") is True:
        return NoneVal()
    if data.get("moved") is True:
        return MovedVal()
    if "bool" in data:
        return BoolVal(bool(data["bool"]))
    if "int" in data:
        return IntVal(int(data["int"]))
    if "str" in data:
        return StrVal(str(data["str"]))
    if "some" in data:
        return SomeVal(json_to_runtime_value(data["some"]))
    if "ok" in data:
        return OkVal(json_to_runtime_value(data["ok"]))
    if "err" in data:
        return ErrVal(str(data["err"]))
    if "array" in data:
        return ArrayVal([json_to_runtime_value(item) for item in data["array"]])
    if "struct" in data:
        item = data["struct"]
        return StructVal(
            name=item["name"],
            fields={k: json_to_runtime_value(v) for k, v in item.get("fields", {}).items()},
        )
    if "resource" in data:
        item = data["resource"]
        return ResourceVal(
            name=item["name"],
            protocol_name=item.get("protocol_name"),
            protocol_state=item.get("protocol_state"),
            fields={k: json_to_runtime_value(v) for k, v in item.get("fields", {}).items()},
        )
    raise ValueError(f"unsupported runtime stub value shape: {data!r}")


def import_stubs_from_dict(data: dict) -> dict[str, ImportStub]:
    if "functions" in data:
        raw_items = data["functions"]
    else:
        raw_items = [{"name": name, **spec} for name, spec in data.items()]
    stubs: dict[str, ImportStub] = {}
    for item in raw_items:
        writes = []
        for write in item.get("writes", []):
            raw_path = write.get("path", [])
            if isinstance(raw_path, str):
                path_parts = tuple(int(part) if part.lstrip("-").isdigit() else part for part in raw_path.split(".") if part != "")
            else:
                path_parts = tuple(raw_path)
            writes.append(
                ImportWrite(
                    ref_param_index=write["ref_param_index"],
                    path=path_parts,
                    value=json_to_runtime_value(write["value"]) if "value" in write else None,
                    source_arg_index=write.get("source_arg_index"),
                    move=write.get("move", False),
                    allow_live_resource_replace=write.get("allow_live_resource_replace", False),
                )
            )
        stubs[item["name"]] = ImportStub(
            builtin=item.get("builtin"),
            writes=writes,
            return_value=json_to_runtime_value(item["return_value"]) if "return_value" in item else None,
        )
    return stubs



def load_signature_inputs(
    import_ownership_paths: list[str] | None,
    dependency_manifest_paths: list[str] | None,
    dependency_lock_path: str | None = None,
) -> tuple[list, set[str]]:
    bundles = [bundle_from_dict(json.loads(Path(path).read_text(encoding='utf-8'))) for path in (import_ownership_paths or [])]
    dependency_lock = None
    if dependency_lock_path:
        dependency_lock = json.loads(Path(dependency_lock_path).read_text(encoding='utf-8'))
        validate_dependency_lock_dict(dependency_lock)
    dep_bundles, dependency_modules = load_dependency_manifest_inputs([
        (path, json.loads(Path(path).read_text(encoding='utf-8')))
        for path in (dependency_manifest_paths or [])
    ], dependency_lock=dependency_lock)
    bundles.extend(dep_bundles)
    return bundles, dependency_modules

def build_conformance_manifest(
    entry_file: str,
    *,
    module_root: str | None = None,
    external_bundles: list[dict] | None = None,
    dependency_manifest_inputs: list[tuple[str, dict]] | None = None,
    dependency_lock_input: dict | None = None,
    public_only: bool = False,
    package_name: str | None = None,
    package_version: str | None = None,
    package_interface_input: dict | None = None,
) -> tuple[dict[str, object], list, list, list[dict[str, object]]]:
    bundles = [bundle_from_dict(item) for item in (external_bundles or [])]
    dependency_manifest_inputs = list(dependency_manifest_inputs or [])
    dep_bundles, dependency_modules = load_dependency_manifest_inputs(
        dependency_manifest_inputs,
        dependency_lock=dependency_lock_input,
    )
    dependency_packages = [dependency_manifest_record_from_dict(data) for _, data in dependency_manifest_inputs]
    dependency_packages.sort(key=lambda item: str(item['package_id']))
    dependency_publication_closure = dependency_publication_closure_from_manifest_inputs(dependency_manifest_inputs)
    generated_lock = dependency_lock_from_manifest_inputs(dependency_manifest_inputs)
    effective_dependency_lock = dependency_lock_input if dependency_lock_input is not None else (generated_lock if dependency_manifest_inputs else None)
    if dependency_manifest_inputs:
        lock_digest = dependency_lock_digest(generated_lock)
    elif dependency_lock_input is not None:
        lock_digest = dependency_lock_digest(dependency_lock_input)
    else:
        lock_digest = None
    package_interface = package_interface_from_dict(package_interface_input)
    bundles.extend(dep_bundles)
    external_signatures = merge_signature_bundles(bundles)
    workspace_bundles, signatures, graph = collect_workspace_export_bundles(
        entry_file,
        module_root=module_root,
        external_signatures=external_signatures,
        dependency_modules=dependency_modules,
    )
    diagnostics = check_workspace_conformance(graph, signatures)
    diagnostics.extend(
        check_package_interface_compatibility(
            package_interface,
            dependency_lock=effective_dependency_lock,
            dependency_publication_closure=dependency_publication_closure,
        )
    )
    manifest = build_workspace_manifest(
        graph,
        workspace_bundles,
        external_signatures,
        diagnostics,
        public_only=public_only,
        package_name=package_name,
        package_version=package_version,
        package_interface=package_interface,
        dependency_packages=dependency_packages,
        dependency_publication_closure=dependency_publication_closure,
        dependency_lock_digest=lock_digest,
        dependency_lock_digest_algorithm='sha256' if lock_digest else None,
    )
    return manifest, diagnostics, [bundle for _, bundle in sorted(workspace_bundles.items())], dependency_packages


def write_conformance_manifest(path: str | None, manifest: dict[str, object]) -> None:
    payload = json.dumps(manifest, indent=2, sort_keys=True) + '\n'
    if path:
        Path(path).write_text(payload, encoding='utf-8')
    else:
        sys.stdout.write(payload)


def write_dependency_lock(path: str | None, lock: dict[str, object]) -> None:
    if not path:
        return
    payload = json.dumps(lock, indent=2, sort_keys=True) + '\n'
    Path(path).write_text(payload, encoding='utf-8')


def run_conformance(args) -> int:
    external_bundles = [json.loads(Path(path).read_text(encoding='utf-8')) for path in getattr(args, 'import_ownership', [])]
    dependency_manifest_inputs = [
        (path, json.loads(Path(path).read_text(encoding='utf-8')))
        for path in getattr(args, 'dependency_manifest', [])
    ]
    dependency_lock_input = None
    dependency_lock_path = getattr(args, 'dependency_lock', None)
    if dependency_lock_path:
        dependency_lock_input = json.loads(Path(dependency_lock_path).read_text(encoding='utf-8'))
    package_interface_input = None
    package_interface_path = getattr(args, 'package_interface', None)
    if package_interface_path:
        package_interface_input = json.loads(Path(package_interface_path).read_text(encoding='utf-8'))
    else:
        module_root = Path(args.module_root).resolve() if getattr(args, 'module_root', None) else Path(args.file).resolve().parent
        candidate = module_root / 'axiomzig.package.json'
        if candidate.is_file():
            package_interface_input = json.loads(candidate.read_text(encoding='utf-8'))
    try:
        manifest, diagnostics, _, dependency_packages = build_conformance_manifest(
            args.file,
            module_root=args.module_root,
            external_bundles=external_bundles,
            dependency_manifest_inputs=dependency_manifest_inputs,
            dependency_lock_input=dependency_lock_input,
            public_only=getattr(args, 'public_only', False),
            package_name=getattr(args, 'package_name', None),
            package_version=getattr(args, 'package_version', None),
            package_interface_input=package_interface_input,
        )
    except ValueError as exc:
        print(f'conformance error: {exc}', file=sys.stderr)
        return 1
    write_conformance_manifest(getattr(args, 'out', None), manifest)
    publication_out = getattr(args, 'publication_out', None)
    has_errors = any(issue.level == 'error' for issue in diagnostics)
    if publication_out and not has_errors:
        publication_manifest = build_publication_manifest(manifest)
        write_conformance_manifest(publication_out, publication_manifest)
    elif publication_out and has_errors:
        print('conformance error: refusing to write publication manifest for non-conforming workspace', file=sys.stderr)
    write_dependency_lock(getattr(args, 'write_dependency_lock', None), dependency_lock_from_manifest_inputs(dependency_manifest_inputs))
    for issue in diagnostics:
        if issue.level == 'error':
            print(f'conformance error: {issue.message}', file=sys.stderr)
    return 1 if has_errors else 0



def _candidate_package_interface_path(args) -> Path:
    module_root = Path(args.module_root).resolve() if getattr(args, 'module_root', None) else Path(args.file).resolve().parent
    return module_root / 'axiomzig.package.json'


def _load_base_package_interface_input(args, *, require_explicit: bool = False) -> tuple[dict | None, Path | None]:
    explicit = getattr(args, 'package_interface', None)
    if explicit:
        path = Path(explicit)
        return json.loads(path.read_text(encoding='utf-8')), path
    if require_explicit:
        return None, None
    candidate = _candidate_package_interface_path(args)
    if candidate.is_file():
        return json.loads(candidate.read_text(encoding='utf-8')), candidate
    return None, candidate


def run_emit_package_interface(args) -> int:
    base_input, _base_path = _load_base_package_interface_input(args)
    rendered = emit_package_interface_for_workspace(
        args.file,
        module_root=getattr(args, 'module_root', None),
        package_name=getattr(args, 'package_name', None),
        package_version=getattr(args, 'package_version', None),
        base_interface_input=base_input,
    )
    payload = json.dumps(rendered, indent=2, sort_keys=True) + '\n'
    if getattr(args, 'out', None):
        Path(args.out).write_text(payload, encoding='utf-8')
    else:
        sys.stdout.write(payload)
    return 0


_PACKAGE_INTERFACE_SYNC_SECTION_LABELS: dict[str, str] = {
    'schema_version': 'schema',
    'package_name': 'package metadata',
    'package_version': 'package metadata',
    'compatibility': 'package compatibility',
    'public_modules': 'public modules',
    'public_functions': 'functions',
    'public_resources': 'resources',
    'public_protocols': 'protocols',
    'public_function_metadata': 'function lifecycle metadata',
    'public_resource_metadata': 'resource lifecycle metadata',
    'public_protocol_metadata': 'protocol lifecycle metadata',
    'public_resource_shapes': 'resource shapes',
    'public_protocol_shapes': 'protocol shapes',
}


def _package_interface_sync_mismatch_sections(existing: dict, rendered: dict) -> list[str]:
    labels: list[str] = []
    seen: set[str] = set()
    ordered_keys = [
        'schema_version',
        'package_name',
        'package_version',
        'compatibility',
        'public_modules',
        'public_functions',
        'public_resources',
        'public_protocols',
        'public_function_metadata',
        'public_resource_metadata',
        'public_protocol_metadata',
        'public_resource_shapes',
        'public_protocol_shapes',
    ]
    all_keys = ordered_keys + sorted((set(existing) | set(rendered)) - set(ordered_keys))
    for key in all_keys:
        if existing.get(key) == rendered.get(key):
            continue
        if key in _PACKAGE_INTERFACE_SYNC_SECTION_LABELS:
            label = _PACKAGE_INTERFACE_SYNC_SECTION_LABELS[key]
        elif key in existing and key not in rendered:
            label = f'extra field {key}'
        elif key in rendered and key not in existing:
            label = f'missing field {key}'
        else:
            label = f'field {key}'
        if label not in seen:
            seen.add(label)
            labels.append(label)
    return labels or ['unknown']


def run_check_package_interface_sync(args) -> int:
    existing_input, existing_path = _load_base_package_interface_input(args, require_explicit=True)
    if existing_input is None or existing_path is None:
        raise ValueError('check-package-interface-sync requires --package-interface PATH')
    invalid_reason: str | None = None
    try:
        rendered = emit_package_interface_for_workspace(
            args.file,
            module_root=getattr(args, 'module_root', None),
            package_name=getattr(args, 'package_name', None),
            package_version=getattr(args, 'package_version', None),
            base_interface_input=existing_input,
        )
    except ValueError as exc:
        # A stale checked-in package interface may be internally invalid after a
        # source edit.  Sync checking should still report section-level drift
        # rather than stopping at package-interface normalization.
        invalid_reason = str(exc)
        rendered = emit_package_interface_for_workspace(
            args.file,
            module_root=getattr(args, 'module_root', None),
            package_name=getattr(args, 'package_name', None) or str(existing_input.get('package_name', '') or '') or None,
            package_version=getattr(args, 'package_version', None) or str(existing_input.get('package_version', '') or '') or None,
            base_interface_input=None,
        )
        for preserved_key in ('compatibility',):
            if preserved_key in existing_input and preserved_key not in rendered:
                rendered[preserved_key] = existing_input[preserved_key]
    if rendered != existing_input or invalid_reason is not None:
        sections_list = _package_interface_sync_mismatch_sections(existing_input, rendered)
        if invalid_reason is not None and 'invalid package interface' not in sections_list:
            sections_list.append('invalid package interface')
        sections = ', '.join(sections_list)
        detail = f'; invalid existing interface: {invalid_reason}' if invalid_reason else ''
        print(
            f'package interface sync error: {existing_path} is out of sync with source-declared public API; '
            f'mismatched sections: {sections}; run emit-package-interface{detail}',
            file=sys.stderr,
        )
        return 1
    return 0

def run_publication_digest(args) -> int:
    """
    pubdigest — compute or verify the canonical digest of a publication manifest.

    Compute mode (no --verify):
      Reads the manifest, computes the canonical publication digest,
      outputs a digest record with null signature placeholder fields.

    Verify mode (--verify DIGEST_FILE):
      Reads the manifest and an existing digest record, recomputes the
      digest, and reports any mismatches.  Does not verify cryptographic
      signatures — that requires an external tool with the signing key.
    """
    manifest_data = json.loads(Path(args.manifest).read_text(encoding='utf-8'))

    if args.verify:
        digest_record = json.loads(Path(args.verify).read_text(encoding='utf-8'))
        errors = verify_publication_digest_record(manifest_data, digest_record)
        if errors:
            for err in errors:
                print(f'digest verify error: {err}', file=sys.stderr)
            return 1
        print('digest ok')
        return 0

    record = build_publication_digest_record(manifest_data)
    output = json.dumps(record, indent=2, sort_keys=True)
    if args.out:
        Path(args.out).write_text(output + '\n', encoding='utf-8')
    else:
        print(output)
    return 0


def run_publication_diff(args) -> int:
    old_manifest = json.loads(Path(args.old_manifest).read_text(encoding='utf-8'))
    new_manifest = json.loads(Path(args.new_manifest).read_text(encoding='utf-8'))
    result = diff_publication_manifests(old_manifest, new_manifest)
    payload = json.dumps(result, indent=2, sort_keys=True) + '\n'
    if getattr(args, 'out', None):
        Path(args.out).write_text(payload, encoding='utf-8')
    else:
        sys.stdout.write(payload)
    if getattr(args, 'fail_on_incompatible', False) and result['classification'] == 'incompatible':
        return 1
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="axiomzig")
    sub = parser.add_subparsers(dest="command", required=True)

    p_lex = sub.add_parser("lex")
    p_lex.add_argument("file")

    p_parse = sub.add_parser("parse")
    p_parse.add_argument("file")

    p_resolve = sub.add_parser("resolve")
    p_resolve.add_argument("file")

    p_elaborate = sub.add_parser("elaborate")
    p_elaborate.add_argument("file")

    p_format = sub.add_parser("format")
    p_format.add_argument("file")
    p_format.add_argument("--in-place", action="store_true")
    p_format.add_argument("--check", action="store_true")

    p_check = sub.add_parser("check")
    p_check.add_argument("file")
    p_check.add_argument("--import-ownership", action="append", default=[])
    p_check.add_argument("--module-root")
    p_check.add_argument("--dependency-manifest", action="append", default=[])
    p_check.add_argument("--dependency-lock")
    p_check.add_argument("--no-workspace-discovery", action="store_true")

    p_typecheck = sub.add_parser("typecheck")
    p_typecheck.add_argument("file")
    p_typecheck.add_argument("--import-ownership", action="append", default=[])
    p_typecheck.add_argument("--module-root")
    p_typecheck.add_argument("--dependency-manifest", action="append", default=[])
    p_typecheck.add_argument("--dependency-lock")

    p_lower = sub.add_parser("lower")
    p_lower.add_argument("file")

    p_cfg = sub.add_parser("cfg")
    p_cfg.add_argument("file")
    p_cfg.add_argument("--module-root")
    p_cfg.add_argument("--dependency-manifest", action="append", default=[])
    p_cfg.add_argument("--dependency-lock")

    p_own = sub.add_parser("owncheck")
    p_own.add_argument("file")
    p_own.add_argument("--import-ownership", action="append", default=[])
    p_own.add_argument("--module-root")
    p_own.add_argument("--dependency-manifest", action="append", default=[])
    p_own.add_argument("--dependency-lock")
    p_own.add_argument("--no-workspace-discovery", action="store_true")

    p_ownsig = sub.add_parser("ownsig")
    p_ownsig.add_argument("file")
    p_ownsig.add_argument("--import-ownership", action="append", default=[])
    p_ownsig.add_argument("--module-root")
    p_ownsig.add_argument("--dependency-manifest", action="append", default=[])
    p_ownsig.add_argument("--dependency-lock")
    p_ownsig.add_argument("--no-workspace-discovery", action="store_true")

    p_interpret = sub.add_parser("interpret")
    p_interpret.add_argument("file")
    p_interpret.add_argument("--entry", default="main")
    p_interpret.add_argument("--import-ownership", action="append", default=[])
    p_interpret.add_argument("--module-root")
    p_interpret.add_argument("--dependency-manifest", action="append", default=[])
    p_interpret.add_argument("--dependency-lock")
    p_interpret.add_argument("--import-stubs", action="append", default=[])
    p_interpret.add_argument("--no-workspace-discovery", action="store_true")

    p_conform = sub.add_parser("conform")
    p_conform.add_argument("file")
    p_conform.add_argument("--import-ownership", action="append", default=[])
    p_conform.add_argument("--module-root")
    p_conform.add_argument("--dependency-manifest", action="append", default=[])
    p_conform.add_argument("--dependency-lock")
    p_conform.add_argument("--out")
    p_conform.add_argument("--publication-out")
    p_conform.add_argument("--write-dependency-lock")
    p_conform.add_argument("--public-only", action="store_true")
    p_conform.add_argument("--package-interface")
    p_conform.add_argument("--package-name")
    p_conform.add_argument("--package-version")

    p_emit_iface = sub.add_parser("emit-package-interface")
    p_emit_iface.add_argument("file")
    p_emit_iface.add_argument("--module-root")
    p_emit_iface.add_argument("--package-interface")
    p_emit_iface.add_argument("--package-name")
    p_emit_iface.add_argument("--package-version")
    p_emit_iface.add_argument("--out")

    p_check_iface = sub.add_parser("check-package-interface-sync")
    p_check_iface.add_argument("file")
    p_check_iface.add_argument("--module-root")
    p_check_iface.add_argument("--package-interface", required=True)
    p_check_iface.add_argument("--package-name")
    p_check_iface.add_argument("--package-version")

    p_pubdiff = sub.add_parser("pubdiff")
    p_pubdiff.add_argument("old_manifest")
    p_pubdiff.add_argument("new_manifest")
    p_pubdiff.add_argument("--out")
    p_pubdiff.add_argument("--fail-on-incompatible", action="store_true")

    p_pubdigest = sub.add_parser("pubdigest")
    p_pubdigest.add_argument("manifest", help="publication manifest to digest")
    p_pubdigest.add_argument("--out", help="write digest record to file (default: stdout)")
    p_pubdigest.add_argument("--verify", metavar="DIGEST_FILE",
                             help="verify manifest against an existing digest record")

    args = parser.parse_args(argv)
    if args.command == 'pubdiff':
        try:
            return run_publication_diff(args)
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            print(f'publication diff error: {exc}', file=sys.stderr)
            return 1
    if args.command == 'pubdigest':
        try:
            return run_publication_digest(args)
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            print(f'publication digest error: {exc}', file=sys.stderr)
            return 1
    if args.command == 'emit-package-interface':
        try:
            return run_emit_package_interface(args)
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            print(f'package interface error: {exc}', file=sys.stderr)
            return 1
    if args.command == 'check-package-interface-sync':
        try:
            return run_check_package_interface_sync(args)
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            print(f'package interface error: {exc}', file=sys.stderr)
            return 1

    text = Path(args.file).read_text(encoding="utf-8")

    try:
        if args.command == "lex":
            for token in lex(text):
                print(token.short())
            return 0

        module = parse_module(text)
    except (LexError, ParseError) as exc:
        print(f"parse error: {exc}", file=sys.stderr)
        return 1

    if args.command == "parse":
        print(json.dumps(dataclass_to_jsonable(module), indent=2))
        return 0

    imported_signatures = {}
    import_stubs = {}
    dependency_modules: set[str] = set()
    try:
        if hasattr(args, 'import_ownership') or hasattr(args, 'dependency_manifest'):
            bundles, dependency_modules = load_signature_inputs(
                getattr(args, 'import_ownership', []),
                getattr(args, 'dependency_manifest', []),
                getattr(args, 'dependency_lock', None),
            )
            imported_signatures = merge_signature_bundles(bundles)
    except ValueError as exc:
        print(f"import error: {exc}", file=sys.stderr)
        return 1
    if args.command == 'conform':
        return run_conformance(args)
    # Workspace discovery: build ownership signatures from the module graph.
    # Explicit --module-root → strict mode (E_MODULE_MISSING is an error).
    # No --module-root       → auto mode  (file's parent as root;
    #                          E_MODULE_MISSING downgraded to warning so that
    #                          genuine external deps don't block the check).
    # --no-workspace-discovery → skip entirely.
    _no_discovery = getattr(args, 'no_workspace_discovery', False)
    _explicit_root = getattr(args, 'module_root', None)
    if not _no_discovery:
        if _explicit_root:
            imported_signatures, module_graph = collect_workspace_ownership_signatures(
                args.file, module_root=_explicit_root,
                external_signatures=imported_signatures,
                dependency_modules=dependency_modules,
            )
            for issue in module_graph.issues:
                if issue.level == 'error':
                    print(f"module error: {issue.message}", file=sys.stderr)
            if any(issue.level == 'error' for issue in module_graph.issues):
                return 1
        else:
            _auto_sigs, _auto_graph = auto_discover_workspace_signatures(
                args.file,
                external_signatures=imported_signatures,
                dependency_modules=dependency_modules,
            )
            if _auto_graph is not None:
                imported_signatures = _auto_sigs
                for issue in _auto_graph.issues:
                    if issue.level == 'error':
                        print(f"module error: {issue.message}", file=sys.stderr)
                if any(issue.level == 'error' for issue in _auto_graph.issues):
                    return 1
    if hasattr(args, 'import_stubs') and args.import_stubs:
        for path in args.import_stubs:
            import_stubs.update(import_stubs_from_dict(json.loads(Path(path).read_text(encoding='utf-8'))))

    if args.command == "resolve":
        print(json.dumps(dataclass_to_jsonable(resolve_module(module)), indent=2))
        return 0

    if args.command == "elaborate":
        print(json.dumps(dataclass_to_jsonable(elaborate_module(module)), indent=2))
        return 0

    if args.command == "typecheck":
        print(json.dumps(dataclass_to_jsonable(typecheck_module(module, imported_signatures=imported_signatures)), indent=2))
        return 0

    if args.command == "lower":
        print(json.dumps(dataclass_to_jsonable(lower_module(module)), indent=2))
        return 0

    if args.command == "cfg":
        print(json.dumps(dataclass_to_jsonable(build_cfg(module, imported_signatures=imported_signatures)), indent=2))
        return 0

    if args.command == "owncheck":
        result = analyze_ownership(module, imported_signatures=imported_signatures)
        print(json.dumps(dataclass_to_jsonable(result), indent=2))
        return 1 if any(issue.level == "error" for issue in result.issues) else 0

    if args.command == "ownsig":
        print(json.dumps(dataclass_to_jsonable(export_ownership_signatures(module, imported_signatures=imported_signatures)), indent=2))
        return 0

    if args.command == "format":
        formatted = format_module(module)
        if args.check:
            return 0 if text == formatted else 1
        if args.in_place:
            Path(args.file).write_text(formatted, encoding="utf-8")
            return 0
        sys.stdout.write(formatted)
        return 0

    if args.command == "check":
        issues = check_module(module, imported_signatures=imported_signatures)
        for issue in issues:
            code_suffix = f" [{issue.code}]" if issue.code else ""
            print(f"{issue.level}: {issue.message}{code_suffix}")
        return 1 if any(issue.level == "error" for issue in issues) else 0

    if args.command == "interpret":
        issues = check_module(module, imported_signatures=imported_signatures)
        for issue in issues:
            code_suffix = f" [{issue.code}]" if issue.code else ""
            print(f"{issue.level}: {issue.message}{code_suffix}", file=sys.stderr)
        if any(issue.level == "error" for issue in issues):
            return 1
        try:
            from .interpreter import Interpreter
            interpreter = Interpreter(module, imported_signatures=imported_signatures, import_stubs=import_stubs)
            value = interpreter.interpret(entry=args.entry)
        except TrapError as exc:
            print(f"trap: {exc.reason}", file=sys.stderr)
            return 1
        except InterpreterUnsupportedError as exc:
            print(f"interpret unsupported: {exc}", file=sys.stderr)
            return 1
        print(interpreter.render_value(value))
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
