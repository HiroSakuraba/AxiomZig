from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import re
from pathlib import Path

from . import ast
from .ownership import analyze_ownership, export_ownership_signatures
from .ownership_signatures import (
    FunctionOwnershipSignature,
    OwnershipSignatureBundle,
    merge_signature_bundles,
    normalize_imported_function_contract,
    signature_bundle_to_jsonable,
    validate_dependency_lock_dict,
)
from .parser import parse_module
from .formatter import format_type


@dataclass(slots=True)
class ModuleGraphIssue:
    level: str
    message: str
    context: str | None = None
    code: str | None = None


@dataclass(slots=True)
class LoadedModule:
    module_path: str
    file_path: str
    module: ast.Module
    imports: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ModuleGraph:
    root: str
    entry_module: str
    modules: dict[str, LoadedModule]
    order: list[str]
    issues: list[ModuleGraphIssue]
    dependency_modules: set[str] = field(default_factory=set)


@dataclass(slots=True, frozen=True)
class PackageInterfaceSpec:
    package_name: str | None
    package_version: str | None
    public_modules: tuple[str, ...]
    public_functions: dict[str, tuple[str, ...]]
    compatibility: dict[str, object] | None = None
    public_function_metadata: dict[str, dict[str, dict[str, object]]] = field(default_factory=dict)
    public_resources: dict[str, tuple[str, ...]] = field(default_factory=dict)
    public_resource_metadata: dict[str, dict[str, dict[str, object]]] = field(default_factory=dict)
    public_protocols: dict[str, tuple[str, ...]] = field(default_factory=dict)
    public_protocol_metadata: dict[str, dict[str, dict[str, object]]] = field(default_factory=dict)
    public_resource_shapes: dict[str, dict[str, dict[str, object]]] = field(default_factory=dict)
    public_protocol_shapes: dict[str, dict[str, dict[str, object]]] = field(default_factory=dict)


def normalize_dotted_name(name: str) -> str:
    text = str(name).replace('\\', '/').strip()
    parts = [part for part in text.replace('/', '.').split('.') if part]
    return '.'.join(parts)


def module_name(module: ast.Module) -> str:
    return normalize_dotted_name('.'.join(module.path))


def import_name(imp: ast.ImportDecl) -> str:
    return normalize_dotted_name('.'.join(imp.path))


def module_path_candidates(root: Path, dotted: str) -> list[Path]:
    normalized = normalize_dotted_name(dotted)
    rel = Path(*normalized.split('.'))
    return [
        (root / rel).with_suffix('.az'),
        (root / rel).with_suffix('.axz'),
        root / rel / 'mod.az',
        root / rel / 'module.az',
    ]


def find_module_files(root: Path, dotted: str) -> list[Path]:
    seen: set[Path] = set()
    matches: list[Path] = []
    for candidate in module_path_candidates(root, dotted):
        resolved = candidate.resolve()
        if resolved.is_file() and resolved not in seen:
            seen.add(resolved)
            matches.append(resolved)
    return matches


def _display_path(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def _import_has_external_contract(
    dotted: str,
    external_signatures: dict[str, FunctionOwnershipSignature] | None,
) -> bool:
    normalized = normalize_dotted_name(dotted)
    for name in (external_signatures or {}):
        exact = normalize_dotted_name(name)
        if exact == normalized or exact.startswith(normalized + '.'):
            return True
    return False


def _is_workspace_internal_import(dotted: str, *, entry_module: str) -> bool:
    normalized = normalize_dotted_name(dotted)
    entry = normalize_dotted_name(entry_module)
    if not normalized or not entry:
        return False
    return normalized.split('.', 1)[0] == entry.split('.', 1)[0]


def _signatures_equivalent(left: FunctionOwnershipSignature, right: FunctionOwnershipSignature) -> bool:
    try:
        return normalize_imported_function_contract(left) == normalize_imported_function_contract(right)
    except Exception:
        return left == right


def load_module_graph(
    entry_file: str | Path,
    *,
    module_root: str | Path | None = None,
    external_signatures: dict[str, FunctionOwnershipSignature] | None = None,
    dependency_modules: set[str] | None = None,
) -> ModuleGraph:
    entry_path = Path(entry_file).resolve()
    root = Path(module_root).resolve() if module_root is not None else entry_path.parent.resolve()
    issues: list[ModuleGraphIssue] = []
    modules: dict[str, LoadedModule] = {}
    visiting: list[str] = []
    visited: set[str] = set()
    order: list[str] = []
    declared_files: dict[str, str] = {}

    def load_file(path: Path, expected: str | None = None) -> ast.Module | None:
        try:
            module = parse_module(path.read_text(encoding='utf-8'))
        except Exception as exc:
            issues.append(ModuleGraphIssue('error', f'could not parse module {path}: {exc}', str(path), 'E_MODULE_PARSE'))
            return None
        actual = module_name(module)
        if expected is not None and actual != normalize_dotted_name(expected):
            issues.append(ModuleGraphIssue('error', f'module path mismatch: import {normalize_dotted_name(expected)} resolved to file declaring {actual}', _display_path(path, root), 'E_MODULE_PATH'))
        prior = declared_files.get(actual)
        current = str(path.resolve())
        if prior is not None and prior != current:
            issues.append(ModuleGraphIssue('error', f'duplicate module name {actual} declared by {_display_path(Path(prior), root)} and {_display_path(path, root)}', actual, 'E_MODULE_DUPLICATE'))
            return None
        declared_files[actual] = current
        return module

    entry_module_ast = load_file(entry_path)
    entry_name = module_name(entry_module_ast) if entry_module_ast is not None else '<entry>'

    def visit(name: str, module: ast.Module | None = None, path: Path | None = None) -> None:
        normalized_name = normalize_dotted_name(name)
        if normalized_name in visited:
            return
        if normalized_name in visiting:
            start = visiting.index(normalized_name)
            cycle = ' -> '.join(visiting[start:] + [normalized_name])
            issues.append(ModuleGraphIssue('error', f'import cycle detected: {cycle}', normalized_name, 'E_MODULE_CYCLE'))
            return
        if module is None:
            matches = find_module_files(root, normalized_name)
            if len(matches) > 1:
                rendered = ', '.join(_display_path(match, root) for match in matches)
                issues.append(ModuleGraphIssue('error', f'import {normalized_name} resolves to multiple module files: {rendered}', normalized_name, 'E_MODULE_DUPLICATE_CANDIDATE'))
                return
            if not matches:
                if normalized_name in (dependency_modules or set()):
                    return
                if _is_workspace_internal_import(normalized_name, entry_module=entry_name) and not _import_has_external_contract(normalized_name, external_signatures):
                    issues.append(ModuleGraphIssue('error', f'import {normalized_name} is missing from module root {_display_path(root, root)}', normalized_name, 'E_MODULE_MISSING'))
                else:
                    issues.append(ModuleGraphIssue('warning', f'import {normalized_name} is unresolved in module root; treating as opaque external import', normalized_name, 'W_MODULE_OPAQUE'))
                return
            path = matches[0]
            module = load_file(path, expected=normalized_name)
            if module is None:
                return
        actual = module_name(module)
        if actual in modules:
            visited.add(actual)
            return
        visiting.append(actual)
        imports = [import_name(imp) for imp in module.imports]
        modules[actual] = LoadedModule(module_path=actual, file_path=str((path or entry_path).resolve()), module=module, imports=imports)
        for dep in imports:
            visit(dep)
        visiting.pop()
        visited.add(actual)
        order.append(actual)

    if entry_module_ast is not None:
        visit(entry_name, entry_module_ast, entry_path)
    return ModuleGraph(root=str(root), entry_module=entry_name, modules=modules, order=order, issues=issues, dependency_modules=set(dependency_modules or set()))


def reachable_internal_modules(graph: ModuleGraph, entry_module_name: str | None = None) -> list[str]:
    reachable = list(graph.order)
    if entry_module_name is not None and entry_module_name in graph.modules and entry_module_name not in reachable:
        reachable.append(entry_module_name)
    return sorted(set(reachable))


def workspace_internal_edges(graph: ModuleGraph, reachable: list[str]) -> list[dict[str, str]]:
    reachable_set = set(reachable)
    edges: list[dict[str, str]] = []
    for module_name in sorted(reachable):
        loaded = graph.modules[module_name]
        for dep in sorted(set(loaded.imports)):
            if dep in reachable_set:
                edges.append({'from': module_name, 'to': dep})
    return edges


def workspace_dependency_imports(
    graph: ModuleGraph,
    reachable: list[str],
) -> list[dict[str, object]]:
    reachable_set = set(reachable)
    dependency_modules = set(graph.dependency_modules)
    by_name: dict[str, set[str]] = {}
    for module_name in sorted(reachable):
        loaded = graph.modules[module_name]
        for dep in loaded.imports:
            if dep not in reachable_set and dep in dependency_modules:
                by_name.setdefault(dep, set()).add(module_name)
    return [
        {
            'name': dep,
            'kind': 'dependency_manifest',
            'imported_by': sorted(by_name[dep]),
        }
        for dep in sorted(by_name)
    ]


def workspace_external_imports(
    graph: ModuleGraph,
    reachable: list[str],
    *,
    external_signatures: dict[str, FunctionOwnershipSignature] | None = None,
) -> list[dict[str, object]]:
    reachable_set = set(reachable)
    by_name: dict[str, set[str]] = {}
    dependency_modules = set(graph.dependency_modules)
    for module_name in sorted(reachable):
        loaded = graph.modules[module_name]
        for dep in loaded.imports:
            if dep not in reachable_set and dep not in dependency_modules:
                by_name.setdefault(dep, set()).add(module_name)
    opaque_contexts = {issue.context for issue in graph.issues if issue.code == 'W_MODULE_OPAQUE' and issue.context}
    externals: list[dict[str, object]] = []
    for dep in sorted(by_name):
        externals.append(
            {
                'name': dep,
                'kind': 'opaque_external' if dep in opaque_contexts else 'external_contract',
                'has_contract': _import_has_external_contract(dep, external_signatures),
                'imported_by': sorted(by_name[dep]),
            }
        )
    return externals


def _parse_numeric_version(version: str) -> tuple[int, ...] | None:
    text = str(version).strip()
    if not text or not re.fullmatch(r"\d+(?:\.\d+)*", text):
        return None
    return tuple(int(part) for part in text.split('.'))


def _pad_version(version: tuple[int, ...], width: int = 3) -> tuple[int, ...]:
    if len(version) >= width:
        return version
    return version + (0,) * (width - len(version))


def _compare_versions(left: tuple[int, ...], right: tuple[int, ...]) -> int:
    width = max(len(left), len(right), 3)
    a = _pad_version(left, width)
    b = _pad_version(right, width)
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


def _caret_upper_bound(version: tuple[int, ...]) -> tuple[int, ...]:
    base = _pad_version(version, 3)
    major, minor, patch = base[:3]
    if major > 0:
        return (major + 1, 0, 0)
    if minor > 0:
        return (0, minor + 1, 0)
    return (0, 0, patch + 1)


def _tilde_upper_bound(version: tuple[int, ...]) -> tuple[int, ...]:
    base = _pad_version(version, 3)
    major, minor, _patch = base[:3]
    return (major, minor + 1, 0)


def _version_comparator_matches(version_text: str, clause: str) -> bool:
    version = _parse_numeric_version(version_text)
    item = clause.strip()
    if not item or item == '*':
        return True
    for prefix in ('^', '~', '>=', '<=', '>', '<', '='):
        if item.startswith(prefix):
            target_text = item[len(prefix):].strip()
            target = _parse_numeric_version(target_text)
            if target is None:
                raise ValueError(f'unsupported dependency version range {item!r}')
            if version is None:
                return False
            if prefix == '^':
                return _compare_versions(version, target) >= 0 and _compare_versions(version, _caret_upper_bound(target)) < 0
            if prefix == '~':
                return _compare_versions(version, target) >= 0 and _compare_versions(version, _tilde_upper_bound(target)) < 0
            cmp = _compare_versions(version, target)
            return {
                '>=': cmp >= 0,
                '<=': cmp <= 0,
                '>': cmp > 0,
                '<': cmp < 0,
                '=': cmp == 0,
            }[prefix]
    target = _parse_numeric_version(item)
    if target is not None:
        if version is None:
            return False
        return _compare_versions(version, target) == 0
    return version_text.strip() == item


def dependency_version_satisfies_range(version_text: str, range_text: str) -> bool:
    text = str(range_text).strip()
    if not text:
        raise ValueError('dependency version range must be a non-empty string')
    clauses = [clause.strip() for clause in text.split(',') if clause.strip()]
    if not clauses:
        raise ValueError('dependency version range must contain at least one clause')
    return all(_version_comparator_matches(version_text, clause) for clause in clauses)


def check_package_interface_compatibility(
    package_interface: PackageInterfaceSpec | None,
    *,
    dependency_lock: dict | None = None,
    dependency_publication_closure: list[dict[str, object]] | None = None,
) -> list[ModuleGraphIssue]:
    if package_interface is None or package_interface.compatibility is None:
        return []
    dependency_ranges = package_interface.compatibility.get('dependency_version_ranges')
    if not isinstance(dependency_ranges, dict) or not dependency_ranges:
        return []
    if dependency_lock is None and not dependency_publication_closure:
        return []
    lock_entries = validate_dependency_lock_dict(dependency_lock) if dependency_lock is not None else {}
    by_package_name: dict[str, list[dict[str, object]]] = {}
    for entry in lock_entries.values():
        by_package_name.setdefault(str(entry['package_name']), []).append(entry)
    for raw in dependency_publication_closure or []:
        if not isinstance(raw, dict):
            continue
        package_name = str(raw.get('package_name', '')).strip()
        package_version = str(raw.get('package_version', '')).strip()
        package_id = str(raw.get('package_id', '')).strip()
        if not package_name or not package_version or not package_id:
            continue
        entry = {
            'package_name': package_name,
            'package_version': package_version,
            'package_id': package_id,
            'manifest_hash': str(raw.get('manifest_hash', '')).strip(),
            'modules': list(raw.get('modules', []) or []),
        }
        existing_ids = {str(item.get('package_id')) for item in by_package_name.get(package_name, [])}
        if package_id not in existing_ids:
            by_package_name.setdefault(package_name, []).append(entry)
    issues: list[ModuleGraphIssue] = []
    for package_name, version_range in sorted(dependency_ranges.items()):
        pinned = sorted(by_package_name.get(str(package_name), []), key=lambda item: str(item['package_id']))
        if not pinned:
            issues.append(
                ModuleGraphIssue(
                    'error',
                    f'package interface compatibility requires dependency {package_name} in range {version_range}, but no pinned dependency with that package name was provided',
                    str(package_name),
                    'E_DEP_VERSION_RANGE_MISSING',
                )
            )
            continue
        if len(pinned) > 1:
            issues.append(
                ModuleGraphIssue(
                    'error',
                    f'package interface compatibility for dependency {package_name} is ambiguous across pinned packages {[item["package_id"] for item in pinned]!r}',
                    str(package_name),
                    'E_DEP_VERSION_RANGE_AMBIGUOUS',
                )
            )
            continue
        entry = pinned[0]
        try:
            matches = dependency_version_satisfies_range(str(entry['package_version']), str(version_range))
        except ValueError as exc:
            issues.append(
                ModuleGraphIssue(
                    'error',
                    f'package interface compatibility for dependency {package_name} uses invalid range {version_range!r}: {exc}',
                    str(package_name),
                    'E_DEP_VERSION_RANGE_INVALID',
                )
            )
            continue
        if not matches:
            issues.append(
                ModuleGraphIssue(
                    'error',
                    f'package interface compatibility requires dependency {package_name} version {version_range}, but pinned dependency {entry["package_id"]} does not satisfy it',
                    str(package_name),
                    'E_DEP_VERSION_RANGE_MISMATCH',
                )
            )
    return issues


def _normalize_public_decl_name(module_name: str, decl_name: str, decl_kind: str) -> str:
    raw = str(decl_name).strip()
    if not raw:
        raise ValueError(f'package interface for {module_name} contains an empty {decl_kind} name')
    normalized_module = normalize_dotted_name(module_name)
    normalized_decl = normalize_dotted_name(raw)
    if '.' not in normalized_decl:
        return f'{normalized_module}.{normalized_decl}'
    return normalized_decl


def _normalize_public_function_name(module_name: str, function_name: str) -> str:
    return _normalize_public_decl_name(module_name, function_name, 'function')


def _normalize_public_resource_name(module_name: str, resource_name: str) -> str:
    return _normalize_public_decl_name(module_name, resource_name, 'resource')


def _normalize_public_protocol_name(module_name: str, protocol_name: str) -> str:
    return _normalize_public_decl_name(module_name, protocol_name, 'protocol')


def _normalize_package_compatibility(raw: object) -> dict[str, object] | None:
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise ValueError('package interface compatibility must be an object')
    normalized: dict[str, object] = {}
    language_version = str(raw.get('language_version', '')).strip()
    if language_version:
        normalized['language_version'] = language_version
    dependency_ranges = raw.get('dependency_version_ranges')
    if dependency_ranges is not None:
        if not isinstance(dependency_ranges, dict):
            raise ValueError('package interface compatibility dependency_version_ranges must be an object')
        rendered: dict[str, str] = {}
        for key, value in sorted(dependency_ranges.items()):
            package_name = normalize_dotted_name(str(key))
            version_range = str(value).strip()
            if not package_name or not version_range:
                raise ValueError('package interface compatibility dependency_version_ranges must map non-empty package names to non-empty ranges')
            try:
                dependency_version_satisfies_range('0.0.0', version_range)
            except ValueError as exc:
                raise ValueError(f'package interface compatibility dependency_version_ranges for {package_name} is invalid: {exc}') from exc
            rendered[package_name] = version_range
        normalized['dependency_version_ranges'] = rendered
    return normalized or None


def _normalize_public_decl_map(
    public_modules: tuple[str, ...],
    raw_items: object,
    *,
    field_name: str,
    decl_kind: str,
    normalizer,
) -> dict[str, tuple[str, ...]]:
    if raw_items is None:
        return {}
    if not isinstance(raw_items, dict):
        raise ValueError(f'package interface {field_name} must be an object mapping module names to {decl_kind} name lists')
    public_module_set = set(public_modules)
    normalized: dict[str, tuple[str, ...]] = {}
    for raw_module_name, items in raw_items.items():
        module_name = normalize_dotted_name(str(raw_module_name))
        if module_name not in public_module_set:
            raise ValueError(f'package interface {field_name} references non-public module {module_name}')
        if not isinstance(items, list):
            raise ValueError(f'package interface {field_name} for {module_name} must be a list')
        normalized[module_name] = tuple(sorted({normalizer(module_name, str(item)) for item in items}))
    return normalized


def _normalize_public_decl_metadata(
    public_modules: tuple[str, ...],
    raw_decls: dict[str, tuple[str, ...]],
    raw_metadata: object,
    *,
    field_name: str,
    decl_kind: str,
    normalizer,
    require_known_decl: bool,
) -> dict[str, dict[str, dict[str, object]]]:
    if raw_metadata is None:
        return {}
    if not isinstance(raw_metadata, dict):
        raise ValueError(f'package interface {field_name} must be an object')
    normalized: dict[str, dict[str, dict[str, object]]] = {}
    public_module_set = set(public_modules)
    known_decls = {module_name: set(items) for module_name, items in raw_decls.items()}
    allowed_stability = {'stable', 'experimental', 'deprecated'}
    for raw_module_name, raw_items in raw_metadata.items():
        module_name = normalize_dotted_name(str(raw_module_name))
        if module_name not in public_module_set:
            raise ValueError(f'package interface {field_name} references non-public module {module_name}')
        if not isinstance(raw_items, dict) or not raw_items:
            raise ValueError(f'package interface {field_name} for {module_name} must be a non-empty object')
        module_meta: dict[str, dict[str, object]] = {}
        for raw_decl_name, raw_meta in sorted(raw_items.items()):
            decl_name = normalizer(module_name, str(raw_decl_name))
            if require_known_decl and decl_name not in known_decls.get(module_name, set()):
                raise ValueError(f'package interface metadata for {module_name} references non-public {decl_kind} {decl_name}')
            if not require_known_decl and module_name in known_decls and known_decls[module_name] and decl_name not in known_decls[module_name]:
                raise ValueError(f'package interface metadata for {module_name} references non-public {decl_kind} {decl_name}')
            if not isinstance(raw_meta, dict):
                raise ValueError(f'package interface metadata for {decl_name} must be an object')
            stability = str(raw_meta.get('stability', 'stable')).strip() or 'stable'
            if stability not in allowed_stability:
                raise ValueError(f'package interface metadata for {decl_name} uses unsupported stability {stability!r}')
            meta: dict[str, object] = {'stability': stability}
            since = str(raw_meta.get('since', '')).strip()
            if since:
                meta['since'] = since
            if stability == 'deprecated':
                reason = str(raw_meta.get('deprecated_reason', '')).strip()
                replacement = str(raw_meta.get('replacement', '')).strip()
                if not reason:
                    raise ValueError(f'package interface metadata for {decl_name} must include deprecated_reason when stability is deprecated')
                meta['deprecated_reason'] = reason
                if replacement:
                    meta['replacement'] = normalizer(module_name, replacement)
            else:
                if raw_meta.get('deprecated_reason') or raw_meta.get('replacement'):
                    raise ValueError(f'package interface metadata for {decl_name} may only include deprecated_reason/replacement when stability is deprecated')
            module_meta[decl_name] = meta
        normalized[module_name] = module_meta
    return normalized


def _normalize_public_function_metadata(
    public_modules: tuple[str, ...],
    raw_functions: dict[str, tuple[str, ...]],
    raw_metadata: object,
) -> dict[str, dict[str, dict[str, object]]]:
    return _normalize_public_decl_metadata(
        public_modules,
        raw_functions,
        raw_metadata,
        field_name='public_function_metadata',
        decl_kind='function',
        normalizer=_normalize_public_function_name,
        require_known_decl=False,
    )


def _normalize_public_resource_metadata(
    public_modules: tuple[str, ...],
    raw_resources: dict[str, tuple[str, ...]],
    raw_metadata: object,
) -> dict[str, dict[str, dict[str, object]]]:
    return _normalize_public_decl_metadata(
        public_modules,
        raw_resources,
        raw_metadata,
        field_name='public_resource_metadata',
        decl_kind='resource',
        normalizer=_normalize_public_resource_name,
        require_known_decl=True,
    )


def _normalize_public_protocol_metadata(
    public_modules: tuple[str, ...],
    raw_protocols: dict[str, tuple[str, ...]],
    raw_metadata: object,
) -> dict[str, dict[str, dict[str, object]]]:
    return _normalize_public_decl_metadata(
        public_modules,
        raw_protocols,
        raw_metadata,
        field_name='public_protocol_metadata',
        decl_kind='protocol',
        normalizer=_normalize_public_protocol_name,
        require_known_decl=True,
    )



def _normalize_field_shape(raw_field: object, *, context: str) -> dict[str, str]:
    if not isinstance(raw_field, dict):
        raise ValueError(f'package interface {context} field entries must be objects')
    name = str(raw_field.get('name', '')).strip()
    typ = str(raw_field.get('type', '')).strip()
    if not name or not typ:
        raise ValueError(f'package interface {context} field entries require non-empty name and type')
    return {'name': name, 'type': typ}


def _normalize_public_resource_shapes(
    public_modules: tuple[str, ...],
    raw_resources: dict[str, tuple[str, ...]],
    raw_shapes: object,
) -> dict[str, dict[str, dict[str, object]]]:
    if raw_shapes is None:
        return {}
    if not isinstance(raw_shapes, dict):
        raise ValueError('package interface public_resource_shapes must be an object')
    public_module_set = set(public_modules)
    known = {module_name: set(items) for module_name, items in raw_resources.items()}
    normalized: dict[str, dict[str, dict[str, object]]] = {}
    for raw_module_name, raw_items in raw_shapes.items():
        module_name = normalize_dotted_name(str(raw_module_name))
        if module_name not in public_module_set:
            raise ValueError(f'package interface public_resource_shapes references non-public module {module_name}')
        if not isinstance(raw_items, dict) or not raw_items:
            raise ValueError(f'package interface public_resource_shapes for {module_name} must be a non-empty object')
        module_shapes: dict[str, dict[str, object]] = {}
        for raw_name, raw_shape in sorted(raw_items.items()):
            name = _normalize_public_resource_name(module_name, str(raw_name))
            if name not in known.get(module_name, set()):
                raise ValueError(f'package interface shape for {module_name} references non-public resource {name}')
            if not isinstance(raw_shape, dict):
                raise ValueError(f'package interface shape for resource {name} must be an object')
            shape: dict[str, object] = {}
            protocol = str(raw_shape.get('protocol', '')).strip()
            if protocol:
                shape['protocol'] = _normalize_public_protocol_name(module_name, protocol)
            raw_fields = raw_shape.get('fields', [])
            if not isinstance(raw_fields, list):
                raise ValueError(f'package interface shape for resource {name} fields must be a list')
            fields = [_normalize_field_shape(field, context=f'public_resource_shapes.{name}') for field in raw_fields]
            seen_fields: set[str] = set()
            for field in fields:
                field_name = field['name']
                if field_name in seen_fields:
                    raise ValueError(f'package interface shape for resource {name} has duplicate field {field_name!r}')
                seen_fields.add(field_name)
            shape['fields'] = fields
            module_shapes[name] = shape
        normalized[module_name] = module_shapes
    return normalized


def _normalize_transition_shape(raw_transition: object, *, context: str) -> dict[str, str]:
    if not isinstance(raw_transition, dict):
        raise ValueError(f'package interface {context} transition entries must be objects')
    name = str(raw_transition.get('name', '')).strip()
    source = str(raw_transition.get('source', '')).strip()
    target = str(raw_transition.get('target', '')).strip()
    if not name or not source or not target:
        raise ValueError(f'package interface {context} transition entries require non-empty name, source, and target')
    return {'name': name, 'source': source, 'target': target}


def _normalize_public_protocol_shapes(
    public_modules: tuple[str, ...],
    raw_protocols: dict[str, tuple[str, ...]],
    raw_shapes: object,
) -> dict[str, dict[str, dict[str, object]]]:
    if raw_shapes is None:
        return {}
    if not isinstance(raw_shapes, dict):
        raise ValueError('package interface public_protocol_shapes must be an object')
    public_module_set = set(public_modules)
    known = {module_name: set(items) for module_name, items in raw_protocols.items()}
    normalized: dict[str, dict[str, dict[str, object]]] = {}
    for raw_module_name, raw_items in raw_shapes.items():
        module_name = normalize_dotted_name(str(raw_module_name))
        if module_name not in public_module_set:
            raise ValueError(f'package interface public_protocol_shapes references non-public module {module_name}')
        if not isinstance(raw_items, dict) or not raw_items:
            raise ValueError(f'package interface public_protocol_shapes for {module_name} must be a non-empty object')
        module_shapes: dict[str, dict[str, object]] = {}
        for raw_name, raw_shape in sorted(raw_items.items()):
            name = _normalize_public_protocol_name(module_name, str(raw_name))
            if name not in known.get(module_name, set()):
                raise ValueError(f'package interface shape for {module_name} references non-public protocol {name}')
            if not isinstance(raw_shape, dict):
                raise ValueError(f'package interface shape for protocol {name} must be an object')
            states = [str(item).strip() for item in raw_shape.get('states', [])]
            terminal = [str(item).strip() for item in raw_shape.get('terminal', [])]
            init = str(raw_shape.get('init', '')).strip()
            transitions = [_normalize_transition_shape(item, context=f'public_protocol_shapes.{name}') for item in raw_shape.get('transitions', [])]
            if not states or any(not item for item in states):
                raise ValueError(f'package interface shape for protocol {name} requires non-empty states')
            if len(set(states)) != len(states):
                raise ValueError(f'package interface shape for protocol {name} has duplicate states')
            state_set = set(states)
            if not init or init not in state_set:
                raise ValueError(f'package interface shape for protocol {name} init must name a state')
            if any(not item or item not in state_set for item in terminal):
                raise ValueError(f'package interface shape for protocol {name} terminal states must name states')
            if len(set(terminal)) != len(terminal):
                raise ValueError(f'package interface shape for protocol {name} has duplicate terminal states')
            seen_transitions: set[str] = set()
            for transition in transitions:
                transition_name = transition['name']
                if transition_name in seen_transitions:
                    raise ValueError(f'package interface shape for protocol {name} has duplicate transition {transition_name!r}')
                seen_transitions.add(transition_name)
                if transition['source'] not in state_set or transition['target'] not in state_set:
                    raise ValueError(f'package interface shape for protocol {name} transition {transition_name!r} references unknown state')
            module_shapes[name] = {
                'states': sorted(states),
                'init': init,
                'terminal': sorted(terminal),
                'transitions': sorted(transitions, key=lambda item: item['name']),
            }
        normalized[module_name] = module_shapes
    return normalized


def _render_shape_map(items: dict[str, dict[str, dict[str, object]]]) -> dict[str, dict[str, dict[str, object]]]:
    return {
        module_name: {decl_name: dict(shape) for decl_name, shape in sorted(module_shapes.items())}
        for module_name, module_shapes in sorted(items.items())
        if module_shapes
    }


def _protocol_shape_from_decl(decl: ast.ProtocolDecl) -> dict[str, object]:
    return {
        'states': sorted(decl.states),
        'init': decl.init,
        'terminal': sorted(decl.terminal),
        'transitions': [
            {'name': tr.name, 'source': tr.source, 'target': tr.target}
            for tr in sorted(decl.transitions, key=lambda item: item.name)
        ],
    }


def _resource_shape_from_decl(module_name: str, decl: ast.ResourceDecl) -> dict[str, object]:
    shape: dict[str, object] = {
        'fields': [{'name': field.name, 'type': format_type(field.typ)} for field in decl.fields],
    }
    if decl.protocol:
        shape['protocol'] = _normalize_public_protocol_name(module_name, decl.protocol)
    return shape

def package_interface_from_dict(data: dict | None) -> PackageInterfaceSpec | None:
    if data is None:
        return None
    if not isinstance(data, dict):
        raise ValueError('package interface must be a JSON object')
    schema = str(data.get('schema_version', '')).strip()
    if schema != 'axiomzig.package_interface.v1':
        raise ValueError("package interface must use schema_version='axiomzig.package_interface.v1'")
    package_name = str(data.get('package_name', '')).strip() or None
    package_version = str(data.get('package_version', '')).strip() or None
    raw_modules = data.get('public_modules')
    if not isinstance(raw_modules, list) or not raw_modules:
        raise ValueError('package interface must define non-empty public_modules list')
    public_modules = tuple(sorted({normalize_dotted_name(str(item)) for item in raw_modules if str(item).strip()}))
    if not public_modules:
        raise ValueError('package interface must define at least one public module')
    normalized_functions = _normalize_public_decl_map(
        public_modules,
        data.get('public_functions', {}),
        field_name='public_functions',
        decl_kind='function',
        normalizer=_normalize_public_function_name,
    )
    normalized_resources = _normalize_public_decl_map(
        public_modules,
        data.get('public_resources', {}),
        field_name='public_resources',
        decl_kind='resource',
        normalizer=_normalize_public_resource_name,
    )
    normalized_protocols = _normalize_public_decl_map(
        public_modules,
        data.get('public_protocols', {}),
        field_name='public_protocols',
        decl_kind='protocol',
        normalizer=_normalize_public_protocol_name,
    )
    compatibility = _normalize_package_compatibility(data.get('compatibility'))
    public_function_metadata = _normalize_public_function_metadata(
        public_modules,
        normalized_functions,
        data.get('public_function_metadata'),
    )
    public_resource_metadata = _normalize_public_resource_metadata(
        public_modules,
        normalized_resources,
        data.get('public_resource_metadata'),
    )
    public_protocol_metadata = _normalize_public_protocol_metadata(
        public_modules,
        normalized_protocols,
        data.get('public_protocol_metadata'),
    )
    public_resource_shapes = _normalize_public_resource_shapes(
        public_modules,
        normalized_resources,
        data.get('public_resource_shapes'),
    )
    public_protocol_shapes = _normalize_public_protocol_shapes(
        public_modules,
        normalized_protocols,
        data.get('public_protocol_shapes'),
    )
    return PackageInterfaceSpec(
        package_name=package_name,
        package_version=package_version,
        public_modules=public_modules,
        public_functions=normalized_functions,
        compatibility=compatibility,
        public_function_metadata=public_function_metadata,
        public_resources=normalized_resources,
        public_resource_metadata=public_resource_metadata,
        public_protocols=normalized_protocols,
        public_protocol_metadata=public_protocol_metadata,
        public_resource_shapes=public_resource_shapes,
        public_protocol_shapes=public_protocol_shapes,
    )


def _render_decl_map(items: dict[str, tuple[str, ...]]) -> dict[str, list[str]]:
    return {key: list(value) for key, value in sorted(items.items())}


def _render_metadata_map(items: dict[str, dict[str, dict[str, object]]]) -> dict[str, dict[str, dict[str, object]]]:
    return {
        module_name: {decl_name: dict(meta) for decl_name, meta in sorted(module_meta.items())}
        for module_name, module_meta in sorted(items.items())
        if module_meta
    }


def render_package_interface_dict(package_interface: PackageInterfaceSpec) -> dict[str, object]:
    payload: dict[str, object] = {
        'schema_version': 'axiomzig.package_interface.v1',
        'public_modules': list(package_interface.public_modules),
        'public_functions': _render_decl_map(package_interface.public_functions),
    }
    if package_interface.public_resources:
        payload['public_resources'] = _render_decl_map(package_interface.public_resources)
    if package_interface.public_protocols:
        payload['public_protocols'] = _render_decl_map(package_interface.public_protocols)
    if package_interface.package_name:
        payload['package_name'] = package_interface.package_name
    if package_interface.package_version:
        payload['package_version'] = package_interface.package_version
    if package_interface.compatibility is not None:
        payload['compatibility'] = dict(package_interface.compatibility)
    if package_interface.public_function_metadata:
        payload['public_function_metadata'] = _render_metadata_map(package_interface.public_function_metadata)
    if package_interface.public_resource_metadata:
        payload['public_resource_metadata'] = _render_metadata_map(package_interface.public_resource_metadata)
    if package_interface.public_protocol_metadata:
        payload['public_protocol_metadata'] = _render_metadata_map(package_interface.public_protocol_metadata)
    if package_interface.public_resource_shapes:
        payload['public_resource_shapes'] = _render_shape_map(package_interface.public_resource_shapes)
    if package_interface.public_protocol_shapes:
        payload['public_protocol_shapes'] = _render_shape_map(package_interface.public_protocol_shapes)
    return payload


def _source_public_decl_metadata(
    decl,
    *,
    module_name: str,
    fq_name: str,
    decl_kind: str,
    normalizer,
) -> dict[str, object]:
    meta: dict[str, object] = {}
    if decl.stability != 'stable' or decl.since or decl.deprecated_reason or decl.replacement:
        meta['stability'] = decl.stability
    if decl.since:
        meta['since'] = decl.since
    if decl.stability == 'deprecated':
        reason = str(decl.deprecated_reason or '').strip()
        if not reason:
            raise ValueError(f'source deprecated public {decl_kind} {fq_name} must provide a non-empty reason')
        meta['deprecated_reason'] = reason
        replacement = str(decl.replacement or '').strip()
        if replacement:
            meta['replacement'] = normalizer(module_name, replacement)
    elif decl.deprecated_reason or decl.replacement:
        raise ValueError(f'source {decl_kind} {fq_name} may only use deprecated_reason/replacement when deprecated')
    return meta


def source_package_interface_from_graph(
    graph: ModuleGraph,
    *,
    package_name: str | None = None,
    package_version: str | None = None,
    base_interface: PackageInterfaceSpec | None = None,
) -> PackageInterfaceSpec:
    reachable = reachable_internal_modules(graph, graph.entry_module)
    public_modules: set[str] = set()
    public_functions: dict[str, tuple[str, ...]] = {}
    public_function_metadata: dict[str, dict[str, dict[str, object]]] = {}
    public_resources: dict[str, tuple[str, ...]] = {}
    public_resource_metadata: dict[str, dict[str, dict[str, object]]] = {}
    public_protocols: dict[str, tuple[str, ...]] = {}
    public_protocol_metadata: dict[str, dict[str, dict[str, object]]] = {}
    public_resource_shapes: dict[str, dict[str, dict[str, object]]] = {}
    public_protocol_shapes: dict[str, dict[str, dict[str, object]]] = {}

    for module_name in sorted(reachable):
        loaded = graph.modules[module_name]
        exported_functions: list[str] = []
        exported_resources: list[str] = []
        exported_protocols: list[str] = []
        function_meta: dict[str, dict[str, object]] = {}
        resource_meta: dict[str, dict[str, object]] = {}
        protocol_meta: dict[str, dict[str, object]] = {}
        resource_shapes: dict[str, dict[str, object]] = {}
        protocol_shapes: dict[str, dict[str, object]] = {}

        for decl in loaded.module.decls:
            if isinstance(decl, ast.FnDecl):
                decl_kind = 'function'
                normalizer = _normalize_public_function_name
                exported = exported_functions
                metadata = function_meta
            elif isinstance(decl, ast.ResourceDecl):
                decl_kind = 'resource'
                normalizer = _normalize_public_resource_name
                exported = exported_resources
                metadata = resource_meta
            elif isinstance(decl, ast.ProtocolDecl):
                decl_kind = 'protocol'
                normalizer = _normalize_public_protocol_name
                exported = exported_protocols
                metadata = protocol_meta
            else:
                continue

            fq_name = f'{module_name}.{decl.name}'
            has_api_metadata = bool(decl.since or decl.stability != 'stable' or decl.deprecated_reason or decl.replacement)
            if has_api_metadata and not decl.is_public:
                raise ValueError(f'source API metadata on non-public {decl_kind} {fq_name} requires pub')
            if not decl.is_public:
                continue
            normalized_name = normalizer(module_name, decl.name)
            exported.append(normalized_name)
            meta = _source_public_decl_metadata(
                decl,
                module_name=module_name,
                fq_name=normalized_name,
                decl_kind=decl_kind,
                normalizer=normalizer,
            )
            if meta:
                metadata[normalized_name] = meta
            if isinstance(decl, ast.ResourceDecl):
                resource_shapes[normalized_name] = _resource_shape_from_decl(module_name, decl)
            elif isinstance(decl, ast.ProtocolDecl):
                protocol_shapes[normalized_name] = _protocol_shape_from_decl(decl)

        if exported_functions or exported_resources or exported_protocols:
            public_modules.add(module_name)
            public_functions[module_name] = tuple(sorted(exported_functions))
            if exported_resources:
                public_resources[module_name] = tuple(sorted(exported_resources))
            if exported_protocols:
                public_protocols[module_name] = tuple(sorted(exported_protocols))
            if function_meta:
                public_function_metadata[module_name] = {name: dict(meta) for name, meta in sorted(function_meta.items())}
            if resource_meta:
                public_resource_metadata[module_name] = {name: dict(meta) for name, meta in sorted(resource_meta.items())}
            if protocol_meta:
                public_protocol_metadata[module_name] = {name: dict(meta) for name, meta in sorted(protocol_meta.items())}
            if resource_shapes:
                public_resource_shapes[module_name] = {name: dict(shape) for name, shape in sorted(resource_shapes.items())}
            if protocol_shapes:
                public_protocol_shapes[module_name] = {name: dict(shape) for name, shape in sorted(protocol_shapes.items())}

    if not public_modules:
        raise ValueError('source package interface emission requires at least one pub fn/resource/protocol across reachable modules')
    spec = PackageInterfaceSpec(
        package_name=(package_name or (base_interface.package_name if base_interface else None)),
        package_version=(package_version or (base_interface.package_version if base_interface else None)),
        public_modules=tuple(sorted(public_modules)),
        public_functions={key: value for key, value in sorted(public_functions.items())},
        compatibility=(dict(base_interface.compatibility) if base_interface and base_interface.compatibility is not None else None),
        public_function_metadata={
            module_name: {fn_name: dict(meta) for fn_name, meta in sorted(module_meta.items())}
            for module_name, module_meta in sorted(public_function_metadata.items())
        },
        public_resources={key: value for key, value in sorted(public_resources.items())},
        public_resource_metadata={
            module_name: {name: dict(meta) for name, meta in sorted(module_meta.items())}
            for module_name, module_meta in sorted(public_resource_metadata.items())
        },
        public_protocols={key: value for key, value in sorted(public_protocols.items())},
        public_protocol_metadata={
            module_name: {name: dict(meta) for name, meta in sorted(module_meta.items())}
            for module_name, module_meta in sorted(public_protocol_metadata.items())
        },
        public_resource_shapes={
            module_name: {name: dict(shape) for name, shape in sorted(module_shapes.items())}
            for module_name, module_shapes in sorted(public_resource_shapes.items())
        },
        public_protocol_shapes={
            module_name: {name: dict(shape) for name, shape in sorted(module_shapes.items())}
            for module_name, module_shapes in sorted(public_protocol_shapes.items())
        },
    )
    return package_interface_from_dict(render_package_interface_dict(spec))


def emit_package_interface_for_workspace(
    entry_file: str | Path,
    *,
    module_root: str | Path | None = None,
    package_name: str | None = None,
    package_version: str | None = None,
    base_interface_input: dict | None = None,
) -> dict[str, object]:
    graph = load_module_graph(entry_file, module_root=module_root)
    if any(issue.level == 'error' for issue in graph.issues):
        rendered = '; '.join(issue.message for issue in graph.issues if issue.level == 'error')
        raise ValueError(rendered or 'workspace contains module graph errors')
    base_interface = package_interface_from_dict(base_interface_input) if base_interface_input is not None else None
    spec = source_package_interface_from_graph(
        graph,
        package_name=package_name,
        package_version=package_version,
        base_interface=base_interface,
    )
    return render_package_interface_dict(spec)


def _resolve_export_surface(
    graph: ModuleGraph,
    bundles: dict[str, OwnershipSignatureBundle],
    *,
    public_only: bool = False,
    package_interface: PackageInterfaceSpec | None = None,
) -> tuple[
    list[str],
    dict[str, OwnershipSignatureBundle],
    str,
    dict[str, list[str]],
    dict[str, dict[str, dict[str, object]]],
    dict[str, list[str]],
    dict[str, list[str]],
    dict[str, dict[str, dict[str, object]]],
    dict[str, dict[str, dict[str, object]]],
]:
    reachable = reachable_internal_modules(graph, graph.entry_module)
    reachable_set = set(reachable)
    if package_interface is not None:
        exported_modules = list(package_interface.public_modules)
        missing_modules = [name for name in exported_modules if name not in reachable_set]
        if missing_modules:
            raise ValueError(f'package interface exports non-reachable modules: {missing_modules!r}')
        filtered_bundles: dict[str, OwnershipSignatureBundle] = {}
        exported_functions: dict[str, list[str]] = {}
        exported_function_metadata: dict[str, dict[str, dict[str, object]]] = {}
        exported_resources: dict[str, list[str]] = {}
        exported_protocols: dict[str, list[str]] = {}
        exported_resource_shapes: dict[str, dict[str, dict[str, object]]] = {}
        exported_protocol_shapes: dict[str, dict[str, dict[str, object]]] = {}
        for module_name in exported_modules:
            bundle = bundles.get(module_name)
            if bundle is None:
                raise ValueError(f'package interface exports unknown module {module_name}')
            loaded = graph.modules[module_name]

            if module_name in package_interface.public_functions:
                allowed_functions = list(package_interface.public_functions.get(module_name, ()))
                available = {fn.name: fn for fn in bundle.functions}
                missing = [name for name in allowed_functions if name not in available]
                if missing:
                    raise ValueError(f'package interface for {module_name} exports unknown functions: {missing!r}')
                functions = [available[name] for name in allowed_functions]
                exported_functions[module_name] = sorted(allowed_functions)
            else:
                # Legacy package-interface behavior: a public module with no explicit
                # function list exports all functions in that module.  v47.55 source
                # emission writes an explicit [] for resource/protocol-only modules.
                functions = list(bundle.functions)
                exported_functions[module_name] = sorted(fn.name for fn in functions)

            if module_name in package_interface.public_resources:
                allowed_resources = list(package_interface.public_resources.get(module_name, ()))
                available_resources = {
                    _normalize_public_resource_name(module_name, decl.name)
                    for decl in loaded.module.decls
                    if isinstance(decl, ast.ResourceDecl)
                }
                missing = [name for name in allowed_resources if name not in available_resources]
                if missing:
                    raise ValueError(f'package interface for {module_name} exports unknown resources: {missing!r}')
                exported_resources[module_name] = sorted(allowed_resources)
                if module_name in package_interface.public_resource_shapes:
                    exported_resource_shapes[module_name] = {
                        name: dict(package_interface.public_resource_shapes[module_name][name])
                        for name in sorted(package_interface.public_resource_shapes[module_name])
                        if name in set(allowed_resources)
                    }

            if module_name in package_interface.public_protocols:
                allowed_protocols = list(package_interface.public_protocols.get(module_name, ()))
                available_protocols = {
                    _normalize_public_protocol_name(module_name, decl.name)
                    for decl in loaded.module.decls
                    if isinstance(decl, ast.ProtocolDecl)
                }
                missing = [name for name in allowed_protocols if name not in available_protocols]
                if missing:
                    raise ValueError(f'package interface for {module_name} exports unknown protocols: {missing!r}')
                exported_protocols[module_name] = sorted(allowed_protocols)
                if module_name in package_interface.public_protocol_shapes:
                    exported_protocol_shapes[module_name] = {
                        name: dict(package_interface.public_protocol_shapes[module_name][name])
                        for name in sorted(package_interface.public_protocol_shapes[module_name])
                        if name in set(allowed_protocols)
                    }

            module_metadata = dict(package_interface.public_function_metadata.get(module_name, {}))
            if module_metadata:
                if module_name in package_interface.public_functions:
                    allowed = set(package_interface.public_functions.get(module_name, ()))
                    exported_function_metadata[module_name] = {
                        name: dict(module_metadata[name])
                        for name in sorted(module_metadata)
                        if name in allowed
                    }
                else:
                    exported_function_metadata[module_name] = {name: dict(meta) for name, meta in sorted(module_metadata.items())}
            filtered_bundles[module_name] = OwnershipSignatureBundle(module_path=bundle.module_path, functions=functions)
        return exported_modules, filtered_bundles, 'package_interface', exported_functions, exported_function_metadata, exported_resources, exported_protocols, exported_resource_shapes, exported_protocol_shapes
    exported_modules = [graph.entry_module] if public_only and graph.entry_module in reachable_set else list(reachable)
    filtered_bundles = {name: bundles[name] for name in bundles if name in set(exported_modules)}
    exported_functions = {name: sorted(fn.name for fn in filtered_bundles[name].functions) for name in sorted(filtered_bundles)}
    return exported_modules, filtered_bundles, ('public_only' if public_only else 'reachable_full'), exported_functions, {}, {}, {}, {}, {}


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def module_source_digests(graph: ModuleGraph, reachable: list[str]) -> dict[str, str]:
    digests: dict[str, str] = {}
    for module_name in sorted(reachable):
        loaded = graph.modules[module_name]
        source_text = Path(loaded.file_path).read_text(encoding='utf-8')
        digests[module_name] = _sha256_text(source_text)
    return digests


def _default_package_name(graph: ModuleGraph) -> str:
    root_name = Path(graph.root).resolve().name
    return root_name or graph.entry_module.split('.')[0]


def _normalized_package_identity(graph: ModuleGraph, package_name: str | None, package_version: str | None) -> tuple[str, str, str]:
    name = (package_name or _default_package_name(graph)).strip()
    if not name:
        name = graph.entry_module.split('.')[0]
    version = (package_version or '0').strip() or '0'
    return name, version, f'{name}@{version}'


def workspace_manifest_graph(
    graph: ModuleGraph,
    reachable: list[str],
    *,
    source_digests: dict[str, str] | None = None,
) -> dict[str, dict[str, object]]:
    reachable_set = set(reachable)
    dependency_set = set(graph.dependency_modules)
    manifest: dict[str, dict[str, object]] = {}
    for module_name in sorted(reachable):
        loaded = graph.modules[module_name]
        file_path = str(Path(loaded.file_path).resolve())
        manifest[module_name] = {
            'file_path': file_path,
            'source_digest': (source_digests or {}).get(module_name),
            'imports': sorted(set(loaded.imports)),
            'internal_imports': sorted(dep for dep in set(loaded.imports) if dep in reachable_set),
            'dependency_imports': sorted(dep for dep in set(loaded.imports) if dep not in reachable_set and dep in dependency_set),
            'external_imports': sorted(dep for dep in set(loaded.imports) if dep not in reachable_set and dep not in dependency_set),
        }
    return manifest


def cross_module_summary_conflicts(graph: ModuleGraph) -> list[ModuleGraphIssue]:
    return [issue for issue in graph.issues if issue.code == 'E_MODULE_SUMMARY_CONFLICT']


def missing_cross_module_summaries(graph: ModuleGraph) -> list[ModuleGraphIssue]:
    missing_codes = {'E_MODULE_MISSING', 'E_MODULE_PATH', 'E_MODULE_DUPLICATE', 'E_MODULE_DUPLICATE_CANDIDATE', 'E_MODULE_CYCLE'}
    return [issue for issue in graph.issues if issue.code in missing_codes]


def collect_workspace_export_bundles(
    entry_file: str | Path,
    *,
    module_root: str | Path | None = None,
    external_signatures: dict[str, FunctionOwnershipSignature] | None = None,
    dependency_modules: set[str] | None = None,
) -> tuple[dict[str, OwnershipSignatureBundle], dict[str, FunctionOwnershipSignature], ModuleGraph]:
    graph = load_module_graph(entry_file, module_root=module_root, external_signatures=external_signatures, dependency_modules=dependency_modules)
    signatures: dict[str, FunctionOwnershipSignature] = dict(external_signatures or {})
    bundles: dict[str, OwnershipSignatureBundle] = {}
    for name in graph.order:
        loaded = graph.modules[name]
        bundle = export_ownership_signatures(loaded.module, imported_signatures=signatures)
        bundles[name] = bundle
        for fn in bundle.functions:
            prior = signatures.get(fn.name)
            if prior is not None and not _signatures_equivalent(prior, fn):
                graph.issues.append(
                    ModuleGraphIssue(
                        'error',
                        f'ownership summary conflict for {fn.name}: workspace export from {loaded.module_path} disagrees with existing summary',
                        fn.name,
                        'E_MODULE_SUMMARY_CONFLICT',
                    )
                )
                continue
            signatures[fn.name] = fn
    return bundles, signatures, graph


def check_workspace_conformance(
    graph: ModuleGraph,
    signatures: dict[str, FunctionOwnershipSignature],
) -> list[ModuleGraphIssue]:
    issues = list(graph.issues)
    for module_name in reachable_internal_modules(graph, graph.entry_module):
        loaded = graph.modules[module_name]
        summary = analyze_ownership(loaded.module, imported_signatures=signatures)
        for issue in summary.issues:
            if issue.level == 'error':
                issues.append(
                    ModuleGraphIssue(
                        issue.level,
                        f'{module_name}: {issue.message}',
                        issue.context or module_name,
                        issue.code,
                    )
                )
    return issues


def build_workspace_manifest(
    graph: ModuleGraph,
    bundles: dict[str, OwnershipSignatureBundle],
    signatures: dict[str, FunctionOwnershipSignature],
    diagnostics: list[ModuleGraphIssue],
    *,
    public_only: bool = False,
    package_name: str | None = None,
    package_version: str | None = None,
    package_interface: PackageInterfaceSpec | None = None,
    dependency_packages: list[dict[str, object]] | None = None,
    dependency_publication_closure: list[dict[str, object]] | None = None,
    dependency_lock_digest: str | None = None,
    dependency_lock_digest_algorithm: str | None = None,
) -> dict[str, object]:
    reachable = reachable_internal_modules(graph, graph.entry_module)
    (
        exported_modules,
        exported_bundle_map,
        export_scope,
        exported_functions,
        exported_function_metadata,
        exported_resources,
        exported_protocols,
        exported_resource_shapes,
        exported_protocol_shapes,
    ) = _resolve_export_surface(
        graph,
        bundles,
        public_only=public_only,
        package_interface=package_interface,
    )
    source_digests = module_source_digests(graph, reachable)
    interface_package_name = package_interface.package_name if package_interface is not None else None
    interface_package_version = package_interface.package_version if package_interface is not None else None
    if package_name and interface_package_name and package_name.strip() != interface_package_name:
        raise ValueError(
            f'package interface package_name {interface_package_name!r} conflicts with CLI package_name {package_name!r}'
        )
    if package_version and interface_package_version and package_version.strip() != interface_package_version:
        raise ValueError(
            f'package interface package_version {interface_package_version!r} conflicts with CLI package_version {package_version!r}'
        )
    normalized_package_name, normalized_package_version, package_id = _normalized_package_identity(
        graph,
        package_name or interface_package_name,
        package_version or interface_package_version,
    )
    diagnostic_items = [
        {'level': issue.level, 'message': issue.message, 'context': issue.context, 'code': issue.code}
        for issue in sorted(diagnostics, key=lambda item: (item.level, item.code or '', item.context or '', item.message))
    ]
    manifest = {
        'schema_version': 'axiomzig.conformance.v4',
        'status': 'error' if any(issue.level == 'error' for issue in diagnostics) else 'ok',
        'package_name': normalized_package_name,
        'package_version': normalized_package_version,
        'package_id': package_id,
        'workspace_root': graph.root,
        'entry_module': graph.entry_module,
        'export_scope': export_scope,
        'reachable_modules': reachable,
        'exported_modules': exported_modules,
        'exported_functions': exported_functions,
        'source_digest_algorithm': 'sha256',
        'workspace_source_digest': _sha256_text(json.dumps(source_digests, sort_keys=True, separators=(',', ':'))),
        'module_graph': workspace_manifest_graph(graph, reachable, source_digests=source_digests),
        'internal_edges': workspace_internal_edges(graph, reachable),
        'dependency_imports': workspace_dependency_imports(graph, reachable),
        'dependency_modules': sorted(graph.dependency_modules),
        'dependency_packages': list(dependency_packages or []),
        'dependency_publication_closure': list(dependency_publication_closure or []),
        'internal_signatures': {
            name: signature_bundle_to_jsonable(exported_bundle_map[name])
            for name in sorted(exported_bundle_map)
        },
        'external_imports': workspace_external_imports(graph, reachable, external_signatures=signatures),
        'diagnostics': diagnostic_items,
        'manifest_hash_algorithm': 'sha256',
    }
    if package_interface is not None:
        manifest['package_interface'] = render_package_interface_dict(package_interface)
        if exported_resources:
            manifest['exported_resources'] = {key: list(value) for key, value in sorted(exported_resources.items())}
        if exported_protocols:
            manifest['exported_protocols'] = {key: list(value) for key, value in sorted(exported_protocols.items())}
        if exported_resource_shapes:
            manifest['public_resource_shapes'] = _render_shape_map(exported_resource_shapes)
        if exported_protocol_shapes:
            manifest['public_protocol_shapes'] = _render_shape_map(exported_protocol_shapes)
        if package_interface.compatibility is not None:
            manifest['api_compatibility'] = dict(package_interface.compatibility)
        if exported_function_metadata:
            rendered_metadata = _render_metadata_map(exported_function_metadata)
            if rendered_metadata:
                manifest['public_function_metadata'] = rendered_metadata
        if package_interface.public_resource_metadata:
            manifest['public_resource_metadata'] = _render_metadata_map(package_interface.public_resource_metadata)
        if package_interface.public_protocol_metadata:
            manifest['public_protocol_metadata'] = _render_metadata_map(package_interface.public_protocol_metadata)
    if dependency_lock_digest:
        manifest['dependency_lock_digest_algorithm'] = dependency_lock_digest_algorithm or 'sha256'
        manifest['dependency_lock_digest'] = dependency_lock_digest
    hash_payload = {key: value for key, value in manifest.items() if key != 'manifest_hash'}
    manifest['manifest_hash'] = _sha256_text(json.dumps(hash_payload, sort_keys=True, separators=(',', ':')))
    return manifest



def build_publication_manifest(conformance_manifest: dict[str, object]) -> dict[str, object]:
    dependency_packages = list(conformance_manifest.get('dependency_packages', []))
    dependency_publication_closure = list(conformance_manifest.get('dependency_publication_closure', []))
    publication = {
        'schema_version': 'axiomzig.publication_manifest.v1',
        'status': conformance_manifest.get('status'),
        'package_name': conformance_manifest.get('package_name'),
        'package_version': conformance_manifest.get('package_version'),
        'package_id': conformance_manifest.get('package_id'),
        'entry_module': conformance_manifest.get('entry_module'),
        'export_scope': conformance_manifest.get('export_scope'),
        'exported_modules': list(conformance_manifest.get('exported_modules', [])),
        'exported_functions': dict(conformance_manifest.get('exported_functions', {})),
        'exported_resources': dict(conformance_manifest.get('exported_resources', {})),
        'exported_protocols': dict(conformance_manifest.get('exported_protocols', {})),
        'public_resource_shapes': dict(conformance_manifest.get('public_resource_shapes', {})),
        'public_protocol_shapes': dict(conformance_manifest.get('public_protocol_shapes', {})),
        'dependency_packages': dependency_packages,
        'dependency_publication_closure': dependency_publication_closure,
        'dependency_publication_refs': [
            {
                'package_id': item.get('package_id'),
                'package_version': item.get('package_version'),
                'modules': list(item.get('modules', [])),
                'export_scope': item.get('export_scope'),
                'manifest_hash': item.get('manifest_hash') or '',
            }
            for item in dependency_packages
        ],
        'source_digest_algorithm': conformance_manifest.get('source_digest_algorithm'),
        'workspace_source_digest': conformance_manifest.get('workspace_source_digest'),
        'internal_signatures': dict(conformance_manifest.get('internal_signatures', {})),
        'manifest_hash_algorithm': 'sha256',
    }
    if 'package_interface' in conformance_manifest:
        publication['package_interface'] = conformance_manifest['package_interface']
    if 'api_compatibility' in conformance_manifest:
        publication['api_compatibility'] = conformance_manifest['api_compatibility']
    if 'public_function_metadata' in conformance_manifest:
        publication['public_function_metadata'] = conformance_manifest['public_function_metadata']
    if 'public_resource_metadata' in conformance_manifest:
        publication['public_resource_metadata'] = conformance_manifest['public_resource_metadata']
    if 'public_protocol_metadata' in conformance_manifest:
        publication['public_protocol_metadata'] = conformance_manifest['public_protocol_metadata']
    if 'dependency_lock_digest' in conformance_manifest:
        publication['dependency_lock_digest_algorithm'] = conformance_manifest.get('dependency_lock_digest_algorithm', 'sha256')
        publication['dependency_lock_digest'] = conformance_manifest['dependency_lock_digest']
    hash_payload = {key: value for key, value in publication.items() if key != 'manifest_hash'}
    publication['manifest_hash'] = _sha256_text(json.dumps(hash_payload, sort_keys=True, separators=(',', ':')))
    return publication



def auto_discover_workspace_signatures(
    entry_file: str | Path,
    *,
    external_signatures: dict[str, FunctionOwnershipSignature] | None = None,
    dependency_modules: set[str] | None = None,
) -> tuple[dict[str, FunctionOwnershipSignature], ModuleGraph | None]:
    """
    Automatically discover and load workspace-local modules starting from the
    entry file's parent directory, without requiring an explicit module root.

    Unlike collect_workspace_ownership_signatures, this function:
    - Uses the entry file's parent as the implicit module root
    - Treats missing workspace-internal imports as warnings rather than errors
      (the import may be an external dependency not on disk)
    - Returns (external_signatures, None) unchanged if no additional workspace
      modules were discovered beyond the entry file itself

    This is the default discovery mode for `check`, `owncheck`, `ownsig`, and
    `interpret` when no explicit --module-root is provided.
    """
    entry_path = Path(entry_file).resolve()
    root = entry_path.parent
    try:
        graph = load_module_graph(
            entry_path,
            module_root=root,
            external_signatures=external_signatures,
            dependency_modules=dependency_modules,
        )
    except Exception:
        return dict(external_signatures or {}), None

    # Downgrade E_MODULE_MISSING to warnings in auto-discovery mode:
    # the import may legitimately be an external dependency not on disk.
    for issue in graph.issues:
        if issue.code == 'E_MODULE_MISSING':
            issue.level = 'warning'
            issue.code = 'W_MODULE_MISSING_AUTO'

    # If nothing beyond the entry module was discovered, skip workspace overhead.
    if len(graph.modules) <= 1 and not any(
        issue.level == 'error' for issue in graph.issues
    ):
        return dict(external_signatures or {}), None

    # Build ownership signatures in topological order.
    signatures: dict[str, FunctionOwnershipSignature] = dict(external_signatures or {})
    for name in graph.order:
        loaded = graph.modules[name]
        bundle = export_ownership_signatures(loaded.module, imported_signatures=signatures)
        for fn in bundle.functions:
            prior = signatures.get(fn.name)
            if prior is not None and not _signatures_equivalent(prior, fn):
                graph.issues.append(
                    ModuleGraphIssue(
                        'error',
                        f'ownership summary conflict for {fn.name}: '
                        f'workspace export from {loaded.module_path} disagrees with existing summary',
                        fn.name,
                        'E_MODULE_SUMMARY_CONFLICT',
                    )
                )
                continue
            signatures[fn.name] = fn

    return signatures, graph


def collect_workspace_ownership_signatures(
    entry_file: str | Path,
    *,
    module_root: str | Path | None = None,
    external_signatures: dict[str, FunctionOwnershipSignature] | None = None,
    dependency_modules: set[str] | None = None,
) -> tuple[dict[str, FunctionOwnershipSignature], ModuleGraph]:
    _, signatures, graph = collect_workspace_export_bundles(
        entry_file,
        module_root=module_root,
        external_signatures=external_signatures,
        dependency_modules=dependency_modules,
    )
    return signatures, graph


def collect_workspace_signature_bundle(
    entry_file: str | Path,
    *,
    module_root: str | Path | None = None,
    external_bundles: list[OwnershipSignatureBundle] | None = None,
    dependency_modules: set[str] | None = None,
) -> tuple[OwnershipSignatureBundle, ModuleGraph]:
    external = merge_signature_bundles(external_bundles or [])
    signatures, graph = collect_workspace_ownership_signatures(entry_file, module_root=module_root, external_signatures=external, dependency_modules=dependency_modules)
    return OwnershipSignatureBundle(module_path=graph.entry_module, functions=list(signatures.values())), graph


def auto_discover_workspace_signatures(
    entry_file: str | Path,
    *,
    external_signatures: dict[str, FunctionOwnershipSignature] | None = None,
    dependency_modules: set[str] | None = None,
) -> tuple[dict[str, FunctionOwnershipSignature], ModuleGraph | None]:
    """
    Auto-discover workspace-local modules from the entry file's parent directory
    without requiring an explicit --module-root flag.

    Behavioural contract:
    - Uses entry_file.parent as the implicit module root.
    - E_MODULE_MISSING is downgraded to W_MODULE_MISSING_AUTO (warning).
      In auto mode, a missing import is assumed to be an undeclared external
      dependency, not a bug.  The caller can still inspect graph.issues.
    - E_MODULE_CYCLE, E_MODULE_DUPLICATE, E_MODULE_PARSE remain errors —
      these are always programmer mistakes regardless of how the root was found.
    - Returns (external_signatures, None) unchanged when no workspace modules
      beyond the entry file itself are discovered, so callers can short-circuit.

    This is the default discovery mode for check / owncheck / ownsig / interpret
    when no explicit --module-root is supplied.
    """
    entry_path = Path(entry_file).resolve()
    root = entry_path.parent

    try:
        graph = load_module_graph(
            entry_path,
            module_root=root,
            external_signatures=external_signatures,
            dependency_modules=dependency_modules,
        )
    except Exception:
        # Filesystem errors — just return unchanged and let the normal check proceed.
        return dict(external_signatures or {}), None

    # Downgrade E_MODULE_MISSING → warning in auto-discovery mode.
    for issue in graph.issues:
        if issue.code == 'E_MODULE_MISSING':
            issue.level = 'warning'
            issue.code = 'W_MODULE_MISSING_AUTO'

    # If nothing beyond the entry module was found, skip the overhead.
    extra_modules = {name for name in graph.modules if name != graph.entry_module}
    if not extra_modules and not any(issue.level == 'error' for issue in graph.issues):
        return dict(external_signatures or {}), None

    # Build ownership signatures in topological order over discovered modules.
    signatures: dict[str, FunctionOwnershipSignature] = dict(external_signatures or {})
    for name in graph.order:
        loaded = graph.modules[name]
        bundle = export_ownership_signatures(loaded.module, imported_signatures=signatures)
        for fn in bundle.functions:
            prior = signatures.get(fn.name)
            if prior is not None and not _signatures_equivalent(prior, fn):
                graph.issues.append(
                    ModuleGraphIssue(
                        'error',
                        f'ownership summary conflict for {fn.name}: '
                        f'auto-discovered module {loaded.module_path} disagrees with existing summary',
                        fn.name,
                        'E_MODULE_SUMMARY_CONFLICT',
                    )
                )
                continue
            signatures[fn.name] = fn

    return signatures, graph


# ─────────────────────────────────────────────────────────────────────────────
# v47.59 — canonical publication digest
# ─────────────────────────────────────────────────────────────────────────────

_DIGEST_EXCLUDED_FIELDS = frozenset({
    'signature',
    'signature_algorithm',
    'signature_public_key_id',
})

_DIGEST_SCHEMA = 'axiomzig.publication_digest.v1'


def compute_publication_digest(manifest: dict) -> str:
    """
    Compute a stable SHA-256 digest over the canonical JSON form of a
    publication manifest, excluding signature fields.

    The digest is computed over sort-keyed, compact JSON with all
    signature-related fields removed.  This is the value a signing tool
    should sign, and a verifying tool should recompute to check the signature.
    """
    payload = {k: v for k, v in manifest.items() if k not in _DIGEST_EXCLUDED_FIELDS}
    canonical = json.dumps(payload, sort_keys=True, separators=(',', ':'))
    return _sha256_text(canonical)


def build_publication_digest_record(manifest: dict) -> dict:
    """
    Build a digest record for a publication manifest.

    The record contains:
      - schema_version: 'axiomzig.publication_digest.v1'
      - package_id, package_name, package_version from the manifest
      - manifest_hash: the existing per-manifest hash (integrity check)
      - publication_digest: the canonical digest (what a signing tool signs)
      - publication_digest_algorithm: 'sha256'
      - excluded_fields: list of field names excluded from the digest
      - signature: null  (placeholder — populate with a real signature externally)
      - signature_algorithm: null
      - signature_public_key_id: null

    The null signature fields signal that verification is not yet attached.
    A verifying tool should:
      1. Recompute publication_digest from the manifest (excluding signature fields).
      2. Compare to this record's publication_digest.
      3. If signature is non-null, verify the signature against publication_digest
         using signature_algorithm and the key identified by signature_public_key_id.
    """
    if manifest.get('schema_version') not in (
        'axiomzig.publication_manifest.v1',
        'axiomzig.conformance.v4',
    ):
        sv = manifest.get('schema_version', '<unknown>')
        raise ValueError(
            f'pubdigest requires a publication manifest; '
            f'got schema_version {sv!r}'
        )
    digest = compute_publication_digest(manifest)
    return {
        'schema_version': _DIGEST_SCHEMA,
        'package_id': manifest.get('package_id', ''),
        'package_name': manifest.get('package_name', ''),
        'package_version': manifest.get('package_version', ''),
        'manifest_hash': manifest.get('manifest_hash', ''),
        'publication_digest': digest,
        'publication_digest_algorithm': 'sha256',
        'excluded_fields': sorted(_DIGEST_EXCLUDED_FIELDS),
        'signature': None,
        'signature_algorithm': None,
        'signature_public_key_id': None,
    }


def verify_publication_digest_record(manifest: dict, digest_record: dict) -> list[str]:
    """
    Verify a digest record against a publication manifest.

    Returns a list of error strings.  Empty list means the record is valid.
    Does NOT verify cryptographic signatures — that requires an external tool
    with access to the signing key.  Verifies only the digest integrity.
    """
    errors: list[str] = []
    if digest_record.get('schema_version') != _DIGEST_SCHEMA:
        errors.append(
            f'digest record schema_version must be {_DIGEST_SCHEMA!r}; '
            f'got {digest_record.get("schema_version")!r}'
        )
        return errors  # can't proceed without correct schema
    # Recompute digest from manifest
    recomputed = compute_publication_digest(manifest)
    recorded = digest_record.get('publication_digest', '')
    if recomputed != recorded:
        errors.append(
            f'publication_digest mismatch: '
            f'recomputed {recomputed!r} != recorded {recorded!r}'
        )
    # Check manifest_hash consistency
    manifest_hash = manifest.get('manifest_hash', '')
    if manifest_hash and digest_record.get('manifest_hash', '') != manifest_hash:
        errors.append(
            f'manifest_hash mismatch: '
            f'manifest has {manifest_hash!r}, digest record has {digest_record.get("manifest_hash")!r}'
        )
    # Check package identity
    for field in ('package_id', 'package_name', 'package_version'):
        if manifest.get(field) != digest_record.get(field):
            errors.append(
                f'{field} mismatch: '
                f'manifest {manifest.get(field)!r} != digest record {digest_record.get(field)!r}'
            )
    return errors
