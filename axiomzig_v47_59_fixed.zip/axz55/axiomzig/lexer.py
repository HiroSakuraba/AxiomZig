from __future__ import annotations

from typing import Iterable

from .token import Token


KEYWORDS = {
    "module",
    "import",
    "const",
    "struct",
    "enum",
    "error_set",
    "protocol",
    "resource",
    "pub",
    "fn",
    "let",
    "var",
    "if",
    "else",
    "while",
    "for",
    "in",
    "match",
    "alias",
    "return",
    "break",
    "continue",
    "defer",
    "errdefer",
    "try",
    "catch",
    "effects",
    "move",
    "borrow",
    "copy",
    "true",
    "false",
    "unit",
    "some",
    "none",
    "ok",
    "error",
    "and",
    "or",
    "not",
}

MULTI = [
    "==",
    "!=",
    "<=",
    ">=",
    "+=",
    "-=",
    "*=",
    "/=",
    "%=",
    "->",
    "..",
]
SINGLE = set("+-*/%=:;,(){}[].<>?!|")


class LexError(ValueError):
    pass


def lex(text: str) -> list[Token]:
    tokens: list[Token] = []
    i = 0
    line = 1
    col = 1

    def current(offset: int = 0) -> str:
        idx = i + offset
        return text[idx] if idx < len(text) else ""

    def advance(n: int = 1) -> None:
        nonlocal i, line, col
        for _ in range(n):
            if i >= len(text):
                return
            ch = text[i]
            i += 1
            if ch == "\n":
                line += 1
                col = 1
            else:
                col += 1

    def emit(kind: str, value: str, tok_line: int, tok_col: int) -> None:
        tokens.append(Token(kind=kind, value=value, line=tok_line, column=tok_col))

    while i < len(text):
        ch = current()

        if ch in " \t\n":
            advance()
            continue

        if ch == "\r":
            raise LexError(f"carriage return forbidden at {line}:{col}")

        if ch == "/" and current(1) == "/":
            while i < len(text) and current() != "\n":
                advance()
            continue

        tok_line, tok_col = line, col

        matched = False
        for op in MULTI:
            if text.startswith(op, i):
                emit(op, op, tok_line, tok_col)
                advance(len(op))
                matched = True
                break
        if matched:
            continue

        if ch == '"':
            advance()
            value_chars: list[str] = []
            while i < len(text):
                c = current()
                if c == '"':
                    advance()
                    emit("STRING", "".join(value_chars), tok_line, tok_col)
                    break
                if c == "\\":
                    advance()
                    esc = current()
                    if esc == "n":
                        value_chars.append("\n")
                        advance()
                    elif esc == "t":
                        value_chars.append("\t")
                        advance()
                    elif esc == "r":
                        value_chars.append("\r")
                        advance()
                    elif esc == "0":
                        value_chars.append("\0")
                        advance()
                    elif esc == '"':
                        value_chars.append('"')
                        advance()
                    elif esc == "\\":
                        value_chars.append("\\")
                        advance()
                    elif esc == "x":
                        hex_digits = text[i + 1:i + 3]
                        if len(hex_digits) != 2 or any(c not in "0123456789abcdefABCDEF" for c in hex_digits):
                            raise LexError(f"invalid \\x escape at {line}:{col}")
                        value_chars.append(bytes.fromhex(hex_digits).decode("latin1"))
                        advance(3)
                    elif esc == "u":
                        hex_digits = text[i + 1:i + 7]
                        if len(hex_digits) != 6 or any(c not in "0123456789abcdefABCDEF" for c in hex_digits):
                            raise LexError(f"invalid \\u escape at {line}:{col}")
                        value_chars.append(chr(int(hex_digits, 16)))
                        advance(7)
                    else:
                        raise LexError(f"unknown escape \\{esc} at {line}:{col}")
                    continue
                if c == "\n":
                    raise LexError(f"newline in string literal at {line}:{col}")
                value_chars.append(c)
                advance()
            else:
                raise LexError(f"unterminated string literal at {tok_line}:{tok_col}")
            continue

        if ch.isdigit():
            start = i
            if ch == "0" and current(1) in {"x", "o", "b"}:
                advance(2)
                while current() and (current().isalnum() or current() == "_"):
                    advance()
            else:
                while current() and (current().isdigit() or current() == "_"):
                    advance()
            emit("INT", text[start:i], tok_line, tok_col)
            continue

        if ch.isalpha() or ch == "_":
            start = i
            while current() and (current().isalnum() or current() == "_"):
                advance()
            value = text[start:i]
            emit(value if value in KEYWORDS else "IDENT", value, tok_line, tok_col)
            continue

        if ch == "@":
            start = i
            advance()
            while current() and (current().isalnum() or current() == "_"):
                advance()
            value = text[start:i]
            emit(value, value, tok_line, tok_col)
            continue

        if ch in SINGLE:
            emit(ch, ch, tok_line, tok_col)
            advance()
            continue

        raise LexError(f"unexpected character {ch!r} at {line}:{col}")

    tokens.append(Token(kind="EOF", value="", line=line, column=col))
    return tokens


def lex_iter(text: str) -> Iterable[Token]:
    return iter(lex(text))
