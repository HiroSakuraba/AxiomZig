from __future__ import annotations

from dataclasses import dataclass, field

from . import ast
from .formatter import format_expr_inline, format_type
from .ownership_signatures import FunctionOwnershipSignature, normalize_imported_contracts, parse_type_text
from .semantic import TypeFacts, sem_place_for_expr
from .diag import *  # noqa: F401,F403 — stable diagnostic codes


INTEGER_NAMES = {"I8", "I16", "I32", "I64", "U8", "U16", "U32", "U64"}
BOOL_TYPE = ast.NamedType("Bool")
UNIT_TYPE = ast.NamedType("Unit")
STR_TYPE = ast.NamedType("Str")
I64_TYPE = ast.NamedType("I64")
U8_TYPE = ast.NamedType("U8")
U64_TYPE = ast.NamedType("U64")


@dataclass(frozen=True, slots=True)
class UnknownType:
    reason: str = "unknown"


@dataclass(frozen=True, slots=True)
class NoneLiteralType:
    pass


TypeLike = ast.Type | UnknownType | NoneLiteralType


@dataclass(slots=True)
class TypeIssue:
    level: str
    message: str
    context: str | None = None
    code: str | None = None


@dataclass(slots=True)
class TypedExprRecord:
    text: str
    kind: str
    type_text: str
    place: str | None = None
    ref_mode: str | None = None
    borrow_mode: str | None = None
    tracked: bool = False
    protocol: str | None = None
    copyable: bool = True


@dataclass(slots=True)
class TypedCallRecord:
    callee: str
    arg_types: list[str]
    return_type: str
    effects: list[str]
    arg_ref_modes: list[str | None] = field(default_factory=list)


@dataclass(slots=True)
class TypedFunction:
    name: str
    declared_return_type: str
    exprs: list[TypedExprRecord] = field(default_factory=list)
    calls: list[TypedCallRecord] = field(default_factory=list)
    issues: list[TypeIssue] = field(default_factory=list)


@dataclass(slots=True)
class TypecheckSummary:
    module_path: str
    functions: list[TypedFunction]
    issues: list[TypeIssue]


@dataclass(slots=True)
class Scope:
    bindings: dict[str, TypeLike] = field(default_factory=dict)
    mutability: dict[str, bool] = field(default_factory=dict)


class TypeChecker:
    def __init__(self, module: ast.Module, imported_signatures: dict[str, FunctionOwnershipSignature] | None = None):
        self.module = module
        self.issues: list[TypeIssue] = []
        self.const_types: dict[str, ast.Type] = {}
        self.functions: dict[str, ast.FnDecl] = {}
        self.structs: dict[str, ast.StructDecl] = {}
        self.resources: dict[str, ast.ResourceDecl] = {}
        self.enums: dict[str, ast.EnumDecl] = {}
        self.error_sets: dict[str, ast.ErrorSetDecl] = {}
        self.imports: dict[str, str] = {}
        self.imported_signatures = imported_signatures or {}
        self.imported_contracts = {}
        self._import_contract_errors: list[str] = []
        try:
            self.imported_contracts = normalize_imported_contracts(self.imported_signatures)
        except ValueError as exc:
            self._import_contract_errors.append(str(exc))
        self.collect_top_level()

    def collect_top_level(self) -> None:
        for imp in self.module.imports:
            self.imports[imp.path[-1]] = ".".join(imp.path)
        for decl in self.module.decls:
            if isinstance(decl, ast.ConstDecl):
                self.const_types[decl.name] = decl.typ
            elif isinstance(decl, ast.FnDecl):
                self.functions[decl.name] = decl
            elif isinstance(decl, ast.StructDecl):
                self.structs[decl.name] = decl
            elif isinstance(decl, ast.ResourceDecl):
                self.resources[decl.name] = decl
            elif isinstance(decl, ast.EnumDecl):
                self.enums[decl.name] = decl
            elif isinstance(decl, ast.ErrorSetDecl):
                self.error_sets[decl.name] = decl

    def typecheck(self) -> TypecheckSummary:
        fns: list[TypedFunction] = []
        for message in self._import_contract_errors:
            self.issue("error", message, None)
        for decl in self.module.decls:
            if isinstance(decl, ast.FnDecl):
                fns.append(self.typecheck_function(decl))
        return TypecheckSummary(module_path=".".join(self.module.path), functions=fns, issues=self.issues)

    def issue(self, level: str, message: str, fn: TypedFunction | None = None, context: str | None = None, code: str | None = None) -> None:
        item = TypeIssue(level=level, message=message, context=context, code=code)
        self.issues.append(item)
        if fn is not None:
            fn.issues.append(item)

    def typecheck_function(self, fn: ast.FnDecl) -> TypedFunction:
        summary = TypedFunction(name=fn.name, declared_return_type=self.type_text(fn.return_type))
        scopes = [Scope()]
        for param in fn.params:
            scopes[-1].bindings[param.name] = param.typ
            scopes[-1].mutability[param.name] = False
        self.typecheck_block(fn.body, scopes, fn, summary)
        return summary

    def typecheck_block(self, block: ast.Block, scopes: list[Scope], fn: ast.FnDecl, summary: TypedFunction) -> None:
        scopes.append(Scope())
        for stmt in block.statements:
            self.typecheck_stmt(stmt, scopes, fn, summary)
        scopes.pop()

    def typecheck_stmt(self, stmt: ast.Stmt, scopes: list[Scope], fn: ast.FnDecl, summary: TypedFunction) -> None:
        if isinstance(stmt, ast.Block):
            self.typecheck_block(stmt, scopes, fn, summary)
            return
        if isinstance(stmt, ast.LetStmt):
            inferred = self.type_of_expr(stmt.value, scopes, fn, summary, expected=stmt.typ)
            bound = stmt.typ if stmt.typ is not None else self.materialize(inferred)
            if stmt.typ is not None and not self.assignable(inferred, stmt.typ):
                self.issue("error", f"let {stmt.name} annotated as {self.type_text(stmt.typ)} but got {self.type_text(inferred)}", summary, code="E_TYPE_MISMATCH")
            scopes[-1].bindings[stmt.name] = bound
            scopes[-1].mutability[stmt.name] = False
            return
        if isinstance(stmt, ast.VarStmt):
            inferred = self.type_of_expr(stmt.value, scopes, fn, summary, expected=stmt.typ)
            bound = stmt.typ if stmt.typ is not None else self.materialize(inferred)
            if stmt.typ is not None and not self.assignable(inferred, stmt.typ):
                self.issue("error", f"var {stmt.name} annotated as {self.type_text(stmt.typ)} but got {self.type_text(inferred)}", summary, code="E_TYPE_MISMATCH")
            scopes[-1].bindings[stmt.name] = bound
            scopes[-1].mutability[stmt.name] = True
            return
        if isinstance(stmt, ast.AssignStmt):
            target_type = self.type_of_lvalue(stmt.target, scopes, fn, summary)
            value_type = self.type_of_expr(stmt.value, scopes, fn, summary, expected=target_type if isinstance(target_type, ast.Type) else None)
            if not self.assignable(value_type, target_type):
                self.issue("error", f"assignment {stmt.op} expects {self.type_text(target_type)} but got {self.type_text(value_type)}", summary, code="E_TYPE_MISMATCH")
            return
        if isinstance(stmt, ast.ExprStmt):
            expr_type = self.type_of_expr(stmt.expr, scopes, fn, summary, expected=None)
            if not self.assignable(expr_type, UNIT_TYPE):
                self.issue("error", f"expression statement has non-Unit type {self.type_text(expr_type)}; use _ = expr to discard", summary, code="E_TYPE_NONUNIT")
            return
        if isinstance(stmt, ast.ReturnStmt):
            value_type = UNIT_TYPE if stmt.expr is None else self.type_of_expr(stmt.expr, scopes, fn, summary, expected=fn.return_type)
            if not self.return_assignable(value_type, fn.return_type):
                self.issue("error", f"return in {fn.name} expects {self.type_text(fn.return_type)} but got {self.type_text(value_type)}", summary, code="E_TYPE_MISMATCH")
            return
        if isinstance(stmt, ast.IfStmt):
            cond_type = self.type_of_expr(stmt.cond, scopes, fn, summary, expected=BOOL_TYPE)
            if not self.assignable(cond_type, BOOL_TYPE):
                self.issue("error", f"if condition must be Bool, got {self.type_text(cond_type)}", summary)
            self.typecheck_block(stmt.then_block, scopes, fn, summary)
            if stmt.else_branch is not None:
                if isinstance(stmt.else_branch, ast.Block):
                    self.typecheck_block(stmt.else_branch, scopes, fn, summary)
                else:
                    self.typecheck_stmt(stmt.else_branch, scopes, fn, summary)
            return
        if isinstance(stmt, ast.WhileStmt):
            cond_type = self.type_of_expr(stmt.cond, scopes, fn, summary, expected=BOOL_TYPE)
            if not self.assignable(cond_type, BOOL_TYPE):
                self.issue("error", f"while condition must be Bool, got {self.type_text(cond_type)}", summary)
            self.typecheck_block(stmt.body, scopes, fn, summary)
            return
        if isinstance(stmt, ast.ForStmt):
            iterable_type = self.type_of_expr(stmt.iterable, scopes, fn, summary, expected=None)
            elem_type = self.iterable_element_type(iterable_type)
            if isinstance(elem_type, UnknownType):
                self.issue("error", f"for iterable has non-iterable type {self.type_text(iterable_type)}", summary, code="E_TYPE_ITER")
            elif not self.assignable(elem_type, stmt.typ):
                self.issue("error", f"for binder {stmt.name}: {self.type_text(stmt.typ)} does not match iterable element type {self.type_text(elem_type)}", summary)
            scopes.append(Scope(bindings={stmt.name: stmt.typ}, mutability={stmt.name: False}))
            for inner in stmt.body.statements:
                self.typecheck_stmt(inner, scopes, fn, summary)
            scopes.pop()
            return
        if isinstance(stmt, ast.DeferStmt | ast.ErrDeferStmt):
            self.typecheck_stmt(stmt.stmt, scopes, fn, summary)
            return
        if isinstance(stmt, ast.BreakStmt | ast.ContinueStmt):
            return
        raise TypeError(f"unsupported statement {type(stmt)!r}")

    def type_of_lvalue(self, expr: ast.Expr, scopes: list[Scope], fn: ast.FnDecl, summary: TypedFunction) -> TypeLike:
        if isinstance(expr, ast.NameExpr):
            if expr.name == "_":
                return UnknownType("discard sink")
            if not self.lookup_mutable(expr.name, scopes):
                self.issue("error", f"assignment target {expr.name} is not mutable", summary, code="E_TYPE_ASSIGN_LVALUE")
            return self.lookup_name(expr.name, scopes)
        root_name = self.lvalue_root_name(expr)
        if root_name is not None:
            root_type = self.lookup_name(root_name, scopes)
            root_norm = self.normalize_type(root_type)
            if isinstance(root_norm, ast.GenericType) and root_norm.name == "Ref":
                return self.type_of_expr(expr, scopes, fn, summary, expected=None)
            if isinstance(root_norm, ast.GenericType) and root_norm.name == "RefConst":
                self.issue("error", f"cannot assign through immutable reference {root_name}", summary)
                return self.type_of_expr(expr, scopes, fn, summary, expected=None)
            if not self.lookup_mutable(root_name, scopes):
                self.issue("error", f"assignment target rooted at {root_name} is not mutable", summary, code="E_TYPE_ASSIGN_LVALUE")
        return self.type_of_expr(expr, scopes, fn, summary, expected=None)

    def lvalue_root_name(self, expr: ast.Expr) -> str | None:
        if isinstance(expr, ast.NameExpr):
            return expr.name
        if isinstance(expr, ast.DottedExpr) and expr.parts:
            return expr.parts[0]
        if isinstance(expr, ast.AttrExpr):
            return self.lvalue_root_name(expr.obj)
        if isinstance(expr, ast.IndexExpr):
            return self.lvalue_root_name(expr.obj)
        if isinstance(expr, ast.SliceExpr):
            return self.lvalue_root_name(expr.obj)
        return None

    def type_of_expr(
        self,
        expr: ast.Expr,
        scopes: list[Scope],
        fn: ast.FnDecl,
        summary: TypedFunction,
        expected: ast.Type | None,
    ) -> TypeLike:
        kind = type(expr).__name__
        if isinstance(expr, ast.NameExpr):
            typ = self.lookup_name(expr.name, scopes)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.DottedExpr):
            typ = self.lookup_dotted(expr.parts)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.IntExpr):
            literal_expected = self.literal_expected_type(expected)
            typ = literal_expected if self.is_integer_type(literal_expected) else I64_TYPE
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.StringExpr):
            self.record_expr(summary, expr, kind, STR_TYPE)
            return STR_TYPE
        if isinstance(expr, ast.BoolExpr):
            self.record_expr(summary, expr, kind, BOOL_TYPE)
            return BOOL_TYPE
        if isinstance(expr, ast.UnitExpr):
            self.record_expr(summary, expr, kind, UNIT_TYPE)
            return UNIT_TYPE
        if isinstance(expr, ast.NoneExpr):
            typ: TypeLike = self.normalize_type(expected) if expected is not None and self.option_inner_type(expected) is not None else NoneLiteralType()
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.SomeExpr):
            inner_expected = self.option_inner_type(expected)
            inner = self.type_of_expr(expr.value, scopes, fn, summary, expected=inner_expected)
            typ = self.normalize_type(expected) if inner_expected is not None else ast.OptionalType(self.materialize(inner))
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.UnaryExpr):
            inner = self.type_of_expr(expr.expr, scopes, fn, summary, expected=None)
            if expr.op == "borrow":
                referent = self.materialize(self.unwrap_ref(inner))
                expected_norm = self.normalize_type(expected)
                if isinstance(expected_norm, ast.GenericType) and expected_norm.name in {"Ref", "RefConst"} and expected_norm.args:
                    typ = expected_norm
                else:
                    typ = ast.GenericType("RefConst", [referent])
            elif expr.op in {"move", "copy"}:
                typ = inner
            elif expr.op == "not":
                if not self.assignable(inner, BOOL_TYPE):
                    self.issue("error", f"not expects Bool, got {self.type_text(inner)}", summary, code="E_TYPE_MISMATCH")
                typ = BOOL_TYPE
            elif expr.op == "-":
                if not self.is_integer_like(inner):
                    self.issue("error", f"unary - expects integer, got {self.type_text(inner)}", summary, code="E_TYPE_MISMATCH")
                typ = inner
            else:
                typ = UnknownType(f"unknown unary operator {expr.op}")
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.BinaryExpr):
            left = self.type_of_expr(expr.left, scopes, fn, summary, expected=None)
            right = self.type_of_expr(expr.right, scopes, fn, summary, expected=left if isinstance(left, ast.Type) else None)
            if expr.op in {"+", "-", "*", "/", "%"}:
                if not self.is_integer_like(left) or not self.assignable(right, left):
                    self.issue("error", f"binary {expr.op} expects matching integer operands, got {self.type_text(left)} and {self.type_text(right)}", summary, code="E_TYPE_MISMATCH")
                typ = left
            elif expr.op in {"<", "<=", ">", ">=", "==", "!="}:
                if not self.assignable(left, right) and not self.assignable(right, left):
                    self.issue("error", f"comparison {expr.op} expects compatible operands, got {self.type_text(left)} and {self.type_text(right)}", summary, code="E_TYPE_MISMATCH")
                typ = BOOL_TYPE
            elif expr.op in {"and", "or"}:
                if not self.assignable(left, BOOL_TYPE) or not self.assignable(right, BOOL_TYPE):
                    self.issue("error", f"logical {expr.op} expects Bool operands, got {self.type_text(left)} and {self.type_text(right)}", summary, code="E_TYPE_MISMATCH")
                typ = BOOL_TYPE
            else:
                typ = UnknownType(f"unknown binary operator {expr.op}")
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.RangeExpr):
            start = self.type_of_expr(expr.start, scopes, fn, summary, expected=None)
            stop = self.type_of_expr(expr.stop, scopes, fn, summary, expected=start if isinstance(start, ast.Type) else None)
            if not self.is_integer_like(start) or not self.assignable(stop, start):
                self.issue("error", f"range expects matching integer bounds, got {self.type_text(start)} and {self.type_text(stop)}", summary, code="E_TYPE_ITER")
            typ = ast.GenericType("Range", [self.materialize(start if self.is_integer_like(start) else I64_TYPE)])
            self.record_expr(summary, expr, kind if 'kind' in locals() else type(expr).__name__, typ)
            return typ

        if isinstance(expr, ast.CallExpr):
            arg_types: list[TypeLike] = []
            arg_ref_modes: list[str | None] = []
            target = None
            imported_sig = None
            if isinstance(expr.callee, ast.NameExpr):
                target = self.functions.get(expr.callee.name)
            if target is None:
                imported_sig = self.imported_function_signature(expr.callee)
            if target is not None:
                if len(expr.args) != len(target.params):
                    self.issue("error", f"call to {target.name} expects {len(target.params)} arguments but got {len(expr.args)}", summary, code="E_TYPE_MISMATCH")
                for idx, arg in enumerate(expr.args):
                    param_expected = target.params[idx].typ if idx < len(target.params) else None
                    arg_type = self.type_of_expr(arg, scopes, fn, summary, expected=param_expected)
                    arg_types.append(arg_type)
                    arg_ref_modes.append(self.type_facts_for_type(param_expected).ref_mode if param_expected is not None else None)
                    if idx < len(target.params) and not self.assignable(arg_type, target.params[idx].typ):
                        self.issue("error", f"call to {target.name} argument {idx + 1} expects {self.type_text(target.params[idx].typ)} but got {self.type_text(arg_type)}", summary, code="E_TYPE_MISMATCH")
                if not set(target.effects).issubset(set(fn.effects)):
                    self.issue("error", f"call to {target.name} requires effects {target.effects} not contained in caller {fn.name} effects {fn.effects}", summary, code="E_EFFECT_UNDER")
                typ = self.normalize_type(target.return_type)
                summary.calls.append(TypedCallRecord(
                    callee=target.name,
                    arg_types=[self.type_text(t) for t in arg_types],
                    return_type=self.type_text(typ),
                    effects=list(target.effects),
                    arg_ref_modes=arg_ref_modes,
                ))
            elif imported_sig is not None:
                if len(expr.args) != len(imported_sig.param_types):
                    self.issue("error", f"call to {imported_sig.name} expects {len(imported_sig.param_types)} arguments but got {len(expr.args)}", summary, code="E_TYPE_MISMATCH")
                for idx, arg in enumerate(expr.args):
                    param_expected = self.imported_param_type(imported_sig, idx)
                    arg_type = self.type_of_expr(arg, scopes, fn, summary, expected=param_expected)
                    arg_types.append(arg_type)
                    arg_ref_modes.append(self.type_facts_for_type(param_expected).ref_mode if param_expected is not None else None)
                    if param_expected is not None and not self.assignable(arg_type, param_expected):
                        self.issue("error", f"call to {imported_sig.name} argument {idx + 1} expects {self.type_text(param_expected)} but got {self.type_text(arg_type)}", summary, code="E_TYPE_MISMATCH")
                if not set(imported_sig.effects).issubset(set(fn.effects)):
                    self.issue("error", f"call to {imported_sig.name} requires effects {imported_sig.effects} not contained in caller {fn.name} effects {fn.effects}", summary, code="E_EFFECT_UNDER")
                typ = self.normalize_type(parse_type_text(imported_sig.return_type))
                summary.calls.append(TypedCallRecord(
                    callee=imported_sig.name,
                    arg_types=[self.type_text(t) for t in arg_types],
                    return_type=self.type_text(typ),
                    effects=list(imported_sig.effects),
                    arg_ref_modes=arg_ref_modes,
                ))
            else:
                self.type_of_expr(expr.callee, scopes, fn, summary, expected=None)
                for arg in expr.args:
                    arg_types.append(self.type_of_expr(arg, scopes, fn, summary, expected=None))
                    arg_ref_modes.append(None)
                typ = UnknownType("unknown call return")
                summary.calls.append(TypedCallRecord(
                    callee=format_expr_inline(expr.callee),
                    arg_types=[self.type_text(t) for t in arg_types],
                    return_type=self.type_text(typ),
                    effects=[],
                    arg_ref_modes=arg_ref_modes,
                ))
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.AttrExpr):
            obj_type = self.type_of_expr(expr.obj, scopes, fn, summary, expected=None)
            typ = self.lookup_attr_type(obj_type, expr.name)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.IndexExpr):
            obj_type = self.type_of_expr(expr.obj, scopes, fn, summary, expected=None)
            index_type = self.type_of_expr(expr.index, scopes, fn, summary, expected=U64_TYPE)
            if not self.assignable(index_type, U64_TYPE):
                self.issue("error", f"index expression expects U64 index, got {self.type_text(index_type)}", summary, code="E_TYPE_SLICE_INDEX")
            typ = self.index_result_type(obj_type)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.SliceExpr):
            obj_type = self.type_of_expr(expr.obj, scopes, fn, summary, expected=None)
            if expr.start is not None:
                start_type = self.type_of_expr(expr.start, scopes, fn, summary, expected=U64_TYPE)
                if not self.assignable(start_type, U64_TYPE):
                    self.issue("error", f"slice start expects U64, got {self.type_text(start_type)}", summary, code="E_TYPE_SLICE_INDEX")
            if expr.stop is not None:
                stop_type = self.type_of_expr(expr.stop, scopes, fn, summary, expected=U64_TYPE)
                if not self.assignable(stop_type, U64_TYPE):
                    self.issue("error", f"slice stop expects U64, got {self.type_text(stop_type)}", summary, code="E_TYPE_SLICE_INDEX")
            typ = self.slice_result_type(obj_type)
            if isinstance(typ, UnknownType) and typ.reason == "slice on non-sliceable value":
                self.issue("error", typ.reason, summary)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.TryExpr):
            inner = self.normalize_type(self.type_of_expr(expr.expr, scopes, fn, summary, expected=None))
            declared_return = self.normalize_type(fn.return_type)
            if isinstance(inner, ast.ResultType):
                if isinstance(declared_return, ast.ResultType):
                    if not self.assignable(inner.err, declared_return.err):
                        self.issue("error", f"result propagation requires enclosing function to return a compatible result type, got {self.type_text(declared_return)}", summary, code="E_TYPE_MISMATCH")
                else:
                    self.issue("error", f"result propagation requires enclosing function to return a compatible result type, got {self.type_text(declared_return)}", summary, code="E_TYPE_MISMATCH")
                typ = inner.ok
            elif isinstance(inner, ast.OptionalType):
                if not isinstance(declared_return, ast.OptionalType):
                    self.issue("error", f"optional propagation requires enclosing function to return an optional type, got {self.type_text(declared_return)}", summary)
                typ = inner.inner
            else:
                self.issue("error", f"propagation operator expects a result or optional type, got {self.type_text(inner)}", summary, code="E_TYPE_MISMATCH")
                typ = UnknownType("try on non-propagating type")
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.CatchExpr):
            inner = self.normalize_type(self.type_of_expr(expr.expr, scopes, fn, summary, expected=None))
            if isinstance(inner, ast.ResultType):
                if expr.binding is not None and expr.handler is not None:
                    # catch |e| { body } — introduce e bound to the error type for the block
                    err_type: ast.Type = inner.err if hasattr(inner, 'err') else ast.NamedType('_error')
                    inner_scopes: list[Scope] = list(scopes) + [{expr.binding: err_type}]
                    self.typecheck_block(expr.handler, inner_scopes, fn, summary)
                    typ = inner.ok
                else:
                    fallback = self.type_of_expr(expr.fallback, scopes, fn, summary, expected=inner.ok)
                    if not self.assignable(fallback, inner.ok):
                        self.issue("error", f"catch fallback expects {self.type_text(inner.ok)} but got {self.type_text(fallback)}", summary, code="E_TYPE_MISMATCH")
                    typ = inner.ok
            else:
                self.issue("error", f"catch operator expects a result type, got {self.type_text(inner)}", summary, code="E_TYPE_MISMATCH")
                if expr.binding is None:
                    self.type_of_expr(expr.fallback, scopes, fn, summary, expected=None)
                typ = UnknownType("catch on non-result")
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.CastExpr):
            self.type_of_expr(expr.expr, scopes, fn, summary, expected=None)
            typ = self.normalize_type(expr.typ)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.StructLiteralExpr):
            fields = self.lookup_record_fields(expr.name)
            seen: set[str] = set()
            for field_name, field_value in expr.fields:
                if field_name in seen:
                    self.issue("error", f"{expr.name} literal repeats field {field_name}", summary)
                seen.add(field_name)
                expected_field = fields.get(field_name)
                value_type = self.type_of_expr(field_value, scopes, fn, summary, expected=expected_field)
                if expected_field is None:
                    self.issue("error", f"{expr.name} literal names unknown field {field_name}", summary)
                elif not self.assignable(value_type, expected_field):
                    self.issue("error", f"{expr.name}.{field_name} expects {self.type_text(expected_field)} but got {self.type_text(value_type)}", summary, code="E_TYPE_MISMATCH")
            missing = sorted(set(fields) - seen)
            for field_name in missing:
                self.issue("error", f"{expr.name} literal is missing field {field_name}", summary)
            typ = ast.NamedType(expr.name)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.EnumLiteralExpr):
            enum_decl = self.enums.get(expr.enum_name)
            fields = {f.name: f.typ for f in self.find_variant_fields(enum_decl, expr.variant_name)}
            if enum_decl is None:
                self.issue("error", f"unknown enum {expr.enum_name}", summary)
            elif not any(v.name == expr.variant_name for v in enum_decl.variants):
                self.issue("error", f"enum {expr.enum_name} has no variant {expr.variant_name}", summary)
            seen: set[str] = set()
            for field_name, field_value in expr.fields:
                if field_name in seen:
                    self.issue("error", f"{expr.enum_name}.{expr.variant_name} literal repeats field {field_name}", summary)
                seen.add(field_name)
                expected_field = fields.get(field_name)
                value_type = self.type_of_expr(field_value, scopes, fn, summary, expected=expected_field)
                if expected_field is None:
                    self.issue("error", f"{expr.enum_name}.{expr.variant_name} literal names unknown field {field_name}", summary)
                elif not self.assignable(value_type, expected_field):
                    self.issue("error", f"{expr.enum_name}.{expr.variant_name}.{field_name} expects {self.type_text(expected_field)} but got {self.type_text(value_type)}", summary, code="E_TYPE_MISMATCH")
            missing = sorted(set(fields) - seen)
            for field_name in missing:
                self.issue("error", f"{expr.enum_name}.{expr.variant_name} literal is missing field {field_name}", summary)
            typ = ast.NamedType(expr.enum_name)
            self.record_expr(summary, expr, kind, typ)
            return typ
        if isinstance(expr, ast.MatchExpr):
            scrutinee = self.type_of_expr(expr.expr, scopes, fn, summary, expected=None)
            arm_types: list[TypeLike] = []
            covered: list[str] = []
            for arm in expr.arms:
                arm_scope = Scope()
                scopes.append(arm_scope)
                self.bind_pattern(arm.pattern, scrutinee, scopes, summary)
                arm_type = self.type_of_expr(arm.expr, scopes, fn, summary, expected=expected)
                arm_types.append(arm_type)
                covered.append(self.cover_key(arm.pattern, scrutinee))
                scopes.pop()
            typ = self.unify_arm_types(arm_types, expected)
            if isinstance(typ, UnknownType) and typ.reason == "incompatible match arms":
                self.issue("error", "match arms have incompatible types", summary, code="E_TYPE_ARM_INCOMPAT")
            missing = self.missing_coverage(scrutinee, covered)
            if missing:
                self.issue("error", f"match is not exhaustive; missing {', '.join(missing)}", summary, code="E_TYPE_NO_EXHAUST")
            self.record_expr(summary, expr, kind, typ)
            return typ
        raise TypeError(f"unsupported expression {type(expr)!r}")

    def bind_pattern(self, pattern: ast.Pattern, scrutinee: TypeLike, scopes: list[Scope], summary: TypedFunction) -> None:
        if isinstance(pattern, ast.WildcardPattern | ast.NonePattern):
            return
        if isinstance(pattern, ast.NamePattern):
            if pattern.name != "_":
                scopes[-1].bindings[pattern.name] = self.materialize(scrutinee)
                scopes[-1].mutability[pattern.name] = False
            return
        if isinstance(pattern, ast.LiteralPattern):
            value_type = self.type_of_expr(pattern.value, scopes, NoneFn(), summary, expected=self.materialize(scrutinee) if isinstance(scrutinee, ast.Type) else None)
            if not self.assignable(value_type, scrutinee):
                self.issue("error", f"literal pattern {format_expr_inline(pattern.value)} incompatible with scrutinee {self.type_text(scrutinee)}", summary)
            return
        if isinstance(pattern, ast.SomePattern):
            inner = self.option_inner_type(scrutinee)
            if inner is None:
                self.issue("error", f"some(...) pattern expects optional scrutinee, got {self.type_text(scrutinee)}", summary, code="E_TYPE_MISMATCH")
            else:
                self.bind_pattern(pattern.inner, inner, scopes, summary)
            return
        if isinstance(pattern, ast.OkPattern):
            scrutinee_norm = self.normalize_type(scrutinee)
            if isinstance(scrutinee_norm, ast.ResultType):
                self.bind_pattern(pattern.inner, scrutinee_norm.ok, scopes, summary)
            else:
                self.issue("error", f"ok(...) pattern expects result scrutinee, got {self.type_text(scrutinee)}", summary, code="E_TYPE_MISMATCH")
            return
        if isinstance(pattern, ast.ErrorPattern):
            scrutinee_norm = self.normalize_type(scrutinee)
            if not isinstance(scrutinee_norm, ast.ResultType):
                self.issue("error", f"error pattern expects result scrutinee, got {self.type_text(scrutinee)}", summary, code="E_TYPE_MISMATCH")
                return
            if pattern.parts and len(pattern.parts) >= 2:
                err_type = scrutinee_norm.err
                if isinstance(err_type, ast.NamedType):
                    err_decl = self.error_sets.get(err_type.name)
                else:
                    err_decl = None
                if err_decl is None or pattern.parts[0] != err_decl.name or pattern.parts[1] not in err_decl.tags:
                    self.issue("error", f"error pattern {'.'.join(pattern.parts)} incompatible with scrutinee {self.type_text(scrutinee)}", summary)
            return
        if isinstance(pattern, ast.EnumPattern):
            scrutinee_norm = self.normalize_type(scrutinee)
            enum_decl = self.enums.get(scrutinee_norm.name) if isinstance(scrutinee_norm, ast.NamedType) else None
            if enum_decl is None or not pattern.parts or pattern.parts[0] != enum_decl.name:
                self.issue("error", f"enum pattern {'.'.join(pattern.parts)} incompatible with scrutinee {self.type_text(scrutinee)}", summary)
                return
            variant_name = pattern.parts[1] if len(pattern.parts) > 1 else ""
            fields = {f.name: f.typ for f in self.find_variant_fields(enum_decl, variant_name)}
            for field_name, subpattern in pattern.fields:
                if field_name not in fields:
                    self.issue("error", f"enum pattern {'.'.join(pattern.parts)} names unknown field {field_name}", summary)
                    continue
                self.bind_pattern(subpattern, fields[field_name], scopes, summary)
            return
        raise TypeError(f"unsupported pattern {type(pattern)!r}")

    def cover_key(self, pattern: ast.Pattern, scrutinee: TypeLike) -> str:
        if isinstance(pattern, ast.WildcardPattern | ast.NamePattern):
            return "*"
        if isinstance(pattern, ast.NonePattern):
            return "none"
        if isinstance(pattern, ast.SomePattern):
            return "some"
        if isinstance(pattern, ast.LiteralPattern):
            if isinstance(pattern.value, ast.BoolExpr):
                return "true" if pattern.value.value else "false"
            if isinstance(pattern.value, ast.UnitExpr):
                return "unit"
        if isinstance(pattern, ast.OkPattern):
            return "ok"
        if isinstance(pattern, ast.ErrorPattern):
            if pattern.parts is None:
                return "error"
            return f"error:{'.'.join(pattern.parts)}"
        if isinstance(pattern, ast.EnumPattern):
            return ".".join(pattern.parts)
        return "?"

    def missing_coverage(self, scrutinee: TypeLike, covered: list[str]) -> list[str]:
        if "*" in covered:
            return []
        scrutinee_norm = self.normalize_type(scrutinee)
        if self.assignable(scrutinee_norm, BOOL_TYPE):
            missing = [name for name in ["true", "false"] if name not in covered]
            return missing
        if self.option_inner_type(scrutinee_norm) is not None:
            missing = [name for name in ["some", "none"] if name not in covered]
            return missing
        if isinstance(scrutinee_norm, ast.ResultType):
            missing = []
            if "ok" not in covered:
                missing.append("ok(...)")
            if "error" in covered:
                return missing
            err_type = self.normalize_type(scrutinee_norm.err)
            if isinstance(err_type, ast.NamedType) and err_type.name in self.error_sets:
                decl = self.error_sets[err_type.name]
                covered_tags: set[str] = set()
                prefix = f"{decl.name}."
                for item in covered:
                    if not item.startswith("error:"):
                        continue
                    key = item[len("error:"):]
                    if key.startswith(prefix):
                        tag = key[len(prefix):]
                        if tag in decl.tags:
                            covered_tags.add(tag)
                missing.extend(f"error({decl.name}.{tag})" for tag in decl.tags if tag not in covered_tags)
                return missing
            if not any(item.startswith("error:") for item in covered):
                missing.append("error ...")
            return missing
        if self.assignable(scrutinee_norm, UNIT_TYPE):
            return [] if "unit" in covered else ["unit"]
        if isinstance(scrutinee_norm, ast.NamedType) and scrutinee_norm.name in self.enums:
            decl = self.enums[scrutinee_norm.name]
            keys = {f"{decl.name}.{variant.name}" for variant in decl.variants}
            return sorted(key for key in keys if key not in covered)
        return []

    def unify_arm_types(self, arm_types: list[TypeLike], expected: ast.Type | None) -> TypeLike:
        if expected is not None and arm_types and all(self.return_assignable(arm, expected) for arm in arm_types):
            return self.normalize_type(expected)
        if not arm_types:
            return UnknownType("empty match")
        current = self.normalize_type(arm_types[0])
        for arm in arm_types[1:]:
            arm_norm = self.normalize_type(arm)
            if self.assignable(arm_norm, current):
                continue
            if self.assignable(current, arm_norm):
                current = arm_norm
                continue
            return UnknownType("incompatible match arms")
        return current

    def lookup_name(self, name: str, scopes: list[Scope]) -> TypeLike:
        for scope in reversed(scopes):
            if name in scope.bindings:
                return self.normalize_type(scope.bindings[name])
        if name in self.const_types:
            return self.normalize_type(self.const_types[name])
        if name in self.functions:
            return UnknownType("function value")
        return UnknownType(f"unresolved name {name}")

    def lookup_mutable(self, name: str, scopes: list[Scope]) -> bool:
        for scope in reversed(scopes):
            if name in scope.mutability:
                return scope.mutability[name]
        return False

    def lookup_dotted(self, parts: list[str]) -> TypeLike:
        if len(parts) >= 2 and parts[0] in self.enums:
            enum_decl = self.enums[parts[0]]
            if any(v.name == parts[1] for v in enum_decl.variants):
                return ast.NamedType(enum_decl.name)
        if len(parts) >= 2 and parts[0] in self.error_sets:
            err_decl = self.error_sets[parts[0]]
            if parts[1] in err_decl.tags:
                return ast.NamedType(err_decl.name)
        imported_name = self.imported_target_name_from_parts(parts)
        if imported_name is not None and imported_name in self.imported_signatures:
            sig = self.imported_signatures[imported_name]
            return parse_type_text(sig.return_type)
        dotted_name = '.'.join(parts)
        if parts and parts[0] in self.imports:
            return UnknownType("import member")
        if any(dotted_name == module_name or dotted_name.startswith(module_name + '.') for module_name in self.imports.values()):
            return UnknownType("import member")
        return UnknownType(f"unresolved dotted name {'.'.join(parts)}")

    def imported_target_name(self, callee: ast.Expr) -> str | None:
        if isinstance(callee, ast.DottedExpr):
            return self.imported_target_name_from_parts(callee.parts)
        return None

    def imported_target_name_from_parts(self, parts: list[str]) -> str | None:
        if not parts:
            return None
        if parts[0] in self.imports:
            suffix = '.'.join(parts[1:])
            base = self.imports[parts[0]]
            return f'{base}.{suffix}' if suffix else base
        candidate = '.'.join(parts)
        if any(candidate == module_name or candidate.startswith(module_name + '.') for module_name in self.imports.values()):
            return candidate
        return None

    def imported_function_signature(self, callee: ast.Expr) -> FunctionOwnershipSignature | None:
        name = self.imported_target_name(callee)
        if name is None:
            return None
        return self.imported_signatures.get(name)

    def imported_param_type(self, sig: FunctionOwnershipSignature, idx: int) -> ast.Type | None:
        if idx >= len(sig.param_types):
            return None
        return parse_type_text(sig.param_types[idx])

    def lookup_attr_type(self, obj_type: TypeLike, attr: str) -> TypeLike:
        obj_norm = self.unwrap_ref(self.normalize_type(obj_type))
        if attr == "len" and (self.assignable(obj_norm, STR_TYPE) or self.generic_name(obj_norm) in {"Slice", "Array"}):
            return U64_TYPE
        if isinstance(obj_norm, ast.NamedType):
            fields = self.lookup_record_fields(obj_norm.name)
            if attr in fields:
                return self.normalize_type(fields[attr])
        return UnknownType(f"unknown attribute {attr}")

    def index_result_type(self, obj_type: TypeLike) -> TypeLike:
        obj_norm = self.unwrap_ref(self.normalize_type(obj_type))
        if self.assignable(obj_norm, STR_TYPE):
            return U8_TYPE
        if isinstance(obj_norm, ast.GenericType) and obj_norm.name in {"Slice", "Array"} and obj_norm.args:
            arg0 = obj_norm.args[0]
            if isinstance(arg0, ast.Type):
                return self.normalize_type(arg0)
        return UnknownType("index on non-indexable value")

    def slice_result_type(self, obj_type: TypeLike) -> TypeLike:
        obj_norm = self.unwrap_ref(self.normalize_type(obj_type))
        if self.assignable(obj_norm, STR_TYPE):
            return STR_TYPE
        if isinstance(obj_norm, ast.GenericType) and obj_norm.name == "Slice":
            return obj_norm
        if isinstance(obj_norm, ast.GenericType) and obj_norm.name == "Array" and obj_norm.args:
            arg0 = obj_norm.args[0]
            if isinstance(arg0, ast.Type):
                return ast.GenericType("Slice", [self.normalize_type(arg0)])
        return UnknownType("slice on non-sliceable value")

    def iterable_element_type(self, typ: TypeLike) -> TypeLike:
        typ_norm = self.unwrap_ref(self.normalize_type(typ))
        if self.assignable(typ_norm, STR_TYPE):
            return U8_TYPE
        if isinstance(typ_norm, ast.GenericType) and typ_norm.name in {"Slice", "Array"} and typ_norm.args:
            arg0 = typ_norm.args[0]
            if isinstance(arg0, ast.Type):
                return self.normalize_type(arg0)
        if isinstance(typ_norm, ast.GenericType) and typ_norm.name == "Range" and typ_norm.args:
            arg0 = typ_norm.args[0]
            if isinstance(arg0, ast.Type):
                return self.normalize_type(arg0)
        return UnknownType("non-iterable")

    def lookup_record_fields(self, name: str) -> dict[str, ast.Type]:
        if name in self.structs:
            return {field.name: self.normalize_type(field.typ) for field in self.structs[name].fields}
        if name in self.resources:
            return {field.name: self.normalize_type(field.typ) for field in self.resources[name].fields}
        return {}

    def find_variant_fields(self, enum_decl: ast.EnumDecl | None, variant_name: str) -> list[ast.Field]:
        if enum_decl is None:
            return []
        for variant in enum_decl.variants:
            if variant.name == variant_name:
                return variant.fields
        return []

    def generic_name(self, typ: TypeLike) -> str | None:
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.GenericType):
            return typ_norm.name
        return None

    def literal_expected_type(self, typ: ast.Type | None) -> ast.Type | None:
        if typ is None:
            return None
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.ResultType):
            return typ_norm.ok
        return typ_norm

    def option_inner_type(self, typ: TypeLike | None) -> ast.Type | None:
        if typ is None:
            return None
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.OptionalType):
            return typ_norm.inner
        return None

    def is_integer_type(self, typ: ast.Type | None) -> bool:
        typ_norm = self.normalize_type(typ) if typ is not None else None
        return isinstance(typ_norm, ast.NamedType) and typ_norm.name in INTEGER_NAMES

    def is_integer_like(self, typ: TypeLike) -> bool:
        typ_norm = self.normalize_type(typ)
        return isinstance(typ_norm, ast.NamedType) and typ_norm.name in INTEGER_NAMES

    def unwrap_ref(self, typ: TypeLike | None) -> TypeLike | None:
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.GenericType) and typ_norm.name in {"Ref", "RefConst"} and typ_norm.args:
            arg0 = typ_norm.args[0]
            if isinstance(arg0, ast.Type):
                return self.normalize_type(arg0)
        return typ_norm

    def protocol_name_for_type(self, typ: ast.Type | None) -> str | None:
        if typ is None:
            return None
        inner = self.unwrap_containers(typ)
        if isinstance(inner, ast.NamedType) and inner.name in self.resources:
            return self.resources[inner.name].protocol
        return None

    def tracked_child_paths(self, typ: ast.Type | None, prefix: tuple[str, ...] = (), seen: set[str] | None = None) -> tuple[tuple[str, ...], ...]:
        if typ is None:
            return ()
        seen = seen or set()
        inner = self.unwrap_containers(typ)
        if isinstance(inner, ast.NamedType) and inner.name in self.resources:
            return (prefix,) if prefix else tuple((field.name,) for field in self.resources[inner.name].fields if self.resource_type_name(field.typ) is not None) or ((),)
        if isinstance(inner, ast.NamedType) and inner.name in self.structs and inner.name not in seen:
            next_seen = set(seen)
            next_seen.add(inner.name)
            paths: list[tuple[str, ...]] = []
            for field in self.structs[inner.name].fields:
                field_paths = self.tracked_child_paths(field.typ, prefix + (field.name,), next_seen)
                paths.extend(field_paths)
            return tuple(paths)
        if (
            isinstance(inner, ast.GenericType)
            and inner.name == 'Array'
            and len(inner.args) == 2
            and isinstance(inner.args[0], ast.Type)
            and isinstance(inner.args[1], int)
            and inner.args[1] >= 0
        ):
            paths: list[tuple[str, ...]] = []
            for idx in range(inner.args[1]):
                elem_paths = self.tracked_child_paths(inner.args[0], prefix + (str(idx),), seen)
                paths.extend(elem_paths)
            return tuple(paths)
        return ()

    def unwrap_containers(self, typ: ast.Type) -> ast.Type:
        if isinstance(typ, ast.OptionalType):
            return self.unwrap_containers(typ.inner)
        if isinstance(typ, ast.ResultType):
            return self.unwrap_containers(typ.ok)
        return typ

    def type_contains_tracked_ownership(self, typ: ast.Type | None, seen: set[str] | None = None) -> bool:
        if typ is None:
            return False
        seen = seen or set()
        inner = self.unwrap_containers(typ)
        if isinstance(inner, ast.GenericType):
            if inner.name in {'Ref', 'RefConst', 'Slice'}:
                return False
            if inner.name == 'Array' and inner.args and isinstance(inner.args[0], ast.Type):
                return self.type_contains_tracked_ownership(inner.args[0], seen)
            return False
        if not isinstance(inner, ast.NamedType):
            return False
        if inner.name in self.resources:
            return True
        if inner.name in seen:
            return False
        if inner.name in self.structs:
            next_seen = set(seen)
            next_seen.add(inner.name)
            return any(self.type_contains_tracked_ownership(field.typ, next_seen) for field in self.structs[inner.name].fields)
        return False

    def resource_type_name(self, typ: ast.Type | None) -> str | None:
        if typ is None:
            return None
        inner = self.unwrap_containers(typ)
        if isinstance(inner, ast.NamedType) and inner.name in self.resources:
            return inner.name
        if isinstance(inner, ast.NamedType) and inner.name in self.structs and self.type_contains_tracked_ownership(inner):
            return inner.name
        if isinstance(inner, ast.GenericType) and inner.name == 'Array' and self.type_contains_tracked_ownership(inner):
            return format_type(inner)
        return None

    def type_facts_for_type(self, typ: TypeLike | None) -> TypeFacts:
        typ_norm = self.normalize_type(typ)
        ref_mode: str | None = None
        is_ref = False
        if isinstance(typ_norm, ast.GenericType) and typ_norm.name in {'Ref', 'RefConst'}:
            is_ref = True
            ref_mode = 'mut' if typ_norm.name == 'Ref' else 'const'
        normalized_ast = typ_norm if isinstance(typ_norm, ast.Type) else None
        tracked = self.type_contains_tracked_ownership(normalized_ast)
        protocol_name = self.protocol_name_for_type(normalized_ast)
        terminal_states: tuple[str, ...] = ()
        resource_name = self.resource_type_name(normalized_ast)
        if protocol_name is not None:
            proto = next((decl for decl in self.module.decls if isinstance(decl, ast.ProtocolDecl) and decl.name == protocol_name), None)
            if proto is not None:
                terminal_states = tuple(proto.terminal)
        copyable = not tracked and not is_ref
        return TypeFacts(
            type_text=self.type_text(typ),
            normalized_type_text=self.type_text(typ_norm),
            is_ref=is_ref,
            ref_mode=ref_mode,
            is_tracked=tracked,
            is_protocol_resource=protocol_name is not None,
            protocol_name=protocol_name,
            tracked_children=self.tracked_child_paths(normalized_ast),
            terminal_states=terminal_states,
            copyable=copyable,
            resource_type_name=resource_name,
        )

    def normalize_type(self, typ: TypeLike | None) -> TypeLike:
        if typ is None or isinstance(typ, UnknownType | NoneLiteralType):
            return typ
        if isinstance(typ, ast.OptionalType):
            return ast.OptionalType(self.materialize(self.normalize_type(typ.inner)))
        if isinstance(typ, ast.ResultType):
            return ast.ResultType(self.materialize(self.normalize_type(typ.ok)), self.materialize(self.normalize_type(typ.err)))
        if isinstance(typ, ast.GenericType):
            if typ.name == "Option" and len(typ.args) == 1 and isinstance(typ.args[0], ast.Type):
                return ast.OptionalType(self.materialize(self.normalize_type(typ.args[0])))
            args: list[ast.Type | int] = []
            for arg in typ.args:
                if isinstance(arg, ast.Type):
                    args.append(self.materialize(self.normalize_type(arg)))
                else:
                    args.append(arg)
            return ast.GenericType(typ.name, args)
        return typ

    def type_key(self, typ: TypeLike) -> object:
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, UnknownType):
            return ("unknown", typ_norm.reason)
        if isinstance(typ_norm, NoneLiteralType):
            return ("none",)
        if isinstance(typ_norm, ast.NamedType):
            return ("named", typ_norm.name)
        if isinstance(typ_norm, ast.OptionalType):
            return ("optional", self.type_key(typ_norm.inner))
        if isinstance(typ_norm, ast.ResultType):
            return ("result", self.type_key(typ_norm.ok), self.type_key(typ_norm.err))
        if isinstance(typ_norm, ast.GenericType):
            inner = []
            for arg in typ_norm.args:
                if isinstance(arg, ast.Type):
                    inner.append(self.type_key(arg))
                else:
                    inner.append(("int", arg))
            return ("generic", typ_norm.name, tuple(inner))
        raise TypeError(f"unsupported type {type(typ_norm)!r}")

    def assignable(self, actual: TypeLike, expected: TypeLike) -> bool:
        if isinstance(actual, UnknownType) or isinstance(expected, UnknownType):
            return True
        actual_norm = self.normalize_type(actual)
        expected_norm = self.normalize_type(expected)
        if isinstance(actual_norm, NoneLiteralType):
            return isinstance(expected_norm, ast.OptionalType)
        if isinstance(expected_norm, NoneLiteralType):
            return isinstance(actual_norm, ast.OptionalType)
        return self.type_key(actual_norm) == self.type_key(expected_norm)

    def return_assignable(self, actual: TypeLike, declared: ast.Type) -> bool:
        declared_norm = self.normalize_type(declared)
        if self.assignable(actual, declared_norm):
            return True
        if isinstance(declared_norm, ast.ResultType):
            return self.assignable(actual, declared_norm.ok) or self.assignable(actual, declared_norm.err)
        return False

    def materialize(self, typ: TypeLike) -> ast.Type:
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.Type):
            return typ_norm
        return ast.NamedType("_Unknown")

    def type_text(self, typ: TypeLike) -> str:
        typ_norm = self.normalize_type(typ)
        if isinstance(typ_norm, ast.Type):
            return format_type(typ_norm)
        if isinstance(typ_norm, NoneLiteralType):
            return "none"
        return f"<{typ_norm.reason}>"

    def record_expr(self, summary: TypedFunction, expr: ast.Expr, kind: str, typ: TypeLike) -> None:
        facts = self.type_facts_for_type(typ)
        place = sem_place_for_expr(expr)
        borrow_mode = None
        if isinstance(expr, ast.UnaryExpr) and expr.op == 'borrow':
            borrow_mode = facts.ref_mode or 'const'
            place = sem_place_for_expr(expr.expr)
        summary.exprs.append(
            TypedExprRecord(
                text=format_expr_inline(expr),
                kind=kind,
                type_text=self.type_text(typ),
                place=place.to_path() if place is not None else None,
                ref_mode=facts.ref_mode,
                borrow_mode=borrow_mode,
                tracked=facts.is_tracked,
                protocol=facts.protocol_name,
                copyable=facts.copyable,
            )
        )


@dataclass(slots=True)
class NoneFn:
    name: str = "<pattern>"
    effects: list[str] = field(default_factory=list)
    return_type: ast.Type = field(default_factory=lambda: ast.NamedType("Unit"))


def typecheck_module(module: ast.Module, imported_signatures: dict[str, FunctionOwnershipSignature] | None = None) -> TypecheckSummary:
    return TypeChecker(module, imported_signatures=imported_signatures).typecheck()
