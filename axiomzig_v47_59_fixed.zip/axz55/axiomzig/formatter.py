from __future__ import annotations

from . import ast


INDENT = "    "


def format_module(module: ast.Module) -> str:
    parts: list[str] = []
    parts.append(f"module {'.'.join(module.path)};")
    if module.imports:
        parts.append("")
        for imp in module.imports:
            parts.append(f"import {'.'.join(imp.path)};")
    if module.decls:
        parts.append("")
        for idx, decl in enumerate(module.decls):
            if idx > 0:
                parts.append("")
            parts.extend(format_top_decl(decl))
    return "\n".join(parts) + "\n"


def _format_public_api_annotations(decl) -> list[str]:
    lines: list[str] = []
    stability = getattr(decl, 'stability', 'stable')
    if stability == 'experimental':
        lines.append('@experimental')
    elif stability == 'deprecated':
        args = [f'reason="{_format_annotation_string(getattr(decl, "deprecated_reason", None) or "")}"']
        replacement = getattr(decl, 'replacement', None)
        if replacement:
            args.append(f'replacement="{_format_annotation_string(replacement)}"')
        lines.append(f"@deprecated({', '.join(args)})")
    since = getattr(decl, 'since', None)
    if since:
        lines.append(f'@since("{_format_annotation_string(since)}")')
    return lines


def format_top_decl(decl: ast.TopDecl) -> list[str]:
    if isinstance(decl, ast.ConstDecl):
        return [f"const {decl.name}: {format_type(decl.typ)} = {format_expr_inline(decl.value)};"]
    if isinstance(decl, ast.StructDecl):
        lines = [f"struct {decl.name} {{"]
        lines.extend(f"{INDENT}{f.name}: {format_type(f.typ)};" for f in decl.fields)
        lines.append("}")
        return lines
    if isinstance(decl, ast.EnumDecl):
        lines = [f"enum {decl.name} {{"]
        for variant in decl.variants:
            if variant.fields:
                lines.append(f"{INDENT}{variant.name} {{")
                lines.extend(f"{INDENT*2}{f.name}: {format_type(f.typ)};" for f in variant.fields)
                lines.append(f"{INDENT}}};")
            else:
                lines.append(f"{INDENT}{variant.name};")
        lines.append("}")
        return lines
    if isinstance(decl, ast.ErrorSetDecl):
        lines = [f"error_set {decl.name} {{"]
        lines.extend(f"{INDENT}{tag};" for tag in decl.tags)
        lines.append("}")
        return lines
    if isinstance(decl, ast.ProtocolDecl):
        lines = _format_public_api_annotations(decl)
        pub_prefix = 'pub ' if decl.is_public else ''
        lines.append(f"{pub_prefix}protocol {decl.name} {{")
        lines.append(f"{INDENT}states {{ {', '.join(decl.states)} }}")
        lines.append(f"{INDENT}init {decl.init};")
        lines.append(f"{INDENT}terminal {{ {', '.join(decl.terminal)} }}")
        lines.append(f"{INDENT}transitions {{")
        for tr in decl.transitions:
            lines.append(f"{INDENT*2}{tr.name}: {tr.source} -> {tr.target};")
        lines.append(f"{INDENT}}}")
        lines.append("}")
        return lines
    if isinstance(decl, ast.ResourceDecl):
        lines = _format_public_api_annotations(decl)
        pub_prefix = 'pub ' if decl.is_public else ''
        lines.append(f"{pub_prefix}resource {decl.name} {{")
        if decl.protocol is not None:
            lines.append(f"{INDENT}protocol: {decl.protocol};")
        lines.append(f"{INDENT}fields {{")
        lines.extend(f"{INDENT*2}{f.name}: {format_type(f.typ)};" for f in decl.fields)
        lines.append(f"{INDENT}}}")
        lines.append("}")
        return lines
    if isinstance(decl, ast.FnDecl):
        params = ", ".join(f"{p.name}: {format_type(p.typ)}" for p in decl.params)
        effects = ", ".join(decl.effects)
        lines = _format_public_api_annotations(decl)
        pub_prefix = 'pub ' if decl.is_public else ''
        lines.append(f"{pub_prefix}fn {decl.name}({params}) -> {format_type(decl.return_type)} effects({effects}) {{")
        lines.extend(format_block_body(decl.body, 1))
        lines.append("}")
        return lines
    raise TypeError(f"unsupported top decl: {type(decl)!r}")


def _format_annotation_string(value: str) -> str:
    return (
        str(value)
        .replace('\\', '\\\\')
        .replace('\n', '\\n')
        .replace('\t', '\\t')
        .replace('"', '\\"')
    )

def format_block_body(block: ast.Block, depth: int) -> list[str]:
    lines: list[str] = []
    for stmt in block.statements:
        lines.extend(format_stmt(stmt, depth))
    return lines


def emit_prefixed_expr_stmt(prefix: str, expr: ast.Expr, suffix: str = ";") -> list[str]:
    expr_lines = format_expr_lines(expr)
    if len(expr_lines) == 1:
        return [f"{prefix}{expr_lines[0]}{suffix}"]
    continuation = prefix[: len(prefix) - len(prefix.lstrip(" "))]
    lines = [f"{prefix}{expr_lines[0]}"]
    lines.extend(continuation + line for line in expr_lines[1:])
    lines[-1] = lines[-1] + suffix
    return lines


def format_stmt(stmt: ast.Stmt, depth: int) -> list[str]:
    pad = INDENT * depth
    if isinstance(stmt, ast.Block):
        lines = [f"{pad}{{"]
        lines.extend(format_block_body(stmt, depth + 1))
        lines.append(f"{pad}}}")
        return lines
    if isinstance(stmt, ast.LetStmt):
        annot = f": {format_type(stmt.typ)}" if stmt.typ else ""
        return emit_prefixed_expr_stmt(f"{pad}let {stmt.name}{annot} = ", stmt.value)
    if isinstance(stmt, ast.VarStmt):
        annot = f": {format_type(stmt.typ)}" if stmt.typ else ""
        return emit_prefixed_expr_stmt(f"{pad}var {stmt.name}{annot} = ", stmt.value)
    if isinstance(stmt, ast.AssignStmt):
        return emit_prefixed_expr_stmt(f"{pad}{format_expr_inline(stmt.target)} {stmt.op} ", stmt.value)
    if isinstance(stmt, ast.ExprStmt):
        return emit_prefixed_expr_stmt(f"{pad}", stmt.expr)
    if isinstance(stmt, ast.ReturnStmt):
        if stmt.expr is None:
            return [f"{pad}return;"]
        return emit_prefixed_expr_stmt(f"{pad}return ", stmt.expr)
    if isinstance(stmt, ast.IfStmt):
        lines = [f"{pad}if ({format_expr_inline(stmt.cond)}) {{"]
        lines.extend(format_block_body(stmt.then_block, depth + 1))
        lines.append(f"{pad}}}")
        if stmt.else_branch is not None:
            if isinstance(stmt.else_branch, ast.Block):
                lines[-1] += " else {"
                lines.extend(format_block_body(stmt.else_branch, depth + 1))
                lines.append(f"{pad}}}")
            else:
                nested = format_stmt(stmt.else_branch, depth)
                lines[-1] += " else " + nested[0].lstrip()
                lines.extend(nested[1:])
        return lines
    if isinstance(stmt, ast.WhileStmt):
        lines = [f"{pad}while ({format_expr_inline(stmt.cond)}) {{"]
        lines.extend(format_block_body(stmt.body, depth + 1))
        lines.append(f"{pad}}}")
        return lines
    if isinstance(stmt, ast.ForStmt):
        lines = [f"{pad}for ({stmt.name}: {format_type(stmt.typ)} in {format_expr_inline(stmt.iterable)}) {{"]
        lines.extend(format_block_body(stmt.body, depth + 1))
        lines.append(f"{pad}}}")
        return lines
    if isinstance(stmt, ast.BreakStmt):
        return [f"{pad}break;"]
    if isinstance(stmt, ast.ContinueStmt):
        return [f"{pad}continue;"]
    if isinstance(stmt, ast.DeferStmt):
        inner = format_stmt(stmt.stmt, depth)
        first = inner[0][len(pad):] if inner[0].startswith(pad) else inner[0]
        return [f"{pad}defer {first}"] + inner[1:]
    if isinstance(stmt, ast.ErrDeferStmt):
        inner = format_stmt(stmt.stmt, depth)
        first = inner[0][len(pad):] if inner[0].startswith(pad) else inner[0]
        return [f"{pad}errdefer {first}"] + inner[1:]
    raise TypeError(f"unsupported stmt: {type(stmt)!r}")


def format_type(typ: ast.Type | None) -> str:
    if typ is None:
        return "_"
    if isinstance(typ, ast.NamedType):
        return typ.name
    if isinstance(typ, ast.GenericType):
        args = ", ".join(format_type(arg) if isinstance(arg, ast.Type) else str(arg) for arg in typ.args)
        return f"{typ.name}<{args}>"
    if isinstance(typ, ast.OptionalType):
        return f"{format_type(typ.inner)}?"
    if isinstance(typ, ast.ResultType):
        return f"{format_type(typ.ok)}!{format_type(typ.err)}"
    raise TypeError(f"unsupported type: {type(typ)!r}")


def format_expr_lines(expr: ast.Expr, indent_level: int = 0) -> list[str]:
    pad = INDENT * indent_level
    if isinstance(expr, ast.MatchExpr):
        lines = [f"{pad}match {format_expr_inline(expr.expr)} {{"]
        for arm in expr.arms:
            arm_expr_lines = format_expr_lines(arm.expr, indent_level + 1)
            if len(arm_expr_lines) == 1:
                lines.append(f"{pad}{INDENT}{format_pattern(arm.pattern)} -> {arm_expr_lines[0].lstrip()},")
            else:
                first = arm_expr_lines[0].lstrip()
                lines.append(f"{pad}{INDENT}{format_pattern(arm.pattern)} -> {first}")
                lines.extend(arm_expr_lines[1:])
                lines[-1] = lines[-1] + ','
        lines.append(f"{pad}}}")
        return lines
    return [pad + format_expr_inline(expr)]


def format_expr_inline(expr: ast.Expr) -> str:
    if isinstance(expr, ast.NameExpr):
        return expr.name
    if isinstance(expr, ast.DottedExpr):
        return ".".join(expr.parts)
    if isinstance(expr, ast.IntExpr):
        return expr.raw
    if isinstance(expr, ast.StringExpr):
        escaped = (
            expr.value.replace("\\", "\\\\")
            .replace("\n", "\\n")
            .replace("\t", "\\t")
            .replace('"', '\\"')
        )
        return f'"{escaped}"'
    if isinstance(expr, ast.BoolExpr):
        return "true" if expr.value else "false"
    if isinstance(expr, ast.UnitExpr):
        return "unit"
    if isinstance(expr, ast.NoneExpr):
        return "none"
    if isinstance(expr, ast.SomeExpr):
        return f"some({format_expr_inline(expr.value)})"
    if isinstance(expr, ast.UnaryExpr):
        return f"{expr.op} {format_expr_inline(expr.expr)}"
    if isinstance(expr, ast.BinaryExpr):
        return f"{format_expr_inline(expr.left)} {expr.op} {format_expr_inline(expr.right)}"
    if isinstance(expr, ast.RangeExpr):
        return f"{format_expr_inline(expr.start)}..{format_expr_inline(expr.stop)}"
    if isinstance(expr, ast.CallExpr):
        args = ", ".join(format_expr_inline(arg) for arg in expr.args)
        return f"{format_expr_inline(expr.callee)}({args})"
    if isinstance(expr, ast.AttrExpr):
        return f"{format_expr_inline(expr.obj)}.{expr.name}"
    if isinstance(expr, ast.IndexExpr):
        return f"{format_expr_inline(expr.obj)}[{format_expr_inline(expr.index)}]"
    if isinstance(expr, ast.SliceExpr):
        start = "" if expr.start is None else format_expr_inline(expr.start)
        stop = "" if expr.stop is None else format_expr_inline(expr.stop)
        return f"{format_expr_inline(expr.obj)}[{start}..{stop}]"
    if isinstance(expr, ast.TryExpr):
        return f"{format_expr_inline(expr.expr)}?"
    if isinstance(expr, ast.CatchExpr):
        if expr.binding is not None and expr.handler is not None:
            inner_lines = format_block_body(expr.handler, 1)
            if inner_lines:
                body = "{ " + " ".join(l.strip() for l in inner_lines) + " }"
            else:
                body = "{}"
            return f"{format_expr_inline(expr.expr)} catch |{expr.binding}| {body}"
        return f"{format_expr_inline(expr.expr)} catch {format_expr_inline(expr.fallback)}"
    if isinstance(expr, ast.CastExpr):
        return f"@cast({format_type(expr.typ)}, {format_expr_inline(expr.expr)})"
    if isinstance(expr, ast.StructLiteralExpr):
        items = ", ".join(f"{name}: {format_expr_inline(value)}" for name, value in expr.fields)
        return f"{expr.name} {{ {items} }}"
    if isinstance(expr, ast.EnumLiteralExpr):
        items = ", ".join(f"{name}: {format_expr_inline(value)}" for name, value in expr.fields)
        return f"{expr.enum_name}.{expr.variant_name}" if not items else f"{expr.enum_name}.{expr.variant_name} {{ {items} }}"
    if isinstance(expr, ast.MatchExpr):
        return "\n".join(format_expr_lines(expr))
    raise TypeError(f"unsupported expr: {type(expr)!r}")


def format_pattern(pattern: ast.Pattern) -> str:
    if isinstance(pattern, ast.WildcardPattern):
        return "_"
    if isinstance(pattern, ast.NamePattern):
        return pattern.name
    if isinstance(pattern, ast.LiteralPattern):
        return format_expr_inline(pattern.value)
    if isinstance(pattern, ast.SomePattern):
        return f"some({format_pattern(pattern.inner)})"
    if isinstance(pattern, ast.NonePattern):
        return "none"
    if isinstance(pattern, ast.OkPattern):
        return f"ok({format_pattern(pattern.inner)})"
    if isinstance(pattern, ast.ErrorPattern):
        return "error(_)" if pattern.parts is None else f"error({'.'.join(pattern.parts)})"
    if isinstance(pattern, ast.EnumPattern):
        if pattern.fields:
            items = ", ".join(f"{name}: {format_pattern(value)}" for name, value in pattern.fields)
            return f"{'.'.join(pattern.parts)} {{ {items} }}"
        return ".".join(pattern.parts)
    raise TypeError(f"unsupported pattern: {type(pattern)!r}")
