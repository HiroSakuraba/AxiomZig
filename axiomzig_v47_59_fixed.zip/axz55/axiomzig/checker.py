from __future__ import annotations

from dataclasses import dataclass

from . import ast
from .elaborate import elaborate_module
from .ownership import analyze_ownership
from .ownership_signatures import FunctionOwnershipSignature
from .resolve import resolve_module
from .typecheck import typecheck_module


@dataclass(slots=True)
class Issue:
    level: str
    message: str
    code: str | None = None


BUILTIN_EFFECTS = {
    "alloc",
    "free",
    "error",
    "recurse",
    "io",
    "protocol_step",
}


def check_module(module: ast.Module, imported_signatures: dict[str, FunctionOwnershipSignature] | None = None) -> list[Issue]:
    issues: list[Issue] = []

    resolution = resolve_module(module)
    for item in resolution.issues:
        issues.append(Issue(item.level, item.message, getattr(item, 'code', None)))

    elaboration = elaborate_module(module)
    for item in elaboration.issues:
        issues.append(Issue(item.level, item.message, getattr(item, 'code', None) or None))

    type_summary = typecheck_module(module, imported_signatures=imported_signatures)
    for item in type_summary.issues:
        issues.append(Issue(item.level, item.message, getattr(item, 'code', None)))

    ownership = analyze_ownership(module, imported_signatures=imported_signatures)
    for item in ownership.issues:
        issues.append(Issue(item.level, item.message, getattr(item, 'code', None)))

    for decl in module.decls:
        if isinstance(decl, ast.ProtocolDecl):
            issues.extend(check_protocol(decl))
        elif isinstance(decl, ast.FnDecl):
            issues.extend(check_fn(decl))
        elif isinstance(decl, ast.ErrorSetDecl):
            issues.extend(check_error_set(decl))
    issues.extend(check_recurse_effects(module))
    # Dedup by (level, message); if two issues share the same key, prefer the one with a code.
    best: dict[tuple[str, str], Issue] = {}
    order: list[tuple[str, str]] = []
    for issue in issues:
        key = (issue.level, issue.message)
        if key not in best:
            best[key] = issue
            order.append(key)
        elif best[key].code is None and issue.code is not None:
            best[key] = issue  # upgrade to code-bearing version
    return [best[k] for k in order]


def check_error_set(decl: ast.ErrorSetDecl) -> list[Issue]:
    issues: list[Issue] = []
    seen: set[str] = set()
    for tag in decl.tags:
        if tag in seen:
            issues.append(Issue("error", f"error_set {decl.name} repeats tag {tag}"))
        seen.add(tag)
    return issues


def check_protocol(decl: ast.ProtocolDecl) -> list[Issue]:
    issues: list[Issue] = []
    state_set = set(decl.states)
    if decl.init not in state_set:
        issues.append(Issue("error", f"protocol {decl.name} init state {decl.init} not in states"))
    missing_terminal = [s for s in decl.terminal if s not in state_set]
    for state in missing_terminal:
        issues.append(Issue("error", f"protocol {decl.name} terminal state {state} not in states"))
    transition_names: set[str] = set()
    for tr in decl.transitions:
        if tr.name in transition_names:
            issues.append(Issue("error", f"protocol {decl.name} repeats transition name {tr.name}"))
        transition_names.add(tr.name)
        if tr.source not in state_set:
            issues.append(Issue("error", f"protocol {decl.name} transition {tr.name} source {tr.source} not in states"))
        if tr.target not in state_set:
            issues.append(Issue("error", f"protocol {decl.name} transition {tr.name} target {tr.target} not in states"))
    return issues


def check_fn(decl: ast.FnDecl) -> list[Issue]:
    issues: list[Issue] = []
    seen_effects: set[str] = set()
    for effect in decl.effects:
        if effect in seen_effects:
            issues.append(Issue("error", f"function {decl.name} repeats effect {effect}"))
        seen_effects.add(effect)
        if effect == "trap":
            issues.append(Issue("error", f"function {decl.name} may not declare builtin effect trap", code="E_EFFECT_TRAP"))
        elif effect not in BUILTIN_EFFECTS:
            issues.append(Issue("warning", f"function {decl.name} uses non-core effect tag {effect}"))
    param_names: set[str] = set()
    for param in decl.params:
        if param.name in param_names:
            issues.append(Issue("error", f"function {decl.name} repeats parameter {param.name}"))
        param_names.add(param.name)
    return issues


def check_recurse_effects(module: ast.Module) -> list[Issue]:
    functions = {decl.name: decl for decl in module.decls if isinstance(decl, ast.FnDecl)}
    names = set(functions)
    call_graph = {name: collect_called_functions(decl.body, names) for name, decl in functions.items()}
    issues: list[Issue] = []
    for name, decl in functions.items():
        if "recurse" in decl.effects:
            continue
        if reaches_self(name, call_graph):
            issues.append(Issue("error", f"function {name} must declare effect recurse", code="E_EFFECT_RECURSE"))
    return issues


def reaches_self(name: str, call_graph: dict[str, set[str]]) -> bool:
    seen: set[str] = set()
    stack = list(call_graph.get(name, ()))
    while stack:
        current = stack.pop()
        if current == name:
            return True
        if current in seen:
            continue
        seen.add(current)
        stack.extend(call_graph.get(current, ()))
    return False


def collect_called_functions(node: ast.Node | None, function_names: set[str]) -> set[str]:
    calls: set[str] = set()
    if node is None:
        return calls
    if isinstance(node, ast.Block):
        for stmt in node.statements:
            calls.update(collect_called_functions(stmt, function_names))
        return calls
    if isinstance(node, (ast.LetStmt, ast.VarStmt)):
        return collect_called_functions(node.value, function_names)
    if isinstance(node, ast.AssignStmt):
        calls.update(collect_called_functions(node.target, function_names))
        calls.update(collect_called_functions(node.value, function_names))
        return calls
    if isinstance(node, ast.ExprStmt):
        return collect_called_functions(node.expr, function_names)
    if isinstance(node, ast.ReturnStmt):
        return collect_called_functions(node.expr, function_names)
    if isinstance(node, ast.IfStmt):
        calls.update(collect_called_functions(node.cond, function_names))
        calls.update(collect_called_functions(node.then_block, function_names))
        calls.update(collect_called_functions(node.else_branch, function_names))
        return calls
    if isinstance(node, ast.WhileStmt):
        calls.update(collect_called_functions(node.cond, function_names))
        calls.update(collect_called_functions(node.body, function_names))
        return calls
    if isinstance(node, ast.ForStmt):
        calls.update(collect_called_functions(node.iterable, function_names))
        calls.update(collect_called_functions(node.body, function_names))
        return calls
    if isinstance(node, (ast.DeferStmt, ast.ErrDeferStmt)):
        return collect_called_functions(node.stmt, function_names)
    if isinstance(node, (ast.BreakStmt, ast.ContinueStmt)):
        return calls
    if isinstance(node, ast.SomeExpr):
        return collect_called_functions(node.value, function_names)
    if isinstance(node, ast.UnaryExpr):
        return collect_called_functions(node.expr, function_names)
    if isinstance(node, ast.BinaryExpr):
        calls.update(collect_called_functions(node.left, function_names))
        calls.update(collect_called_functions(node.right, function_names))
        return calls
    if isinstance(node, ast.RangeExpr):
        calls.update(collect_called_functions(node.start, function_names))
        calls.update(collect_called_functions(node.stop, function_names))
        return calls
    if isinstance(node, ast.CallExpr):
        if isinstance(node.callee, ast.NameExpr) and node.callee.name in function_names:
            calls.add(node.callee.name)
        calls.update(collect_called_functions(node.callee, function_names))
        for arg in node.args:
            calls.update(collect_called_functions(arg, function_names))
        return calls
    if isinstance(node, ast.AttrExpr):
        return collect_called_functions(node.obj, function_names)
    if isinstance(node, ast.IndexExpr):
        calls.update(collect_called_functions(node.obj, function_names))
        calls.update(collect_called_functions(node.index, function_names))
        return calls
    if isinstance(node, ast.SliceExpr):
        calls.update(collect_called_functions(node.obj, function_names))
        calls.update(collect_called_functions(node.start, function_names))
        calls.update(collect_called_functions(node.stop, function_names))
        return calls
    if isinstance(node, ast.TryExpr):
        return collect_called_functions(node.expr, function_names)
    if isinstance(node, ast.CatchExpr):
        calls.update(collect_called_functions(node.expr, function_names))
        calls.update(collect_called_functions(node.fallback, function_names))
        return calls
    if isinstance(node, ast.CastExpr):
        return collect_called_functions(node.expr, function_names)
    if isinstance(node, ast.StructLiteralExpr):
        for _, expr in node.fields:
            calls.update(collect_called_functions(expr, function_names))
        return calls
    if isinstance(node, ast.EnumLiteralExpr):
        for _, expr in node.fields:
            calls.update(collect_called_functions(expr, function_names))
        return calls
    if isinstance(node, ast.MatchExpr):
        calls.update(collect_called_functions(node.expr, function_names))
        for arm in node.arms:
            calls.update(collect_called_functions(arm.expr, function_names))
        return calls
    if isinstance(node, (ast.NameExpr, ast.DottedExpr, ast.IntExpr, ast.StringExpr, ast.BoolExpr, ast.UnitExpr, ast.NoneExpr)):
        return calls
    raise TypeError(f"unsupported node {type(node)!r}")
