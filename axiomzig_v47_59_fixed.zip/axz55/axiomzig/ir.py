from __future__ import annotations

from dataclasses import dataclass, field

from . import ast
from .formatter import format_expr_inline, format_type
from .typecheck import Scope, TypeChecker, TypedFunction, UnknownType


@dataclass(slots=True)
class IRExpr:
    text: str
    kind: str
    type_text: str


@dataclass(slots=True)
class IRStmt:
    kind: str


@dataclass(slots=True)
class IRLet(IRStmt):
    name: str
    mutable: bool
    declared_type: str | None
    value: IRExpr


@dataclass(slots=True)
class IRAssign(IRStmt):
    target: IRExpr
    op: str
    value: IRExpr


@dataclass(slots=True)
class IRExprStmt(IRStmt):
    expr: IRExpr


@dataclass(slots=True)
class IRReturn(IRStmt):
    value: IRExpr | None


@dataclass(slots=True)
class IRIf(IRStmt):
    cond: IRExpr
    then_body: list[IRStmt]
    else_body: list[IRStmt] | None


@dataclass(slots=True)
class IRWhile(IRStmt):
    cond: IRExpr
    body: list[IRStmt]


@dataclass(slots=True)
class IRFor(IRStmt):
    name: str
    binder_type: str
    iterable: IRExpr
    body: list[IRStmt]


@dataclass(slots=True)
class IRDefer(IRStmt):
    error_only: bool
    body: IRStmt


@dataclass(slots=True)
class IRBreak(IRStmt):
    pass


@dataclass(slots=True)
class IRContinue(IRStmt):
    pass


@dataclass(slots=True)
class IRFunction:
    name: str
    params: list[tuple[str, str]]
    return_type: str
    effects: list[str]
    body: list[IRStmt]
    issues: list[str] = field(default_factory=list)


@dataclass(slots=True)
class IRModule:
    module_path: str
    functions: list[IRFunction]


class IRLowerer:
    def __init__(self, module: ast.Module):
        self.module = module
        self.checker = TypeChecker(module)

    def lower(self) -> IRModule:
        functions: list[IRFunction] = []
        for decl in self.module.decls:
            if isinstance(decl, ast.FnDecl):
                functions.append(self.lower_function(decl))
        return IRModule(module_path='.'.join(self.module.path), functions=functions)

    def lower_function(self, fn: ast.FnDecl) -> IRFunction:
        summary = TypedFunction(name=fn.name, declared_return_type=format_type(fn.return_type))
        scopes = [Scope()]
        for param in fn.params:
            scopes[-1].bindings[param.name] = param.typ
            scopes[-1].mutability[param.name] = False
        body = self.lower_block(fn.body, scopes, fn, summary)
        return IRFunction(
            name=fn.name,
            params=[(param.name, format_type(param.typ)) for param in fn.params],
            return_type=format_type(fn.return_type),
            effects=list(fn.effects),
            body=body,
            issues=[item.message for item in summary.issues],
        )

    def lower_block(self, block: ast.Block, scopes: list[Scope], fn: ast.FnDecl, summary: TypedFunction) -> list[IRStmt]:
        scopes.append(Scope())
        body = [self.lower_stmt(stmt, scopes, fn, summary) for stmt in block.statements]
        scopes.pop()
        return body

    def lower_stmt(self, stmt: ast.Stmt, scopes: list[Scope], fn: ast.FnDecl, summary: TypedFunction) -> IRStmt:
        if isinstance(stmt, ast.Block):
            return IRIf(kind='block', cond=IRExpr(text='unit', kind='UnitExpr', type_text='Unit'), then_body=self.lower_block(stmt, scopes, fn, summary), else_body=None)
        if isinstance(stmt, ast.LetStmt):
            value = self.lower_expr(stmt.value, scopes, fn, summary, stmt.typ)
            scopes[-1].bindings[stmt.name] = stmt.typ if stmt.typ is not None else self.checker.materialize(self.checker.type_of_expr(stmt.value, scopes, fn, summary, stmt.typ))
            scopes[-1].mutability[stmt.name] = False
            return IRLet(kind='let', name=stmt.name, mutable=False, declared_type=format_type(stmt.typ) if stmt.typ else None, value=value)
        if isinstance(stmt, ast.VarStmt):
            value = self.lower_expr(stmt.value, scopes, fn, summary, stmt.typ)
            scopes[-1].bindings[stmt.name] = stmt.typ if stmt.typ is not None else self.checker.materialize(self.checker.type_of_expr(stmt.value, scopes, fn, summary, stmt.typ))
            scopes[-1].mutability[stmt.name] = True
            return IRLet(kind='var', name=stmt.name, mutable=True, declared_type=format_type(stmt.typ) if stmt.typ else None, value=value)
        if isinstance(stmt, ast.AssignStmt):
            target = self.lower_expr(stmt.target, scopes, fn, summary, None)
            value = self.lower_expr(stmt.value, scopes, fn, summary, None)
            return IRAssign(kind='assign', target=target, op=stmt.op, value=value)
        if isinstance(stmt, ast.ExprStmt):
            return IRExprStmt(kind='expr', expr=self.lower_expr(stmt.expr, scopes, fn, summary, None))
        if isinstance(stmt, ast.ReturnStmt):
            return IRReturn(kind='return', value=None if stmt.expr is None else self.lower_expr(stmt.expr, scopes, fn, summary, fn.return_type))
        if isinstance(stmt, ast.IfStmt):
            cond = self.lower_expr(stmt.cond, scopes, fn, summary, ast.NamedType('Bool'))
            then_body = self.lower_block(stmt.then_block, scopes, fn, summary)
            else_body = None
            if stmt.else_branch is not None:
                if isinstance(stmt.else_branch, ast.Block):
                    else_body = self.lower_block(stmt.else_branch, scopes, fn, summary)
                else:
                    else_body = [self.lower_stmt(stmt.else_branch, scopes, fn, summary)]
            return IRIf(kind='if', cond=cond, then_body=then_body, else_body=else_body)
        if isinstance(stmt, ast.WhileStmt):
            cond = self.lower_expr(stmt.cond, scopes, fn, summary, ast.NamedType('Bool'))
            return IRWhile(kind='while', cond=cond, body=self.lower_block(stmt.body, scopes, fn, summary))
        if isinstance(stmt, ast.ForStmt):
            iterable = self.lower_expr(stmt.iterable, scopes, fn, summary, None)
            scopes.append(Scope(bindings={stmt.name: stmt.typ}, mutability={stmt.name: False}))
            body = [self.lower_stmt(inner, scopes, fn, summary) for inner in stmt.body.statements]
            scopes.pop()
            return IRFor(kind='for', name=stmt.name, binder_type=format_type(stmt.typ), iterable=iterable, body=body)
        if isinstance(stmt, ast.DeferStmt):
            return IRDefer(kind='defer', error_only=False, body=self.lower_stmt(stmt.stmt, scopes, fn, summary))
        if isinstance(stmt, ast.ErrDeferStmt):
            return IRDefer(kind='errdefer', error_only=True, body=self.lower_stmt(stmt.stmt, scopes, fn, summary))
        if isinstance(stmt, ast.BreakStmt):
            return IRBreak(kind='break')
        if isinstance(stmt, ast.ContinueStmt):
            return IRContinue(kind='continue')
        raise TypeError(f'unsupported statement {type(stmt)!r}')

    def lower_expr(self, expr: ast.Expr, scopes: list[Scope], fn: ast.FnDecl, summary: TypedFunction, expected: ast.Type | None) -> IRExpr:
        typ = self.checker.type_of_expr(expr, scopes, fn, summary, expected)
        return IRExpr(text=format_expr_inline(expr), kind=type(expr).__name__, type_text=self.checker.type_text(typ))


def lower_module(module: ast.Module) -> IRModule:
    return IRLowerer(module).lower()
