from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class Node:
    pass


@dataclass(slots=True)
class Type(Node):
    pass


@dataclass(slots=True)
class NamedType(Type):
    name: str


@dataclass(slots=True)
class GenericType(Type):
    name: str
    args: list[Type | int]


@dataclass(slots=True)
class OptionalType(Type):
    inner: Type


@dataclass(slots=True)
class ResultType(Type):
    ok: Type
    err: Type


@dataclass(slots=True)
class Field(Node):
    name: str
    typ: Type


@dataclass(slots=True)
class Param(Node):
    name: str
    typ: Type


@dataclass(slots=True)
class ImportDecl(Node):
    path: list[str]


@dataclass(slots=True)
class ConstDecl(Node):
    name: str
    typ: Type
    value: 'Expr'


@dataclass(slots=True)
class StructDecl(Node):
    name: str
    fields: list[Field]


@dataclass(slots=True)
class EnumVariant(Node):
    name: str
    fields: list[Field] = field(default_factory=list)


@dataclass(slots=True)
class EnumDecl(Node):
    name: str
    variants: list[EnumVariant]


@dataclass(slots=True)
class ErrorSetDecl(Node):
    name: str
    tags: list[str]


@dataclass(slots=True)
class ProtocolTransition(Node):
    name: str
    source: str
    target: str


@dataclass(slots=True)
class ProtocolDecl(Node):
    name: str
    states: list[str]
    init: str
    terminal: list[str]
    transitions: list[ProtocolTransition]
    is_public: bool = False
    stability: str = 'stable'
    since: str | None = None
    deprecated_reason: str | None = None
    replacement: str | None = None


@dataclass(slots=True)
class ResourceDecl(Node):
    name: str
    protocol: str | None
    fields: list[Field]
    is_public: bool = False
    stability: str = 'stable'
    since: str | None = None
    deprecated_reason: str | None = None
    replacement: str | None = None


@dataclass(slots=True)
class Block(Node):
    statements: list['Stmt']


@dataclass(slots=True)
class FnDecl(Node):
    name: str
    params: list[Param]
    return_type: Type
    effects: list[str]
    body: Block
    is_public: bool = False
    stability: str = 'stable'
    since: str | None = None
    deprecated_reason: str | None = None
    replacement: str | None = None


TopDecl = ConstDecl | StructDecl | EnumDecl | ErrorSetDecl | ProtocolDecl | ResourceDecl | FnDecl


@dataclass(slots=True)
class Module(Node):
    path: list[str]
    imports: list[ImportDecl]
    decls: list[TopDecl]


@dataclass(slots=True)
class Expr(Node):
    pass


@dataclass(slots=True)
class NameExpr(Expr):
    name: str


@dataclass(slots=True)
class DottedExpr(Expr):
    parts: list[str]


@dataclass(slots=True)
class IntExpr(Expr):
    raw: str


@dataclass(slots=True)
class StringExpr(Expr):
    value: str


@dataclass(slots=True)
class BoolExpr(Expr):
    value: bool


@dataclass(slots=True)
class UnitExpr(Expr):
    pass


@dataclass(slots=True)
class NoneExpr(Expr):
    pass


@dataclass(slots=True)
class SomeExpr(Expr):
    value: Expr


@dataclass(slots=True)
class UnaryExpr(Expr):
    op: str
    expr: Expr


@dataclass(slots=True)
class BinaryExpr(Expr):
    left: Expr
    op: str
    right: Expr


@dataclass(slots=True)
class RangeExpr(Expr):
    start: Expr
    stop: Expr


@dataclass(slots=True)
class CallExpr(Expr):
    callee: Expr
    args: list[Expr]


@dataclass(slots=True)
class AttrExpr(Expr):
    obj: Expr
    name: str


@dataclass(slots=True)
class IndexExpr(Expr):
    obj: Expr
    index: Expr


@dataclass(slots=True)
class SliceExpr(Expr):
    obj: Expr
    start: Expr | None
    stop: Expr | None


@dataclass(slots=True)
class TryExpr(Expr):
    expr: Expr


@dataclass(slots=True)
class CatchExpr(Expr):
    expr: Expr
    fallback: Expr
    binding: str | None = None   # name bound to the error value in handler block
    handler: 'Block | None' = None  # block body when binding is present


@dataclass(slots=True)
class CastExpr(Expr):
    typ: Type
    expr: Expr


@dataclass(slots=True)
class StructLiteralExpr(Expr):
    name: str
    fields: list[tuple[str, Expr]]


@dataclass(slots=True)
class EnumLiteralExpr(Expr):
    enum_name: str
    variant_name: str
    fields: list[tuple[str, Expr]]


@dataclass(slots=True)
class MatchArm(Node):
    pattern: 'Pattern'
    expr: Expr


@dataclass(slots=True)
class MatchExpr(Expr):
    expr: Expr
    arms: list[MatchArm]


@dataclass(slots=True)
class Pattern(Node):
    pass


@dataclass(slots=True)
class WildcardPattern(Pattern):
    pass


@dataclass(slots=True)
class NamePattern(Pattern):
    name: str


@dataclass(slots=True)
class LiteralPattern(Pattern):
    value: Expr


@dataclass(slots=True)
class SomePattern(Pattern):
    inner: Pattern


@dataclass(slots=True)
class NonePattern(Pattern):
    pass


@dataclass(slots=True)
class OkPattern(Pattern):
    inner: Pattern


@dataclass(slots=True)
class ErrorPattern(Pattern):
    parts: list[str] | None


@dataclass(slots=True)
class EnumPattern(Pattern):
    parts: list[str]
    fields: list[tuple[str, Pattern]]


@dataclass(slots=True)
class Stmt(Node):
    pass


@dataclass(slots=True)
class LetStmt(Stmt):
    name: str
    typ: Type | None
    value: Expr


@dataclass(slots=True)
class VarStmt(Stmt):
    name: str
    typ: Type | None
    value: Expr


@dataclass(slots=True)
class AssignStmt(Stmt):
    target: Expr
    op: str
    value: Expr


@dataclass(slots=True)
class ExprStmt(Stmt):
    expr: Expr


@dataclass(slots=True)
class ReturnStmt(Stmt):
    expr: Expr | None


@dataclass(slots=True)
class IfStmt(Stmt):
    cond: Expr
    then_block: Block
    else_branch: Block | 'IfStmt' | None


@dataclass(slots=True)
class WhileStmt(Stmt):
    cond: Expr
    body: Block


@dataclass(slots=True)
class ForStmt(Stmt):
    name: str
    typ: Type
    iterable: Expr
    body: Block


@dataclass(slots=True)
class BreakStmt(Stmt):
    pass


@dataclass(slots=True)
class ContinueStmt(Stmt):
    pass


@dataclass(slots=True)
class DeferStmt(Stmt):
    stmt: Stmt


@dataclass(slots=True)
class ErrDeferStmt(Stmt):
    stmt: Stmt
