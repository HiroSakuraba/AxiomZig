"""Reference front-end scaffold for AxiomZig v1.1."""

__all__ = [
    "Module",
    "build_cfg",
    "check_module",
    "elaborate_module",
    "format_module",
    "lower_module",
    "lex",
    "analyze_ownership",
    "parse_module",
    "resolve_module",
    "typecheck_module",
]

_LAZY_EXPORTS = {
    "Module": (".ast", "Module"),
    "build_cfg": (".cfg", "build_cfg"),
    "check_module": (".checker", "check_module"),
    "elaborate_module": (".elaborate", "elaborate_module"),
    "format_module": (".formatter", "format_module"),
    "lower_module": (".ir", "lower_module"),
    "lex": (".lexer", "lex"),
    "analyze_ownership": (".ownership", "analyze_ownership"),
    "parse_module": (".parser", "parse_module"),
    "resolve_module": (".resolve", "resolve_module"),
    "typecheck_module": (".typecheck", "typecheck_module"),
}


def __getattr__(name: str):
    if name not in _LAZY_EXPORTS:
        raise AttributeError(name)
    import importlib

    module_name, attr_name = _LAZY_EXPORTS[name]
    value = getattr(importlib.import_module(module_name, __name__), attr_name)
    globals()[name] = value
    return value
