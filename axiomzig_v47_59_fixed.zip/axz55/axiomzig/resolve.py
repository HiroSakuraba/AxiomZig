from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from . import ast
from .diag import *  # noqa: F401,F403 — stable diagnostic codes


BUILTIN_NAMED_TYPES = {
    "Bool",
    "Unit",
    "Str",
    "I8",
    "I16",
    "I32",
    "I64",
    "U8",
    "U16",
    "U32",
    "U64",
}

BUILTIN_TYPE_CONSTRUCTORS = {
    "Option",
    "Slice",
    "Array",
    "Ref",
    "RefConst",
}

TOP_DECL_KIND = {
    ast.ConstDecl: "const",
    ast.StructDecl: "struct",
    ast.EnumDecl: "enum",
    ast.ErrorSetDecl: "error_set",
    ast.ProtocolDecl: "protocol",
    ast.ResourceDecl: "resource",
    ast.FnDecl: "fn",
}


@dataclass(slots=True)
class ResolutionIssue:
    level: str
    message: str
    context: str | None = None
    code: str | None = None


@dataclass(slots=True)
class TypeRef:
    text: str
    classification: str


@dataclass(slots=True)
class ValueRef:
    text: str
    classification: str


@dataclass(slots=True)
class FunctionSummary:
    name: str
    params: list[str]
    locals: list[str] = field(default_factory=list)
    types: list[TypeRef] = field(default_factory=list)
    values: list[ValueRef] = field(default_factory=list)


@dataclass(slots=True)
class ModuleSummary:
    module_path: str
    imports: dict[str, str]
    top_symbols: dict[str, str]
    functions: list[FunctionSummary]
    issues: list[ResolutionIssue]


@dataclass(slots=True)
class Scope:
    names: dict[str, str]
    kind: str


class Resolver:
    def __init__(self, module: ast.Module):
        self.module = module
        self.issues: list[ResolutionIssue] = []
        self.imports: dict[str, str] = {}
        self.top_symbols: dict[str, str] = {}
        self.enums: dict[str, ast.EnumDecl] = {}
        self.error_sets: dict[str, ast.ErrorSetDecl] = {}
        self.protocols: dict[str, ast.ProtocolDecl] = {}
        self.structs: dict[str, ast.StructDecl] = {}
        self.resources: dict[str, ast.ResourceDecl] = {}
        self.functions: dict[str, ast.FnDecl] = {}

    def resolve(self) -> ModuleSummary:
        self.collect_top_level()
        function_summaries: list[FunctionSummary] = []
        for decl in self.module.decls:
            if isinstance(decl, ast.StructDecl):
                self.resolve_field_list(decl.name, decl.fields)
            elif isinstance(decl, ast.ResourceDecl):
                if decl.protocol and decl.protocol not in self.protocols:
                    self.issue("error", f"resource {decl.name} references unknown protocol {decl.protocol}", code="E_RESOLVE_UNKNOWN_TYPE")
                self.resolve_field_list(decl.name, decl.fields)
            elif isinstance(decl, ast.EnumDecl):
                self.resolve_enum_decl(decl)
            elif isinstance(decl, ast.ConstDecl):
                self.resolve_type_ref(decl.typ, None)
                self.resolve_expr(decl.value, [Scope({}, "module")], None)
            elif isinstance(decl, ast.FnDecl):
                function_summaries.append(self.resolve_function(decl))
        return ModuleSummary(
            module_path=".".join(self.module.path),
            imports=dict(sorted(self.imports.items())),
            top_symbols=dict(sorted(self.top_symbols.items())),
            functions=function_summaries,
            issues=self.issues,
        )

    def issue(self, level: str, message: str, context: str | None = None, code: str | None = None) -> None:
        self.issues.append(ResolutionIssue(level=level, message=message, context=context, code=code))

    def collect_top_level(self) -> None:
        for imp in self.module.imports:
            local_name = imp.path[-1]
            full_path = ".".join(imp.path)
            if local_name in self.imports:
                self.issue("error", f"duplicate import binding {local_name}", code="E_RESOLVE_DUPLICATE")
            self.imports[local_name] = full_path

        for decl in self.module.decls:
            kind = TOP_DECL_KIND[type(decl)]
            name = getattr(decl, "name")
            if name in self.top_symbols:
                self.issue("error", f"duplicate top-level name {name}", code="E_RESOLVE_DUPLICATE")
                continue
            self.top_symbols[name] = kind
            if isinstance(decl, ast.EnumDecl):
                self.enums[name] = decl
            elif isinstance(decl, ast.ErrorSetDecl):
                self.error_sets[name] = decl
            elif isinstance(decl, ast.ProtocolDecl):
                self.protocols[name] = decl
            elif isinstance(decl, ast.StructDecl):
                self.structs[name] = decl
            elif isinstance(decl, ast.ResourceDecl):
                self.resources[name] = decl
            elif isinstance(decl, ast.FnDecl):
                self.functions[name] = decl

    def resolve_field_list(self, owner: str, fields: list[ast.Field]) -> None:
        seen: set[str] = set()
        for field in fields:
            if field.name in seen:
                self.issue("error", f"{owner} repeats field {field.name}", code="E_RESOLVE_DUPLICATE")
            seen.add(field.name)
            self.resolve_type_ref(field.typ, None)

    def resolve_enum_decl(self, decl: ast.EnumDecl) -> None:
        seen_variants: set[str] = set()
        for variant in decl.variants:
            if variant.name in seen_variants:
                self.issue("error", f"enum {decl.name} repeats variant {variant.name}", code="E_RESOLVE_DUPLICATE")
            seen_variants.add(variant.name)
            self.resolve_field_list(f"{decl.name}.{variant.name}", variant.fields)

    def resolve_function(self, fn: ast.FnDecl) -> FunctionSummary:
        params = [p.name for p in fn.params]
        summary = FunctionSummary(name=fn.name, params=params)
        function_scope = Scope({}, "fn")
        for param in fn.params:
            if param.name in function_scope.names:
                self.issue("error", f"function {fn.name} repeats parameter {param.name}", code="E_RESOLVE_DUPLICATE")
            function_scope.names[param.name] = "param"
            summary.locals.append(param.name)
            summary.types.extend(self.collect_type_refs(param.typ))
        summary.types.extend(self.collect_type_refs(fn.return_type))
        self.resolve_block(fn.body, [function_scope], summary)
        summary.locals = sorted(set(summary.locals))
        return summary

    def collect_type_refs(self, typ: ast.Type) -> list[TypeRef]:
        refs: list[TypeRef] = []
        self.resolve_type_ref(typ, refs)
        return refs

    def resolve_type_ref(self, typ: ast.Type, collector: list[TypeRef] | None) -> str:
        if isinstance(typ, ast.NamedType):
            name = typ.name
            if name in BUILTIN_NAMED_TYPES:
                classification = "builtin_type"
            elif name in self.top_symbols and self.top_symbols[name] in {"struct", "enum", "resource", "error_set", "protocol"}:
                classification = f"top_{self.top_symbols[name]}"
            elif name in self.imports:
                classification = "imported_type"
            else:
                classification = "unresolved_type"
                self.issue("error", f"unknown type name {name}", code="E_RESOLVE_UNKNOWN_TYPE")
            if collector is not None:
                collector.append(TypeRef(text=name, classification=classification))
            return classification
        if isinstance(typ, ast.GenericType):
            if typ.name not in BUILTIN_TYPE_CONSTRUCTORS:
                self.issue("error", f"unknown type constructor {typ.name}", code="E_RESOLVE_UNKNOWN_TYPE")
                classification = "unresolved_constructor"
            else:
                classification = f"builtin_constructor:{typ.name}"
            if collector is not None:
                collector.append(TypeRef(text=typ.name, classification=classification))
            for arg in typ.args:
                if isinstance(arg, ast.Type):
                    self.resolve_type_ref(arg, collector)
            return classification
        if isinstance(typ, ast.OptionalType):
            self.resolve_type_ref(typ.inner, collector)
            if collector is not None:
                collector.append(TypeRef(text="?", classification="optional_type"))
            return "optional_type"
        if isinstance(typ, ast.ResultType):
            self.resolve_type_ref(typ.ok, collector)
            self.resolve_type_ref(typ.err, collector)
            if collector is not None:
                collector.append(TypeRef(text="!", classification="result_type"))
            return "result_type"
        raise TypeError(f"unsupported type {type(typ)!r}")

    def resolve_block(self, block: ast.Block, scopes: list[Scope], summary: FunctionSummary) -> None:
        block_scope = Scope({}, "block")
        scopes.append(block_scope)
        for stmt in block.statements:
            self.resolve_stmt(stmt, scopes, summary)
        scopes.pop()

    def bind_name(self, name: str, kind: str, scopes: list[Scope], summary: FunctionSummary) -> None:
        if name == "_":
            return
        for scope in reversed(scopes):
            if name in scope.names:
                self.issue("error", f"shadowing forbidden for name {name}", code="E_RESOLVE_SHADOW")
                return
        if name in self.top_symbols or name in self.imports:
            self.issue("error", f"local binding {name} conflicts with top-level or imported name", code="E_RESOLVE_SHADOW")
            return
        scopes[-1].names[name] = kind
        summary.locals.append(name)

    def lookup_name(self, name: str, scopes: list[Scope]) -> str:
        if name == "_":
            return "wildcard"
        for scope in reversed(scopes):
            if name in scope.names:
                return scope.names[name]
        if name in self.top_symbols:
            return f"top_{self.top_symbols[name]}"
        if name in self.imports:
            return "import"
        return "unresolved"

    def resolve_stmt(self, stmt: ast.Stmt, scopes: list[Scope], summary: FunctionSummary) -> None:
        if isinstance(stmt, ast.Block):
            self.resolve_block(stmt, scopes, summary)
            return
        if isinstance(stmt, ast.LetStmt):
            if stmt.typ is not None:
                self.resolve_type_ref(stmt.typ, summary.types)
            self.resolve_expr(stmt.value, scopes, summary)
            self.bind_name(stmt.name, "let", scopes, summary)
            return
        if isinstance(stmt, ast.VarStmt):
            if stmt.typ is not None:
                self.resolve_type_ref(stmt.typ, summary.types)
            self.resolve_expr(stmt.value, scopes, summary)
            self.bind_name(stmt.name, "var", scopes, summary)
            return
        if isinstance(stmt, ast.AssignStmt):
            self.resolve_expr(stmt.target, scopes, summary)
            self.resolve_expr(stmt.value, scopes, summary)
            return
        if isinstance(stmt, ast.ExprStmt):
            self.resolve_expr(stmt.expr, scopes, summary)
            return
        if isinstance(stmt, ast.ReturnStmt):
            if stmt.expr is not None:
                self.resolve_expr(stmt.expr, scopes, summary)
            return
        if isinstance(stmt, ast.IfStmt):
            self.resolve_expr(stmt.cond, scopes, summary)
            self.resolve_block(stmt.then_block, scopes, summary)
            if stmt.else_branch is not None:
                if isinstance(stmt.else_branch, ast.Block):
                    self.resolve_block(stmt.else_branch, scopes, summary)
                else:
                    self.resolve_stmt(stmt.else_branch, scopes, summary)
            return
        if isinstance(stmt, ast.WhileStmt):
            self.resolve_expr(stmt.cond, scopes, summary)
            self.resolve_block(stmt.body, scopes, summary)
            return
        if isinstance(stmt, ast.ForStmt):
            self.resolve_type_ref(stmt.typ, summary.types)
            self.resolve_expr(stmt.iterable, scopes, summary)
            loop_scope = Scope({}, "for")
            scopes.append(loop_scope)
            self.bind_name(stmt.name, "for_var", scopes, summary)
            self.resolve_block(stmt.body, scopes, summary)
            scopes.pop()
            return
        if isinstance(stmt, ast.BreakStmt | ast.ContinueStmt):
            return
        if isinstance(stmt, ast.DeferStmt | ast.ErrDeferStmt):
            if isinstance(stmt.stmt, (ast.ReturnStmt, ast.BreakStmt, ast.ContinueStmt)):
                self.issue("error", "defer/errdefer body may not alter control flow", code="E_DEFER_FLOW")
            elif isinstance(stmt.stmt, (ast.DeferStmt, ast.ErrDeferStmt)):
                self.issue("error", "defer/errdefer body may not contain a nested defer or errdefer", code="E_DEFER_NESTED")
            self.resolve_stmt(stmt.stmt, scopes, summary)
            return
        raise TypeError(f"unsupported statement {type(stmt)!r}")

    def resolve_expr(self, expr: ast.Expr, scopes: list[Scope], summary: FunctionSummary | None) -> None:
        if isinstance(expr, ast.NameExpr):
            classification = self.lookup_name(expr.name, scopes)
            if classification == "unresolved":
                self.issue("error", f"unresolved name {expr.name}", code="E_RESOLVE_UNBOUND")
            if summary is not None:
                summary.values.append(ValueRef(text=expr.name, classification=classification))
            return
        if isinstance(expr, ast.DottedExpr):
            classification = self.classify_dotted(expr.parts, scopes)
            if classification == "unresolved":
                self.issue("error", f"unresolved dotted name {'.'.join(expr.parts)}", code="E_RESOLVE_UNBOUND")
            if summary is not None:
                summary.values.append(ValueRef(text='.'.join(expr.parts), classification=classification))
            return
        if isinstance(expr, (ast.IntExpr, ast.StringExpr, ast.BoolExpr, ast.UnitExpr, ast.NoneExpr)):
            return
        if isinstance(expr, ast.SomeExpr):
            self.resolve_expr(expr.value, scopes, summary)
            return
        if isinstance(expr, ast.UnaryExpr):
            self.resolve_expr(expr.expr, scopes, summary)
            return
        if isinstance(expr, ast.BinaryExpr):
            self.resolve_expr(expr.left, scopes, summary)
            self.resolve_expr(expr.right, scopes, summary)
            return
        if isinstance(expr, ast.RangeExpr):
            self.resolve_expr(expr.start, scopes, summary)
            self.resolve_expr(expr.stop, scopes, summary)
            return
        if isinstance(expr, ast.CallExpr):
            self.resolve_expr(expr.callee, scopes, summary)
            for arg in expr.args:
                self.resolve_expr(arg, scopes, summary)
            return
        if isinstance(expr, ast.AttrExpr):
            self.resolve_expr(expr.obj, scopes, summary)
            if summary is not None:
                summary.values.append(ValueRef(text=expr.name, classification="field_access"))
            return
        if isinstance(expr, ast.IndexExpr):
            self.resolve_expr(expr.obj, scopes, summary)
            self.resolve_expr(expr.index, scopes, summary)
            return
        if isinstance(expr, ast.SliceExpr):
            self.resolve_expr(expr.obj, scopes, summary)
            if expr.start is not None:
                self.resolve_expr(expr.start, scopes, summary)
            if expr.stop is not None:
                self.resolve_expr(expr.stop, scopes, summary)
            return
        if isinstance(expr, ast.TryExpr):
            self.resolve_expr(expr.expr, scopes, summary)
            return
        if isinstance(expr, ast.CatchExpr):
            self.resolve_expr(expr.expr, scopes, summary)
            if expr.binding is not None and expr.handler is not None:
                # catch |e| { body } — introduce binding into a new scope for the block
                inner_scope: dict[str, str] = {}
                scopes.append(inner_scope)
                inner_scope[expr.binding] = 'let'
                for stmt in expr.handler.statements:
                    self.resolve_stmt(stmt, scopes, summary)
                scopes.pop()
            else:
                self.resolve_expr(expr.fallback, scopes, summary)
            return
        if isinstance(expr, ast.CastExpr):
            self.resolve_type_ref(expr.typ, summary.types if summary is not None else None)
            self.resolve_expr(expr.expr, scopes, summary)
            return
        if isinstance(expr, ast.StructLiteralExpr):
            if expr.name not in self.structs and expr.name not in self.resources:
                self.issue("error", f"unknown struct/resource literal type {expr.name}", code="E_RESOLVE_UNKNOWN_TYPE")
            if summary is not None:
                summary.values.append(ValueRef(text=expr.name, classification="struct_literal_type"))
            seen: set[str] = set()
            for field_name, field_value in expr.fields:
                if field_name in seen:
                    self.issue("error", f"struct literal {expr.name} repeats field {field_name}", code="E_RESOLVE_DUPLICATE")
                seen.add(field_name)
                self.resolve_expr(field_value, scopes, summary)
            return
        if isinstance(expr, ast.EnumLiteralExpr):
            classification = self.classify_dotted([expr.enum_name, expr.variant_name], scopes)
            if classification == "unresolved":
                self.issue("error", f"unknown enum literal {expr.enum_name}.{expr.variant_name}", code="E_RESOLVE_UNKNOWN_TYPE")
            if summary is not None:
                summary.values.append(ValueRef(text=f"{expr.enum_name}.{expr.variant_name}", classification=classification))
            for _, value in expr.fields:
                self.resolve_expr(value, scopes, summary)
            return
        if isinstance(expr, ast.MatchExpr):
            self.resolve_expr(expr.expr, scopes, summary)
            for arm in expr.arms:
                arm_scope = Scope({}, "match_arm")
                scopes.append(arm_scope)
                self.resolve_pattern(arm.pattern, scopes, summary)
                self.resolve_expr(arm.expr, scopes, summary)
                scopes.pop()
            return
        raise TypeError(f"unsupported expression {type(expr)!r}")

    def classify_dotted(self, parts: list[str], scopes: list[Scope]) -> str:
        if not parts:
            return "unresolved"
        first = parts[0]
        base = self.lookup_name(first, scopes)
        if base != "unresolved":
            if base.startswith("top_enum") and len(parts) >= 2:
                enum_decl = self.enums.get(first)
                if enum_decl and any(v.name == parts[1] for v in enum_decl.variants):
                    return "enum_variant"
            if base.startswith("top_error_set") and len(parts) >= 2:
                err = self.error_sets.get(first)
                if err and parts[1] in err.tags:
                    return "error_tag"
            if base == "import":
                return "import_member"
            return "field_chain"
        dotted_name = '.'.join(parts)
        if any(dotted_name == module_name or dotted_name.startswith(module_name + '.') for module_name in self.imports.values()):
            return "import_member"
        return "unresolved"

    def resolve_pattern(self, pattern: ast.Pattern, scopes: list[Scope], summary: FunctionSummary | None) -> None:
        if isinstance(pattern, ast.WildcardPattern | ast.NonePattern):
            return
        if isinstance(pattern, ast.NamePattern):
            self.bind_name(pattern.name, "pattern", scopes, summary if summary is not None else FunctionSummary("<pattern>", []))
            return
        if isinstance(pattern, ast.LiteralPattern):
            self.resolve_expr(pattern.value, scopes, summary)
            return
        if isinstance(pattern, ast.SomePattern):
            self.resolve_pattern(pattern.inner, scopes, summary)
            return
        if isinstance(pattern, ast.OkPattern):
            self.resolve_pattern(pattern.inner, scopes, summary)
            return
        if isinstance(pattern, ast.ErrorPattern):
            if pattern.parts is not None:
                classification = self.classify_dotted(pattern.parts, scopes)
                if classification not in {"error_tag", "field_chain"}:
                    self.issue("error", f"unknown error pattern {'.'.join(pattern.parts)}", code="E_RESOLVE_UNBOUND")
                elif classification == "field_chain":
                    # classify_dotted can only see top_error_set as a structured tag.
                    self.issue("error", f"error pattern must reference an error set tag: {'.'.join(pattern.parts)}", code="E_RESOLVE_UNBOUND")
            return
        if isinstance(pattern, ast.EnumPattern):
            classification = self.classify_dotted(pattern.parts, scopes)
            if classification != "enum_variant":
                self.issue("error", f"unknown enum pattern {'.'.join(pattern.parts)}", code="E_RESOLVE_UNBOUND")
            field_seen: set[str] = set()
            for field_name, subpattern in pattern.fields:
                if field_name in field_seen:
                    self.issue("error", f"enum pattern {'.'.join(pattern.parts)} repeats field {field_name}", code="E_RESOLVE_DUPLICATE")
                field_seen.add(field_name)
                self.resolve_pattern(subpattern, scopes, summary)
            return
        raise TypeError(f"unsupported pattern {type(pattern)!r}")


def resolve_module(module: ast.Module) -> ModuleSummary:
    return Resolver(module).resolve()
