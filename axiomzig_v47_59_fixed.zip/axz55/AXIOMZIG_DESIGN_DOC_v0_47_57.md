# AxiomZig v0.47.57 Design Note — Public Shape Publication and Diffing

## Design decision

v0.47.57 publishes the shape of public resources and public protocols as canonical artifact data.

The new fields are artifact-level fields, not separate source-truth fields:

```text
public_resource_shapes
public_protocol_shapes
```

They are emitted from source by the canonical package-interface emitter and then propagated into conformance/publication manifests.

## Resource shape model

A public resource shape contains:

```json
{
  "protocol": "demo.main.Readable",
  "fields": [
    {"name": "fd", "type": "Int"}
  ]
}
```

The `protocol` field is omitted when no protocol binding exists. Field order is source order. Field types are rendered using the existing formatter type text.

Compatibility policy:

- changing the protocol binding is incompatible
- removing a field is incompatible
- changing a field type is incompatible
- adding a field is compatible

This treats public resource fields as a real API surface, but allows additive extension.

## Protocol shape model

A public protocol shape contains:

```json
{
  "states": ["Closed", "Open"],
  "init": "Open",
  "terminal": ["Closed"],
  "transitions": [
    {"name": "close", "source": "Open", "target": "Closed"}
  ]
}
```

States, terminal states, and transitions are normalized deterministically.

Compatibility policy:

- changing the initial state is incompatible
- removing a state is incompatible
- adding a state is compatible
- removing a terminal state is incompatible
- adding a terminal state is compatible
- removing a transition is incompatible
- adding a transition is compatible
- changing a transition source/target is incompatible

This keeps additive protocol evolution possible while preserving clients that depend on existing states/transitions.

## Diff separation

`pubdiff` now keeps these domains separate:

- public function/resource/protocol declaration presence
- lifecycle metadata
- resource shape
- protocol shape
- ownership signatures
- dependency policy/lock data
- publication metadata

The overall classification still uses precedence:

```text
incompatible > compatible > metadata-only
```

## Non-goals

v0.47.57 does not add module-level `pub`, `export`, `pub struct`, transitive dependency closure, signed manifests, or a new publication-manifest schema version.
