# AxiomZig v0.47.46 — Next Steps

## Priority 1: dependency-manifest hardening

1. detect duplicate/conflicting dependency manifests explicitly
2. add regression coverage for every static CLI command that now accepts `--dependency-manifest`
3. decide whether dependency manifests without `manifest_hash` should remain accepted or become errors
4. consider pinning dependency `workspace_source_digest` / `manifest_hash` in a higher-level lock artifact

## Priority 2: package publication policy

1. separate public/package interface semantics from debug/CI export semantics
2. replace the conservative entry-module-only `--public-only` rule when the language surface supports explicit publication
3. decide whether dependency manifests should expose package identity/version fields

## Priority 3: whole-program fixed points

1. decide whether cyclic source-module ownership solving is in scope
2. if yes, introduce a constrained fixed-point model for legal cycles rather than the current hard cycle rejection
