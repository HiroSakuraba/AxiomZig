from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _build_publication(
    root: Path,
    capsys,
    *,
    package_name: str,
    package_version: str,
    module_name: str,
    source: str,
    dependency_manifests: list[Path] | None = None,
) -> Path:
    source_path = _write(root / Path(*module_name.split('.')).with_suffix('.az'), source)
    iface = root / 'axiomzig.package.json'
    rc = main([
        'emit-package-interface',
        str(source_path),
        '--module-root',
        str(root),
        '--package-name',
        package_name,
        '--package-version',
        package_version,
        '--out',
        str(iface),
    ])
    assert rc == 0
    capsys.readouterr()
    pub = root / f'{package_name}_{package_version.replace(".", "_")}.publication.json'
    full = root / f'{package_name}_{package_version.replace(".", "_")}.full.json'
    args = [
        'conform',
        str(source_path),
        '--module-root',
        str(root),
        '--package-interface',
        str(iface),
        '--out',
        str(full),
        '--publication-out',
        str(pub),
    ]
    for dep in dependency_manifests or []:
        args.extend(['--dependency-manifest', str(dep)])
    rc = main(args)
    captured = capsys.readouterr()
    assert rc == 0, captured.err
    return pub


def test_publication_manifest_carries_direct_and_transitive_dependency_closure(tmp_path: Path, capsys) -> None:
    leaf_pub = _build_publication(
        tmp_path / 'leaf',
        capsys,
        package_name='leaf',
        package_version='1.0.0',
        module_name='leaf.api',
        source='module leaf.api;\n\npub fn ping() -> Unit effects() { return unit; }\n',
    )
    mid_pub = _build_publication(
        tmp_path / 'mid',
        capsys,
        package_name='mid',
        package_version='1.0.0',
        module_name='mid.api',
        source='module mid.api;\nimport leaf.api;\n\npub fn mid() -> Unit effects() { return unit; }\n',
        dependency_manifests=[leaf_pub],
    )
    app_pub = _build_publication(
        tmp_path / 'app',
        capsys,
        package_name='app',
        package_version='1.0.0',
        module_name='app.main',
        source='module app.main;\nimport mid.api;\n\npub fn run() -> Unit effects() { return unit; }\n',
        dependency_manifests=[mid_pub],
    )

    publication = json.loads(app_pub.read_text(encoding='utf-8'))
    closure = publication['dependency_publication_closure']
    by_name = {item['package_name']: item for item in closure}

    assert sorted(by_name) == ['leaf', 'mid']
    assert by_name['mid']['direct'] is True
    assert by_name['mid']['depth'] == 1
    assert by_name['leaf']['direct'] is False
    assert by_name['leaf']['depth'] == 2
    assert by_name['leaf']['required_by'] == ['mid@1.0.0']
    assert by_name['leaf']['public_surface']['exported_functions'] == {'leaf.api': ['leaf.api.ping']}
    assert by_name['leaf']['public_surface_digest']


def test_pubdiff_detects_incompatible_transitive_dependency_api_movement(tmp_path: Path, capsys) -> None:
    leaf_v1 = _build_publication(
        tmp_path / 'leaf_v1',
        capsys,
        package_name='leaf',
        package_version='1.0.0',
        module_name='leaf.api',
        source='module leaf.api;\n\npub fn ping() -> Unit effects() { return unit; }\n',
    )
    leaf_v2 = _build_publication(
        tmp_path / 'leaf_v2',
        capsys,
        package_name='leaf',
        package_version='2.0.0',
        module_name='leaf.api',
        source='module leaf.api;\n\npub fn pong() -> Unit effects() { return unit; }\n',
    )
    mid_v1 = _build_publication(
        tmp_path / 'mid_v1',
        capsys,
        package_name='mid',
        package_version='1.0.0',
        module_name='mid.api',
        source='module mid.api;\nimport leaf.api;\n\npub fn mid() -> Unit effects() { return unit; }\n',
        dependency_manifests=[leaf_v1],
    )
    mid_v2 = _build_publication(
        tmp_path / 'mid_v2',
        capsys,
        package_name='mid',
        package_version='2.0.0',
        module_name='mid.api',
        source='module mid.api;\nimport leaf.api;\n\npub fn mid() -> Unit effects() { return unit; }\n',
        dependency_manifests=[leaf_v2],
    )
    app_old = _build_publication(
        tmp_path / 'app_old',
        capsys,
        package_name='app',
        package_version='1.0.0',
        module_name='app.main',
        source='module app.main;\nimport mid.api;\n\npub fn run() -> Unit effects() { return unit; }\n',
        dependency_manifests=[mid_v1],
    )
    app_new = _build_publication(
        tmp_path / 'app_new',
        capsys,
        package_name='app',
        package_version='1.1.0',
        module_name='app.main',
        source='module app.main;\nimport mid.api;\n\npub fn run() -> Unit effects() { return unit; }\n',
        dependency_manifests=[mid_v2],
    )
    diff_out = tmp_path / 'diff.json'
    rc = main(['pubdiff', str(app_old), str(app_new), '--out', str(diff_out)])
    assert rc == 0
    result = json.loads(diff_out.read_text(encoding='utf-8'))
    codes = {issue['code'] for issue in result['issues']}
    categories = {issue['category'] for issue in result['issues']}

    assert result['classification'] == 'incompatible'
    assert 'DEP_E_PUBLIC_FUNCTION_REMOVED' in codes
    assert 'DEP_C_PUBLIC_FUNCTION_ADDED' in codes
    assert 'dependency_closure_api' in categories
    assert 'dependency_closure' in categories


def test_transitive_dependency_ranges_are_checked_against_closure(tmp_path: Path, capsys) -> None:
    leaf_pub = _build_publication(
        tmp_path / 'leaf',
        capsys,
        package_name='leaf',
        package_version='2.0.0',
        module_name='leaf.api',
        source='module leaf.api;\n\npub fn ping() -> Unit effects() { return unit; }\n',
    )
    mid_pub = _build_publication(
        tmp_path / 'mid',
        capsys,
        package_name='mid',
        package_version='1.0.0',
        module_name='mid.api',
        source='module mid.api;\nimport leaf.api;\n\npub fn mid() -> Unit effects() { return unit; }\n',
        dependency_manifests=[leaf_pub],
    )
    app_root = tmp_path / 'app'
    app_file = _write(
        app_root / 'app' / 'main.az',
        'module app.main;\nimport mid.api;\n\npub fn run() -> Unit effects() { return unit; }\n',
    )
    iface = app_root / 'axiomzig.package.json'
    rc = main([
        'emit-package-interface',
        str(app_file),
        '--module-root',
        str(app_root),
        '--package-name',
        'app',
        '--package-version',
        '1.0.0',
        '--out',
        str(iface),
    ])
    assert rc == 0
    capsys.readouterr()
    data = json.loads(iface.read_text(encoding='utf-8'))
    data['compatibility'] = {'dependency_version_ranges': {'leaf': '^1.0'}}
    iface.write_text(json.dumps(data, indent=2, sort_keys=True), encoding='utf-8')
    out = app_root / 'full.json'

    rc = main([
        'conform',
        str(app_file),
        '--module-root',
        str(app_root),
        '--package-interface',
        str(iface),
        '--dependency-manifest',
        str(mid_pub),
        '--out',
        str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 1
    assert manifest['status'] == 'error'
    assert any(item['code'] == 'E_DEP_VERSION_RANGE_MISMATCH' for item in manifest['diagnostics'])
    assert 'leaf version ^1.0' in captured.err


def test_mixed_publication_pipeline_fixture_runs_emit_sync_conform_and_pubdiff(tmp_path: Path, capsys) -> None:
    dep_pub = _build_publication(
        tmp_path / 'dep',
        capsys,
        package_name='dep',
        package_version='1.2.3',
        module_name='dep.api',
        source='module dep.api;\n\npub fn dep_ping() -> Unit effects() { return unit; }\n',
    )
    base_source = '''module demo.main;
import dep.api;

@experimental
pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

pub resource File { protocol: Readable; fields { fd: Int; } }

@deprecated(reason="use demo.main.run2", replacement="demo.main.run2")
pub fn run() -> Unit effects() { return unit; }

pub fn run2() -> Unit effects() { return unit; }
'''
    changed_source = base_source.replace('fields { fd: Int; }', 'fields { fd: Str; }')
    pubs = []
    for label, source in [('old', base_source), ('new', changed_source)]:
        root = tmp_path / f'app_{label}'
        main_file = _write(root / 'demo' / 'main.az', source)
        iface = root / 'axiomzig.package.json'
        rc = main(['emit-package-interface', str(main_file), '--module-root', str(root), '--package-name', 'demo', '--package-version', f'1.0.{0 if label == "old" else 1}', '--out', str(iface)])
        assert rc == 0
        capsys.readouterr()
        rc = main(['check-package-interface-sync', str(main_file), '--module-root', str(root), '--package-interface', str(iface)])
        assert rc == 0
        pub = root / 'publication.json'
        rc = main(['conform', str(main_file), '--module-root', str(root), '--package-interface', str(iface), '--dependency-manifest', str(dep_pub), '--publication-out', str(pub)])
        captured = capsys.readouterr()
        assert rc == 0, captured.err
        pubs.append(pub)

    diff_out = tmp_path / 'mixed.diff.json'
    rc = main(['pubdiff', str(pubs[0]), str(pubs[1]), '--out', str(diff_out)])
    assert rc == 0
    result = json.loads(diff_out.read_text(encoding='utf-8'))
    codes = {issue['code'] for issue in result['issues']}

    assert result['classification'] == 'incompatible'
    assert 'E_PUBLIC_RESOURCE_FIELD_TYPE_CHANGED' in codes


def test_dependency_publication_refs_carry_manifest_hash(tmp_path: Path, capsys) -> None:
    """
    dependency_publication_refs entries must include manifest_hash so
    consumers can verify the pinned manifest has not been tampered with.

    The hash in the ref must exactly match the manifest_hash of the
    dependency's own publication manifest.
    """
    dep_pub = _build_publication(
        tmp_path / 'dep',
        capsys,
        package_name='dep',
        package_version='1.0.0',
        module_name='dep.api',
        source='module dep.api;\n\npub fn helper() -> Unit effects() { return unit; }\n',
    )
    dep_manifest = json.loads(dep_pub.read_text(encoding='utf-8'))
    expected_hash = dep_manifest['manifest_hash']
    assert expected_hash, "dep publication must have a manifest_hash"

    app_pub = _build_publication(
        tmp_path / 'app',
        capsys,
        package_name='app',
        package_version='1.0.0',
        module_name='app.main',
        source='module app.main;\nimport dep.api;\n\npub fn run() -> Unit effects() { return unit; }\n',
        dependency_manifests=[dep_pub],
    )
    app_manifest = json.loads(app_pub.read_text(encoding='utf-8'))

    refs = app_manifest.get('dependency_publication_refs', [])
    assert refs, "app must have at least one dependency_publication_ref"
    dep_ref = next((r for r in refs if r.get('package_id') == 'dep@1.0.0'), None)
    assert dep_ref is not None, f"dep@1.0.0 not found in refs: {refs}"

    assert 'manifest_hash' in dep_ref, (
        "dependency_publication_ref must carry manifest_hash; "
        f"got keys: {sorted(dep_ref)}"
    )
    assert dep_ref['manifest_hash'] == expected_hash, (
        f"ref manifest_hash {dep_ref['manifest_hash']!r} "
        f"does not match dep publication manifest_hash {expected_hash!r}"
    )


def test_diamond_dependency_closure_deduplication(tmp_path: Path, capsys) -> None:
    """
    Diamond dependency: app -> left, app -> right, left -> base, right -> base.

    The closure must:
    - contain 'base' exactly once (deduplication)
    - record base as non-direct (app does not import base directly)
    - record base.depth == 2
    - record base.required_by containing both left@1.0.0 and right@1.0.0
    - not produce any E_MODULE_CYCLE or conflict errors

    Diamond layout:
         app
        /   \\
      left  right
        \\   /
         base
    """
    # Build base
    base_pub = _build_publication(
        tmp_path / 'base',
        capsys,
        package_name='base',
        package_version='1.0.0',
        module_name='base.api',
        source='module base.api;\n\npub fn base_fn() -> Unit effects() { return unit; }\n',
    )

    # Build left (depends on base)
    left_pub = _build_publication(
        tmp_path / 'left',
        capsys,
        package_name='left',
        package_version='1.0.0',
        module_name='left.api',
        source='module left.api;\nimport base.api;\n\npub fn left_fn() -> Unit effects() { return unit; }\n',
        dependency_manifests=[base_pub],
    )

    # Build right (depends on base)
    right_pub = _build_publication(
        tmp_path / 'right',
        capsys,
        package_name='right',
        package_version='1.0.0',
        module_name='right.api',
        source='module right.api;\nimport base.api;\n\npub fn right_fn() -> Unit effects() { return unit; }\n',
        dependency_manifests=[base_pub],
    )

    # Build app (depends on both left and right)
    app_pub = _build_publication(
        tmp_path / 'app',
        capsys,
        package_name='app',
        package_version='1.0.0',
        module_name='app.main',
        source=(
            'module app.main;\n'
            'import left.api;\n'
            'import right.api;\n\n'
            'pub fn run() -> Unit effects() { return unit; }\n'
        ),
        dependency_manifests=[left_pub, right_pub],
    )

    publication = json.loads(app_pub.read_text(encoding='utf-8'))
    closure = publication['dependency_publication_closure']

    # Index by package_name
    by_name = {item['package_name']: item for item in closure}

    # All three packages (left, right, base) should appear
    assert 'left' in by_name,  f"left missing from closure: {sorted(by_name)}"
    assert 'right' in by_name, f"right missing from closure: {sorted(by_name)}"
    assert 'base' in by_name,  f"base missing from closure: {sorted(by_name)}"

    # base appears exactly once (deduplication)
    base_entries = [item for item in closure if item.get('package_name') == 'base']
    assert len(base_entries) == 1, (
        f"base must appear exactly once in closure (deduplication); "
        f"found {len(base_entries)} entries"
    )

    # left and right are direct dependencies of app
    assert by_name['left']['direct']  is True,  "left must be direct"
    assert by_name['right']['direct'] is True,  "right must be direct"
    assert by_name['left']['depth']   == 1,     "left depth must be 1"
    assert by_name['right']['depth']  == 1,     "right depth must be 1"

    # base is transitive — not direct, depth 2
    assert by_name['base']['direct']  is False, "base must not be direct"
    assert by_name['base']['depth']   == 2,     f"base depth must be 2, got {by_name['base']['depth']}"

    # base.required_by must name both left and right
    required_by = sorted(by_name['base'].get('required_by', []))
    assert 'left@1.0.0'  in required_by, f"base.required_by missing left@1.0.0: {required_by}"
    assert 'right@1.0.0' in required_by, f"base.required_by missing right@1.0.0: {required_by}"

    # base must carry a public_surface_digest (content integrity)
    assert by_name['base'].get('public_surface_digest'), \
        "base closure entry must have public_surface_digest"

    # The publication must have no error-level diagnostics
    diagnostics = publication.get('diagnostics', [])
    errors = [d for d in diagnostics if d.get('level') == 'error']
    assert not errors, f"diamond closure produced errors: {errors}"
