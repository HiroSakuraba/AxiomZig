from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def test_check_package_interface_sync_reports_function_resource_protocol_sections(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        '''module demo.main;

pub fn run() -> Unit effects() { return unit; }

pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

pub resource File {
    protocol: Readable;
    fields { fd: Int; }
}
''',
    )
    interface_path = _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.main'],
                'public_functions': {'demo.main': ['demo.main.old_run']},
                'public_resources': {'demo.main': ['demo.main.OldFile']},
                'public_protocols': {'demo.main': ['demo.main.OldReadable']},
            }
        ),
    )

    rc = main([
        'check-package-interface-sync',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(interface_path),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'mismatched sections:' in captured.err
    assert 'functions' in captured.err
    assert 'resources' in captured.err
    assert 'protocols' in captured.err


def test_check_package_interface_sync_reports_lifecycle_metadata_sections(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        '''module demo.main;

@experimental
pub fn run() -> Unit effects() { return unit; }

@deprecated(reason="use demo.main.File2", replacement="demo.main.File2")
pub resource File {
    fields {
        fd: Int;
    }
}

@since("0.47.56")
pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}
''',
    )
    interface_path = _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.main'],
                'public_functions': {'demo.main': ['demo.main.run']},
                'public_resources': {'demo.main': ['demo.main.File']},
                'public_protocols': {'demo.main': ['demo.main.Readable']},
                'public_function_metadata': {'demo.main': {'demo.main.run': {'stability': 'stable'}}},
                'public_resource_metadata': {'demo.main': {'demo.main.File': {'stability': 'stable'}}},
                'public_protocol_metadata': {'demo.main': {'demo.main.Readable': {'stability': 'stable'}}},
            }
        ),
    )

    rc = main([
        'check-package-interface-sync',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(interface_path),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'function lifecycle metadata' in captured.err
    assert 'resource lifecycle metadata' in captured.err
    assert 'protocol lifecycle metadata' in captured.err


def test_check_package_interface_sync_reports_extra_unknown_fields(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\n\npub fn run() -> Unit effects() { return unit; }\n',
    )
    interface_path = _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.main'],
                'public_functions': {'demo.main': ['demo.main.run']},
                'x_local_note': 'not preserved by canonical emission',
            }
        ),
    )

    rc = main([
        'check-package-interface-sync',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(interface_path),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'extra field x_local_note' in captured.err
