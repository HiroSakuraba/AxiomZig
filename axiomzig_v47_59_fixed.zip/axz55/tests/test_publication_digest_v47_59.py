"""
test_publication_digest_v47_59.py — v47.59: canonical publication digest

Tests for:
  - build_publication_digest_record: produces a valid digest record
  - compute_publication_digest: stable, deterministic, excludes signature fields
  - verify_publication_digest_record: accepts correct records, rejects tampered ones
  - `pubdigest` CLI command: compute and verify modes
  - Integration with the publication pipeline (emit -> conform -> pubdigest)
"""
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

from axiomzig.cli import main
from axiomzig.module_graph import (
    build_publication_digest_record,
    compute_publication_digest,
    verify_publication_digest_record,
)


# ─────────────────────────────────────────────────────────────────────────────
# helpers
# ─────────────────────────────────────────────────────────────────────────────

def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def _minimal_manifest(*, version: str = "1.0.0") -> dict:
    return {
        "schema_version": "axiomzig.publication_manifest.v1",
        "package_name": "mypkg",
        "package_version": version,
        "package_id": f"mypkg@{version}",
        "manifest_hash": "abc123",
        "exported_functions": {"mypkg.api": ["mypkg.api.f"]},
        "exported_modules": ["mypkg.api"],
    }


def _build_pub(root: Path, capsys, *, name: str = "pkg",
               version: str = "1.0.0", module: str = "pkg.api",
               source: str = "module pkg.api;\npub fn f() -> Unit effects() { return unit; }\n") -> Path:
    src = _write(root / Path(*module.split(".")).with_suffix(".az"), source)
    iface = root / "iface.json"
    main(["emit-package-interface", str(src), "--module-root", str(root),
          "--package-name", name, "--package-version", version, "--out", str(iface)])
    capsys.readouterr()
    pub = root / "pub.json"
    main(["conform", str(src), "--module-root", str(root),
          "--package-interface", str(iface), "--publication-out", str(pub)])
    capsys.readouterr()
    return pub


# ─────────────────────────────────────────────────────────────────────────────
# Unit tests: compute_publication_digest
# ─────────────────────────────────────────────────────────────────────────────

def test_digest_is_deterministic() -> None:
    m = _minimal_manifest()
    d1 = compute_publication_digest(m)
    d2 = compute_publication_digest(m)
    assert d1 == d2
    assert len(d1) == 64  # SHA-256 hex


def test_digest_excludes_signature_fields() -> None:
    m = _minimal_manifest()
    d_no_sig = compute_publication_digest(m)

    m_with_sig = deepcopy(m)
    m_with_sig["signature"] = "deadbeef"
    m_with_sig["signature_algorithm"] = "ed25519"
    m_with_sig["signature_public_key_id"] = "key-1"
    d_with_sig = compute_publication_digest(m_with_sig)

    assert d_no_sig == d_with_sig, (
        "digest must be identical whether or not signature fields are present"
    )


def test_digest_changes_when_content_changes() -> None:
    m = _minimal_manifest()
    d1 = compute_publication_digest(m)
    m2 = deepcopy(m)
    m2["package_version"] = "2.0.0"
    d2 = compute_publication_digest(m2)
    assert d1 != d2


def test_digest_is_stable_across_field_ordering() -> None:
    """Canonical JSON uses sort_keys so field ordering in the dict is irrelevant."""
    m1 = {"schema_version": "axiomzig.publication_manifest.v1",
          "package_name": "x", "package_version": "1.0.0", "package_id": "x@1.0.0",
          "manifest_hash": "h", "a": 1, "b": 2}
    m2 = {"b": 2, "a": 1, "manifest_hash": "h", "package_id": "x@1.0.0",
          "package_name": "x", "package_version": "1.0.0",
          "schema_version": "axiomzig.publication_manifest.v1"}
    assert compute_publication_digest(m1) == compute_publication_digest(m2)


# ─────────────────────────────────────────────────────────────────────────────
# Unit tests: build_publication_digest_record
# ─────────────────────────────────────────────────────────────────────────────

def test_digest_record_schema_version() -> None:
    record = build_publication_digest_record(_minimal_manifest())
    assert record["schema_version"] == "axiomzig.publication_digest.v1"


def test_digest_record_carries_package_identity() -> None:
    m = _minimal_manifest()
    record = build_publication_digest_record(m)
    assert record["package_name"] == "mypkg"
    assert record["package_version"] == "1.0.0"
    assert record["package_id"] == "mypkg@1.0.0"


def test_digest_record_publication_digest_is_non_empty() -> None:
    record = build_publication_digest_record(_minimal_manifest())
    assert record["publication_digest"]
    assert record["publication_digest_algorithm"] == "sha256"


def test_digest_record_signature_fields_are_null() -> None:
    record = build_publication_digest_record(_minimal_manifest())
    assert record["signature"] is None
    assert record["signature_algorithm"] is None
    assert record["signature_public_key_id"] is None


def test_digest_record_lists_excluded_fields() -> None:
    record = build_publication_digest_record(_minimal_manifest())
    excl = set(record["excluded_fields"])
    assert "signature" in excl
    assert "signature_algorithm" in excl
    assert "signature_public_key_id" in excl


def test_digest_record_rejects_wrong_schema() -> None:
    bad = _minimal_manifest()
    bad["schema_version"] = "axiomzig.package_interface.v1"
    with pytest.raises(ValueError, match="pubdigest requires a publication manifest"):
        build_publication_digest_record(bad)


def test_digest_record_conformance_schema_accepted() -> None:
    m = _minimal_manifest()
    m["schema_version"] = "axiomzig.conformance.v4"
    record = build_publication_digest_record(m)
    assert record["schema_version"] == "axiomzig.publication_digest.v1"


def test_digest_record_manifest_hash_propagated() -> None:
    m = _minimal_manifest()
    m["manifest_hash"] = "deadbeef1234"
    record = build_publication_digest_record(m)
    assert record["manifest_hash"] == "deadbeef1234"


# ─────────────────────────────────────────────────────────────────────────────
# Unit tests: verify_publication_digest_record
# ─────────────────────────────────────────────────────────────────────────────

def test_verify_clean_record_returns_no_errors() -> None:
    m = _minimal_manifest()
    record = build_publication_digest_record(m)
    errors = verify_publication_digest_record(m, record)
    assert errors == []


def test_verify_detects_tampered_content() -> None:
    m = _minimal_manifest()
    record = build_publication_digest_record(m)
    tampered = deepcopy(m)
    tampered["package_version"] = "9.9.9"
    errors = verify_publication_digest_record(tampered, record)
    assert any("publication_digest mismatch" in e for e in errors)


def test_verify_detects_wrong_package_id() -> None:
    m = _minimal_manifest()
    record = build_publication_digest_record(m)
    m2 = deepcopy(m)
    m2["package_id"] = "otherpkg@1.0.0"
    errors = verify_publication_digest_record(m2, record)
    assert any("package_id" in e for e in errors)


def test_verify_ignores_signature_field_additions() -> None:
    """Adding a signature to the manifest must not change the digest."""
    m = _minimal_manifest()
    record = build_publication_digest_record(m)
    signed = deepcopy(m)
    signed["signature"] = "cafebabe"
    signed["signature_algorithm"] = "ed25519"
    signed["signature_public_key_id"] = "key-42"
    errors = verify_publication_digest_record(signed, record)
    assert errors == [], f"signature addition must not invalidate digest: {errors}"


def test_verify_rejects_wrong_schema_version() -> None:
    m = _minimal_manifest()
    record = build_publication_digest_record(m)
    record["schema_version"] = "axiomzig.publication_digest.v0"
    errors = verify_publication_digest_record(m, record)
    assert any("schema_version" in e for e in errors)


def test_verify_detects_manifest_hash_mismatch() -> None:
    m = _minimal_manifest()
    record = build_publication_digest_record(m)
    m2 = deepcopy(m)
    m2["manifest_hash"] = "different_hash"
    errors = verify_publication_digest_record(m2, record)
    # digest mismatch (content changed) and/or manifest_hash mismatch
    assert len(errors) > 0


# ─────────────────────────────────────────────────────────────────────────────
# CLI tests: pubdigest command
# ─────────────────────────────────────────────────────────────────────────────

def test_cli_pubdigest_writes_json_to_file(tmp_path: Path, capsys) -> None:
    pub = _build_pub(tmp_path / "pkg", capsys)
    out = tmp_path / "digest.json"
    rc = main(["pubdigest", str(pub), "--out", str(out)])
    assert rc == 0
    record = json.loads(out.read_text(encoding="utf-8"))
    assert record["schema_version"] == "axiomzig.publication_digest.v1"
    assert record["publication_digest"]


def test_cli_pubdigest_prints_to_stdout(tmp_path: Path, capsys) -> None:
    pub = _build_pub(tmp_path / "pkg", capsys)
    rc = main(["pubdigest", str(pub)])
    captured = capsys.readouterr()
    assert rc == 0
    record = json.loads(captured.out)
    assert record["schema_version"] == "axiomzig.publication_digest.v1"


def test_cli_pubdigest_verify_passes_on_clean(tmp_path: Path, capsys) -> None:
    pub = _build_pub(tmp_path / "pkg", capsys)
    digest_file = tmp_path / "digest.json"
    main(["pubdigest", str(pub), "--out", str(digest_file)])
    capsys.readouterr()
    rc = main(["pubdigest", str(pub), "--verify", str(digest_file)])
    captured = capsys.readouterr()
    assert rc == 0
    assert "ok" in captured.out.lower()


def test_cli_pubdigest_verify_fails_on_tampered_manifest(tmp_path: Path, capsys) -> None:
    pub = _build_pub(tmp_path / "pkg", capsys)
    digest_file = tmp_path / "digest.json"
    main(["pubdigest", str(pub), "--out", str(digest_file)])
    capsys.readouterr()

    # Tamper with the manifest
    data = json.loads(pub.read_text(encoding="utf-8"))
    data["package_version"] = "9.9.9"
    tampered = tmp_path / "tampered.json"
    tampered.write_text(json.dumps(data), encoding="utf-8")

    rc = main(["pubdigest", str(tampered), "--verify", str(digest_file)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "error" in captured.err.lower() or "mismatch" in captured.err.lower()


def test_cli_pubdigest_rejects_package_interface_schema(tmp_path: Path, capsys) -> None:
    """pubdigest must reject package-interface files (wrong schema)."""
    pkg_root = tmp_path / "pkg"
    src = _write(pkg_root / "api.az", "module pkg.api;\npub fn f() -> Unit effects() { return unit; }\n")
    iface = pkg_root / "iface.json"
    main(["emit-package-interface", str(src), "--module-root", str(pkg_root),
          "--package-name", "pkg", "--package-version", "1.0.0", "--out", str(iface)])
    capsys.readouterr()
    rc = main(["pubdigest", str(iface)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "error" in captured.err.lower()


def test_cli_pubdigest_digest_stable_after_signature_attachment(tmp_path: Path, capsys) -> None:
    """
    Attaching a signature to the manifest must not change the publication_digest.
    A verifier can check the signed manifest just as well as the unsigned one.
    """
    pub = _build_pub(tmp_path / "pkg", capsys)
    digest_file = tmp_path / "digest.json"
    main(["pubdigest", str(pub), "--out", str(digest_file)])
    capsys.readouterr()

    # Simulate external signing tool attaching a signature
    pub_data = json.loads(pub.read_text(encoding="utf-8"))
    pub_data["signature"] = "0" * 128  # fake ed25519 sig (hex)
    pub_data["signature_algorithm"] = "ed25519"
    pub_data["signature_public_key_id"] = "test-key-1"
    signed_pub = tmp_path / "signed_pub.json"
    signed_pub.write_text(json.dumps(pub_data, indent=2), encoding="utf-8")

    # Verify the signed manifest against the original digest record
    rc = main(["pubdigest", str(signed_pub), "--verify", str(digest_file)])
    captured = capsys.readouterr()
    assert rc == 0, (
        f"verification must pass after signature attachment: {captured.err}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Integration: full pipeline emit -> conform -> pubdigest -> verify
# ─────────────────────────────────────────────────────────────────────────────

def test_full_pipeline_emit_conform_pubdigest_verify(tmp_path: Path, capsys) -> None:
    """
    End-to-end: build a real publication manifest through the CLI pipeline
    and verify it round-trips through pubdigest without errors.
    """
    pub = _build_pub(
        tmp_path / "pkg", capsys,
        name="mypkg", version="2.3.4", module="mypkg.core",
        source=(
            "module mypkg.core;\n\n"
            "@since(\"2.0.0\")\n"
            "pub fn stable() -> Unit effects() { return unit; }\n\n"
            "@experimental\n"
            "pub fn beta() -> Unit effects() { return unit; }\n"
        ),
    )

    digest_file = tmp_path / "mypkg_digest.json"
    rc = main(["pubdigest", str(pub), "--out", str(digest_file)])
    assert rc == 0

    record = json.loads(digest_file.read_text(encoding="utf-8"))
    assert record["package_name"] == "mypkg"
    assert record["package_version"] == "2.3.4"
    assert record["package_id"] == "mypkg@2.3.4"
    assert record["signature"] is None  # unsigned placeholder
    assert record["publication_digest_algorithm"] == "sha256"

    rc2 = main(["pubdigest", str(pub), "--verify", str(digest_file)])
    capsys.readouterr()
    assert rc2 == 0


def test_pubdigest_record_tracks_manifest_hash_from_real_publication(tmp_path: Path, capsys) -> None:
    """
    The digest record's manifest_hash must match the publication manifest's
    own manifest_hash exactly, so a verifier can chain from the digest record
    back to the manifest integrity.
    """
    pub = _build_pub(tmp_path / "pkg", capsys)
    pub_data = json.loads(pub.read_text(encoding="utf-8"))
    manifest_hash = pub_data["manifest_hash"]
    assert manifest_hash, "real publication must have a manifest_hash"

    record = build_publication_digest_record(pub_data)
    assert record["manifest_hash"] == manifest_hash, (
        f"digest record must carry the publication's manifest_hash: "
        f"expected {manifest_hash!r}, got {record['manifest_hash']!r}"
    )
