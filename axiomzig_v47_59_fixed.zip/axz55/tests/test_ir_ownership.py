from axiomzig.ir import lower_module
from axiomzig.ownership import analyze_ownership
from axiomzig.parser import parse_module


def ownership_messages(summary):
    return [issue.message for issue in summary.issues]


def test_lower_emits_typed_ir_for_match_return() -> None:
    module = parse_module(
        '''
module demo.lowered;

error_set ParseError {
    Empty;
}

enum Status {
    Ok;
}

fn parse_one(s: Str) -> Status!ParseError effects(error) {
    return match s {
        "" -> ParseError.Empty,
        _ -> Status.Ok,
    };
}
'''
    )
    lowered = lower_module(module)
    fn = lowered.functions[0]
    assert fn.name == 'parse_one'
    assert fn.return_type == 'Status!ParseError'
    ret = fn.body[0]
    assert ret.kind == 'return'
    assert ret.value is not None
    assert ret.value.kind == 'MatchExpr'
    assert ret.value.type_text == 'Status!ParseError'


def test_ownership_accepts_defer_close_move() -> None:
    module = parse_module(
        '''
module demo.fileok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn consume_file(f: File) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn good(f: File) -> Unit effects(protocol_step) {
    defer consume_file(move f);
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_ownership_rejects_leak() -> None:
    module = parse_module(
        '''
module demo.leak;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn leak(f: File) -> Unit effects() {
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    joined = '\n'.join(ownership_messages(summary))
    assert 'resource f: File leaves scope in non-terminal state Open' in joined


def test_ownership_rejects_branch_mismatch() -> None:
    module = parse_module(
        '''
module demo.branch;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn bad(f: File, cond: Bool) -> Unit effects(protocol_step) {
    if (cond) {
        f.close();
    } else {
    }
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    joined = '\n'.join(ownership_messages(summary))
    assert 'if branches leave resource f in different states: Closed vs Open' in joined
