from axiomzig.interpreter import ArrayVal, BoolVal, ImportStub, IntVal, Interpreter, RefVal, RuntimePlace, TrapError, UnitVal
from axiomzig.ownership import analyze_ownership
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature
from axiomzig.parser import parse_module


def _i32(n: int) -> IntVal:
    return IntVal(n, width=32, signed=True)


def _holder_file_source(body: str, return_type: str = "Unit") -> str:
    return f"""
module demo.main;
import demo.util;

protocol FileProtocol {{
    states {{ Open, Closed }}
    init Open;
    terminal {{ Closed }}
    transitions {{
        close: Open -> Closed;
    }}
}}

resource File {{
    protocol: FileProtocol;
    fields {{
        fd: I32;
    }}
}}

struct Holder {{
    inner: File;
}}

fn make_holder() -> Holder effects() {{
    return Holder {{ inner: File {{ fd: 0 }} }};
}}

{body}
"""


def _close_inner_sig() -> FunctionOwnershipSignature:
    return FunctionOwnershipSignature(
        name="demo.util.close_inner",
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Holder", effects={"inner": "Closed"})],
        param_types=["Ref<Holder>"],
        return_type="Unit",
        effects=["protocol_step"],
    )


def _reopen_inner_sig() -> FunctionOwnershipSignature:
    return FunctionOwnershipSignature(
        name="demo.util.reopen_inner",
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Holder", effects={"inner": "Open"})],
        param_types=["Ref<Holder>"],
        return_type="Unit",
        effects=["protocol_step"],
    )


def _sig_index(signatures: list[FunctionOwnershipSignature]) -> dict[str, FunctionOwnershipSignature]:
    return {sig.name: sig for sig in signatures}


def _stub_index(signatures: list[FunctionOwnershipSignature]) -> dict[str, ImportStub]:
    return {sig.name: ImportStub(return_value=UnitVal()) for sig in signatures}


def _inner_state(holder) -> str:
    return holder.fields["inner"].protocol_state


def test_imported_nested_ref_summary_closes_holder_inner_runtime_place() -> None:
    src = _holder_file_source(
        """
fn close_and_return() -> Holder effects(protocol_step) {
    var h: Holder = make_holder();
    demo.util.close_inner(borrow h);
    return h;
}
"""
    )
    sigs = _sig_index([_close_inner_sig()])
    interp = Interpreter(parse_module(src), imported_signatures=sigs, import_stubs=_stub_index(list(sigs.values())))

    holder = interp.call_function(interp.functions["close_and_return"], [])

    assert _inner_state(holder) == "Closed"


def test_imported_nested_ref_summary_reopens_closed_holder_inner_runtime_place() -> None:
    src = _holder_file_source(
        """
fn reopen_and_reclose() -> Unit effects(protocol_step) {
    var h: Holder = make_holder();
    h.inner.close();
    demo.util.reopen_inner(borrow h);
    h.inner.close();
    return unit;
}
"""
    )
    sigs = _sig_index([_reopen_inner_sig()])
    interp = Interpreter(parse_module(src), imported_signatures=sigs, import_stubs=_stub_index(list(sigs.values())))

    result = interp.call_function(interp.functions["reopen_and_reclose"], [])

    assert isinstance(result, UnitVal)


def test_imported_numeric_nested_path_closes_indexed_array_resource() -> None:
    src = _holder_file_source(
        """
fn close_second(xs: Ref<Array<Holder, 2>>) -> Unit effects(protocol_step) {
    demo.util.close_second(xs);
    return unit;
}
"""
    )
    sig = FunctionOwnershipSignature(
        name="demo.util.close_second",
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Array<Holder, 2>", effects={"1.inner": "Closed"})],
        param_types=["Ref<Array<Holder, 2>>"],
        return_type="Unit",
        effects=["protocol_step"],
    )
    sigs = _sig_index([sig])
    interp = Interpreter(parse_module(src), imported_signatures=sigs, import_stubs=_stub_index(list(sigs.values())))
    first = interp.call_function(interp.functions["make_holder"], [])
    second = interp.call_function(interp.functions["make_holder"], [])
    root = interp.allocate_cell(ArrayVal([first, second]))

    interp.call_function(interp.functions["close_second"], [RefVal(RuntimePlace(root, ()), mutable=True)])

    assert interp.read_runtime_place(RuntimePlace(root, (0, "inner"))).protocol_state == "Open"
    assert interp.read_runtime_place(RuntimePlace(root, (1, "inner"))).protocol_state == "Closed"


def test_imported_nested_summary_is_runtime_visible_after_join_on_both_branches() -> None:
    src = _holder_file_source(
        """
fn close_after_join(flag: Bool) -> Holder effects(protocol_step) {
    var h: Holder = make_holder();
    if (flag) {
        demo.util.close_inner(borrow h);
    } else {
        demo.util.close_inner(borrow h);
    }
    return h;
}
"""
    )
    sigs = _sig_index([_close_inner_sig()])
    stubs = _stub_index(list(sigs.values()))
    interp = Interpreter(parse_module(src), imported_signatures=sigs, import_stubs=stubs)

    true_holder = interp.call_function(interp.functions["close_after_join"], [BoolVal(True)])
    false_holder = interp.call_function(interp.functions["close_after_join"], [BoolVal(False)])

    assert _inner_state(true_holder) == "Closed"
    assert _inner_state(false_holder) == "Closed"


def test_imported_nested_summary_traps_if_local_transition_repeats_after_join() -> None:
    src = _holder_file_source(
        """
fn close_twice(flag: Bool) -> Unit effects(protocol_step) {
    var h: Holder = make_holder();
    if (flag) {
        demo.util.close_inner(borrow h);
    } else {
        demo.util.close_inner(borrow h);
    }
    h.inner.close();
    return unit;
}
"""
    )
    sigs = _sig_index([_close_inner_sig()])
    interp = Interpreter(parse_module(src), imported_signatures=sigs, import_stubs=_stub_index(list(sigs.values())))

    try:
        interp.call_function(interp.functions["close_twice"], [BoolVal(True)])
    except TrapError as exc:
        assert exc.reason == "invalid protocol transition close from Closed"
    else:
        raise AssertionError("expected repeated post-import transition to trap")


def test_imported_join_state_static_conformance_accepts_matching_branch_effects() -> None:
    src = _holder_file_source(
        """
fn run(flag: Bool) -> Unit effects(protocol_step) {
    var h: Holder = make_holder();
    if (flag) {
        demo.util.close_inner(borrow h);
    } else {
        demo.util.close_inner(borrow h);
    }
    return unit;
}
"""
    )
    module = parse_module(src)
    summary = analyze_ownership(module, imported_signatures=_sig_index([_close_inner_sig()]))

    assert [issue.message for issue in summary.issues if issue.level == "error"] == []


def test_imported_join_state_static_conformance_rejects_divergent_branch_effects() -> None:
    src = _holder_file_source(
        """
fn run(flag: Bool) -> Unit effects(protocol_step) {
    var h: Holder = make_holder();
    if (flag) {
        demo.util.close_inner(borrow h);
    } else {
        demo.util.reopen_inner(borrow h);
    }
    return unit;
}
"""
    )
    module = parse_module(src)
    summary = analyze_ownership(module, imported_signatures=_sig_index([_close_inner_sig(), _reopen_inner_sig()]))
    errors = "\n".join(issue.message for issue in summary.issues if issue.level == "error")

    assert "if branches leave resource h in different states" in errors
