from axiomzig.formatter import format_module
from axiomzig.parser import parse_module


UGLY_COMPLEX_MODULE = """
module   demo.formatter ;

struct Pair{left:I64;right:I64;}

enum Choice{First;Second{value:I64;};}

fn helper(x:I64,y:I64)->I64 effects( ) {return x+y;}
fn helper_result(x:I64)->I64!ParseError effects(error){return x;}

error_set ParseError{Empty;}

fn main(flag:Bool,xs:Slice<I64>)->I64!ParseError effects(error){var total:I64=0;defer helper(total,0);errdefer helper(0,0);if(flag){total=helper(xs[0],@cast(I64,2));}else if(flag){total=Choice.Second{value:Pair{left:1,right:2}.left}.value;}else{total=try helper_result(total);}for(i:I64 in 0..10){total+=i;}return total;}
"""


EXPECTED_FORMATTED_COMPLEX_MODULE = """module demo.formatter;

struct Pair {
    left: I64;
    right: I64;
}

enum Choice {
    First;
    Second {
        value: I64;
    };
}

fn helper(x: I64, y: I64) -> I64 effects() {
    return x + y;
}

fn helper_result(x: I64) -> I64!ParseError effects(error) {
    return x;
}

error_set ParseError {
    Empty;
}

fn main(flag: Bool, xs: Slice<I64>) -> I64!ParseError effects(error) {
    var total: I64 = 0;
    defer helper(total, 0);
    errdefer helper(0, 0);
    if (flag) {
        total = helper(xs[0], @cast(I64, 2));
    } else if (flag) {
        total = Choice.Second { value: Pair { left: 1, right: 2 }.left }.value;
    } else {
        total = helper_result(total)?;
    }
    for (i: I64 in 0..10) {
        total += i;
    }
    return total;
}
"""


MESSY_MATCH_MODULE = """
module demo.matchfmt;

fn bump(flag: Bool, x: Option<I64>) -> Option<I64> effects() {
    return match x { some(v)->some(v+1), none -> match flag { true -> some(1), false -> none, }, };
}
"""


EXPECTED_MATCH_FORMAT = """module demo.matchfmt;

fn bump(flag: Bool, x: Option<I64>) -> Option<I64> effects() {
    return match x {
        some(v) -> some(v + 1),
        none -> match flag {
            true -> some(1),
            false -> none,
        },
    };
}
"""


def test_formatter_normalizes_complex_module_to_expected_output() -> None:
    module = parse_module(UGLY_COMPLEX_MODULE)
    formatted = format_module(module)
    assert formatted == EXPECTED_FORMATTED_COMPLEX_MODULE


def test_formatter_roundtrip_is_stable_for_complex_module() -> None:
    formatted1 = format_module(parse_module(UGLY_COMPLEX_MODULE))
    formatted2 = format_module(parse_module(formatted1))
    assert formatted1 == formatted2


def test_formatter_expands_nested_match_expression_consistently() -> None:
    formatted = format_module(parse_module(MESSY_MATCH_MODULE))
    assert formatted == EXPECTED_MATCH_FORMAT


def test_formatter_is_idempotent_on_already_formatted_output() -> None:
    formatted1 = format_module(parse_module(EXPECTED_FORMATTED_COMPLEX_MODULE))
    formatted2 = format_module(parse_module(formatted1))
    assert formatted1 == formatted2

MESSY_DECLS_AND_DEFER_MODULE = """
module demo.protofmt;
import demo.io;
protocol FileProto{states{Open,Closed} init Open; terminal{Closed} transitions{close: Open -> Closed;}}
resource File{protocol: FileProto; fields{fd: I64;}}
fn main(flag: Bool) -> Unit effects() {
    defer if(flag){return unit;} else {return unit;}
    return unit;
}
"""


EXPECTED_DECLS_AND_DEFER_FORMAT = """module demo.protofmt;

import demo.io;

protocol FileProto {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProto;
    fields {
        fd: I64;
    }
}

fn main(flag: Bool) -> Unit effects() {
    defer if (flag) {
        return unit;
    } else {
        return unit;
    }
    return unit;
}
"""


MESSY_LET_MATCH_MODULE = """
module demo.letmatch;

fn f(flag: Bool) -> I64 effects() {
    let y=match flag { true->1,false->2,};
    return y;
}
"""


EXPECTED_LET_MATCH_FORMAT = """module demo.letmatch;

fn f(flag: Bool) -> I64 effects() {
    let y = match flag {
        true -> 1,
        false -> 2,
    };
    return y;
}
"""


def test_formatter_normalizes_protocol_resource_imports_and_multiline_defer() -> None:
    formatted = format_module(parse_module(MESSY_DECLS_AND_DEFER_MODULE))
    assert formatted == EXPECTED_DECLS_AND_DEFER_FORMAT


def test_formatter_formats_multiline_match_inside_let_binding() -> None:
    formatted = format_module(parse_module(MESSY_LET_MATCH_MODULE))
    assert formatted == EXPECTED_LET_MATCH_FORMAT


def test_formatter_nested_match_arm_does_not_emit_block_body_syntax() -> None:
    formatted = format_module(parse_module(MESSY_MATCH_MODULE))
    assert '-> {' not in formatted
    assert 'none -> match flag {' in formatted
