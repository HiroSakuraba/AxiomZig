from axiomzig.parser import parse_module
from axiomzig.resolve import resolve_module


def messages(summary):
    return [issue.message for issue in summary.issues]


def test_resolution_classifies_enum_and_error_tags() -> None:
    module = parse_module(
        """
module demo.resolve;

enum Status {
    Ok;
    Failed { code: I64; };
}

error_set ParseError {
    Empty;
}

fn classify(x: Status, y: Str) -> Status!ParseError effects(error) {
    let z = match x {
        Status.Ok -> Status.Ok,
        Status.Failed { code: c } -> Status.Failed { code: c },
    };
    return match y {
        "" -> ParseError.Empty,
        _ -> z,
    };
}
"""
    )
    summary = resolve_module(module)
    assert messages(summary) == []
    refs = {ref.text: ref.classification for ref in summary.functions[0].values}
    assert refs["Status.Ok"] == "enum_variant"
    assert refs["ParseError.Empty"] == "error_tag"


def test_resolution_reports_unknown_names_and_types() -> None:
    module = parse_module(
        """
module demo.bad;

fn bad(x: Unknown) -> I64 effects() {
    return missing_name;
}
"""
    )
    summary = resolve_module(module)
    joined = "\n".join(messages(summary))
    assert "unknown type name Unknown" in joined
    assert "unresolved name missing_name" in joined


def test_shadowing_is_rejected() -> None:
    module = parse_module(
        """
module demo.shadow;

fn bad(x: I64) -> I64 effects() {
    let y = x;
    if (true) {
        let y = 1;
        return y;
    }
    return y;
}
"""
    )
    summary = resolve_module(module)
    assert any("shadowing forbidden for name y" == msg for msg in messages(summary))


def test_defer_control_flow_is_rejected() -> None:
    module = parse_module(
        """
module demo.deferbad;

fn bad() -> Unit effects() {
    defer return;
    return;
}
"""
    )
    summary = resolve_module(module)
    assert any("defer/errdefer body may not alter control flow" == msg for msg in messages(summary))



def test_defer_nested_defer_is_rejected() -> None:
    module = parse_module(
        """
module demo.defernested;

fn cleanup() -> Unit effects() { return unit; }

fn bad() -> Unit effects() {
    defer defer cleanup();
    return unit;
}
"""
    )
    summary = resolve_module(module)
    assert any("defer/errdefer body may not contain a nested defer or errdefer" in msg for msg in messages(summary))


def test_errdefer_nested_in_defer_is_rejected() -> None:
    module = parse_module(
        """
module demo.errdeferindefer;

fn cleanup() -> Unit effects() { return unit; }

fn bad() -> Unit effects() {
    defer errdefer cleanup();
    return unit;
}
"""
    )
    summary = resolve_module(module)
    assert any("defer/errdefer body may not contain a nested defer or errdefer" in msg for msg in messages(summary))


def test_defer_with_call_is_accepted() -> None:
    module = parse_module(
        """
module demo.deferclean;

fn cleanup() -> Unit effects() { return unit; }

fn good() -> Unit effects() {
    defer cleanup();
    return unit;
}
"""
    )
    summary = resolve_module(module)
    assert not any("nested defer" in msg for msg in messages(summary))


def test_import_binding_is_classified() -> None:
    module = parse_module(
        """
module demo.imports;

import core.io.Reader;

fn use_import(x: I64) -> I64 effects() {
    let y = x;
    Reader.open(y);
    return y;
}
"""
    )
    summary = resolve_module(module)
    assert messages(summary) == []
    refs = {ref.text: ref.classification for ref in summary.functions[0].values}
    assert refs["Reader.open"] == "import_member"


def test_resolution_accepts_integer_range_for_loop() -> None:
    module = parse_module(
        """
module demo.rangefor;

fn main() -> Unit effects() {
    for (i: I64 in 0..4) {
        let x = i;
    }
    return unit;
}
"""
    )
    summary = resolve_module(module)
    assert messages(summary) == []


def test_resolution_accepts_fully_qualified_import_member_path() -> None:
    module = parse_module(
        """
module demo.main;

import demo.util;

fn main() -> I64 effects() {
    return demo.util.add(2, 3);
}
"""
    )
    summary = resolve_module(module)
    assert messages(summary) == []
    refs = {ref.text: ref.classification for ref in summary.functions[0].values}
    assert refs["demo.util.add"] == "import_member"
