from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
LEDGER_PATH = ROOT / "docs" / "interpreter_runtime_conformance_ledger_v47_31.json"
ALLOWED_STATUS = {"supported", "supported_narrow", "unsupported"}
TEST_REF_RE = re.compile(r"^(tests/[^:]+)::(test_[A-Za-z0-9_]+)$")


def _load_ledger() -> dict:
    return json.loads(LEDGER_PATH.read_text(encoding="utf-8"))


def _assert_test_ref_exists(ref: str) -> None:
    match = TEST_REF_RE.fullmatch(ref)
    assert match is not None, f"invalid test reference syntax: {ref}"
    rel_path, test_name = match.groups()
    file_path = ROOT / rel_path
    assert file_path.exists(), f"referenced test file does not exist: {rel_path}"
    text = file_path.read_text(encoding="utf-8")
    assert re.search(rf"^def {re.escape(test_name)}\(", text, re.MULTILINE), (
        f"referenced test function does not exist: {ref}"
    )


def test_interpreter_conformance_ledger_schema_and_references() -> None:
    payload = _load_ledger()
    assert payload["version"] == "v47.31"
    assert isinstance(payload.get("entries"), list)
    assert payload["entries"], "ledger must contain entries"

    ids: set[str] = set()
    for entry in payload["entries"]:
        assert set(entry) == {"id", "feature", "status", "source_tests", "direct_tests", "notes"}
        assert isinstance(entry["id"], str) and entry["id"]
        assert entry["id"] not in ids, f"duplicate ledger id: {entry['id']}"
        ids.add(entry["id"])
        assert isinstance(entry["feature"], str) and entry["feature"]
        assert entry["status"] in ALLOWED_STATUS
        assert isinstance(entry["notes"], str) and entry["notes"]
        assert isinstance(entry["source_tests"], list)
        assert isinstance(entry["direct_tests"], list)
        if entry["status"] != "unsupported":
            assert entry["source_tests"] or entry["direct_tests"], (
                f"supported entry must cite at least one test: {entry['id']}"
            )
        for ref in [*entry["source_tests"], *entry["direct_tests"]]:
            _assert_test_ref_exists(ref)


def test_interpreter_conformance_ledger_expected_narrow_points_are_present() -> None:
    payload = _load_ledger()
    by_id = {entry["id"]: entry for entry in payload["entries"]}

    assert by_id["array_slice_runtime_values"]["status"] == "supported_narrow"
    assert by_id["imported_pure_calls_stubbed_only"]["status"] == "supported"
    assert by_id["imported_nested_path_summaries"]["status"] == "supported"
    assert by_id["imported_cleanup_replay"]["status"] == "supported_narrow"
    assert by_id["imported_cleanup_replay"]["source_tests"]
    assert by_id["cleanup_suppression_scope"]["status"] == "supported_narrow"
    assert by_id["cleanup_suppression_scope"]["source_tests"]
    assert "signature-backed local/imported wrapper cleanups" in by_id["cleanup_suppression_scope"]["notes"]
