from axiomzig.interpreter import ArrayVal, ImportStub, ImportWrite, IntVal, Interpreter, InterpreterUnsupportedError, MovedVal, RefVal, ResourceVal, RuntimePlace, SliceVal
from axiomzig.parser import parse_module
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature


def _interp(src: str) -> Interpreter:
    return Interpreter(parse_module(src))


def _i64(n: int) -> IntVal:
    return IntVal(n, width=64, signed=True)


def test_interpreter_array_param_indexing_and_len() -> None:
    interp = _interp(
        """
module demo.arr;

fn second(xs: Array<I64, 3>) -> I64 effects() {
    return xs[1];
}

fn size(xs: Array<I64, 3>) -> U64 effects() {
    return xs.len;
}
"""
    )
    xs = ArrayVal([_i64(5), _i64(7), _i64(9)])
    got_second = interp.call_function(interp.functions["second"], [xs])
    got_size = interp.call_function(interp.functions["size"], [xs])
    assert isinstance(got_second, IntVal)
    assert got_second.value == 7
    assert isinstance(got_size, IntVal)
    assert got_size.value == 3
    assert got_size.width == 64 and not got_size.signed


def test_interpreter_array_slice_and_slice_indexing() -> None:
    interp = _interp(
        """
module demo.sliceidx;

fn middle(xs: Array<I64, 4>) -> Slice<I64> effects() {
    return xs[1..3];
}

fn pick(xs: Slice<I64>) -> I64 effects() {
    return xs[1];
}
"""
    )
    xs = ArrayVal([_i64(10), _i64(20), _i64(30), _i64(40)])
    mid = interp.call_function(interp.functions["middle"], [xs])
    assert isinstance(mid, SliceVal)
    picked = interp.call_function(interp.functions["pick"], [mid])
    assert isinstance(picked, IntVal)
    assert picked.value == 30


def test_interpreter_for_over_array_and_slice() -> None:
    interp = _interp(
        """
module demo.forsum;

fn sum_array(xs: Array<I64, 4>) -> I64 effects() {
    var total: I64 = 0;
    for (x: I64 in xs) {
        total = total + x;
    }
    return total;
}

fn sum_slice(xs: Slice<I64>) -> I64 effects() {
    var total: I64 = 0;
    for (x: I64 in xs) {
        total = total + x;
    }
    return total;
}
"""
    )
    xs = ArrayVal([_i64(1), _i64(2), _i64(3), _i64(4)])
    array_sum = interp.call_function(interp.functions["sum_array"], [xs])
    assert isinstance(array_sum, IntVal)
    assert array_sum.value == 10

    mid = interp.make_slice_view(None, xs, 1, 4)
    assert isinstance(mid, SliceVal)
    slice_sum = interp.call_function(interp.functions["sum_slice"], [mid])
    assert isinstance(slice_sum, IntVal)
    assert slice_sum.value == 9


def test_interpreter_borrowed_array_element_assignment_updates_storage() -> None:
    interp = _interp(
        """
module demo.bump;

fn bump(xs: Ref<Array<I64, 3>>) -> Unit effects() {
    xs[1] = xs[1] + 5;
    return unit;
}
"""
    )
    root_cell = interp.allocate_cell(ArrayVal([_i64(3), _i64(4), _i64(5)]))
    ref = RefVal(RuntimePlace(root_cell, ()), mutable=True)
    result = interp.call_function(interp.functions["bump"], [ref])
    assert result.__class__.__name__ == "UnitVal"
    updated = interp.read_runtime_place(RuntimePlace(root_cell, (1,)))
    assert isinstance(updated, IntVal)
    assert updated.value == 9


def _resource_module() -> Interpreter:
    return _interp(
        """
module demo.runtime_resource;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
"""
    )


def test_interpreter_rejects_read_of_moved_nested_resource_field() -> None:
    interp = _resource_module()
    holder = interp.call_function(interp.functions["make_holder"], [])
    root_cell = interp.allocate_cell(holder)
    inner_place = RuntimePlace(root_cell, ("inner",))
    moved = interp.read_runtime_place(inner_place)
    interp.write_runtime_place(inner_place, MovedVal())
    assert moved.__class__.__name__ == "ResourceVal"
    try:
        interp.read_runtime_place(inner_place)
    except Exception as exc:
        assert exc.__class__.__name__ == "TrapError"
        assert str(exc) == "read of moved value"
    else:
        raise AssertionError("expected read of moved nested field to trap")


def test_interpreter_rejects_live_nested_resource_replacement() -> None:
    interp = _resource_module()
    holder = interp.call_function(interp.functions["make_holder"], [])
    replacement = interp.call_function(interp.functions["make_file"], [])
    root_cell = interp.allocate_cell(holder)
    try:
        interp.write_runtime_place(RuntimePlace(root_cell, ("inner",)), replacement)
    except Exception as exc:
        assert exc.__class__.__name__ == "TrapError"
        assert "cannot overwrite non-terminal resource" in str(exc)
        assert "Open" in str(exc)
    else:
        raise AssertionError("expected live resource replacement to trap")


def test_interpreter_allows_terminal_nested_resource_replacement_and_reclose() -> None:
    interp = _resource_module()
    holder = interp.call_function(interp.functions["make_holder"], [])
    root_cell = interp.allocate_cell(holder)
    ref = RefVal(RuntimePlace(root_cell, ()), mutable=True)
    interp.call_function(interp.functions["close_inner"], [ref])
    replacement = interp.call_function(interp.functions["make_file"], [])
    interp.write_runtime_place(RuntimePlace(root_cell, ("inner",)), replacement)
    interp.call_function(interp.functions["close_inner"], [ref])
    final_inner = interp.read_runtime_place(RuntimePlace(root_cell, ("inner",)))
    assert final_inner.__class__.__name__ == "ResourceVal"
    assert getattr(final_inner, "protocol_state") == "Closed"


def test_interpreter_writes_through_nested_indexed_resource_field() -> None:
    interp = _resource_module()
    first = interp.call_function(interp.functions["make_holder"], [])
    second = interp.call_function(interp.functions["make_holder"], [])
    root_cell = interp.allocate_cell(ArrayVal([first, second]))
    inner_place = RuntimePlace(root_cell, (1, "inner"))
    inner = interp.read_runtime_place(inner_place)
    assert inner.__class__.__name__ == "ResourceVal"
    interp.apply_resource_transition(inner_place, inner, "close")
    updated = interp.read_runtime_place(inner_place)
    assert getattr(updated, "protocol_state") == "Closed"



def _import_resource_module() -> Interpreter:
    module = parse_module(
        """
module demo.import_resource;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 0 } };
    demo.util.reset(borrow h);
    h.inner.close();
    return unit;
}
"""
    )
    sig = FunctionOwnershipSignature(
        name="demo.util.reset",
        param_types=["Ref<Holder>"],
        return_type="Unit",
        ref_params=[
            RefParamOwnershipSignature(
                param_index=0,
                mode="mut",
                type_name="Holder",
                effects={"inner": "Open"},
            )
        ],
    )
    stub = ImportStub(
        writes=[
            ImportWrite(
                ref_param_index=0,
                path=("inner",),
                value=ResourceVal(
                    name="File",
                    protocol_name="FileProtocol",
                    protocol_state="Open",
                    fields={"fd": _i64(7)},
                ),
            )
        ]
    )
    return Interpreter(module, imported_signatures={"demo.util.reset": sig}, import_stubs={"demo.util.reset": stub})


def test_interpreter_imported_ref_holder_can_reinitialize_resource_field_when_summary_declares_it() -> None:
    interp = _import_resource_module()
    result = interp.interpret("main")
    assert result.__class__.__name__ == "UnitVal"


def test_interpreter_imported_ref_resource_write_without_matching_summary_is_clean_error() -> None:
    interp = _import_resource_module()
    sig = FunctionOwnershipSignature(
        name="demo.util.reset",
        param_types=["Ref<Holder>"],
        return_type="Unit",
        ref_params=[
            RefParamOwnershipSignature(
                param_index=0,
                mode="mut",
                type_name="Holder",
                effects={},
            )
        ],
    )
    interp.imported_signatures["demo.util.reset"] = sig
    try:
        interp.interpret("main")
    except InterpreterUnsupportedError as exc:
        assert "writes resource/ownership path inner without a matching imported ownership summary" in str(exc)
    else:
        raise AssertionError("expected hidden imported resource write to be rejected")


def test_interpreter_imported_scalar_ref_write_does_not_require_resource_summary() -> None:
    module = parse_module(
        """
module demo.import_scalar;
import demo.util;

struct Counter {
    value: I64;
}

fn main() -> I64 effects() {
    var c = Counter { value: 1 };
    demo.util.bump(borrow c);
    return c.value;
}
"""
    )
    sig = FunctionOwnershipSignature(
        name="demo.util.bump",
        param_types=["Ref<Counter>"],
        return_type="Unit",
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Counter", effects={})],
    )
    stub = ImportStub(writes=[ImportWrite(ref_param_index=0, path=("value",), value=_i64(9))])
    interp = Interpreter(module, imported_signatures={"demo.util.bump": sig}, import_stubs={"demo.util.bump": stub})
    got = interp.interpret("main")
    assert isinstance(got, IntVal)
    assert got.value == 9
