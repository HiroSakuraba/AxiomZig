from __future__ import annotations

from pathlib import Path

from axiomzig.cli import main
from axiomzig.interpreter import ArrayVal, IntVal, Interpreter, MovedVal, RefVal, RuntimePlace, TrapError
from axiomzig.parser import parse_module


def _run_cli_source(tmp_path: Path, name: str, source: str, capsys) -> tuple[int, str, str]:
    src = tmp_path / name
    src.write_text(source, encoding="utf-8")
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    return rc, captured.out.strip(), captured.err.strip()


def _interp(source: str) -> Interpreter:
    return Interpreter(parse_module(source))


def test_conformance_cli_try_catch_result_path(tmp_path, capsys) -> None:
    rc, out, err = _run_cli_source(
        tmp_path,
        "try_catch.az",
        """
module conf.trycatch;

error_set E { Bad; }

fn fail() -> I64!E effects(error) {
    return E.Bad;
}

fn main() -> I64 effects(error) {
    return fail() catch 17;
}
""",
        capsys,
    )
    assert rc == 0, err
    assert out == "17"


def test_conformance_cli_defer_and_errdefer_runtime_order(tmp_path, capsys) -> None:
    rc, out, err = _run_cli_source(
        tmp_path,
        "defer_errdefer.az",
        """
module conf.deferorder;

error_set E { Bad; }

struct Box { n: I64; }

fn get_box(b: RefConst<Box>) -> I64 effects() {
    return b.n;
}

fn fail_after_defers(b: Ref<Box>) -> I64!E effects(error) {
    defer b.n = 1;
    errdefer b.n = 11;
    return E.Bad;
}

fn main() -> I64 effects(error) {
    var b = Box { n: 0 };
    let y: I64 = fail_after_defers(borrow b) catch 100;
    return get_box(borrow b) + y;
}
""",
        capsys,
    )
    assert rc == 0, err
    assert out == "101"


def test_conformance_cli_borrow_move_and_nested_resource_replacement(tmp_path, capsys) -> None:
    rc, out, err = _run_cli_source(
        tmp_path,
        "borrow_move_replace.az",
        """
module conf.borrowmove;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn close_holder(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    let old: File = move h.inner;
    h.inner = File { fd: 2 };
    close_holder(borrow h);
    old.close();
    return unit;
}
""",
        capsys,
    )
    assert rc == 0, err
    assert out == "unit"


def test_conformance_cli_receiver_method_dispatch_to_local_function(tmp_path, capsys) -> None:
    rc, out, err = _run_cli_source(
        tmp_path,
        "method_dispatch.az",
        """
module conf.method;

struct Counter { n: I64; }

fn read(c: Counter) -> I64 effects() {
    return c.n;
}

fn main() -> I64 effects() {
    let c = Counter { n: 9 };
    return c.read();
}
""",
        capsys,
    )
    assert rc == 0, err
    assert out == "9"


def _resource_interpreter() -> Interpreter:
    return _interp(
        """
module conf.negative;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}
"""
    )


def test_conformance_runtime_negative_moved_nested_read_traps() -> None:
    interp = _resource_interpreter()
    holder = interp.call_function(interp.functions["make_holder"], [])
    root = interp.allocate_cell(holder)
    place = RuntimePlace(root, ("inner",))
    interp.write_runtime_place(place, MovedVal())
    try:
        interp.read_runtime_place(place)
    except TrapError as exc:
        assert exc.reason == "read of moved value"
    else:
        raise AssertionError("expected moved nested read to trap")


def test_conformance_runtime_negative_live_resource_overwrite_traps() -> None:
    interp = _resource_interpreter()
    holder = interp.call_function(interp.functions["make_holder"], [])
    replacement = interp.call_function(interp.functions["make_file"], [])
    root = interp.allocate_cell(holder)
    try:
        interp.write_runtime_place(RuntimePlace(root, ("inner",)), replacement)
    except TrapError as exc:
        assert "cannot overwrite non-terminal resource" in exc.reason
    else:
        raise AssertionError("expected live resource overwrite to trap")


def test_conformance_runtime_negative_array_index_out_of_bounds_traps() -> None:
    interp = _resource_interpreter()
    root = interp.allocate_cell(ArrayVal([IntVal(1), IntVal(2)]))
    try:
        interp.read_runtime_place(RuntimePlace(root, (2,)))
    except TrapError as exc:
        assert exc.reason == "index out of bounds"
    else:
        raise AssertionError("expected array index trap")


def test_conformance_runtime_negative_invalid_protocol_transition_traps() -> None:
    interp = _resource_interpreter()
    file_value = interp.call_function(interp.functions["make_file"], [])
    root = interp.allocate_cell(file_value)
    place = RuntimePlace(root, ())
    resource = interp.read_runtime_place(place)
    interp.apply_resource_transition(place, resource, "close")
    closed = interp.read_runtime_place(place)
    try:
        interp.apply_resource_transition(place, closed, "close")
    except TrapError as exc:
        assert exc.reason == "invalid protocol transition close from Closed"
    else:
        raise AssertionError("expected invalid transition trap")

def test_conformance_runtime_receiver_method_dispatch_mutates_ref_receiver() -> None:
    interp = _interp(
        """
module conf.method_runtime;

struct Counter { n: I64; }

fn set_to(c: Ref<Counter>, value: I64) -> Unit effects() {
    c.n = value;
    return unit;
}

fn main() -> I64 effects() {
    var c = Counter { n: 1 };
    c.set_to(12);
    return c.n;
}
"""
    )
    result = interp.interpret()
    assert isinstance(result, IntVal)
    assert result.value == 12
