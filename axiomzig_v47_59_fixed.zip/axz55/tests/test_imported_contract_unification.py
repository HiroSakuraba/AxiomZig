from axiomzig.interpreter import ImportStub, ImportWrite, IntVal, Interpreter, InterpreterUnsupportedError, ResourceVal
from axiomzig.ownership import analyze_ownership
from axiomzig.ownership_signatures import (
    FunctionOwnershipSignature,
    RefParamOwnershipSignature,
    normalize_imported_function_contract,
)
from axiomzig.parser import parse_module
from axiomzig.typecheck import typecheck_module


def _sig(name="demo.util.touch", effects=None):
    return FunctionOwnershipSignature(
        name=name,
        param_types=["Ref<Holder>"],
        return_type="Unit",
        effects=["protocol_step"],
        ref_params=[RefParamOwnershipSignature(0, "mut", "Holder", {"inner": "Closed"} if effects is None else effects)],
    )


def _module():
    return parse_module(
        """
module demo.contract;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 0 } };
    demo.util.touch(borrow h);
    return unit;
}
"""
    )


def test_normalized_contract_is_the_single_path_parser_for_numeric_nested_paths():
    contract = normalize_imported_function_contract(_sig(effects={"1.inner": "Closed"}))
    assert contract.paths_for_ref_param(0) == {(1, "inner")}


def test_malformed_imported_summary_is_reported_at_type_boundary():
    bad = FunctionOwnershipSignature(
        name="demo.util.touch",
        param_types=["Ref<Holder>"],
        return_type="Unit",
        ref_params=[RefParamOwnershipSignature(0, "mut", "Holder", {"[*].inner": "Closed"})],
    )
    summary = typecheck_module(_module(), imported_signatures={"demo.util.touch": bad})
    messages = [issue.message for issue in summary.issues]
    assert any("uses unsupported non-literal indexed path(s)" in msg for msg in messages)


def test_ownership_consumes_normalized_imported_summary_paths():
    summary = analyze_ownership(_module(), imported_signatures={"demo.util.touch": _sig()})
    assert not [issue for issue in summary.issues if issue.level == "error"]


def test_interpreter_stub_resource_write_must_match_normalized_summary_path():
    sig = _sig(effects={})
    stub = ImportStub(
        writes=[
            ImportWrite(
                ref_param_index=0,
                path=("inner",),
                value=ResourceVal("File", "FileProtocol", "Closed", {"fd": IntVal(1, width=32, signed=True)}),
            )
        ]
    )
    interp = Interpreter(_module(), imported_signatures={"demo.util.touch": sig}, import_stubs={"demo.util.touch": stub})
    try:
        interp.interpret("main")
    except InterpreterUnsupportedError as exc:
        assert "without a matching imported ownership summary" in str(exc)
    else:
        raise AssertionError("expected stub/summary resource-write mismatch to fail")
