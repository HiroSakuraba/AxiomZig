from __future__ import annotations

import pytest

from axiomzig.lexer import LexError
from axiomzig.parser import ParseError, parse_module


def test_parse_rejects_top_level_alias_with_targeted_message() -> None:
    src = """
module demo.alias_top;

alias Foo = I64;
"""
    with pytest.raises(ParseError, match=r"top-level alias declarations are not part of AxiomZig v1\.1"):
        parse_module(src)


def test_parse_accepts_catch_binding_form_with_block() -> None:
    """catch |e| { body } is now a supported syntax form (P2 complete)."""
    from axiomzig.parser import parse_module as _parse
    src = """
module demo.catch_bind2;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8 effects(error) {
    let result: U8 = parse_one(s) catch |e| {
        return 0;
    };
    return result;
}
"""
    module = _parse(src)
    assert module is not None
    assert len(module.decls) > 0

def test_lex_accepts_bar_token_for_future_catch_binding_syntax() -> None:
    src = """
module demo.catch_bind;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8 effects(error) {
    return parse_one(s) catch |e| 0;
}
"""
    try:
        parse_module(src)
    except LexError as exc:  # pragma: no cover
        raise AssertionError(f"unexpected lex failure: {exc}") from exc
    except ParseError:
        pass
