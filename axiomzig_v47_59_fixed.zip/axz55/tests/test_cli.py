import json
from pathlib import Path

from axiomzig.cli import main


def test_cli_reports_parse_error_without_traceback(tmp_path, capsys) -> None:
    bad = tmp_path / "bad.az"
    bad.write_text("module demo.bad;\nfn main() -> Unit effects() { let x = ; }\n", encoding="utf-8")
    rc = main(["parse", str(bad)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "parse error:" in captured.err
    assert "Traceback" not in captured.err


def test_cli_ownsig_exports_ref_param_effects(tmp_path, capsys) -> None:
    src = tmp_path / "util.az"
    src.write_text(
        """
module demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["ownsig", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert '"name": "demo.util.close_inner"' in captured.out
    assert '"effects": {' in captured.out
    assert '"inner": "Closed"' in captured.out


def test_cli_owncheck_exits_nonzero_on_ownership_error(tmp_path, capsys) -> None:
    src = tmp_path / "bad_own.az"
    src.write_text(
        """
module demo.badown;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn bad() -> Unit effects(protocol_step) {
    let f = File { fd: 0 };
    f.close();
    f.close();
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["owncheck", str(src)])
    captured = capsys.readouterr()
    assert rc == 1
    assert '"level": "error"' in captured.out



def test_cli_interpret_runs_pure_arithmetic_program(tmp_path, capsys) -> None:
    src = tmp_path / "interp_add.az"
    src.write_text(
        """
module demo.math;

fn add(x: I64, y: I64) -> I64 effects() {
    return x + y;
}

fn main() -> I64 effects() {
    return add(2, 3);
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "5"


def test_cli_interpret_runs_match_option_program(tmp_path, capsys) -> None:
    src = tmp_path / "interp_option.az"
    src.write_text(
        """
module demo.opt;

fn bump(x: Option<I64>) -> Option<I64> effects() {
    return match x {
        some(v) -> some(v + 1),
        none -> none,
    };
}

fn main() -> Option<I64> effects() {
    return bump(some(2));
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "some(3)"


def test_cli_interpret_runs_defer_on_lexical_scope_exit(tmp_path, capsys) -> None:
    src = tmp_path / "interp_defer.az"
    src.write_text(
        """
module demo.dfr;

fn main() -> I64 effects() {
    var x: I64 = 1;
    {
        defer x = x + 1;
    }
    return x;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "2"


def test_cli_interpret_supports_result_propagation_and_catch(tmp_path, capsys) -> None:
    src = tmp_path / "interp_result.az"
    src.write_text(
        """
module demo.parse;

error_set ParseError {
    Empty;
    InvalidDigit;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return match s {
        "" -> ParseError.Empty,
        _ -> 7,
    };
}

fn main() -> U8 effects(error) {
    return parse_one("") catch 9;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "9"


def test_cli_interpret_reports_runtime_trap(tmp_path, capsys) -> None:
    src = tmp_path / "interp_trap.az"
    src.write_text(
        """
module demo.trap;

fn main() -> I64 effects() {
    return 1 / 0;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "trap: division by zero" in captured.err


def test_cli_interpret_runs_resource_transition_through_ref_param(tmp_path, capsys) -> None:
    src = tmp_path / "interp_ref.az"
    src.write_text(
        """
module demo.refclose;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn close_it(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    let f = File { fd: 0 };
    close_it(borrow f);
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"


def test_cli_interpret_runs_nested_ref_field_transition(tmp_path, capsys) -> None:
    src = tmp_path / "interp_nested_ref.az"
    src.write_text(
        """
module demo.nestedref;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    let h = Holder { inner: File { fd: 1 } };
    let r: Ref<Holder> = borrow h;
    r.inner.close();
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"


def test_cli_interpret_runs_move_into_local_function(tmp_path, capsys) -> None:
    src = tmp_path / "interp_move.az"
    src.write_text(
        """
module demo.moveclose;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn consume(f: File) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    let f = File { fd: 9 };
    consume(move f);
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"


def test_cli_interpret_reports_string_index_trap(tmp_path, capsys) -> None:
    src = tmp_path / "interp_index_trap.az"
    src.write_text(
        """
module demo.idxtrap;

fn main() -> U8 effects() {
    return "abc"[3];
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "trap: index out of bounds" in captured.err


def test_cli_interpret_runs_string_slice(tmp_path, capsys) -> None:
    src = tmp_path / "interp_slice.az"
    src.write_text(
        """
module demo.slice;

fn main() -> Str effects() {
    return "abcd"[1..3];
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == repr("bc")


def test_cli_interpret_reports_signed_overflow_trap(tmp_path, capsys) -> None:
    src = tmp_path / "interp_overflow_add.az"
    src.write_text(
        """
module demo.ovf;

fn main() -> I8 effects() {
    let x: I8 = @cast(I8, 127);
    return x + @cast(I8, 1);
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "trap: integer overflow in binary +" in captured.err


def test_cli_interpret_reports_unsigned_underflow_trap(tmp_path, capsys) -> None:
    src = tmp_path / "interp_underflow_sub.az"
    src.write_text(
        """
module demo.under;

fn main() -> U8 effects() {
    let x: U8 = @cast(U8, 0);
    return x - @cast(U8, 1);
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "trap: integer overflow in binary -" in captured.err


def test_cli_interpret_uses_truncating_signed_division_and_remainder(tmp_path, capsys) -> None:
    src = tmp_path / "interp_divmod.az"
    src.write_text(
        """
module demo.divmod;

fn divv(x: I64, y: I64) -> I64 effects() {
    return x / y;
}

fn remm(x: I64, y: I64) -> I64 effects() {
    return x % y;
}

fn main() -> I64 effects() {
    let q: I64 = divv(@cast(I64, 0) - @cast(I64, 3), @cast(I64, 2));
    let r: I64 = remm(@cast(I64, 0) - @cast(I64, 3), @cast(I64, 2));
    return q * @cast(I64, 10) + r;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "-11"


def test_cli_interpret_runs_refconst_param_read_and_projection(tmp_path, capsys) -> None:
    src = tmp_path / "interp_refconst_read.az"
    src.write_text(
        """
module demo.refconstread;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn peek_file(f: RefConst<File>) -> I32 effects() {
    return f.fd;
}

fn project_and_peek(h: RefConst<Holder>) -> I32 effects() {
    return peek_file(borrow h.inner);
}

fn main() -> I32 effects(protocol_step) {
    let h = Holder { inner: File { fd: 7 } };
    var out: I32 = 0;
    {
        out = project_and_peek(borrow h);
    }
    h.inner.close();
    return out;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "7"


def test_cli_interpret_rejects_refconst_to_mut_ref_surface(tmp_path, capsys) -> None:
    src = tmp_path / "interp_refconst_reject.az"
    src.write_text(
        """
module demo.refconstreject;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn close_it(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    let f = File { fd: 0 };
    let c: RefConst<File> = borrow f;
    close_it(c);
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "error:" in captured.err
    assert "Ref<File>" in captured.err


def test_cli_interpret_runs_nested_resource_partial_move_reinit_and_close(tmp_path, capsys) -> None:
    src = tmp_path / "interp_nested_reinit.az"
    src.write_text(
        """
module demo.interp_nested_reinit;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn main() -> Unit effects(protocol_step) {
    var h = make_holder();
    let f: File = move h.inner;
    h.inner = File { fd: 1 };
    h.inner.close();
    f.close();
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"


def test_cli_interpret_runs_alias_rooted_terminal_replacement(tmp_path, capsys) -> None:
    src = tmp_path / "interp_alias_replacement.az"
    src.write_text(
        """
module demo.interp_alias_replacement;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn main() -> Unit effects(protocol_step) {
    let h = make_holder();
    var r: Ref<Holder> = borrow h;
    r.inner.close();
    let replacement = make_file();
    r.inner = move replacement;
    r.inner.close();
    return unit;
}
""",
        encoding="utf-8",
    )
    rc = main(["interpret", str(src)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"


def test_cli_interpret_supports_import_stub_builtin_bundle(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_stub.az"
    src.write_text(
        """
module demo.main;
import demo.util;

fn main() -> I64 effects() {
    return demo.util.add(2, 3);
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.add",
                        "param_types": ["I64", "I64"],
                        "return_type": "I64",
                        "ref_params": [],
                        "effects": [],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps({"functions": [{"name": "demo.util.add", "builtin": "i64_add"}]}),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "5"


def test_cli_interpret_supports_import_stub_ref_write_bundle(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_write.az"
    src.write_text(
        """
module demo.main;
import demo.util;

struct Counter {
    value: I64;
}

fn main() -> I64 effects() {
    var c = Counter { value: 1 };
    demo.util.bump(borrow c);
    return c.value;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.bump",
                        "param_types": ["Ref<Counter>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {"param_index": 0, "mode": "mut", "type_name": "Counter", "effects": {}}
                        ],
                        "effects": [],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.bump",
                        "writes": [
                            {"ref_param_index": 0, "path": ["value"], "value": {"int": 9}}
                        ],
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "9"


def test_cli_interpret_reports_clean_missing_import_stub_diagnostic(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_missing_stub.az"
    src.write_text(
        """
module demo.main;
import demo.util;

fn main() -> I64 effects() {
    return demo.util.add(2, 3);
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.add",
                        "param_types": ["I64", "I64"],
                        "return_type": "I64",
                        "ref_params": [],
                        "effects": [],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "trap: imported pure function demo.util.add has no runtime stub" in captured.err



def test_cli_check_accepts_fully_qualified_import_call_without_interpret_tolerance(tmp_path, capsys) -> None:
    src = tmp_path / "check_import_full_path.az"
    src.write_text(
        """
module demo.main;
import demo.util;

fn main() -> I64 effects() {
    return demo.util.add(2, 3);
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.add",
                        "param_types": ["I64", "I64"],
                        "return_type": "I64",
                        "ref_params": [],
                        "effects": [],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["check", str(src), "--import-ownership", str(sig)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == ""
    assert captured.err.strip() == ""


def test_cli_interpret_fully_qualified_import_call_without_tolerance(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_full_path.az"
    src.write_text(
        """
module demo.main;
import demo.util;

fn main() -> I64 effects() {
    return demo.util.add(2, 3);
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.add",
                        "param_types": ["I64", "I64"],
                        "return_type": "I64",
                        "ref_params": [],
                        "effects": [],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps({"functions": [{"name": "demo.util.add", "builtin": "i64_add"}]}),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "5"
    assert captured.err.strip() == ""


def test_cli_interpret_supports_import_stub_holder_recycle_bundle_with_summary_backed_replace(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_holder_recycle.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    let replacement = File { fd: 9 };
    var r: Ref<Holder> = borrow h;
    demo.util.recycle_inner(r, move replacement);
    r.inner.close();
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.recycle_inner",
                        "param_types": ["Ref<Holder>", "File"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Open"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.recycle_inner",
                        "writes": [
                            {
                                "ref_param_index": 0,
                                "path": ["inner"],
                                "source_arg_index": 1
                            }
                        ],
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"
    assert captured.err.strip() == ""




def test_cli_check_accepts_imported_nested_summary_matching_join(tmp_path, capsys) -> None:
    src = tmp_path / "check_import_nested_join.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_after_join(flag: Bool) -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    if (flag) {
        demo.util.close_inner(borrow h);
    } else {
        demo.util.close_inner(borrow h);
    }
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    close_after_join(true);
    close_after_join(false);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["check", str(src), "--import-ownership", str(sig)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == ""
    assert captured.err.strip() == ""



def test_cli_interpret_supports_imported_nested_summary_matching_join_both_branches(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_nested_join.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_after_join(flag: Bool) -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    if (flag) {
        demo.util.close_inner(borrow h);
    } else {
        demo.util.close_inner(borrow h);
    }
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    close_after_join(true);
    close_after_join(false);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "return_value": {"unit": True},
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"
    assert captured.err.strip() == ""

def test_cli_interpret_rejects_import_stub_holder_replace_without_matching_summary(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_holder_bad_replace.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    var r: Ref<Holder> = borrow h;
    demo.util.bad_replace(r);
    r.inner.close();
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.bad_replace",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.bad_replace",
                        "writes": [
                            {
                                "ref_param_index": 0,
                                "path": ["inner"],
                                "value": {
                                    "resource": {
                                        "name": "File",
                                        "protocol_name": "FileProtocol",
                                        "protocol_state": "Open",
                                        "fields": {"fd": {"int": 2}},
                                    }
                                },
                            }
                        ],
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "interpret unsupported: import stub for demo.util.bad_replace writes resource/ownership path inner without a matching imported ownership summary" in captured.err



def test_cli_interpret_imported_close_skips_errdefer_cleanup(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_errdefer_cleanup.az"
    src.write_text(
        """
module demo.main;
import demo.util;

error_set E { Bad; }

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit!E effects(error, protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    var r: Ref<Holder> = borrow h;
    errdefer demo.util.cleanup_inner(r);
    demo.util.close_inner(r);
    return E.Bad;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "return_value": {"unit": True},
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "E.Bad"
    assert captured.err.strip() == ""



def test_cli_interpret_imported_close_skips_normal_defer_cleanup(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_defer_cleanup.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    var r: Ref<Holder> = borrow h;
    defer demo.util.cleanup_inner(r);
    demo.util.close_inner(r);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "return_value": {"unit": True},
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"
    assert captured.err.strip() == ""



def test_cli_interpret_imported_reinitialization_updates_defer_cleanup_target(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_reinit_defer_cleanup.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    let replacement = File { fd: 9 };
    var r: Ref<Holder> = borrow h;
    defer demo.util.cleanup_inner(r);
    demo.util.recycle_inner(r, move replacement);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.recycle_inner",
                        "param_types": ["Ref<Holder>", "File"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Open"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.recycle_inner",
                        "writes": [
                            {
                                "ref_param_index": 0,
                                "path": ["inner"],
                                "source_arg_index": 1,
                            }
                        ],
                        "return_value": {"unit": True},
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"
    assert captured.err.strip() == ""



def test_cli_interpret_imported_wrapper_cleanup_is_skipped_after_close(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_wrapper_cleanup.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    var r: Ref<Holder> = borrow h;
    defer demo.util.cleanup_inner(r);
    demo.util.close_inner(r);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.close_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.cleanup_inner",
                        "return_value": {"unit": True},
                    },
                    {
                        "name": "demo.util.close_inner",
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"
    assert captured.err.strip() == ""


def test_cli_check_accepts_imported_indexed_nested_summary_matching_join(tmp_path, capsys) -> None:
    src = tmp_path / "check_import_indexed_nested_join.az"
    src.write_text(
        """
module demo.main;
import demo.seed;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_after_join(flag: Bool) -> Unit effects(protocol_step) {
    var hs: Array<Holder, 2> = demo.seed.make_holders();
    {
        var r1: Ref<Array<Holder, 2>> = borrow hs;
        demo.util.close_first(r1);
    }
    if (flag) {
        var r2: Ref<Array<Holder, 2>> = borrow hs;
        demo.util.close_second(r2);
    } else {
        var r2: Ref<Array<Holder, 2>> = borrow hs;
        demo.util.close_second(r2);
    }
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    close_after_join(true);
    close_after_join(false);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.seed",
                "functions": [
                    {
                        "name": "demo.seed.make_holders",
                        "param_types": [],
                        "return_type": "Array<Holder, 2>",
                        "ref_params": [],
                        "effects": [],
                    },
                    {
                        "name": "demo.util.close_first",
                        "param_types": ["Ref<Array<Holder, 2>>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Array<Holder, 2>",
                                "effects": {"0.inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.close_second",
                        "param_types": ["Ref<Array<Holder, 2>>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Array<Holder, 2>",
                                "effects": {"1.inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                ],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["check", str(src), "--import-ownership", str(sig)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == ""
    assert captured.err.strip() == ""



def test_cli_interpret_supports_imported_indexed_nested_summary_matching_join_both_branches(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_indexed_nested_join.az"
    src.write_text(
        """
module demo.main;
import demo.seed;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_after_join(flag: Bool) -> Unit effects(protocol_step) {
    var hs: Array<Holder, 2> = demo.seed.make_holders();
    {
        var r1: Ref<Array<Holder, 2>> = borrow hs;
        demo.util.close_first(r1);
    }
    if (flag) {
        var r2: Ref<Array<Holder, 2>> = borrow hs;
        demo.util.close_second(r2);
    } else {
        var r2: Ref<Array<Holder, 2>> = borrow hs;
        demo.util.close_second(r2);
    }
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    close_after_join(true);
    close_after_join(false);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.seed",
                "functions": [
                    {
                        "name": "demo.seed.make_holders",
                        "param_types": [],
                        "return_type": "Array<Holder, 2>",
                        "ref_params": [],
                        "effects": [],
                    },
                    {
                        "name": "demo.util.close_first",
                        "param_types": ["Ref<Array<Holder, 2>>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Array<Holder, 2>",
                                "effects": {"0.inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.close_second",
                        "param_types": ["Ref<Array<Holder, 2>>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Array<Holder, 2>",
                                "effects": {"1.inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.seed.make_holders",
                        "return_value": {
                            "array": [
                                {
                                    "struct": {
                                        "name": "Holder",
                                        "fields": {
                                            "inner": {
                                                "resource": {
                                                    "name": "File",
                                                    "protocol_name": "FileProtocol",
                                                    "protocol_state": "Open",
                                                    "fields": {"fd": {"int": 1}},
                                                }
                                            }
                                        },
                                    }
                                },
                                {
                                    "struct": {
                                        "name": "Holder",
                                        "fields": {
                                            "inner": {
                                                "resource": {
                                                    "name": "File",
                                                    "protocol_name": "FileProtocol",
                                                    "protocol_state": "Open",
                                                    "fields": {"fd": {"int": 2}},
                                                }
                                            }
                                        },
                                    }
                                },
                            ]
                        },
                    },
                    {
                        "name": "demo.util.close_first",
                        "return_value": {"unit": True},
                    },
                    {
                        "name": "demo.util.close_second",
                        "return_value": {"unit": True},
                    },
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() == "unit"
    assert captured.err.strip() == ""



def test_cli_interpret_imported_cleanup_missing_stub_reports_clean_replay_diagnostic(tmp_path, capsys) -> None:
    src = tmp_path / "interp_import_cleanup_missing_stub.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn main() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    var r: Ref<Holder> = borrow h;
    defer demo.util.cleanup_inner(r);
    demo.util.close_inner(r);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                    {
                        "name": "demo.util.cleanup_inner",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    },
                ],
            }
        ),
        encoding="utf-8",
    )
    stubs = tmp_path / "import_stubs.json"
    stubs.write_text(
        json.dumps(
            {
                "functions": [
                    {
                        "name": "demo.util.close_inner",
                        "return_value": {"unit": True},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    rc = main(["interpret", str(src), "--import-ownership", str(sig), "--import-stubs", str(stubs)])
    captured = capsys.readouterr()
    assert rc == 1
    assert captured.out.strip() == ""
    assert "trap: imported cleanup helper demo.util.cleanup_inner has ownership signature but no runtime stub" in captured.err

def test_cli_check_rejects_imported_ref_summary_on_nonliteral_indexed_referent(tmp_path, capsys) -> None:
    src = tmp_path / "bad_import_dynamic_index.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn main(i: U64, hs: Array<Holder, 2>) -> Unit effects(protocol_step) {
    demo.util.close_holder(borrow hs[i]);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.close_holder",
                        "param_types": ["Ref<Holder>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Holder",
                                "effects": {"inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["check", str(src), "--import-ownership", str(sig)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "non-literal indexed resource path hs[*] is not supported for reference ownership summaries" in captured.out


def test_cli_check_rejects_imported_wildcard_index_summary_path(tmp_path, capsys) -> None:
    src = tmp_path / "bad_import_wildcard_summary.az"
    src.write_text(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn main(hs: Array<Holder, 2>) -> Unit effects(protocol_step) {
    demo.util.close_any(borrow hs);
    return unit;
}
""",
        encoding="utf-8",
    )
    sig = tmp_path / "import_ownership.json"
    sig.write_text(
        json.dumps(
            {
                "module_path": "demo.util",
                "functions": [
                    {
                        "name": "demo.util.close_any",
                        "param_types": ["Ref<Array<Holder, 2>>"],
                        "return_type": "Unit",
                        "ref_params": [
                            {
                                "param_index": 0,
                                "mode": "mut",
                                "type_name": "Array<Holder, 2>",
                                "effects": {"[*].inner": "Closed"},
                            }
                        ],
                        "effects": ["protocol_step"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["check", str(src), "--import-ownership", str(sig)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "import error: imported/reference ownership summary for demo.util.close_any uses unsupported non-literal indexed path(s): [*].inner" in captured.err
