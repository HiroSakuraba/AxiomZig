from __future__ import annotations

from copy import deepcopy

from axiomzig.interpreter import (
    ImportStub,
    ImportWrite,
    IntVal,
    Interpreter,
    InterpreterUnsupportedError,
    ResourceVal,
    TrapError,
    UnitVal,
)
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature
from axiomzig.parser import parse_module


def _sig(name: str, *, param_types: list[str], return_type: str = "Unit", ref_params=None, effects=None) -> FunctionOwnershipSignature:
    return FunctionOwnershipSignature(
        name=name,
        param_types=param_types,
        return_type=return_type,
        ref_params=list(ref_params or []),
        effects=list(effects or []),
    )


def test_imported_pure_call_returning_scalar_uses_builtin_stub() -> None:
    src = """
module demo.main;
import demo.util;

fn run() -> I64 effects() {
    return demo.util.add64(40, 2);
}
"""
    sig = _sig("demo.util.add64", param_types=["I64", "I64"], return_type="I64")
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: ImportStub(builtin="i64_add")},
    )

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "42"


def test_imported_call_mutating_through_ref_updates_runtime_place() -> None:
    src = """
module demo.main;
import demo.util;

struct Box {
    n: I32;
}

fn run() -> I32 effects() {
    var b = Box { n: 0 };
    demo.util.set_n(borrow b, 41);
    return b.n;
}
"""
    sig = _sig("demo.util.set_n", param_types=["Ref<Box>", "I32"])
    stub = ImportStub(
        writes=[ImportWrite(ref_param_index=0, path=("n",), source_arg_index=1)],
        return_value=UnitVal(),
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: stub},
    )

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "41"


def test_imported_call_can_move_then_reinitialize_resource_field_through_ref_holder() -> None:
    src = """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 7 } };
}

fn run() -> Unit effects(protocol_step) {
    var h = make_holder();
    demo.util.recycle_inner(borrow h, 9);
    h.inner.close();
    return unit;
}
"""
    sig = _sig(
        "demo.util.recycle_inner",
        param_types=["Ref<Holder>", "I32"],
        ref_params=[
            RefParamOwnershipSignature(
                param_index=0,
                mode="mut",
                type_name="Holder",
                effects={"inner": "Moved"},
            )
        ],
        effects=["protocol_step"],
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: ImportStub(return_value=UnitVal())},
    )
    replacement = deepcopy(interp.call_function(interp.functions["make_holder"], []).fields["inner"])
    replacement.fields["fd"].value = 9
    interp.import_stubs[sig.name].writes = [
        ImportWrite(
            ref_param_index=0,
            path=("inner",),
            value=replacement,
        )
    ]

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "unit"


def test_imported_pure_call_without_stub_traps_cleanly() -> None:
    src = """
module demo.main;
import demo.util;

fn run() -> I64 effects() {
    return demo.util.add64(1, 2);
}
"""
    sig = _sig("demo.util.add64", param_types=["I64", "I64"], return_type="I64")
    interp = Interpreter(parse_module(src), imported_signatures={sig.name: sig})

    try:
        interp.call_function(interp.functions["run"], [])
    except TrapError as exc:
        assert exc.reason == "imported pure function demo.util.add64 has no runtime stub"
    else:
        raise AssertionError("expected pure imported call without stub to trap")


def test_unsupported_import_without_signature_reports_clean_diagnostic() -> None:
    src = """
module demo.main;
import demo.util;

fn run() -> Unit effects() {
    demo.util.missing();
    return unit;
}
"""
    interp = Interpreter(parse_module(src))

    try:
        interp.call_function(interp.functions["run"], [])
    except InterpreterUnsupportedError as exc:
        assert str(exc) == "unsupported imported function demo.util.missing: no ownership/type signature"
    else:
        raise AssertionError("expected unsupported imported function diagnostic")


def test_imported_summary_path_allows_whole_resource_replacement_to_final_state() -> None:
    src = """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn run() -> I32 effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    demo.util.recycle_inner(borrow h, 9);
    let fd = h.inner.fd;
    h.inner.close();
    return fd;
}
"""
    sig = _sig(
        "demo.util.recycle_inner",
        param_types=["Ref<Holder>", "I32"],
        ref_params=[
            RefParamOwnershipSignature(
                param_index=0,
                mode="mut",
                type_name="Holder",
                effects={"inner": "Open"},
            )
        ],
        effects=["protocol_step"],
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: ImportStub(return_value=UnitVal())},
    )
    fresh = ResourceVal(
        name="File",
        protocol_name="FileProtocol",
        protocol_state="Open",
        fields={"fd": IntVal(0, width=32, signed=True)},
    )
    interp.import_stubs[sig.name].writes = [
        ImportWrite(ref_param_index=0, path=("inner",), value=fresh),
        ImportWrite(ref_param_index=0, path=("inner", "fd"), source_arg_index=1),
    ]

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "9"


def test_imported_stub_resource_replacement_without_matching_summary_still_traps() -> None:
    src = """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn run() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    demo.util.bad_replace(borrow h);
    return unit;
}
"""
    sig = _sig(
        "demo.util.bad_replace",
        param_types=["Ref<Holder>"],
        ref_params=[
            RefParamOwnershipSignature(
                param_index=0,
                mode="mut",
                type_name="Holder",
                effects={},
            )
        ],
        effects=["protocol_step"],
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={
            sig.name: ImportStub(
                writes=[
                    ImportWrite(
                        ref_param_index=0,
                        path=("inner",),
                        value=ResourceVal(
                            name="File",
                            protocol_name="FileProtocol",
                            protocol_state="Open",
                            fields={"fd": IntVal(2, width=32, signed=True)},
                        ),
                    )
                ],
                return_value=UnitVal(),
            )
        },
    )

    try:
        interp.call_function(interp.functions["run"], [])
    except InterpreterUnsupportedError as exc:
        assert "without a matching imported ownership summary" in str(exc)
    except TrapError as exc:
        assert exc.reason == "cannot overwrite non-terminal resource at @1.inner: File is in state Open"
    else:
        raise AssertionError("expected resource write without matching summary to fail")
