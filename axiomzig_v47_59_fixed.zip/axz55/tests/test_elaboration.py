from axiomzig.elaborate import elaborate_module
from axiomzig.parser import parse_module


def messages(summary):
    return [issue.message for issue in summary.issues]


def test_elaboration_infers_call_and_local_types() -> None:
    module = parse_module(
        """
module demo.elab;

fn add(x: I64, y: I64) -> I64 effects() {
    return x + y;
}

fn main() -> I64 effects() {
    let z = add(1, 2);
    return z;
}
"""
    )
    summary = elaborate_module(module)
    assert messages(summary) == []
    fn = next(item for item in summary.functions if item.name == "main")
    bindings = {binding.name: binding.type_text for binding in fn.bindings}
    assert bindings["z"] == "I64"
    assert fn.calls[0].callee == "add"
    assert fn.calls[0].return_type == "I64"


def test_elaboration_handles_result_lifting_in_match_return() -> None:
    module = parse_module(
        """
module demo.resultlift;

error_set ParseError {
    Empty;
}

enum Status {
    Ok;
}

fn bump(x: Str) -> Status!ParseError effects(error) {
    return match x {
        "" -> ParseError.Empty,
        _ -> Status.Ok,
    };
}
"""
    )
    summary = elaborate_module(module)
    assert messages(summary) == []
    fn = summary.functions[0]
    match_notes = [item for item in fn.expr_types if item.expr.startswith("match x")]
    assert match_notes
    assert match_notes[-1].type_text == "Status!ParseError"


def test_effect_containment_is_checked_at_elaboration_time() -> None:
    module = parse_module(
        """
module demo.fx;

fn allocish() -> I64 effects(alloc) {
    return 1;
}

fn caller() -> I64 effects() {
    return allocish();
}
"""
    )
    summary = elaborate_module(module)
    joined = "\n".join(messages(summary))
    assert "call to allocish requires effects ['alloc'] not contained in caller caller effects []" in joined


def test_elaboration_records_semantic_place_and_borrow_mode() -> None:
    module = parse_module(
        """
module demo.elabfacts;

resource File {
    fields {
        fd: I32;
    }
}

fn peek(f: RefConst<File>) -> I32 effects() {
    return f.fd;
}

fn main(f: File) -> I32 effects() {
    return peek(borrow f);
}
"""
    )
    summary = elaborate_module(module)
    assert messages(summary) == []
    fn = next(item for item in summary.functions if item.name == "main")
    borrow_records = [item for item in fn.expr_types if item.expr == "borrow f"]
    assert borrow_records
    assert borrow_records[-1].place == "f"
    assert borrow_records[-1].borrow_mode == "const"
    assert fn.calls[0].arg_ref_modes == ["const"]
