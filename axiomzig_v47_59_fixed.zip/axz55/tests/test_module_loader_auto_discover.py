"""
test_module_loader_auto_discover.py — A3: module loader auto-discovery

All tests that touch the filesystem use tmp_path to write real .az files.

Layout rule:
  - flat workspace (auto-discover tests): all files in tmp_path, single-component
    module names (module util;, module main;).  auto_discover uses entry_path.parent
    as the root, so util.az at tmp_path/util.az is found when main.az imports util.
  - nested workspace (explicit --module-root tests): files in tmp_path/<pkg>/name.az,
    multi-component module names (module pkg.name;), module_root=tmp_path.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from axiomzig.cli import main as cli_main
from axiomzig.module_graph import (
    auto_discover_workspace_signatures,
    collect_workspace_ownership_signatures,
    load_module_graph,
)


# ─────────────────────────────────────────────────────────────────────────────
# helpers
# ─────────────────────────────────────────────────────────────────────────────

def _w(tmp_path: Path, rel: str, content: str) -> Path:
    """Write content to tmp_path/rel, creating parent dirs as needed."""
    p = tmp_path / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding='utf-8')
    return p



# ─────────────────────────────────────────────────────────────────────────────
# 1.  auto_discover_workspace_signatures — unit level
# ─────────────────────────────────────────────────────────────────────────────

def test_auto_discover_finds_flat_sibling(tmp_path):
    """
    entry (main.az) imports a sibling (util.az) in the same directory.
    auto_discover resolves it without any --module-root flag.
    """
    _w(tmp_path, 'util.az', """\
module util;
fn helper(x: I64) -> I64 effects() { return x + 1; }
""")
    entry = _w(tmp_path, 'main.az', """\
module main;
import util;
fn run(x: I64) -> I64 effects() { return util.helper(x); }
""")
    sigs, graph = auto_discover_workspace_signatures(entry)
    assert graph is not None, "expected workspace modules to be discovered"
    assert 'util' in graph.modules
    assert 'util.helper' in sigs
    assert 'main.run' in sigs


def test_auto_discover_single_file_returns_none_graph(tmp_path):
    """A file with no imports → (empty_sigs, None); no workspace overhead."""
    solo = _w(tmp_path, 'solo.az', """\
module solo;
fn f() -> I64 effects() { return 1; }
""")
    sigs, graph = auto_discover_workspace_signatures(solo)
    assert graph is None
    assert sigs == {}


def test_auto_discover_missing_import_is_warning_not_error(tmp_path):
    """
    An import that cannot be found on disk becomes W_MODULE_OPAQUE or
    W_MODULE_MISSING_AUTO (both warnings) in auto mode, never an error.
    """
    entry = _w(tmp_path, 'main.az', """\
module main;
import third.party.lib;
fn run() -> Unit effects() { return unit; }
""")
    sigs, graph = auto_discover_workspace_signatures(entry)
    if graph is not None:
        assert not any(i.level == 'error' for i in graph.issues), \
            [i for i in graph.issues if i.level == 'error']


def test_auto_discover_cycle_is_still_an_error(tmp_path):
    """Import cycles are always errors in any mode."""
    _w(tmp_path, 'a.az', """\
module a;
import b;
fn fa() -> Unit effects() { return unit; }
""")
    b = _w(tmp_path, 'b.az', """\
module b;
import a;
fn fb() -> Unit effects() { return unit; }
""")
    sigs, graph = auto_discover_workspace_signatures(b)
    assert graph is not None
    assert any(i.level == 'error' and i.code == 'E_MODULE_CYCLE' for i in graph.issues)


def test_auto_discover_transitive_imports(tmp_path):
    """A → B → C: all three modules are discovered from A."""
    _w(tmp_path, 'c.az', """\
module c;
fn fc() -> I64 effects() { return 42; }
""")
    _w(tmp_path, 'b.az', """\
module b;
import c;
fn fb() -> I64 effects() { return c.fc(); }
""")
    a = _w(tmp_path, 'a.az', """\
module a;
import b;
fn fa() -> I64 effects() { return b.fb(); }
""")
    sigs, graph = auto_discover_workspace_signatures(a)
    assert graph is not None
    assert 'b' in graph.modules
    assert 'c' in graph.modules
    assert 'c.fc' in sigs
    assert 'b.fb' in sigs
    assert 'a.fa' in sigs


def test_auto_discover_builds_signatures_for_all_discovered(tmp_path):
    """Signatures come from every module in the discovered workspace."""
    _w(tmp_path, 'lib.az', """\
module lib;
fn lib_fn(x: I64) -> I64 effects() { return x + 1; }
fn lib_fn2(x: I64) -> I64 effects() { return x * 2; }
""")
    entry = _w(tmp_path, 'app.az', """\
module app;
import lib;
fn app_fn(x: I64) -> I64 effects() { return lib.lib_fn(x); }
""")
    sigs, graph = auto_discover_workspace_signatures(entry)
    assert graph is not None
    assert 'lib.lib_fn' in sigs
    assert 'lib.lib_fn2' in sigs
    assert 'app.app_fn' in sigs


# ─────────────────────────────────────────────────────────────────────────────
# 2.  load_module_graph — recursive traversal unit tests (nested structure)
# ─────────────────────────────────────────────────────────────────────────────

def test_load_module_graph_recursively_resolves_all_imports(tmp_path):
    """A → B → C with nested paths; all three appear in graph.modules."""
    _w(tmp_path, 'pkg/c.az', """\
module pkg.c;
fn fc() -> I64 effects() { return 1; }
""")
    _w(tmp_path, 'pkg/b.az', """\
module pkg.b;
import pkg.c;
fn fb() -> I64 effects() { return pkg.c.fc(); }
""")
    a = _w(tmp_path, 'pkg/a.az', """\
module pkg.a;
import pkg.b;
fn fa() -> I64 effects() { return pkg.b.fb(); }
""")
    graph = load_module_graph(a, module_root=str(tmp_path))
    assert set(graph.modules.keys()) == {'pkg.a', 'pkg.b', 'pkg.c'}
    assert not any(i.level == 'error' for i in graph.issues)


def test_load_module_graph_detects_diamond_without_error(tmp_path):
    """Diamond (A→B, A→C, B→D, C→D): D is visited exactly once."""
    _w(tmp_path, 'pkg/d.az', """\
module pkg.d;
fn fd() -> I64 effects() { return 9; }
""")
    _w(tmp_path, 'pkg/b.az', """\
module pkg.b;
import pkg.d;
fn fb() -> I64 effects() { return pkg.d.fd(); }
""")
    _w(tmp_path, 'pkg/c.az', """\
module pkg.c;
import pkg.d;
fn fc() -> I64 effects() { return pkg.d.fd(); }
""")
    a = _w(tmp_path, 'pkg/a.az', """\
module pkg.a;
import pkg.b;
import pkg.c;
fn fa() -> I64 effects() { return pkg.b.fb() + pkg.c.fc(); }
""")
    graph = load_module_graph(a, module_root=str(tmp_path))
    assert 'pkg.d' in graph.modules
    assert graph.order.count('pkg.d') == 1
    assert not any(i.level == 'error' for i in graph.issues)


def test_load_module_graph_topological_order(tmp_path):
    """graph.order is a valid topological sort: dependencies precede dependents."""
    _w(tmp_path, 'pkg/leaf.az', """\
module pkg.leaf;
fn f() -> I64 effects() { return 0; }
""")
    _w(tmp_path, 'pkg/mid.az', """\
module pkg.mid;
import pkg.leaf;
fn g() -> I64 effects() { return pkg.leaf.f(); }
""")
    root = _w(tmp_path, 'pkg/root.az', """\
module pkg.root;
import pkg.mid;
fn h() -> I64 effects() { return pkg.mid.g(); }
""")
    graph = load_module_graph(root, module_root=str(tmp_path))
    order = graph.order
    assert order.index('pkg.leaf') < order.index('pkg.mid')
    assert order.index('pkg.mid') < order.index('pkg.root')


def test_load_module_graph_cycle_detected(tmp_path):
    """Cycle A → B → A: E_MODULE_CYCLE is reported."""
    _w(tmp_path, 'pkg/x.az', """\
module pkg.x;
import pkg.y;
fn fx() -> Unit effects() { return unit; }
""")
    y = _w(tmp_path, 'pkg/y.az', """\
module pkg.y;
import pkg.x;
fn fy() -> Unit effects() { return unit; }
""")
    graph = load_module_graph(y, module_root=str(tmp_path))
    assert any(i.code == 'E_MODULE_CYCLE' for i in graph.issues)


# ─────────────────────────────────────────────────────────────────────────────
# 3.  collect_workspace_ownership_signatures — explicit module_root
# ─────────────────────────────────────────────────────────────────────────────

def test_collect_workspace_signatures_includes_all_modules(tmp_path):
    """Signatures include every function in the transitive workspace."""
    _w(tmp_path, 'pkg/utils.az', """\
module pkg.utils;
fn double(x: I64) -> I64 effects() { return x * 2; }
fn triple(x: I64) -> I64 effects() { return x * 3; }
""")
    entry = _w(tmp_path, 'pkg/entry.az', """\
module pkg.entry;
import pkg.utils;
fn run(x: I64) -> I64 effects() { return pkg.utils.double(x); }
""")
    sigs, graph = collect_workspace_ownership_signatures(
        entry, module_root=str(tmp_path)
    )
    assert 'pkg.utils.double' in sigs
    assert 'pkg.utils.triple' in sigs
    assert 'pkg.entry.run' in sigs
    assert not any(i.level == 'error' for i in graph.issues)


def test_explicit_module_root_errors_on_missing_internal(tmp_path):
    """
    Explicit --module-root: a missing workspace-internal import (same prefix) is
    E_MODULE_MISSING (error), not silently skipped.
    """
    main = _w(tmp_path, 'ws/main.az', """\
module ws.main;
import ws.missing_module;
fn run() -> Unit effects() { return unit; }
""")
    sigs, graph = collect_workspace_ownership_signatures(
        main, module_root=str(tmp_path)
    )
    assert any(
        i.level == 'error' and i.code == 'E_MODULE_MISSING'
        for i in graph.issues
    )


# ─────────────────────────────────────────────────────────────────────────────
# 4.  CLI check — auto-discovery end-to-end
# ─────────────────────────────────────────────────────────────────────────────

def test_cli_check_auto_discovers_sibling(tmp_path, capsys):
    """
    `axiomzig check main.az` without --module-root auto-discovers util.az.
    A valid single-file program with correct cross-module calls passes.
    """
    _w(tmp_path, 'util.az', """\
module util;
fn add(a: I64, b: I64) -> I64 effects() { return a + b; }
""")
    main = _w(tmp_path, 'main.az', """\
module main;
import util;
fn run() -> I64 effects() { return util.add(1, 2); }
""")
    rc = cli_main(['check', str(main)])
    out = capsys.readouterr()
    assert rc == 0, f"expected 0; out={out.out!r} err={out.err!r}"


def test_cli_check_auto_discovers_type_error_across_modules(tmp_path, capsys):
    """
    A type mismatch in a cross-module call is caught even in auto-discovery mode.
    """
    _w(tmp_path, 'util.az', """\
module util;
fn takes_i64(x: I64) -> I64 effects() { return x; }
""")
    main = _w(tmp_path, 'main.az', """\
module main;
import util;
fn run() -> I64 effects() { return util.takes_i64(true); }
""")
    rc = cli_main(['check', str(main)])
    out = capsys.readouterr()
    assert rc == 1
    assert 'error' in out.out or 'error' in out.err


def test_cli_check_no_workspace_discovery_skips_siblings(tmp_path, capsys):
    """
    --no-workspace-discovery: siblings are not loaded; unresolved imports
    are treated as opaque externals and the check proceeds without crashing.
    """
    _w(tmp_path, 'util.az', """\
module util;
fn helper() -> I64 effects() { return 1; }
""")
    main = _w(tmp_path, 'main.az', """\
module main;
import util;
fn run() -> I64 effects() { return 1; }
""")
    rc = cli_main(['check', '--no-workspace-discovery', str(main)])
    out = capsys.readouterr()
    assert 'Traceback' not in out.err


def test_cli_check_explicit_module_root_missing_internal_is_error(tmp_path, capsys):
    """
    --module-root explicit: missing workspace-internal import is an error.
    """
    main = _w(tmp_path, 'ws/main.az', """\
module ws.main;
import ws.does_not_exist;
fn run() -> Unit effects() { return unit; }
""")
    rc = cli_main(['check', '--module-root', str(tmp_path), str(main)])
    out = capsys.readouterr()
    assert rc == 1
    assert 'module error' in out.err


# ─────────────────────────────────────────────────────────────────────────────
# 5.  Cross-module resource ownership
# ─────────────────────────────────────────────────────────────────────────────

def test_cli_check_resource_from_sibling_properly_closed_passes(tmp_path, capsys):
    """
    A resource type defined in an auto-discovered sibling module that is
    correctly discharged passes the ownership checker.
    """
    _w(tmp_path, 'filemod.az', """\
module filemod;
protocol FileP { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileP; fields { fd: I32; } }
pub fn open_file() -> File effects() { return File { fd: 0 }; }
pub fn close_file(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
""")
    main = _w(tmp_path, 'main.az', """\
module main;
import filemod;

fn run() -> Unit effects(protocol_step) {
    let f = filemod.open_file();
    filemod.close_file(f);
    return unit;
}
""")
    rc = cli_main(['check', str(main)])
    out = capsys.readouterr()
    assert rc == 0, f"out={out.out!r} err={out.err!r}"


def test_cli_check_type_error_in_cross_module_call_caught(tmp_path, capsys):
    """
    A type error in a cross-module call (wrong argument type) is caught via
    auto-discovery, confirming the checker sees the callee's signature.
    Note: cross-module resource leak detection requires explicit type annotations;
    dotted type names (module.Type) are not yet parsed, so that case is deferred.
    """
    _w(tmp_path, 'mathlib.az', """\
module mathlib;
fn square(x: I64) -> I64 effects() { return x * x; }
""")
    main = _w(tmp_path, 'main.az', """\
module main;
import mathlib;
fn run() -> I64 effects() { return mathlib.square(true); }
""")
    rc = cli_main(['check', str(main)])
    out = capsys.readouterr()
    assert rc == 1
    assert 'error' in out.out or 'error' in out.err


def test_cli_check_effect_subset_across_modules(tmp_path, capsys):
    """
    A caller that doesn't declare the effect set of a cross-module callee
    is rejected with E_EFFECT_UNDER.
    """
    _w(tmp_path, 'io_mod.az', """\
module io_mod;
fn do_io() -> Unit effects(io) { return unit; }
""")
    main = _w(tmp_path, 'main.az', """\
module main;
import io_mod;
fn run() -> Unit effects() { io_mod.do_io(); return unit; }
""")
    rc = cli_main(['check', str(main)])
    out = capsys.readouterr()
    assert rc == 1
    assert 'E_EFFECT_UNDER' in out.out or 'requires effects' in out.out
