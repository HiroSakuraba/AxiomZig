from axiomzig.cfg import BorrowMark, CFGBuilder, FlowState, build_cfg
from axiomzig.parser import parse_module
from axiomzig.semantic import sem_place_from_path


def edges_of(fn):
    return [(edge.src, edge.dst, edge.kind, tuple(edge.cleanup)) for edge in fn.edges]


def labels(fn):
    return {node.id: (node.kind, node.label) for node in fn.nodes}


def test_cfg_emits_true_false_branch_edges() -> None:
    module = parse_module(
        '''
module demo.cfg_if;

fn choose(cond: Bool) -> U8 effects() {
    if (cond) {
        return 1;
    } else {
        return 2;
    }
}
'''
    )
    cfg = build_cfg(module)
    fn = cfg.functions[0]
    node_labels = labels(fn)
    branch_nodes = [nid for nid, (kind, _) in node_labels.items() if kind == 'branch']
    assert len(branch_nodes) == 1
    branch_id = branch_nodes[0]
    outgoing = [(kind, dst) for src, dst, kind, _ in edges_of(fn) if src == branch_id]
    assert any(kind == 'true' for kind, _ in outgoing)
    assert any(kind == 'false' for kind, _ in outgoing)


def test_cfg_marks_try_error_edge_and_cleanup_order() -> None:
    module = parse_module(
        '''
module demo.cfg_try;

error_set ParseError {
    Empty;
}

fn read_one(s: Str) -> U8!ParseError effects(error) {
    defer log_ok();
    errdefer log_err();
    let x: U8 = parse_byte(s)?;
    return x;
}
'''
    )
    cfg = build_cfg(module)
    fn = cfg.functions[0]
    node_labels = labels(fn)
    let_node = next(nid for nid, (kind, label) in node_labels.items() if kind == 'let' and label == 'let x')
    error_edges = [edge for edge in fn.edges if edge.src == let_node and edge.kind == 'error']
    assert len(error_edges) == 1
    assert error_edges[0].cleanup == ['log_err()', 'log_ok()']


def test_cfg_attaches_normal_cleanup_to_return() -> None:
    module = parse_module(
        '''
module demo.cfg_return;

fn done() -> Unit effects() {
    defer close_it();
    errdefer report_err();
    return unit;
}
'''
    )
    cfg = build_cfg(module)
    fn = cfg.functions[0]
    node_labels = labels(fn)
    return_node = next(nid for nid, (kind, _) in node_labels.items() if kind == 'return')
    return_edges = [edge for edge in fn.edges if edge.src == return_node and edge.kind == 'return']
    assert len(return_edges) == 1
    assert return_edges[0].cleanup == ['close_it()']


def test_cfg_keeps_const_alias_assignment_targets_in_alias_state_model() -> None:
    module = parse_module(
        """
module demo.cfg_const_alias_assign;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn make_file() -> File effects() {
    return File { fd: 1 };
}

fn bad() -> Unit effects(protocol_step) {
    let h = make_holder();
    let c: RefConst<Holder> = borrow h;
    let replacement = make_file();
    c.inner = move replacement;
    return unit;
}
"""
    )
    cfg = build_cfg(module)
    fn = next(item for item in cfg.functions if item.name == 'bad')
    assign_node = next(node for node in fn.nodes if node.kind == 'assign')
    assert [(op.kind, op.name, op.aux_name, op.borrow_mode) for op in assign_node.ownership_ops] == [
        ('move_resource', None, None, None),
        ('invalid_ref_alias', 'c', None, 'mut'),
    ]


def test_cfg_keeps_const_ref_param_method_transition_in_alias_state_model() -> None:
    module = parse_module(
        """
module demo.cfg_const_ref_param_transition;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn bad(c: RefConst<File>) -> Unit effects(protocol_step) {
    c.close();
    return unit;
}
"""
    )
    cfg = build_cfg(module)
    fn = next(item for item in cfg.functions if item.name == 'bad')
    call_node = next(node for node in fn.nodes if node.kind == 'expr' and node.label == 'c.close()')
    assert [(op.kind, op.name, op.aux_name, op.borrow_mode, op.transition) for op in call_node.ownership_ops] == [
        ('transition_alias', 'c', None, 'via_mut_ref', 'close'),
    ]


def test_cfg_direct_resource_ops_carry_canonical_places() -> None:
    module = parse_module(
        """
module demo.cfg_sem_places;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn demo() -> Unit effects() {
    let f = make_file();
    let r: RefConst<File> = borrow f;
    let g = move f;
    return unit;
}
"""
    )
    cfg = build_cfg(module)
    fn = next(item for item in cfg.functions if item.name == 'demo')
    borrow_node = next(node for node in fn.nodes if node.kind == 'let' and node.label == 'let r')
    bind_node = next(node for node in fn.nodes if node.kind == 'let' and node.label == 'let g')

    begin_borrow = borrow_node.ownership_ops[0]
    define_alias = borrow_node.ownership_ops[1]
    bind_from = bind_node.ownership_ops[0]

    assert begin_borrow.kind == 'begin_borrow'
    assert begin_borrow.place is not None
    assert begin_borrow.place.to_path() == 'f'
    assert begin_borrow.name is None

    assert define_alias.kind == 'define_ref_alias'
    assert define_alias.aux_place is not None
    assert define_alias.aux_place.to_path() == 'f'

    assert bind_from.kind == 'bind_from'
    assert bind_from.place is not None
    assert bind_from.place.to_path() == 'g'
    assert bind_from.name is None
    assert bind_from.aux_place is not None
    assert bind_from.aux_place.to_path() == 'f'
    assert bind_from.aux_name is None





def test_cfg_transition_and_call_ref_param_carry_canonical_places() -> None:
    module = parse_module(
        """
module demo.cfg_transition_places;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn inspect(f: RefConst<File>) -> Unit effects() {
    return unit;
}

fn demo() -> Unit effects(protocol_step) {
    let f = File { fd: 0 };
    f.close();
    inspect(borrow f);
    return unit;
}
"""
    )
    cfg = build_cfg(module)
    fn = next(item for item in cfg.functions if item.name == 'demo')

    close_node = next(node for node in fn.nodes if node.kind == 'expr' and node.label == 'f.close()')
    inspect_node = next(node for node in fn.nodes if node.kind == 'expr' and node.label == 'inspect(borrow f)')

    transition = close_node.ownership_ops[0]
    call_ref = inspect_node.ownership_ops[-1]

    assert transition.kind == 'transition'
    assert transition.place is not None
    assert transition.place.to_path() == 'f'
    assert transition.name is None

    assert call_ref.kind == 'call_ref_param'
    assert call_ref.place is not None
    assert call_ref.place.to_path() == 'f'
    assert call_ref.name is None

def test_cfg_scope_alias_entries_store_canonical_places():
    module = parse_module(
        """
module demo.scope_aliases;

fn demo() -> Unit effects() {
    return unit;
}
"""
    )
    builder = CFGBuilder(module)
    scopes = builder.add_ref_alias(tuple(), 'r', sem_place_from_path('f.fd'), 'const')
    entry = scopes[0].ref_aliases[0]
    assert entry.alias_name == 'r'
    assert entry.target_place is not None
    assert entry.target_place.to_path() == 'f.fd'


def test_cfg_scope_pop_preserves_borrow_place_payloads():
    module = parse_module(
        """
module demo.scope_aliases;

fn demo() -> Unit effects() {
    return unit;
}
"""
    )
    builder = CFGBuilder(module)
    mark = BorrowMark(path='f.fd', mode='const', place=sem_place_from_path('f.fd'))
    scopes = builder.add_borrow_marks(tuple(), [mark])
    ops = builder.pop_ops_for_frame(scopes[0])
    assert ops[0].kind == 'end_borrow'
    assert ops[0].place is not None
    assert ops[0].place.to_path() == 'f.fd'


def test_cfg_alias_ops_use_relative_semantic_places_instead_of_suffix_strings() -> None:
    module = parse_module(
        """
module demo.alias_relative_places;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn observe(f: RefConst<File>) -> Unit effects() {
    return unit;
}

fn demo(h: Ref<Holder>, s: Ref<File>) -> Unit effects() {
    observe(h.inner);
    h.inner = move s;
    return unit;
}
"""
    )
    cfg = build_cfg(module)
    fn = next(item for item in cfg.functions if item.name == 'demo')
    call_node = next(node for node in fn.nodes if node.kind == 'expr' and node.label == 'observe(h.inner)')
    assign_node = next(node for node in fn.nodes if node.kind == 'assign' and node.label == 'h.inner = ...')

    call_op = next(op for op in call_node.ownership_ops if op.kind == 'call_ref_alias_param')
    assert call_op.aux_name is None
    assert call_op.aux_place is not None
    assert call_op.aux_place.root == ''
    assert call_op.aux_place.to_path() == 'inner'

    bind_op = next(op for op in assign_node.ownership_ops if op.kind == 'bind_alias_target_from_alias_source')
    assert bind_op.aux_name is None
    assert bind_op.source_aux_name is None
    assert bind_op.aux_place is not None
    assert bind_op.aux_place.root == ''
    assert bind_op.aux_place.to_path() == 'inner'
    assert bind_op.source_aux_place is not None
    assert bind_op.source_aux_place.root == ''
    assert bind_op.source_aux_place.to_path() == ''


def test_cfg_lookup_tracked_binding_accepts_canonical_place() -> None:
    module = parse_module(
        """
module demo.lookup_tracked_place;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn demo() -> Unit effects() {
    return unit;
}
"""
    )
    builder = CFGBuilder(module)
    scopes = builder.add_binding(tuple(), 'h', 'Holder')
    tracked = builder.lookup_tracked_binding(sem_place_from_path('h.inner'), [FlowState(node_id=0, active_scopes=scopes)])
    assert tracked == 'File'
