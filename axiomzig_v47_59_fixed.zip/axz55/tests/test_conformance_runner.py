"""
test_conformance_runner.py — unified conformance suite runner

Discovers every .az file under conformance/, reads its .json sidecar,
and drives the appropriate CLI phase. Reports pass/fail against the sidecar
expectation with stable diagnostic codes where required.

Sidecar schema:
  phase:      "check" | "parse" | "format" | "interpret"
  expect:     "pass" | "fail" | "trap" | "format" | "output"
  diagnostic: "E_*" | "R_TRAP_*"   (required for fail/trap)
  output:     str                    (required for format/output)
  notes:      str                    (optional)
"""
from __future__ import annotations

import json
import sys
import subprocess
from pathlib import Path

import pytest

from axiomzig.cli import main as cli_main
from axiomzig.formatter import format_module
from axiomzig.interpreter import Interpreter, TrapError
from axiomzig.lexer import LexError
from axiomzig.parser import parse_module, ParseError

CONFORMANCE_ROOT = Path(__file__).parent.parent / "conformance"


# ─────────────────────────────────────────────────────────────────────────────
# Discovery
# ─────────────────────────────────────────────────────────────────────────────

def _discover() -> list[tuple[Path, dict]]:
    """Return (source_path, metadata) for every conformance test."""
    cases = []
    for az in sorted(CONFORMANCE_ROOT.rglob("*.az")):
        sidecar = az.with_suffix(".json")
        if not sidecar.exists():
            continue
        meta = json.loads(sidecar.read_text(encoding="utf-8"))
        cases.append((az, meta))
    return cases


_CASES = _discover()


def pytest_generate_tests(metafunc):
    if "conformance_case" in metafunc.fixturenames:
        ids = [
            f"{p.parent.name}/{p.stem}"
            for p, _ in _CASES
        ]
        metafunc.parametrize("conformance_case", _CASES, ids=ids)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _run_check(path: Path) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, "-m", "axiomzig.cli", "check", str(path)],
        capture_output=True, text=True, timeout=20,
        cwd=str(path.parent.parent.parent),
    )
    return proc.returncode, proc.stdout, proc.stderr


def _run_parse(path: Path) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, "-m", "axiomzig.cli", "parse", str(path)],
        capture_output=True, text=True, timeout=20,
        cwd=str(path.parent.parent.parent),
    )
    return proc.returncode, proc.stdout, proc.stderr


def _run_interpret(path: Path) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, "-m", "axiomzig.cli", "interpret", str(path)],
        capture_output=True, text=True, timeout=20,
        cwd=str(path.parent.parent.parent),
    )
    return proc.returncode, proc.stdout, proc.stderr


# ─────────────────────────────────────────────────────────────────────────────
# Main test
# ─────────────────────────────────────────────────────────────────────────────

def test_conformance_case(conformance_case):
    path, meta = conformance_case
    phase = meta["phase"]
    expect = meta["expect"]
    diag = meta.get("diagnostic", "")
    expected_output = meta.get("output", "")

    src = path.read_text(encoding="utf-8")
    label = f"{path.parent.name}/{path.stem}"

    if phase == "parse":
        if expect == "pass":
            try:
                parse_module(src)
            except ParseError as e:
                pytest.fail(f"{label}: expected parse to succeed, got: {e}")
        elif expect == "fail":
            with pytest.raises((ParseError, LexError)):
                parse_module(src)
        else:
            pytest.fail(f"{label}: unsupported parse expect={expect!r}")

    elif phase in ("check",):
        rc, out, err = _run_check(path)
        assert "Traceback" not in out, f"{label}: traceback in stdout\n{out}"
        assert "Traceback" not in err, f"{label}: traceback in stderr\n{err}"
        if expect == "pass":
            assert rc == 0, (
                f"{label}: expected check to pass (rc=0)\n"
                f"stdout: {out}\nstderr: {err}"
            )
        elif expect == "fail":
            assert rc != 0, (
                f"{label}: expected check to fail (rc≠0)\n"
                f"stdout: {out}\nstderr: {err}"
            )
            if diag:
                assert diag in out, (
                    f"{label}: expected diagnostic {diag!r} in stdout\n{out}"
                )
        else:
            pytest.fail(f"{label}: unsupported check expect={expect!r}")

    elif phase == "format":
        try:
            m = parse_module(src)
        except ParseError as e:
            pytest.fail(f"{label}: parse failed before format: {e}")
        result = format_module(m)
        # Idempotence: always check
        result2 = format_module(parse_module(result))
        assert result == result2, (
            f"{label}: formatter not idempotent\n"
            f"first:  {result!r}\nsecond: {result2!r}"
        )
        if expected_output:
            assert result == expected_output, (
                f"{label}: formatted output mismatch\n"
                f"expected: {expected_output!r}\n"
                f"got:      {result!r}"
            )

    elif phase == "interpret":
        rc, out, err = _run_interpret(path)
        assert "Traceback" not in err, f"{label}: traceback in stderr\n{err}"
        if expect == "pass":
            assert rc == 0, f"{label}: expected interpret pass\n{out}\n{err}"
        elif expect == "output":
            assert rc == 0, f"{label}: expected interpret pass\n{out}\n{err}"
            assert out.strip() == expected_output, (
                f"{label}: output mismatch\n"
                f"expected: {expected_output!r}\ngot: {out.strip()!r}"
            )
        elif expect == "trap":
            assert rc != 0, f"{label}: expected trap (rc≠0)\n{out}\n{err}"
            combined = out + err
            if diag == "R_TRAP_DIV_ZERO":
                assert "division by zero" in combined or "trap" in combined.lower(), (
                    f"{label}: expected div-zero trap\n{combined}"
                )
            elif diag == "R_TRAP_OVERFLOW":
                assert "overflow" in combined, (
                    f"{label}: expected overflow trap\n{combined}"
                )
            elif diag == "R_TRAP_CAST":
                assert "cast" in combined or "out of range" in combined or "overflow" in combined, (
                    f"{label}: expected cast trap\n{combined}"
                )
            elif diag == "R_TRAP_BOUNDS":
                assert "bounds" in combined or "index" in combined, (
                    f"{label}: expected bounds trap\n{combined}"
                )
            elif diag:
                assert diag in combined or "trap" in combined.lower(), (
                    f"{label}: expected trap diagnostic {diag!r}\n{combined}"
                )
        elif expect == "fail":
            assert rc != 0, f"{label}: expected interpret fail (rc≠0)\n{out}\n{err}"
        else:
            pytest.fail(f"{label}: unsupported interpret expect={expect!r}")

    else:
        pytest.fail(f"{label}: unknown phase {phase!r}")


# ─────────────────────────────────────────────────────────────────────────────
# Coverage summary
# ─────────────────────────────────────────────────────────────────────────────

def test_conformance_coverage_summary():
    """Print a per-category coverage table as a test. Always passes."""
    categories: dict[str, dict[str, int]] = {}
    for path, meta in _CASES:
        cat = path.parent.name
        if cat not in categories:
            categories[cat] = {"pass": 0, "fail": 0, "trap": 0, "total": 0}
        expect = meta.get("expect", "?")
        key = "fail" if expect in ("fail", "trap") else "pass"
        categories[cat][key] += 1
        categories[cat]["total"] += 1

    minimums = {
        "parser": 35, "formatter": 20, "name_resolution": 20,
        "typing": 50, "effects": 25, "ownership": 40,
        "protocols": 30, "defer": 25, "runtime": 35,
        "canonical_roundtrip": 15,
    }

    print("\n╔══ Conformance coverage ══════════════════════════════════════╗")
    header = f"{'Category':<22} {'Pass':>5} {'Fail':>5} {'Total':>6} {'Min':>5} {'Status':>8}"
    print(f"║ {header} ║")
    print("╠" + "═"*64 + "╣")
    all_ok = True
    for cat in sorted(categories):
        d = categories[cat]
        mn = minimums.get(cat, 0)
        status = "✓" if d["total"] >= mn else f"↑{mn - d['total']}"
        if d["total"] < mn:
            all_ok = False
        row = f"{cat:<22} {d['pass']:>5} {d['fail']:>5} {d['total']:>6} {mn:>5} {status:>8}"
        print(f"║ {row} ║")

    neg = sum(d["fail"] for d in categories.values())
    tot = sum(d["total"] for d in categories.values())
    pct = 100 * neg // tot if tot else 0
    print("╠" + "═"*64 + "╣")
    print(f"║ {'TOTAL':<22} {'':>5} {neg:>5} {tot:>6} {'':>5} {pct:>7}% ║")
    print("╚" + "═"*64 + "╝")
    print(f"  (negative test ratio: {pct}% — plan requires ≥40%)")
    assert True  # always passes; informational only
