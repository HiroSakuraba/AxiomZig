from __future__ import annotations

import json
import subprocess
import sys
from functools import lru_cache
from pathlib import Path

from axiomzig.cfg import build_cfg
from axiomzig.cli import dataclass_to_jsonable
from axiomzig.elaborate import elaborate_module
from axiomzig.formatter import format_module
from axiomzig.ir import lower_module
from axiomzig.ownership import analyze_ownership
from axiomzig.parser import parse_module
from axiomzig.resolve import resolve_module
from axiomzig.typecheck import typecheck_module


EXAMPLES = [
    Path("examples/demo_math.az"),
    Path("examples/demo_parse.az"),
    Path("examples/demo_file.az"),
    Path("examples/demo_option.az"),
]


CLI_EXAMPLES = [
    Path("examples/demo_file.az"),
]


DIRECT_PASSES = {
    "parse": lambda module: module,
    "resolve": resolve_module,
    "elaborate": elaborate_module,
    "typecheck": typecheck_module,
    "lower": lower_module,
    "cfg": build_cfg,
    "owncheck": analyze_ownership,
}


TOP_LEVEL_KEYS = {
    "parse": {"path", "imports", "decls"},
    "resolve": {"module_path", "imports", "top_symbols", "functions", "issues"},
    "elaborate": {"module_path", "functions", "issues"},
    "typecheck": {"module_path", "functions", "issues"},
    "lower": {"module_path", "functions"},
    "cfg": {"module_path", "functions"},
    "owncheck": {"module_path", "functions", "issues"},
}


FUNCTION_KEYS = {
    "resolve": {"name", "params", "locals", "types", "values"},
    "elaborate": {"name", "declared_return_type", "bindings", "expr_types", "calls", "issues"},
    "typecheck": {"name", "declared_return_type", "exprs", "calls", "issues"},
    "lower": {"name", "params", "return_type", "effects", "body", "issues"},
    "cfg": {"name", "entry", "fallthrough_exit", "return_exit", "error_exit", "nodes", "edges"},
    "owncheck": {"name", "resource_states", "ref_param_states", "ref_param_effects", "issues"},
}


CFG_NODE_KEYS = {"id", "kind", "label", "ownership_ops"}
CFG_EDGE_KEYS = {"src", "dst", "kind", "cleanup", "cleanup_actions", "pre_cleanup_ops", "post_cleanup_ops", "pop_bindings"}
LOWER_STMT_BASE_KEYS = {"kind"}
LOWER_STMT_PAYLOAD_KEYS = {"expr", "value"}


@lru_cache(maxsize=None)
def run_cli(command: str, path: Path) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, "-m", "axiomzig.cli", command, str(path)],
        capture_output=True,
        text=True,
        cwd=path.parent.parent if path.parts[0] == "examples" else None,
    )
    return proc.returncode, proc.stdout, proc.stderr


@lru_cache(maxsize=None)
def cli_json(command: str, path: Path):
    rc, stdout, stderr = run_cli(command, path)
    assert rc == 0, f"{command} failed for {path.name}: {stderr}"
    assert stderr == ""
    return json.loads(stdout)


def direct_json(command: str, text: str):
    module = parse_module(text)
    payload = dataclass_to_jsonable(DIRECT_PASSES[command](module))
    return json.loads(json.dumps(payload))


def test_direct_pipeline_is_invariant_under_canonical_roundtrip() -> None:
    for path in EXAMPLES:
        original_text = path.read_text(encoding="utf-8")
        formatted_text = format_module(parse_module(original_text))

        for command in DIRECT_PASSES:
            original = direct_json(command, original_text)
            canonical = direct_json(command, formatted_text)
            assert original == canonical, (path.name, command)


def test_cli_and_direct_pipeline_outputs_agree() -> None:
    for path in CLI_EXAMPLES:
        text = path.read_text(encoding="utf-8")

        formatted_rc, formatted_stdout, formatted_stderr = run_cli("format", path)
        assert formatted_rc == 0, path.name
        assert formatted_stderr == ""
        assert formatted_stdout == format_module(parse_module(text)), path.name

        for command in DIRECT_PASSES:
            assert cli_json(command, path) == direct_json(command, text), (path.name, command)


def test_cli_json_shapes_remain_stable_across_examples() -> None:
    for path in CLI_EXAMPLES:
        for command, expected_keys in TOP_LEVEL_KEYS.items():
            payload = cli_json(command, path)
            assert set(payload.keys()) == expected_keys, (path.name, command)

            if command == "parse":
                assert isinstance(payload["path"], list)
                assert isinstance(payload["imports"], list)
                assert isinstance(payload["decls"], list)
                continue

            functions = payload["functions"]
            assert isinstance(functions, list), (path.name, command)
            if not functions:
                continue

            fn = functions[0]
            assert set(fn.keys()) == FUNCTION_KEYS[command], (path.name, command)

            if command == "lower" and fn["body"]:
                stmt_keys = set(fn["body"][0].keys())
                assert LOWER_STMT_BASE_KEYS <= stmt_keys, path.name
                assert stmt_keys & LOWER_STMT_PAYLOAD_KEYS, path.name
            if command == "cfg":
                if fn["nodes"]:
                    assert set(fn["nodes"][0].keys()) == CFG_NODE_KEYS, path.name
                if fn["edges"]:
                    assert set(fn["edges"][0].keys()) == CFG_EDGE_KEYS, path.name
