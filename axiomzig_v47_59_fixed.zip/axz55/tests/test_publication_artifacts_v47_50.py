from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main

COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _build_dep_manifest(dep_root: Path, capsys) -> Path:
    dep_file = _write(
        dep_root / 'dep' / 'api.az',
        f'''module dep.api;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    out = dep_root / 'dep_manifest.json'
    rc = main([
        'conform',
        str(dep_file),
        '--module-root', str(dep_root),
        '--package-name', 'dep',
        '--package-version', '1.2.3',
        '--public-only',
        '--publication-out', str(out),
        '--out', str(dep_root / 'dep_full.json'),
    ])
    assert rc == 0
    capsys.readouterr()
    return out


def test_conform_writes_publication_manifest_and_dependency_lock(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dep_manifest(tmp_path / 'dep_pkg', capsys)
    app_root = tmp_path / 'app'
    main_file = _write(
        app_root / 'app' / 'main.az',
        f'''module app.main;
import dep.api;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ dep.api.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )
    full_out = app_root / 'full.json'
    pub_out = app_root / 'pub.json'
    lock_out = app_root / 'deps.lock.json'
    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(app_root),
        '--dependency-manifest', str(dep_manifest),
        '--package-name', 'app',
        '--package-version', '0.9.0',
        '--public-only',
        '--out', str(full_out),
        '--publication-out', str(pub_out),
        '--write-dependency-lock', str(lock_out),
    ])
    assert rc == 0
    full_manifest = json.loads(full_out.read_text(encoding='utf-8'))
    publication = json.loads(pub_out.read_text(encoding='utf-8'))
    lock = json.loads(lock_out.read_text(encoding='utf-8'))
    assert full_manifest['schema_version'] == 'axiomzig.conformance.v4'
    assert full_manifest['dependency_packages'][0]['package_id'] == 'dep@1.2.3'
    assert publication['schema_version'] == 'axiomzig.publication_manifest.v1'
    assert publication['package_id'] == 'app@0.9.0'
    assert publication['exported_modules'] == ['app.main']
    assert 'module_graph' not in publication
    assert publication['dependency_packages'][0]['package_id'] == 'dep@1.2.3'
    assert lock['schema_version'] == 'axiomzig.dependency_lock.v1'
    assert lock['dependencies'][0]['package_id'] == 'dep@1.2.3'


def test_publication_manifest_is_accepted_as_dependency_input(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dep_manifest(tmp_path / 'dep_pkg', capsys)
    app_root = tmp_path / 'app'
    main_file = _write(
        app_root / 'app' / 'main.az',
        f'''module app.main;
import dep.api;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ dep.api.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )
    out = app_root / 'full.json'
    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(app_root),
        '--dependency-manifest', str(dep_manifest),
        '--out', str(out),
    ])
    captured = capsys.readouterr()
    assert rc == 0
    manifest = json.loads(out.read_text(encoding='utf-8'))
    assert manifest['status'] == 'ok'
    assert 'conformance error:' not in captured.err


def test_conform_refuses_publication_manifest_on_error(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        f'''module demo.util;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        f'''module demo.main;
import demo.util;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects() {{ h.inner = File {{ fd: 3 }}; return unit; }}
''',
    )
    ext_path = tmp_path / 'import_ownership.json'
    ext_path.write_text(
        json.dumps(
            {
                'module_path': 'demo.util',
                'functions': [
                    {
                        'name': 'demo.util.close_inner',
                        'param_types': ['Ref<Holder>'],
                        'return_type': 'Unit',
                        'ref_params': [
                            {
                                'param_index': 0,
                                'mode': 'mut',
                                'type_name': 'Holder',
                                'effects': {'inner': 'dead'},
                            }
                        ],
                        'effects': ['protocol_step'],
                    }
                ],
            },
            indent=2,
        ),
        encoding='utf-8',
    )
    full_out = tmp_path / 'full.json'
    pub_out = tmp_path / 'pub.json'
    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(tmp_path),
        '--import-ownership', str(ext_path),
        '--out', str(full_out),
        '--publication-out', str(pub_out),
    ])
    captured = capsys.readouterr()
    assert rc == 1
    assert full_out.is_file()
    assert not pub_out.exists()
    assert 'refusing to write publication manifest' in captured.err
