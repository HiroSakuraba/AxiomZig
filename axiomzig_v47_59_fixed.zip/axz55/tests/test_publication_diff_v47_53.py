from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from axiomzig.cli import main
from axiomzig.publication_diff import diff_publication_manifests


def _base_manifest() -> dict:
    return {
        'schema_version': 'axiomzig.publication_manifest.v1',
        'package_name': 'demo',
        'package_version': '1.0.0',
        'package_id': 'demo@1.0.0',
        'exported_modules': ['demo.main'],
        'exported_functions': {'demo.main': ['demo.main.run']},
        'internal_signatures': {
            'demo.main': {
                'schema_version': 'axiomzig.ownership_signatures.v1',
                'module': 'demo.main',
                'functions': [
                    {
                        'name': 'demo.main.run',
                        'effects': [],
                        'params': [],
                        'return': 'Unit',
                        'resource_transitions': [],
                        'ref_writes': [],
                    }
                ],
            }
        },
        'public_function_metadata': {
            'demo.main': {
                'demo.main.run': {'stability': 'stable', 'since': '1.0.0'}
            }
        },
        'api_compatibility': {
            'language_version': 'axiomzig>=0.47',
            'dependency_version_ranges': {'dep': '^1.2'},
        },
        'dependency_lock_digest': 'lock-old',
        'dependency_publication_refs': [
            {'package_id': 'dep@1.2.3', 'package_version': '1.2.3', 'modules': ['dep.api'], 'export_scope': 'public_only'}
        ],
        'workspace_source_digest': 'src-old',
        'manifest_hash': 'hash-old',
    }


def test_publication_diff_classifies_api_lifecycle_dependency_and_metadata_separately() -> None:
    old = _base_manifest()
    new = deepcopy(old)
    new['package_version'] = '1.0.1'
    new['package_id'] = 'demo@1.0.1'
    new['manifest_hash'] = 'hash-new'
    new['workspace_source_digest'] = 'src-new'
    new['public_function_metadata']['demo.main']['demo.main.run'] = {
        'stability': 'deprecated',
        'since': '1.0.0',
        'deprecated_reason': 'use demo.main.run2',
        'replacement': 'demo.main.run2',
    }
    new['api_compatibility']['dependency_version_ranges'] = {'dep': '^1.3'}
    new['dependency_lock_digest'] = 'lock-new'
    new['dependency_publication_refs'] = [
        {'package_id': 'dep@1.3.0', 'package_version': '1.3.0', 'modules': ['dep.api'], 'export_scope': 'public_only'}
    ]

    result = diff_publication_manifests(old, new)

    assert result['classification'] == 'compatible'
    categories = {issue['category'] for issue in result['issues']}
    assert 'api_lifecycle' in categories
    assert 'dependency_policy' in categories
    assert 'dependency_lock' in categories
    assert 'metadata' in categories
    assert any(issue['code'] == 'C_API_LIFECYCLE_NARROWED' for issue in result['issues'])
    assert any(issue['code'] == 'C_DEPENDENCY_POLICY_CHANGED' for issue in result['issues'])
    assert any(issue['code'] == 'C_DEPENDENCY_LOCK_CHANGED' for issue in result['issues'])


def test_publication_diff_marks_ownership_signature_changes_incompatible() -> None:
    old = _base_manifest()
    new = deepcopy(old)
    new['internal_signatures']['demo.main']['functions'][0]['effects'] = ['protocol_step']

    result = diff_publication_manifests(old, new)

    assert result['classification'] == 'incompatible'
    assert any(issue['category'] == 'ownership_signature' and issue['code'] == 'E_OWNERSHIP_SIGNATURE_CHANGED' for issue in result['issues'])


def test_publication_diff_marks_public_api_removal_incompatible_and_addition_compatible() -> None:
    old = _base_manifest()
    new = deepcopy(old)
    new['exported_functions'] = {'demo.main': ['demo.main.run2']}
    new['internal_signatures']['demo.main']['functions'][0]['name'] = 'demo.main.run2'

    result = diff_publication_manifests(old, new)

    assert result['classification'] == 'incompatible'
    assert any(issue['code'] == 'E_PUBLIC_FUNCTION_REMOVED' for issue in result['issues'])
    assert any(issue['code'] == 'C_PUBLIC_FUNCTION_ADDED' for issue in result['issues'])


def test_pubdiff_cli_writes_json_and_can_fail_on_incompatible(tmp_path: Path, capsys) -> None:
    old = _base_manifest()
    new = deepcopy(old)
    new['exported_modules'] = []
    new['exported_functions'] = {}
    old_path = tmp_path / 'old.json'
    new_path = tmp_path / 'new.json'
    out_path = tmp_path / 'diff.json'
    old_path.write_text(json.dumps(old), encoding='utf-8')
    new_path.write_text(json.dumps(new), encoding='utf-8')

    rc = main(['pubdiff', str(old_path), str(new_path), '--out', str(out_path), '--fail-on-incompatible'])
    capsys.readouterr()
    diff = json.loads(out_path.read_text(encoding='utf-8'))

    assert rc == 1
    assert diff['schema_version'] == 'axiomzig.publication_diff.v1'
    assert diff['classification'] == 'incompatible'
    assert any(issue['code'] == 'E_PUBLIC_MODULE_REMOVED' for issue in diff['issues'])
