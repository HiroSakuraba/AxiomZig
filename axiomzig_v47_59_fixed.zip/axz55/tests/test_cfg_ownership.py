from axiomzig.cfg import OwnershipOp
from axiomzig.ownership import AnalysisState, CFGOwnershipAnalyzer, FunctionOwnership, ResourceState, analyze_ownership, export_ownership_signatures
from axiomzig.semantic import SemPlace
from axiomzig.parser import parse_module
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature


def ownership_messages(summary):
    return [issue.message for issue in summary.issues]



def _sig(name: str, *, param_types: list[str], return_type: str = "Unit", ref_params=None, effects=None) -> FunctionOwnershipSignature:
    return FunctionOwnershipSignature(
        name=name,
        param_types=param_types,
        return_type=return_type,
        ref_params=list(ref_params or []),
        effects=list(effects or []),
    )

def test_cfg_ownership_accepts_defer_cleanup_on_try_error_edge() -> None:
    module = parse_module(
        '''
module demo.cfg_own_try;

error_set ParseError {
    Empty;
}

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn parse_byte(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn use_file(f: File, s: Str) -> Unit!ParseError effects(protocol_step, error) {
    defer f.close();
    let x: U8 = parse_byte(s)?;
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_accepts_terminal_state_convergence_at_join() -> None:
    module = parse_module(
        '''
module demo.cfg_join_terminal_ok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn converge(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    if (flag) {
        f.close();
    } else {
        let g: File = f;
        g.close();
    }
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert messages == []


def test_cfg_ownership_rejects_use_after_terminal_state_convergence() -> None:
    module = parse_module(
        '''
module demo.cfg_join_terminal_use;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad_after_join(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    if (flag) {
        f.close();
    } else {
        let g: File = f;
        g.close();
    }
    let h: File = f;
    h.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot bind h from terminal resource f in state <terminal>' in messages




def test_cfg_ownership_allows_terminal_convergence_through_match_expr_stmt() -> None:
    module = parse_module(
        '''
module demo.cfg_match_expr_terminal_ok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn close_in_match(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    match flag {
        true -> f.close(),
        false -> f.close(),
    };
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_rejects_divergent_states_after_match_expr_stmt() -> None:
    module = parse_module(
        '''
module demo.cfg_match_expr_divergent_use;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad_after_match(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    match flag {
        true -> f.close(),
        false -> unit,
    };
    let g: File = f;
    g.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any(msg.startswith('CFG merge leaves resource f in different states at node') for msg in messages)
    assert 'cannot bind g from terminal resource f in state <terminal>' in messages

def test_cfg_ownership_tracks_unannotated_resource_return_values() -> None:
    module = parse_module(
        '''
module demo.cfg_unannotated_return;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn close_it(f: File) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn bad() -> Unit effects(protocol_step) {
    let f = make_file();
    close_it(move f);
    close_it(move f);
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any(msg in messages for msg in ['cannot move resource f from terminal state Moved', 'cannot move resource f from terminal state <terminal>'])


def test_cfg_ownership_tracks_unannotated_match_derived_resources() -> None:
    module = parse_module(
        '''
module demo.cfg_unannotated_match_return;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn choose(flag: Bool) -> File effects() {
    return match flag {
        true -> make_file(),
        false -> make_file(),
    };
}

fn close_it(f: File) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f = match flag {
        true -> make_file(),
        false -> choose(flag),
    };
    close_it(move f);
    close_it(move f);
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any(msg in messages for msg in ['cannot move resource f from terminal state Moved', 'cannot move resource f from terminal state <terminal>'])


def test_cfg_ownership_reinitializes_tracked_assignment_from_match_derived_resource() -> None:
    module = parse_module(
        '''
module demo.cfg_match_assignment_reinit;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn good_assign(flag: Bool) -> Unit effects(protocol_step) {
    var f: File = make_file();
    f.close();
    f = match flag {
        true -> make_file(),
        false -> make_file(),
    };
    f.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_treats_structs_containing_resources_as_owned() -> None:
    module = parse_module(
        '''
module demo.cfg_struct_owned;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn leak() -> Unit effects() {
    let h = make_holder();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'resource h: Holder leaves block scope in non-terminal state Allocated{inner=Open}' in messages


def test_cfg_ownership_allows_discharge_via_inner_field_transition() -> None:
    module = parse_module(
        '''
module demo.cfg_inner_transition_ok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn close_holder() -> Unit effects(protocol_step) {
    let h = make_holder();
    h.inner.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_rejects_leak_when_inner_field_stays_open() -> None:
    module = parse_module(
        '''
module demo.cfg_inner_transition_leak;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn leak_holder() -> Unit effects() {
    let h = make_holder();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'resource h: Holder leaves block scope in non-terminal state Allocated{inner=Open}' in messages


def test_cfg_ownership_allows_partial_move_of_inner_resource_field() -> None:
    module = parse_module(
        '''
module demo.cfg_partial_field_move_ok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn take_inner() -> Unit effects(protocol_step) {
    let h = make_holder();
    let f: File = move h.inner;
    f.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_rejects_use_of_inner_field_after_partial_move() -> None:
    module = parse_module(
        '''
module demo.cfg_partial_field_move_bad;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn bad_after_partial_move() -> Unit effects(protocol_step) {
    let h = make_holder();
    let f: File = move h.inner;
    h.inner.close();
    f.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot call h.inner.close on moved resource' in messages


def test_cfg_ownership_allows_nested_partial_move_of_resource_field() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_partial_field_move_ok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

struct Outer {
    holder: Holder;
}

fn make_outer() -> Outer effects() {
    return Outer { holder: Holder { inner: File { fd: 0 } } };
}

fn take_nested_inner() -> Unit effects(protocol_step) {
    let o = make_outer();
    let f: File = move o.holder.inner;
    f.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_allows_reinit_of_partially_moved_inner_field() -> None:
    module = parse_module(
        '''
module demo.cfg_partial_field_reinit_ok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn reinit_inner() -> Unit effects(protocol_step) {
    var h = make_holder();
    let f: File = move h.inner;
    h.inner = File { fd: 1 };
    h.inner.close();
    f.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_rejects_overwrite_of_live_inner_resource_field() -> None:
    module = parse_module(
        '''
module demo.cfg_partial_field_reinit_bad;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn overwrite_live_inner() -> Unit effects() {
    var h = make_holder();
    h.inner = File { fd: 1 };
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot assign to resource h.inner while it is in non-terminal state Open' in messages


def test_imported_ref_holder_summary_propagates_nested_effects() -> None:
    util_module = parse_module(
        '''
module demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
'''
    )
    imported = {fn.name: fn for fn in export_ownership_signatures(util_module).functions}
    main_module = parse_module(
        '''
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn run_ok() -> Unit effects(protocol_step) {
    let h: Holder = make_holder();
    util.close_inner(borrow h);
    return unit;
}
'''
    )
    summary = analyze_ownership(main_module, imported_signatures=imported)
    assert ownership_messages(summary) == []


def test_exported_ownership_signature_records_nested_ref_effects() -> None:
    module = parse_module(
        '''
module demo.utilsig;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
'''
    )
    bundle = export_ownership_signatures(module)
    close_inner = next(fn for fn in bundle.functions if fn.name == 'demo.utilsig.close_inner')
    assert len(close_inner.ref_params) == 1
    assert close_inner.ref_params[0].effects == {'inner': 'Closed'}


def test_cfg_ownership_rejects_aliasing_same_mut_ref_argument_twice() -> None:
    module = parse_module(
        '''
module demo.aliascall;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn close_both(a: Ref<File>, b: Ref<File>) -> Unit effects(protocol_step) {
    a.close();
    b.close();
    return unit;
}

fn bad() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    let r: Ref<File> = borrow f;
    close_both(r, r);
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    joined = '\n'.join(ownership_messages(summary))
    assert 'call to close_both passes aliased reference f to incompatible ref parameters 1 and 2' in joined


def test_imported_ref_summary_type_mismatch_is_reported() -> None:
    util_module = parse_module(
        '''
module demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
'''
    )
    imported = {fn.name: fn for fn in export_ownership_signatures(util_module).functions}
    main_module = parse_module(
        '''
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn run_bad() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    util.close_inner(borrow f);
    return unit;
}
'''
    )
    summary = analyze_ownership(main_module, imported_signatures=imported)
    joined = '\n'.join(ownership_messages(summary))
    assert 'call to demo.util.close_inner parameter 1 expects referent type Holder but got File at f' in joined


def test_cfg_ownership_rejects_overlapping_ref_arguments() -> None:
    module = parse_module(
        '''
module demo.overlapcall;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_both(a: Ref<Holder>, b: Ref<File>) -> Unit effects(protocol_step) {
    a.inner.close();
    b.close();
    return unit;
}

fn bad() -> Unit effects(protocol_step) {
    let h: Holder = Holder { inner: File { fd: 0 } };
    close_both(borrow h, borrow h.inner);
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    joined = '\n'.join(ownership_messages(summary))
    assert 'call to close_both passes overlapping references h and h.inner to incompatible ref parameters 1 and 2' in joined


def test_imported_ref_summary_survives_alias_transfer_rebinding() -> None:
    util_module = parse_module(
        """
module demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
"""
    )
    imported = {fn.name: fn for fn in export_ownership_signatures(util_module).functions}
    main_module = parse_module(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn run_ok() -> Unit effects(protocol_step) {
    let h: Holder = make_holder();
    let r1: Ref<Holder> = borrow h;
    let r2: Ref<Holder> = r1;
    demo.util.close_inner(r2);
    return unit;
}
"""
    )
    summary = analyze_ownership(main_module, imported_signatures=imported)
    assert ownership_messages(summary) == []


def test_imported_ref_summary_rejects_ambiguous_joined_alias() -> None:
    util_module = parse_module(
        """
module demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
"""
    )
    imported = {fn.name: fn for fn in export_ownership_signatures(util_module).functions}
    main_module = parse_module(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn run_bad(flag: Bool) -> Unit effects(protocol_step) {
    let h1: Holder = make_holder();
    let h2: Holder = make_holder();
    let r: Ref<Holder> = borrow h1;
    if (flag) {
        r = borrow h1;
    } else {
        r = borrow h2;
    }
    demo.util.close_inner(r);
    return unit;
}
"""
    )
    summary = analyze_ownership(main_module, imported_signatures=imported)
    joined = '\n'.join(ownership_messages(summary))
    assert 'mutable reference alias r does not have a live unique referent' in joined


def test_cfg_ownership_accepts_place_only_direct_ops_without_legacy_name_fields() -> None:
    module = parse_module(
        '''
module demo.place_only_direct_ops;

fn demo() -> Unit effects() {
    return unit;
}
'''
    )
    analyzer = CFGOwnershipAnalyzer(module)
    env = AnalysisState(resources={'f': ResourceState(type_name='File', state='Moved')})
    summary = FunctionOwnership(name='demo')

    analyzer.apply_ops(env, [OwnershipOp(kind='read_resource', place=SemPlace(root='f'))], summary)

    assert ownership_messages(summary) == ['use of moved resource f']


def test_cfg_ownership_match_let_expr_converges_terminal_state() -> None:
    module = parse_module(
        '''
module demo.cfg_match_let_converges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    let u = match flag {
        true -> f.close(),
        false -> f.close(),
    };
    return u;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_match_let_expr_reports_divergent_resource_state() -> None:
    module = parse_module(
        '''
module demo.cfg_match_let_diverges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    let u = match flag {
        true -> f.close(),
        false -> unit,
    };
    let g: File = f;
    g.close();
    return u;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('CFG merge leaves resource f in different states at node' in m for m in messages)


def test_cfg_ownership_match_assign_expr_converges_terminal_state() -> None:
    module = parse_module(
        '''
module demo.cfg_match_assign_converges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    var u: Unit = unit;
    u = match flag {
        true -> f.close(),
        false -> f.close(),
    };
    return u;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_match_assign_expr_reports_divergent_resource_state() -> None:
    module = parse_module(
        '''
module demo.cfg_match_assign_diverges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    var u: Unit = unit;
    u = match flag {
        true -> f.close(),
        false -> unit,
    };
    let g: File = f;
    g.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('CFG merge leaves resource f in different states at node' in m for m in messages)


def test_cfg_ownership_nested_match_call_expr_converges_terminal_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_call_converges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn wrap(u: Unit) -> Unit effects() {
    return u;
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    let u = wrap(match flag {
        true -> make_file().close(),
        false -> make_file().close(),
    });
    return u;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_nested_match_expr_stmt_converges_terminal_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_expr_stmt_converges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn wrap(u: Unit) -> Unit effects() {
    return u;
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    wrap(match flag {
        true -> make_file().close(),
        false -> make_file().close(),
    });
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_nested_match_expr_stmt_reports_divergent_resource_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_expr_stmt_diverges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn wrap(u: Unit) -> Unit effects() {
    return u;
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    wrap(match flag {
        true -> f.close(),
        false -> unit,
    });
    let g: File = f;
    g.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('CFG merge leaves resource f in different states at node' in m for m in messages)


def test_cfg_ownership_nested_match_call_expr_reports_divergent_resource_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_call_diverges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn wrap(u: Unit) -> Unit effects() {
    return u;
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    let u = wrap(match flag {
        true -> f.close(),
        false -> unit,
    });
    let g: File = f;
    g.close();
    return u;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('CFG merge leaves resource f in different states at node' in m for m in messages)


def test_cfg_ownership_nested_match_if_condition_converges_terminal_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_if_cond_converges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn truthy(u: Unit) -> Bool effects() {
    return true;
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    if (truthy(match flag {
        true -> make_file().close(),
        false -> make_file().close(),
    })) {
        return unit;
    }
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_nested_match_if_condition_reports_divergent_resource_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_if_cond_diverges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn truthy(u: Unit) -> Bool effects() {
    return true;
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    if (truthy(match flag {
        true -> f.close(),
        false -> unit,
    })) {
        return unit;
    }
    let g: File = f;
    g.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('CFG merge leaves resource f in different states at node' in m for m in messages)


def test_cfg_ownership_nested_match_while_condition_converges_terminal_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_while_cond_converges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn truthy(u: Unit) -> Bool effects() {
    return false;
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    while (truthy(match flag {
        true -> make_file().close(),
        false -> make_file().close(),
    })) {
        break;
    }
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_nested_match_while_condition_reports_divergent_resource_state() -> None:
    module = parse_module(
        '''
module demo.cfg_nested_match_while_cond_diverges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn truthy(u: Unit) -> Bool effects() {
    return false;
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    while (truthy(match flag {
        true -> f.close(),
        false -> unit,
    })) {
        break;
    }
    let g: File = f;
    g.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('CFG merge leaves resource f in different states at node' in m for m in messages)


def test_cfg_ownership_nested_match_for_iterable_converges_terminal_state() -> None:
    module = parse_module(
        """
module demo.cfg_nested_match_for_iter_converges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn closed_str_a() -> Str effects(protocol_step) {
    let f: File = make_file();
    f.close();
    return "x";
}

fn closed_str_b() -> Str effects(protocol_step) {
    let f: File = make_file();
    f.close();
    return "x";
}

fn id_str(s: Str) -> Str effects() {
    return s;
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    for (b: U8 in id_str(match flag {
        true -> closed_str_a(),
        false -> closed_str_b(),
    })) {
        _ = b;
        break;
    }
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_nested_match_for_iterable_reports_divergent_resource_state() -> None:
    module = parse_module(
        """
module demo.cfg_nested_match_for_iter_diverges;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn close_and_str(r: Ref<File>) -> Str effects(protocol_step) {
    r.close();
    return "x";
}

fn unit_str() -> Str effects() {
    return "x";
}

fn id_str(s: Str) -> Str effects() {
    return s;
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let f: File = make_file();
    for (b: U8 in id_str(match flag {
        true -> close_and_str(borrow f),
        false -> unit_str(),
    })) {
        _ = b;
        break;
    }
    let g: File = f;
    g.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('CFG merge leaves resource f in different states at node' in m for m in messages)
    assert 'cannot move borrowed resource f while borrow is live' not in messages

def test_cfg_ownership_accepts_defer_cleanup_with_nested_match_same_referent() -> None:
    module = parse_module(
        '''
module demo.cfg_defer_nested_match_same;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn close_ref(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn main(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    defer close_ref(match flag {
        true -> borrow a,
        false -> borrow a,
    });
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_rejects_defer_cleanup_with_nested_match_divergent_referents() -> None:
    module = parse_module(
        '''
module demo.cfg_defer_nested_match_divergent;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn close_ref(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn main(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    defer close_ref(match flag {
        true -> borrow a,
        false -> borrow b,
    });
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    joined = '\n'.join(ownership_messages(summary))
    assert 'cleanup branches leave resource a in different states' in joined
    assert 'cleanup branches leave resource b in different states' in joined



def test_cfg_ownership_accepts_defer_cleanup_with_pattern_bound_bool_substitution() -> None:
    module = parse_module(
        '''
module demo.cfg_defer_pattern_bound_bool_subst;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn close_ref(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn main() -> Unit effects(protocol_step) {
    let a = make_file();
    defer close_ref(match some(true) {
        some(v) -> match v {
            true -> borrow a,
            false -> borrow a,
        },
        none -> borrow a,
    });
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_cfg_ownership_rejects_defer_cleanup_with_pattern_bound_bool_nested_match_divergence() -> None:
    module = parse_module(
        '''
module demo.cfg_defer_pattern_bound_bool_nested_divergence;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn close_ref(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn main(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    defer close_ref(match some(match flag {
        true -> true,
        false -> false,
    }) {
        some(v) -> match v {
            true -> borrow a,
            false -> borrow b,
        },
        none -> borrow a,
    });
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    joined = '\n'.join(ownership_messages(summary))
    assert 'cleanup branches leave resource a in different states' in joined
    assert 'cleanup branches leave resource b in different states' in joined

def test_imported_ref_param_rejects_nonliteral_indexed_referent_path() -> None:
    imported = {
        sig.name: sig
        for sig in [
            _sig(
                name='demo.util.close_holder',
                param_types=['Ref<Holder>'],
                ref_params=[
                    RefParamOwnershipSignature(
                        param_index=0,
                        mode='mut',
                        type_name='Holder',
                        effects={'inner': 'Closed'},
                    )
                ],
                effects=['protocol_step'],
            ),
        ]
    }
    module = parse_module(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn bad_dynamic_index(i: U64, hs: Array<Holder, 2>) -> Unit effects(protocol_step) {
    demo.util.close_holder(borrow hs[i]);
    return unit;
}
"""
    )
    summary = analyze_ownership(module, imported_signatures=imported)
    joined = '\n'.join(ownership_messages(summary))
    assert 'non-literal indexed resource path hs[*] is not supported for reference ownership summaries' in joined


def test_imported_summary_rejects_wildcard_index_effect_path() -> None:
    imported = {
        sig.name: sig
        for sig in [
            _sig(
                name='demo.util.close_any',
                param_types=['Ref<Array<Holder, 2>>'],
                ref_params=[
                    RefParamOwnershipSignature(
                        param_index=0,
                        mode='mut',
                        type_name='Array<Holder, 2>',
                        effects={'[*].inner': 'Closed'},
                    )
                ],
                effects=['protocol_step'],
            ),
        ]
    }
    module = parse_module(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn bad_wildcard_summary(hs: Array<Holder, 2>) -> Unit effects(protocol_step) {
    demo.util.close_any(borrow hs);
    return unit;
}
"""
    )
    summary = analyze_ownership(module, imported_signatures=imported)
    joined = '\n'.join(ownership_messages(summary))
    assert "imported/reference ownership summary for demo.util.close_any uses unsupported non-literal indexed path(s): [*].inner" in joined


def test_array_nested_merge_diagnostics_are_context_only_root_first() -> None:
    imported = {
        sig.name: sig
        for sig in [
            _sig(
                name='demo.util.close_first',
                param_types=['Ref<Array<Holder, 2>>'],
                ref_params=[
                    RefParamOwnershipSignature(
                        param_index=0,
                        mode='mut',
                        type_name='Array<Holder, 2>',
                        effects={'0.inner': 'Closed'},
                    )
                ],
                effects=['protocol_step'],
            ),
        ]
    }
    module = parse_module(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn diverge(flag: Bool, hs: Array<Holder, 2>) -> Unit effects(protocol_step) {
    if (flag) {
        demo.util.close_first(borrow hs);
    } else {
    }
    return unit;
}
"""
    )
    summary = analyze_ownership(module, imported_signatures=imported)
    messages = ownership_messages(summary)
    root = [m for m in messages if 'if branches leave resource hs in different states' in m]
    nested = [m for m in messages if 'if branches leave resource hs[0].inner in different states' in m]
    assert len(root) == 1
    assert len(nested) == 1
    assert messages.index(root[0]) < messages.index(nested[0])
    assert 'hs[1]' not in '\n'.join(messages)


def test_array_nested_merge_diagnostics_do_not_replace_root_resource_decision() -> None:
    imported = {
        sig.name: sig
        for sig in [
            _sig(
                name='demo.util.close_first',
                param_types=['Ref<Array<Holder, 2>>'],
                ref_params=[
                    RefParamOwnershipSignature(
                        param_index=0,
                        mode='mut',
                        type_name='Array<Holder, 2>',
                        effects={'0.inner': 'Closed'},
                    )
                ],
                effects=['protocol_step'],
            ),
        ]
    }
    module = parse_module(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn diverge(flag: Bool, hs: Array<Holder, 2>) -> Unit effects(protocol_step) {
    if (flag) {
        demo.util.close_first(borrow hs);
    } else {
    }
    return unit;
}
"""
    )
    summary = analyze_ownership(module, imported_signatures=imported)
    messages = ownership_messages(summary)
    assert sum('if branches leave resource hs in different states' in m for m in messages) == 1
    assert sum('if branches leave resource hs[0].inner in different states' in m for m in messages) == 1
    assert len(messages) == len(set(messages))


def test_imported_dynamic_index_boundary_still_rejects_before_nested_merge_context() -> None:
    imported = {
        sig.name: sig
        for sig in [
            _sig(
                name='demo.util.close_holder',
                param_types=['Ref<Holder>'],
                ref_params=[
                    RefParamOwnershipSignature(
                        param_index=0,
                        mode='mut',
                        type_name='Holder',
                        effects={'inner': 'Closed'},
                    )
                ],
                effects=['protocol_step'],
            ),
        ]
    }
    module = parse_module(
        """
module demo.main;
import demo.util;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields { fd: I32; }
}

struct Holder { inner: File; }

fn bad_dynamic_index(flag: Bool, i: U64, hs: Array<Holder, 2>) -> Unit effects(protocol_step) {
    if (flag) {
        demo.util.close_holder(borrow hs[i]);
    } else {
    }
    return unit;
}
"""
    )
    summary = analyze_ownership(module, imported_signatures=imported)
    joined = '\n'.join(ownership_messages(summary))
    assert 'non-literal indexed resource path hs[*] is not supported for reference ownership summaries' in joined
    assert 'hs[0].inner' not in joined
