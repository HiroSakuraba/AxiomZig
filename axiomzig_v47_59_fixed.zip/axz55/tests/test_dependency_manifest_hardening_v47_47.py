from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main

COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _build_dependency_manifest(dep_root: Path, capsys) -> Path:
    dep_file = _write(
        dep_root / 'dep' / 'api.az',
        f'''module dep.api;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    out = dep_root / 'dep_manifest.json'
    rc = main(['conform', str(dep_file), '--module-root', str(dep_root), '--public-only', '--out', str(out)])
    capsys.readouterr()
    assert rc == 0
    return out


def test_duplicate_dependency_manifests_are_rejected(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.api;\nfn run() -> Unit effects() { return unit; }\n',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
        '--dependency-manifest',
        str(dep_manifest),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'dependency module dep.api provided by multiple manifests' in captured.err


def test_conflicting_dependency_manifest_and_import_bundle_are_rejected(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    conflict_bundle = _write(
        tmp_path / 'conflict_bundle.json',
        json.dumps(
            {
                'module_path': 'dep.api',
                'functions': [
                    {
                        'name': 'dep.api.close_inner',
                        'param_types': ['Ref<Holder>'],
                        'return_type': 'Unit',
                        'effects': ['protocol_step'],
                        'ref_params': [
                            {
                                'param_index': 0,
                                'mode': 'mut',
                                'type_name': 'Holder',
                                'effects': {'other': 'moved'},
                            }
                        ],
                    }
                ],
            }
        ),
    )
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        f'''module app.main;
import dep.api;
{COMMON}
fn run() -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    dep.api.close_inner(borrow h);
    return unit;
}}
''',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
        '--import-ownership',
        str(conflict_bundle),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'conflicting ownership summaries for imported function dep.api.close_inner' in captured.err


def test_static_cli_commands_consume_dependency_manifests_without_dependency_source(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        f'''module app.main;
import dep.api;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ dep.api.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )
    commands = ['check', 'typecheck', 'cfg', 'owncheck', 'ownsig', 'conform']

    for command in commands:
        argv = [command, str(main_file), '--module-root', str(consumer_root), '--dependency-manifest', str(dep_manifest)]
        rc = main(argv)
        captured = capsys.readouterr()
        assert rc == 0, (command, captured.out, captured.err)
        assert captured.err.strip() == '', command
        if command == 'check':
            assert captured.out.strip() == ''
        else:
            payload = json.loads(captured.out)
            assert isinstance(payload, dict)
            if command == 'owncheck':
                assert payload['issues'] == []
            if command == 'conform':
                assert payload['dependency_modules'] == ['dep.api']


def test_interpret_uses_dependency_manifest_for_static_contract_and_stub_for_runtime(tmp_path: Path, capsys) -> None:
    dep_root = tmp_path / 'dep_workspace'
    dep_file = _write(
        dep_root / 'dep' / 'api.az',
        'module dep.api;\nfn add1(x: I32) -> I32 effects() { return x + 1; }\n',
    )
    dep_manifest = dep_root / 'dep_manifest.json'
    rc_dep = main(['conform', str(dep_file), '--module-root', str(dep_root), '--public-only', '--out', str(dep_manifest)])
    capsys.readouterr()
    assert rc_dep == 0

    consumer = _write(
        tmp_path / 'main.az',
        'module app.main;\nimport dep.api;\nfn main() -> I32 effects() { return dep.api.add1(41); }\n',
    )
    stubs = _write(
        tmp_path / 'stubs.json',
        json.dumps({'functions': [{'name': 'dep.api.add1', 'return_value': {'int': 42}}]}),
    )

    rc = main([
        'interpret',
        str(consumer),
        '--dependency-manifest',
        str(dep_manifest),
        '--import-stubs',
        str(stubs),
    ])
    captured = capsys.readouterr()

    assert rc == 0
    assert captured.err.strip() == ''
    assert captured.out.strip() == '42'
