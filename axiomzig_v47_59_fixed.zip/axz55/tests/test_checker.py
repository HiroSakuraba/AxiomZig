from axiomzig.checker import check_module
from axiomzig.parser import parse_module


def test_check_module_deduplicates_repeated_semantic_errors() -> None:
    module = parse_module(
        """
module demo.dup;

fn bad() -> Unit effects() {
    let x: Bool = 1;
    return unit;
}
"""
    )
    issues = check_module(module)
    messages = [issue.message for issue in issues if issue.level == "error"]
    assert messages.count("let x annotated as Bool but got I64") == 1


def test_check_module_reports_incompatible_match_arm_types() -> None:
    module = parse_module(
        """
module demo.badmatchtypes;

fn bad(x: Bool) -> I64 effects() {
    return match x {
        true -> 1,
        false -> false,
    };
}
"""
    )
    issues = check_module(module)
    messages = [issue.message for issue in issues if issue.level == "error"]
    assert "match arms have incompatible types" in messages


def test_check_module_rejects_trap_effect_declaration() -> None:
    module = parse_module(
        """
module demo.trapfx;

fn bad() -> Unit effects(trap) {
    return unit;
}
"""
    )
    issues = check_module(module)
    messages = [issue.message for issue in issues if issue.level == "error"]
    assert "function bad may not declare builtin effect trap" in messages



def test_check_module_requires_recurse_effect_for_direct_recursion() -> None:
    module = parse_module(
        """
module demo.recurse_direct;

fn loop(n: I64) -> I64 effects() {
    return loop(n);
}
"""
    )
    issues = check_module(module)
    messages = [issue.message for issue in issues if issue.level == "error"]
    assert "function loop must declare effect recurse" in messages


def test_check_module_requires_recurse_effect_for_mutual_recursion() -> None:
    module = parse_module(
        """
module demo.recurse_mutual;

fn even(n: I64) -> I64 effects() {
    return odd(n);
}

fn odd(n: I64) -> I64 effects(recurse) {
    return even(n);
}
"""
    )
    issues = check_module(module)
    messages = [issue.message for issue in issues if issue.level == "error"]
    assert "function even must declare effect recurse" in messages
    assert "function odd must declare effect recurse" not in messages


def test_check_module_accepts_recursive_function_with_recurse_effect() -> None:
    module = parse_module(
        """
module demo.recurse_ok;

fn loop(n: I64) -> I64 effects(recurse) {
    return loop(n);
}
"""
    )
    issues = check_module(module)
    messages = [issue.message for issue in issues if issue.level == "error"]
    assert "function loop must declare effect recurse" not in messages


def test_check_module_allows_discard_sink_assignment() -> None:
    module = parse_module(
        """
module demo.check_discard;

fn f() -> I64 effects() {
    return 1;
}

fn good() -> Unit effects() {
    _ = f();
    return unit;
}
"""
    )
    issues = check_module(module)
    messages = [issue.message for issue in issues if issue.level == "error"]
    assert "assignment target _ is not mutable" not in messages
    assert messages == []
