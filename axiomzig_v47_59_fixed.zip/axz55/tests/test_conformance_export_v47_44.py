from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main


COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _write_stale_close_inner_bundle(path: Path, *, state_path: str = 'other') -> Path:
    path.write_text(
        json.dumps(
            {
                'module_path': 'demo.util',
                'functions': [
                    {
                        'name': 'demo.util.close_inner',
                        'param_types': ['Ref<Holder>'],
                        'return_type': 'Unit',
                        'effects': ['protocol_step'],
                        'ref_params': [
                            {
                                'param_index': 0,
                                'mode': 'mut',
                                'type_name': 'Holder',
                                'effects': {state_path: 'Closed'},
                            }
                        ],
                    }
                ],
            }
        ),
        encoding='utf-8',
    )
    return path


def test_conform_exports_workspace_manifest_with_canonical_paths(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        f'''module demo.util;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        f'''module demo.main;
import demo.util;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ demo.util.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )
    out = tmp_path / 'manifest.json'

    rc = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out)])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err.strip() == ''
    assert manifest['status'] == 'ok'
    assert manifest['entry_module'] == 'demo.main'
    assert manifest['reachable_modules'] == ['demo.main', 'demo.util']
    close_inner = manifest['internal_signatures']['demo.util']['functions'][0]
    assert close_inner['name'] == 'demo.util.close_inner'
    assert close_inner['ref_effects'][0]['display_path'] == 'inner'
    assert close_inner['ref_effects'][0]['canonical_path'] == [{'kind': 'field', 'value': 'inner'}]


def test_conform_manifest_is_deterministic_across_runs(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\nfn helper() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { return unit; }\n',
    )
    out1 = tmp_path / 'manifest1.json'
    out2 = tmp_path / 'manifest2.json'

    rc1 = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out1)])
    capsys.readouterr()
    rc2 = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out2)])
    capsys.readouterr()

    assert rc1 == 0
    assert rc2 == 0
    assert out1.read_text(encoding='utf-8') == out2.read_text(encoding='utf-8')


def test_conform_preserves_unresolved_external_as_opaque_manifest_boundary(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport vendor.crypto;\nfn run() -> Unit effects() { return unit; }\n',
    )
    out = tmp_path / 'manifest.json'

    rc = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out)])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err.strip() == ''
    assert manifest['external_imports'] == [
        {
            'has_contract': False,
            'imported_by': ['demo.main'],
            'kind': 'opaque_external',
            'name': 'vendor.crypto',
        }
    ]


def test_conform_failure_writes_error_manifest_and_exits_nonzero(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        f'''module demo.util;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        f'''module demo.main;
import demo.util;
{COMMON}
fn run() -> Unit effects() {{ return unit; }}
''',
    )
    stale = _write_stale_close_inner_bundle(tmp_path / 'stale_import_ownership.json')
    out = tmp_path / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--import-ownership',
        str(stale),
        '--out',
        str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 1
    assert 'conformance error: ownership summary conflict for demo.util.close_inner' in captured.err
    assert manifest['status'] == 'error'
    assert any(item['code'] == 'E_MODULE_SUMMARY_CONFLICT' for item in manifest['diagnostics'])
