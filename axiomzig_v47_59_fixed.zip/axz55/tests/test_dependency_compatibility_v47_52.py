from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _build_dep_publication_manifest(
    dep_root: Path,
    capsys,
    *,
    package_name: str = 'dep',
    package_version: str = '1.2.3',
    module_name: str = 'dep.api',
    function_name: str = 'ping',
) -> Path:
    dep_file = _write(
        dep_root / Path(*module_name.split('.')).with_suffix('.az'),
        f'module {module_name};\nfn {function_name}() -> Unit effects() {{ return unit; }}\n',
    )
    publication_out = dep_root / f'{package_name}_{package_version.replace(".", "_")}_pub.json'
    rc = main([
        'conform',
        str(dep_file),
        '--module-root', str(dep_root),
        '--package-name', package_name,
        '--package-version', package_version,
        '--public-only',
        '--publication-out', str(publication_out),
        '--out', str(dep_root / f'{package_name}_{package_version.replace(".", "_")}_full.json'),
    ])
    assert rc == 0
    capsys.readouterr()
    return publication_out


def test_conform_accepts_pinned_dependency_versions_within_declared_range(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dep_publication_manifest(tmp_path / 'dep_pkg', capsys, package_version='1.2.3')
    app_root = tmp_path / 'app'
    main_file = _write(app_root / 'app' / 'main.az', 'module app.main;\nfn run() -> Unit effects() { return unit; }\n')
    package_interface = _write(
        app_root / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'package_name': 'app',
                'package_version': '0.1.0',
                'public_modules': ['app.main'],
                'compatibility': {
                    'dependency_version_ranges': {'dep': '^1.2'}
                },
            },
            indent=2,
        ),
    )
    out = app_root / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(app_root),
        '--package-interface', str(package_interface),
        '--dependency-manifest', str(dep_manifest),
        '--out', str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err.strip() == ''
    assert manifest['status'] == 'ok'
    assert manifest['api_compatibility']['dependency_version_ranges'] == {'dep': '^1.2'}



def test_conform_rejects_pinned_dependency_version_outside_declared_range(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dep_publication_manifest(tmp_path / 'dep_pkg', capsys, package_version='2.0.0')
    app_root = tmp_path / 'app'
    main_file = _write(app_root / 'app' / 'main.az', 'module app.main;\nfn run() -> Unit effects() { return unit; }\n')
    package_interface = _write(
        app_root / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['app.main'],
                'compatibility': {
                    'dependency_version_ranges': {'dep': '^1.2'}
                },
            },
            indent=2,
        ),
    )
    out = app_root / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(app_root),
        '--package-interface', str(package_interface),
        '--dependency-manifest', str(dep_manifest),
        '--out', str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 1
    assert manifest['status'] == 'error'
    assert any(item['code'] == 'E_DEP_VERSION_RANGE_MISMATCH' for item in manifest['diagnostics'])
    assert 'dep version ^1.2' in captured.err
    assert 'dep@2.0.0' in captured.err



def test_conform_rejects_missing_declared_dependency_from_pinned_set(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dep_publication_manifest(tmp_path / 'dep_pkg', capsys, package_version='1.2.3')
    app_root = tmp_path / 'app'
    main_file = _write(app_root / 'app' / 'main.az', 'module app.main;\nfn run() -> Unit effects() { return unit; }\n')
    package_interface = _write(
        app_root / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['app.main'],
                'compatibility': {
                    'dependency_version_ranges': {'dep': '^1.2', 'other': '^1.0'}
                },
            },
            indent=2,
        ),
    )
    out = app_root / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(app_root),
        '--package-interface', str(package_interface),
        '--dependency-manifest', str(dep_manifest),
        '--out', str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 1
    assert manifest['status'] == 'error'
    assert any(item['code'] == 'E_DEP_VERSION_RANGE_MISSING' for item in manifest['diagnostics'])
    assert 'other' in captured.err
    assert 'no pinned dependency with that package name was provided' in captured.err



def test_conform_rejects_ambiguous_pinned_dependency_versions_for_one_package_name(tmp_path: Path, capsys) -> None:
    dep_v1 = _build_dep_publication_manifest(
        tmp_path / 'dep_pkg_v1',
        capsys,
        package_name='dep',
        package_version='1.2.3',
        module_name='dep.api',
        function_name='ping_one',
    )
    dep_v2 = _build_dep_publication_manifest(
        tmp_path / 'dep_pkg_v2',
        capsys,
        package_name='dep',
        package_version='2.0.0',
        module_name='dep.extra',
        function_name='ping_two',
    )
    app_root = tmp_path / 'app'
    main_file = _write(app_root / 'app' / 'main.az', 'module app.main;\nfn run() -> Unit effects() { return unit; }\n')
    package_interface = _write(
        app_root / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['app.main'],
                'compatibility': {
                    'dependency_version_ranges': {'dep': '^1.2'}
                },
            },
            indent=2,
        ),
    )
    out = app_root / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(app_root),
        '--package-interface', str(package_interface),
        '--dependency-manifest', str(dep_v1),
        '--dependency-manifest', str(dep_v2),
        '--out', str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 1
    assert manifest['status'] == 'error'
    assert any(item['code'] == 'E_DEP_VERSION_RANGE_AMBIGUOUS' for item in manifest['diagnostics'])
    assert 'ambiguous' in captured.err
    assert 'dep@1.2.3' in captured.err
    assert 'dep@2.0.0' in captured.err
