from __future__ import annotations

import random

from axiomzig.formatter import format_module
from axiomzig.lexer import lex
from axiomzig.parser import parse_module


EXPR_LIBRARY = [
    '0',
    '1',
    'x',
    'helper(x, 1)',
    'helper(@cast(I64, 2), x)',
    'Pair { left: 1, right: 2 }.left',
    'Choice.Second { value: x }.value',
    'match flag { true -> x, false -> 0, }',
    'match opt { some(v) -> v, none -> x, }',
    'xs[0]',
    'helper_result(x)?',
]


STATEMENT_TEMPLATES = [
    'helper(x, 0);',
    'defer helper(x, 0);',
    'errdefer helper(0, 0);',
    'if (flag) { helper(x, 1); } else { helper(0, x); }',
    'while (flag) { break; }',
    'for (i: I64 in 0..3) { helper(i, x); }',
    '{ let scoped = helper(x, 0); helper(scoped, 0); }',
    'let tmp___N__: I64 = __EXPR__;',
    'var tmp___N__: I64 = __EXPR__;',
    'let alt___N__ = match flag { true -> __EXPR__, false -> x, };',
]


TRIVIA_CHOICES = [
    ' ',
    '\n',
    '\n\n',
    '\t',
    ' \t ',
    '\n// fuzz\n',
]


MODULE_TEMPLATE = """
module fuzz.valid_{seed};

struct Pair {
    left: I64;
    right: I64;
}

enum Choice {
    First;
    Second {
        value: I64;
    };
}

error_set ParseError {
    Empty;
}

fn helper(x: I64, y: I64) -> I64 effects() {
    return x + y;
}

fn helper_result(x: I64) -> I64!ParseError effects(error) {
    return x;
}

fn main(flag: Bool, x: I64, xs: Slice<I64>, opt: Option<I64>) -> I64!ParseError effects(error) {
__BODY__
}
""".lstrip()


def render_token_value(tok) -> str:
    if tok.kind == 'STRING':
        value = tok.value
        value = value.replace('\\', '\\\\')
        value = value.replace('"', '\\"')
        value = value.replace('\n', '\\n')
        value = value.replace('\t', '\\t')
        value = value.replace('\r', '\\r')
        value = value.replace('\x00', '\\0')
        return f'"{value}"'
    return tok.value


def render_with_random_trivia(source: str, seed: int) -> str:
    rng = random.Random(seed)
    token_values = [render_token_value(tok) for tok in lex(source) if tok.kind != 'EOF']
    if not token_values:
        return '\n'
    pieces: list[str] = [token_values[0]]
    for value in token_values[1:]:
        pieces.append(rng.choice(TRIVIA_CHOICES))
        pieces.append(value)
    pieces.append('\n')
    return ''.join(pieces)


def generate_statement(rng: random.Random, n: int) -> str:
    template = rng.choice(STATEMENT_TEMPLATES)
    return template.replace('__N__', str(n)).replace('__EXPR__', rng.choice(EXPR_LIBRARY))


def generate_valid_module(seed: int) -> str:
    rng = random.Random(seed)
    stmt_count = rng.randint(4, 9)
    body = [generate_statement(rng, i) for i in range(stmt_count)]
    body.append(f'    return {rng.choice(EXPR_LIBRARY)};')
    indented = '\n'.join(f'    {stmt}' for stmt in body[:-1]) + '\n' + body[-1]
    return MODULE_TEMPLATE.replace('{seed}', str(seed)).replace('__BODY__', indented)


def generated_modules() -> list[str]:
    return [generate_valid_module(seed) for seed in range(40)]


def test_generated_valid_structure_modules_parse_and_format() -> None:
    for source in generated_modules():
        module = parse_module(source)
        formatted1 = format_module(module)
        formatted2 = format_module(parse_module(formatted1))
        assert formatted1 == formatted2


def test_generated_valid_structure_modules_canonicalize_under_trivia_perturbation() -> None:
    for source_index, source in enumerate(generated_modules()):
        canonical = format_module(parse_module(source))
        for variant_index in range(5):
            perturbed = render_with_random_trivia(source, seed=0xC0DE000 + source_index * 100 + variant_index)
            reformatted = format_module(parse_module(perturbed))
            assert reformatted == canonical


def test_generated_valid_structure_modules_keep_try_alias_canonicalized() -> None:
    saw_postfix = False
    for source in generated_modules():
        canonical = format_module(parse_module(source))
        if 'helper_result(x)?' in canonical:
            saw_postfix = True
        assert 'try helper_result(x)' not in canonical
    assert saw_postfix
