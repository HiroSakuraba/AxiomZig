from pathlib import Path

from axiomzig.checker import check_module
from axiomzig.formatter import format_module
from axiomzig.parser import parse_module


EXAMPLES = [
    Path("examples/demo_math.az"),
    Path("examples/demo_parse.az"),
    Path("examples/demo_file.az"),
    Path("examples/demo_option.az"),
]


def test_examples_parse_and_roundtrip() -> None:
    for path in EXAMPLES:
        text = path.read_text(encoding="utf-8")
        module = parse_module(text)
        formatted = format_module(module)
        module2 = parse_module(formatted)
        formatted2 = format_module(module2)
        assert formatted == formatted2, path.name


def test_examples_are_structurally_clean() -> None:
    for path in EXAMPLES:
        module = parse_module(path.read_text(encoding="utf-8"))
        issues = check_module(module)
        assert [issue for issue in issues if issue.level == "error"] == [], path.name


def test_try_alias_canonicalizes_to_postfix_question() -> None:
    module = parse_module(
        """
module demo.tryalias;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8!ParseError effects(error) {
    let x: U8 = try parse_one(s);
    return x;
}
"""
    )
    formatted = format_module(module)
    assert 'try parse_one(s)' not in formatted
    assert 'parse_one(s)?' in formatted


def test_catch_expression_roundtrip_is_stable() -> None:
    module = parse_module(
        """
module demo.catchfmt;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8 effects(error) {
    return parse_one(s) catch 0;
}
"""
    )
    formatted = format_module(module)
    module2 = parse_module(formatted)
    formatted2 = format_module(module2)
    assert formatted == formatted2
    assert "parse_one(s) catch 0" in formatted
