from axiomzig.ownership import analyze_ownership
from axiomzig.parser import parse_module


def ownership_messages(summary):
    return [issue.message for issue in summary.issues]


def test_borrow_region_rejects_move_while_borrow_is_live() -> None:
    module = parse_module(
        '''
module demo.borrow_live_move;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad() -> Unit effects(protocol_step) {
    let f = make_file();
    let rf: RefConst<File> = borrow f;
    let g: File = move f;
    g.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot move borrowed resource f while borrow is live' in messages


def test_borrow_region_rejects_parent_move_when_child_borrow_is_live() -> None:
    module = parse_module(
        '''
module demo.borrow_live_parent_move;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn bad() -> Unit effects(protocol_step) {
    let h = make_holder();
    let r: RefConst<File> = borrow h.inner;
    let moved: Holder = move h;
    moved.inner.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot move borrowed resource h while borrow is live' in messages


def test_borrow_region_ends_before_deferred_cleanup_replay() -> None:
    module = parse_module(
        '''
module demo.borrow_defer_cleanup;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn clean() -> Unit effects(protocol_step) {
    let f = make_file();
    let rf: RefConst<File> = borrow f;
    defer f.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_typecheck_accepts_mutable_borrow_for_ref_parameter() -> None:
    from axiomzig.typecheck import typecheck_module

    module = parse_module(
        '''
module demo.borrow_mut_typecheck;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn touch(f: Ref<File>) -> Unit effects() {
    return unit;
}

fn good() -> Unit effects() {
    let f = make_file();
    touch(borrow f);
    return unit;
}
'''
    )
    summary = typecheck_module(module)
    assert [issue.message for issue in summary.issues] == []


def test_mutable_borrow_rejects_overlapping_immutable_borrow() -> None:
    module = parse_module(
        '''
module demo.borrow_mut_vs_const;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad() -> Unit effects() {
    let f = make_file();
    let m: Ref<File> = borrow f;
    let c: RefConst<File> = borrow f;
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot immutably borrow resource f while mutable borrow is live' in messages


def test_branch_scoped_borrows_do_not_escape_join() -> None:
    module = parse_module(
        '''
module demo.borrow_join_scopes;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    let f = make_file();
    if (flag) {
        let m: Ref<File> = borrow f;
    } else {
        let c: RefConst<File> = borrow f;
    }
    f.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_mutable_borrow_alias_transition_updates_underlying_resource() -> None:
    module = parse_module(
        '''
module demo.borrow_alias_transition;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn good() -> Unit effects(protocol_step) {
    let f = make_file();
    let m: Ref<File> = borrow f;
    m.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_mutable_borrow_alias_nested_transition_updates_underlying_resource() -> None:
    module = parse_module(
        '''
module demo.borrow_alias_nested_transition;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn good() -> Unit effects(protocol_step) {
    let h = make_holder();
    let m: Ref<Holder> = borrow h;
    m.inner.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_mutable_borrow_alias_allows_reinitialization_through_reference() -> None:
    module = parse_module(
        '''
module demo.borrow_alias_reinit;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn good() -> Unit effects(protocol_step) {
    let h = make_holder();
    let m: Ref<Holder> = borrow h;
    m.inner.close();
    m.inner = make_file();
    m.inner.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_mutable_borrow_rebind_ends_old_borrow_region() -> None:
    module = parse_module(
        """
module demo.borrow_rebind_end_old;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn good() -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var m: Ref<File> = borrow a;
    m = borrow b;
    a.close();
    m.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_alias_rooted_move_reports_underlying_referent_path() -> None:
    module = parse_module(
        """
module demo.borrow_alias_move;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn bad() -> Unit effects(protocol_step) {
    let h = make_holder();
    let m: Ref<Holder> = borrow h;
    let taken: File = move m.inner;
    taken.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot move borrowed resource h.inner while borrow is live' in messages


def test_alias_join_with_divergent_referents_is_rejected() -> None:
    module = parse_module(
        """
module demo.borrow_alias_join_ambiguous;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var m: Ref<File> = borrow a;
    if (flag) {
        m = borrow b;
    }
    m.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('reference alias m does not have a live unique referent' in msg for msg in messages)

def test_interprocedural_mutable_ref_transition_updates_caller_state() -> None:
    module = parse_module(
        """
module demo.borrow_interproc_transition;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn touch(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn good() -> Unit effects(protocol_step) {
    let f = make_file();
    touch(borrow f);
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_interprocedural_ref_summary_composes_across_nested_calls() -> None:
    module = parse_module(
        """
module demo.borrow_interproc_nested;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn inner(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn outer(f: Ref<File>) -> Unit effects(protocol_step) {
    inner(borrow f);
    return unit;
}

fn good() -> Unit effects(protocol_step) {
    let f = make_file();
    outer(borrow f);
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_interprocedural_ref_holder_reinit_inner_updates_caller_state() -> None:
    module = parse_module(
        """
module demo.borrow_interproc_holder_reinit;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn reset_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    h.inner = File { fd: 1 };
    h.inner.close();
    return unit;
}

fn good() -> Unit effects(protocol_step) {
    let h = make_holder();
    reset_inner(borrow h);
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_interprocedural_ref_summary_records_relative_field_effects() -> None:
    module = parse_module(
        """
module demo.borrow_interproc_holder_summary;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    fn = next(item for item in summary.functions if item.name == 'close_inner')
    assert fn.ref_param_effects == {'h': {'inner': 'Closed'}}


def test_rebinding_one_of_two_const_aliases_keeps_other_borrow_live() -> None:
    module = parse_module(
        """
module demo.borrow_alias_refcount;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad() -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var r1: RefConst<File> = borrow a;
    let r2: RefConst<File> = borrow a;
    r1 = borrow b;
    let m: Ref<File> = borrow a;
    m.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot mutably borrow resource a while borrow is live' in messages


def test_const_ref_alias_copy_preserves_borrow_after_rebinding_original() -> None:
    module = parse_module(
        """
module demo.borrow_alias_copy;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad() -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var r1: RefConst<File> = borrow a;
    let r2: RefConst<File> = r1;
    r1 = borrow b;
    let m: Ref<File> = borrow a;
    m.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot mutably borrow resource a while borrow is live' in messages


def test_mut_ref_alias_transfer_invalidates_source_alias() -> None:
    module = parse_module(
        """
module demo.borrow_alias_transfer;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad() -> Unit effects(protocol_step) {
    let a = make_file();
    var m1: Ref<File> = borrow a;
    let m2: Ref<File> = m1;
    m2.close();
    m1.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot read resource a while mutable borrow is live' not in messages
    assert any('reference alias m1 does not have a live unique referent' in msg for msg in messages)


def test_mut_ref_alias_rebind_assignment_uses_new_alias_referent() -> None:
    module = parse_module(
        """
module demo.borrow_alias_rebind;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad() -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var m1: Ref<File> = borrow a;
    var m2: Ref<File> = borrow b;
    m1 = m2;
    m1.close();
    m2.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot read resource b while mutable borrow is live' not in messages
    assert any('reference alias m2 does not have a live unique referent' in msg for msg in messages)



def test_alias_rooted_ref_call_conflict_uses_ownership_alias_model() -> None:
    module = parse_module(
        """
module demo.borrow_alias_call_conflict;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn close_both(h: Ref<Holder>, f: Ref<File>) -> Unit effects(protocol_step) {
    h.inner.close();
    f.close();
    return unit;
}

fn bad() -> Unit effects(protocol_step) {
    let h = Holder { inner: File { fd: 0 } };
    let m: Ref<Holder> = borrow h;
    close_both(m, m.inner);
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'call to close_both passes overlapping references h and h.inner to incompatible ref parameters 1 and 2' in messages

def test_alias_join_reports_merge_diagnostic_before_use() -> None:
    module = parse_module(
        """
module demo.borrow_alias_join_diag;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var m: Ref<File> = borrow a;
    if (flag) {
        m = borrow b;
    }
    m.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'if branches leave reference alias m without a unique referent' in '\n'.join(messages)
    assert any('reference alias m does not have a live unique referent' in msg for msg in messages)


def test_interprocedural_alias_join_uses_merged_alias_model() -> None:
    module = parse_module(
        """
module demo.borrow_alias_join_interproc;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn touch(f: Ref<File>) -> Unit effects(protocol_step) {
    f.close();
    return unit;
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var m: Ref<File> = borrow a;
    if (flag) {
        m = borrow b;
    }
    touch(m);
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    joined = '\n'.join(messages)
    assert 'if branches leave reference alias m without a unique referent' in joined
    assert messages.count('mutable reference alias m does not have a live unique referent') == 1

def test_alias_join_move_uses_merged_alias_model() -> None:
    module = parse_module(
        """
module demo.borrow_alias_join_move;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: make_file() };
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_holder();
    let b = make_holder();
    var m: Ref<Holder> = borrow a;
    if (flag) {
        m = borrow b;
    }
    let stolen: File = move m.inner;
    a.inner.close();
    b.inner.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    joined = '\n'.join(messages)
    assert 'if branches leave reference alias m without a unique referent' in joined
    assert any('reference alias m does not have a live unique referent' in msg for msg in messages)


def test_alias_join_nested_borrow_uses_merged_alias_model() -> None:
    module = parse_module(
        """
module demo.borrow_alias_join_nested_borrow;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: make_file() };
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_holder();
    let b = make_holder();
    var m: Ref<Holder> = borrow a;
    if (flag) {
        m = borrow b;
    }
    let c: RefConst<File> = borrow m.inner;
    a.inner.close();
    b.inner.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    joined = '\n'.join(messages)
    assert 'if branches leave reference alias m without a unique referent' in joined
    assert any('reference alias m does not have a live unique referent' in msg for msg in messages)




def test_nested_match_alias_rebind_same_referent_converges() -> None:
    module = parse_module(
        """
module demo.nested_match_alias_rebind_same;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn good(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    var m: Ref<File> = borrow a;
    m = match flag {
        true -> borrow a,
        false -> borrow a,
    };
    m.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_nested_match_alias_rebind_divergent_referents_reports_alias_merge() -> None:
    module = parse_module(
        """
module demo.nested_match_alias_rebind_divergent;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad(flag: Bool) -> Unit effects(protocol_step) {
    let a = make_file();
    let b = make_file();
    var m: Ref<File> = borrow a;
    m = match flag {
        true -> borrow a,
        false -> borrow b,
    };
    m.close();
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    joined = '\n'.join(ownership_messages(summary))
    assert 'CFG merge leaves reference alias m without a unique referent at node' in joined
    assert 'mutable reference alias m does not have a live unique referent' in joined
def test_alias_rooted_reinitialization_target_resolves_in_ownership_state() -> None:
    module = parse_module(
        '''
module demo.alias_target_reinit;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn good() -> Unit effects(protocol_step) {
    let h = make_holder();
    var r: Ref<Holder> = borrow h;
    r.inner.close();
    let replacement = make_file();
    r.inner = move replacement;
    r.inner.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert ownership_messages(summary) == []


def test_alias_rooted_assignment_target_rejects_live_replacement() -> None:
    module = parse_module(
        '''
module demo.alias_target_live_assignment;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn bad() -> Unit effects(protocol_step) {
    let h = make_holder();
    var r: Ref<Holder> = borrow h;
    let replacement = make_file();
    r.inner = move replacement;
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'cannot assign to resource h.inner while it is in non-terminal state Open' in messages


def test_const_ref_param_method_transition_is_rejected() -> None:
    module = parse_module(
        '''
module demo.const_ref_param_transition;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn bad(c: RefConst<File>) -> Unit effects(protocol_step) {
    c.close();
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert 'mutable reference alias c does not have a live unique referent' in messages





def test_mutable_reborrow_through_refconst_alias_is_rejected() -> None:
    module = parse_module(
        """
module demo.reborrow_mut_refconst_alias;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn bad(c: RefConst<Holder>) -> Unit effects() {
    let m: Ref<File> = borrow c.inner;
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('mutable reference alias c does not have a live unique referent' in msg for msg in messages)


def test_mutable_rebind_borrow_through_refconst_alias_is_rejected() -> None:
    module = parse_module(
        """
module demo.rebind_mut_refconst_alias;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn bad() -> Unit effects() {
    let h1 = make_holder();
    let h2 = make_holder();
    var m: Ref<File> = borrow h1.inner;
    let c: RefConst<Holder> = borrow h2;
    m = borrow c.inner;
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('mutable reference alias c does not have a live unique referent' in msg for msg in messages)

def test_move_through_refconst_alias_is_rejected() -> None:
    module = parse_module(
        """
module demo.borrow_move_refconst;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn bad(c: RefConst<Holder>) -> Unit effects() {
    let taken: File = move c.inner;
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('mutable reference alias c does not have a live unique referent' in msg for msg in messages)


def test_bind_from_const_alias_source_is_rejected() -> None:
    module = parse_module(
        """
module demo.bind_alias_const_source;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn bad() -> Unit effects() {
    let h = make_holder();
    let c: RefConst<Holder> = borrow h;
    let taken: File = c.inner;
    return unit;
}
"""
    )
    summary = analyze_ownership(module)
    messages = ownership_messages(summary)
    assert any('mutable reference alias c does not have a live unique referent' in msg for msg in messages)
