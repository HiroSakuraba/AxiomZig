from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main
from axiomzig.ownership_signatures import dependency_lock_digest


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def test_package_interface_metadata_flows_into_conformance_and_publication_manifests(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\n'
        'fn run() -> Unit effects() { return unit; }\n'
        'fn old_run() -> Unit effects() { return unit; }\n',
    )
    package_interface = _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'package_name': 'demo_pkg',
                'package_version': '3.1.0',
                'public_modules': ['demo.main'],
                'public_functions': {'demo.main': ['run', 'old_run']},
                'compatibility': {
                    'language_version': 'axiomzig>=0.47',
                    'dependency_version_ranges': {'dep': '^1.2'},
                },
                'public_function_metadata': {
                    'demo.main': {
                        'run': {'stability': 'stable', 'since': '3.0.0'},
                        'old_run': {
                            'stability': 'deprecated',
                            'deprecated_reason': 'use run',
                            'replacement': 'run',
                            'since': '2.5.0',
                        },
                    }
                },
            },
            indent=2,
        ),
    )
    out = tmp_path / 'full.json'
    pub = tmp_path / 'pub.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(tmp_path),
        '--package-interface', str(package_interface),
        '--out', str(out),
        '--publication-out', str(pub),
    ])
    capsys.readouterr()
    assert rc == 0

    manifest = json.loads(out.read_text(encoding='utf-8'))
    publication = json.loads(pub.read_text(encoding='utf-8'))

    assert manifest['package_name'] == 'demo_pkg'
    assert manifest['package_version'] == '3.1.0'
    assert manifest['api_compatibility'] == {
        'language_version': 'axiomzig>=0.47',
        'dependency_version_ranges': {'dep': '^1.2'},
    }
    assert manifest['public_function_metadata']['demo.main']['demo.main.old_run'] == {
        'stability': 'deprecated',
        'deprecated_reason': 'use run',
        'replacement': 'demo.main.run',
        'since': '2.5.0',
    }
    assert publication['api_compatibility'] == manifest['api_compatibility']
    assert publication['public_function_metadata'] == manifest['public_function_metadata']
    assert publication['package_interface']['compatibility'] == manifest['api_compatibility']


COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def _build_dep_publication_manifest(dep_root: Path, capsys) -> Path:
    dep_file = _write(
        dep_root / 'dep' / 'api.az',
        f'''module dep.api;\n{COMMON}\nfn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}\n''',
    )
    publication_out = dep_root / 'dep_publication.json'
    rc = main([
        'conform',
        str(dep_file),
        '--module-root', str(dep_root),
        '--package-name', 'dep',
        '--package-version', '1.2.3',
        '--public-only',
        '--publication-out', str(publication_out),
        '--out', str(dep_root / 'dep_full.json'),
    ])
    assert rc == 0
    capsys.readouterr()
    return publication_out


def test_publication_manifest_embeds_dependency_lock_digest_and_dependency_refs(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dep_publication_manifest(tmp_path / 'dep_pkg', capsys)
    app_root = tmp_path / 'app'
    main_file = _write(
        app_root / 'app' / 'main.az',
        f'''module app.main;\nimport dep.api;\n{COMMON}\nfn run(flag: Bool) -> Unit effects(protocol_step) {{\n    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};\n    h.other.close();\n    if (flag) {{ dep.api.close_inner(borrow h); }} else {{ h.inner.close(); }}\n    return unit;\n}}\n''',
    )
    out = app_root / 'full.json'
    pub = app_root / 'pub.json'
    lock = app_root / 'deps.lock.json'
    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(app_root),
        '--dependency-manifest', str(dep_manifest),
        '--package-name', 'app',
        '--package-version', '0.9.0',
        '--public-only',
        '--out', str(out),
        '--publication-out', str(pub),
        '--write-dependency-lock', str(lock),
    ])
    capsys.readouterr()
    assert rc == 0

    manifest = json.loads(out.read_text(encoding='utf-8'))
    publication = json.loads(pub.read_text(encoding='utf-8'))
    lock_data = json.loads(lock.read_text(encoding='utf-8'))
    expected_digest = dependency_lock_digest(lock_data)

    assert manifest['dependency_lock_digest_algorithm'] == 'sha256'
    assert manifest['dependency_lock_digest'] == expected_digest
    assert publication['dependency_lock_digest'] == expected_digest
    dep_refs = publication['dependency_publication_refs']
    assert len(dep_refs) == 1
    ref = dep_refs[0]
    assert ref['package_id'] == 'dep@1.2.3'
    assert ref['package_version'] == '1.2.3'
    assert ref['modules'] == ['dep.api']
    assert ref['export_scope'] == 'public_only'
    assert 'manifest_hash' in ref, "dependency_publication_ref must carry manifest_hash"
    assert ref['manifest_hash'], "manifest_hash must be non-empty" 


def test_package_interface_rejects_invalid_deprecation_metadata(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nfn run() -> Unit effects() { return unit; }\n',
    )
    bad_interface = _write(
        tmp_path / 'iface.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.main'],
                'public_functions': {'demo.main': ['run']},
                'public_function_metadata': {
                    'demo.main': {
                        'run': {'stability': 'deprecated'}
                    }
                },
            }
        ),
    )
    rc = main([
        'conform',
        str(main_file),
        '--module-root', str(tmp_path),
        '--package-interface', str(bad_interface),
    ])
    captured = capsys.readouterr()
    assert rc == 1
    assert 'deprecated_reason' in captured.err
