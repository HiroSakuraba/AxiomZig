from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from axiomzig.cli import main
from axiomzig.formatter import format_module
from axiomzig.parser import parse_module
from axiomzig.publication_diff import diff_publication_manifests


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def test_parser_and_formatter_roundtrip_pub_resource_and_protocol_annotations() -> None:
    text = '''module demo.main;

@experimental
@since("0.47.55")
pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

@deprecated(reason="use demo.main.File2", replacement="demo.main.File2")
pub resource File {
    protocol: Readable;
    fields {
        fd: Int;
    }
}
'''
    module = parse_module(text)
    proto = module.decls[0]
    resource = module.decls[1]

    assert proto.is_public is True
    assert proto.stability == 'experimental'
    assert proto.since == '0.47.55'
    assert resource.is_public is True
    assert resource.stability == 'deprecated'
    assert resource.deprecated_reason == 'use demo.main.File2'
    assert resource.replacement == 'demo.main.File2'
    assert format_module(module) == text


def test_emit_package_interface_includes_public_resources_protocols_and_resource_only_modules(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        '''module demo.main;

@experimental
pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

@deprecated(reason="use demo.main.File2", replacement="demo.main.File2")
pub resource File {
    protocol: Readable;
    fields {
        fd: Int;
    }
}

fn hidden() -> Unit effects() { return unit; }
''',
    )
    out = tmp_path / 'axiomzig.package.json'

    rc = main(['emit-package-interface', str(main_file), '--module-root', str(tmp_path), '--out', str(out)])
    captured = capsys.readouterr()
    rendered = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err == ''
    assert rendered['public_modules'] == ['demo.main']
    assert rendered['public_functions'] == {'demo.main': []}
    assert rendered['public_resources'] == {'demo.main': ['demo.main.File']}
    assert rendered['public_protocols'] == {'demo.main': ['demo.main.Readable']}
    assert rendered['public_resource_metadata']['demo.main']['demo.main.File']['stability'] == 'deprecated'
    assert rendered['public_protocol_metadata']['demo.main']['demo.main.Readable']['stability'] == 'experimental'


def test_conform_exports_resource_protocol_surface_without_accidentally_exporting_functions(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        '''module demo.main;

pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

pub resource File {
    protocol: Readable;
    fields {
        fd: Int;
    }
}

fn hidden() -> Unit effects() { return unit; }
''',
    )
    iface = _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.main'],
                'public_functions': {'demo.main': []},
                'public_resources': {'demo.main': ['File']},
                'public_protocols': {'demo.main': ['Readable']},
            }
        ),
    )
    out = tmp_path / 'manifest.json'
    pub = tmp_path / 'publication.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(iface),
        '--out',
        str(out),
        '--publication-out',
        str(pub),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))
    publication = json.loads(pub.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err == ''
    assert manifest['exported_functions'] == {'demo.main': []}
    assert manifest['exported_resources'] == {'demo.main': ['demo.main.File']}
    assert manifest['exported_protocols'] == {'demo.main': ['demo.main.Readable']}
    assert publication['exported_resources'] == {'demo.main': ['demo.main.File']}
    assert publication['exported_protocols'] == {'demo.main': ['demo.main.Readable']}


def test_emit_package_interface_rejects_lifecycle_metadata_on_non_public_resource_or_protocol(tmp_path: Path, capsys) -> None:
    bad_resource = _write(
        tmp_path / 'demo' / 'bad_resource.az',
        'module demo.bad_resource;\n\n@experimental\nresource File { fields { fd: Int; } }\n',
    )
    rc = main(['emit-package-interface', str(bad_resource), '--module-root', str(tmp_path)])
    captured = capsys.readouterr()
    assert rc == 1
    assert 'source API metadata on non-public resource demo.bad_resource.File requires pub' in captured.err

    bad_protocol = _write(
        tmp_path / 'demo' / 'bad_protocol.az',
        '''module demo.bad_protocol;

@experimental
protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}
''',
    )
    rc = main(['emit-package-interface', str(bad_protocol), '--module-root', str(tmp_path)])
    captured = capsys.readouterr()
    assert rc == 1
    assert 'source API metadata on non-public protocol demo.bad_protocol.Readable requires pub' in captured.err


def _publication_manifest() -> dict:
    return {
        'schema_version': 'axiomzig.publication_manifest.v1',
        'package_name': 'demo',
        'package_version': '1.0.0',
        'package_id': 'demo@1.0.0',
        'exported_modules': ['demo.main'],
        'exported_functions': {'demo.main': ['demo.main.run']},
        'exported_resources': {'demo.main': ['demo.main.File']},
        'exported_protocols': {'demo.main': ['demo.main.Readable']},
        'internal_signatures': {
            'demo.main': {
                'schema_version': 'axiomzig.ownership_signatures.v1',
                'module': 'demo.main',
                'functions': [
                    {
                        'name': 'demo.main.run',
                        'effects': [],
                        'params': [],
                        'return': 'Unit',
                        'resource_transitions': [],
                        'ref_writes': [],
                    }
                ],
            }
        },
        'public_resource_metadata': {'demo.main': {'demo.main.File': {'stability': 'stable'}}},
        'public_protocol_metadata': {'demo.main': {'demo.main.Readable': {'stability': 'stable'}}},
        'manifest_hash': 'old',
    }


def test_pubdiff_classifies_resource_protocol_api_changes_separately() -> None:
    old = _publication_manifest()
    new = deepcopy(old)
    new['exported_resources'] = {'demo.main': ['demo.main.File2']}
    new['exported_protocols'] = {'demo.main': ['demo.main.Readable', 'demo.main.Writable']}
    new['public_protocol_metadata']['demo.main']['demo.main.Readable'] = {
        'stability': 'deprecated',
        'deprecated_reason': 'use demo.main.Writable',
        'replacement': 'demo.main.Writable',
    }

    result = diff_publication_manifests(old, new)
    codes = {issue['code'] for issue in result['issues']}
    categories = {issue['category'] for issue in result['issues']}

    assert result['classification'] == 'incompatible'
    assert 'E_PUBLIC_RESOURCE_REMOVED' in codes
    assert 'C_PUBLIC_RESOURCE_ADDED' in codes
    assert 'C_PUBLIC_PROTOCOL_ADDED' in codes
    assert 'C_API_LIFECYCLE_NARROWED' in codes
    assert 'public_api_resource' in categories
    assert 'public_api_protocol' in categories
    assert 'api_lifecycle' in categories
