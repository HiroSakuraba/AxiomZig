from __future__ import annotations

from pathlib import Path

from axiomzig.module_graph import collect_workspace_ownership_signatures, load_module_graph
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature

COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def test_module_graph_reports_internal_missing_module_as_error(tmp_path: Path):
    main = tmp_path / 'demo' / 'main.az'
    main.parent.mkdir(parents=True)
    main.write_text(
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { return unit; }\n',
        encoding='utf-8',
    )
    graph = load_module_graph(main, module_root=tmp_path)
    assert any(issue.code == 'E_MODULE_MISSING' for issue in graph.issues)
    assert not any(issue.code == 'W_MODULE_OPAQUE' and issue.context == 'demo.util' for issue in graph.issues)


def test_module_graph_keeps_unresolved_external_import_opaque(tmp_path: Path):
    main = tmp_path / 'demo' / 'main.az'
    main.parent.mkdir(parents=True)
    main.write_text(
        'module demo.main;\nimport vendor.crypto;\nfn run() -> Unit effects() { return unit; }\n',
        encoding='utf-8',
    )
    graph = load_module_graph(main, module_root=tmp_path)
    assert any(issue.code == 'W_MODULE_OPAQUE' and issue.context == 'vendor.crypto' for issue in graph.issues)
    assert not any(issue.level == 'error' for issue in graph.issues)


def test_module_graph_detects_import_cycles(tmp_path: Path):
    a = tmp_path / 'demo' / 'a.az'
    b = tmp_path / 'demo' / 'b.az'
    a.parent.mkdir(parents=True)
    a.write_text('module demo.a;\nimport demo.b;\nfn run() -> Unit effects() { return unit; }\n', encoding='utf-8')
    b.write_text('module demo.b;\nimport demo.a;\nfn helper() -> Unit effects() { return unit; }\n', encoding='utf-8')
    graph = load_module_graph(a, module_root=tmp_path)
    messages = '\n'.join(issue.message for issue in graph.issues)
    assert any(issue.code == 'E_MODULE_CYCLE' for issue in graph.issues)
    assert 'demo.a -> demo.b -> demo.a' in messages


def test_module_graph_detects_duplicate_candidate_files_for_same_import(tmp_path: Path):
    main = tmp_path / 'demo' / 'main.az'
    util_a = tmp_path / 'demo' / 'util.az'
    util_b = tmp_path / 'demo' / 'util' / 'module.az'
    util_b.parent.mkdir(parents=True)
    main.write_text('module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { return unit; }\n', encoding='utf-8')
    util_a.write_text('module demo.util;\nfn helper() -> Unit effects() { return unit; }\n', encoding='utf-8')
    util_b.write_text('module demo.util;\nfn helper2() -> Unit effects() { return unit; }\n', encoding='utf-8')
    graph = load_module_graph(main, module_root=tmp_path)
    assert any(issue.code == 'E_MODULE_DUPLICATE_CANDIDATE' for issue in graph.issues)


def test_module_graph_detects_workspace_summary_conflict_with_external_contract(tmp_path: Path):
    util = tmp_path / 'demo' / 'util.az'
    main = tmp_path / 'demo' / 'main.az'
    util.parent.mkdir(parents=True)
    util.write_text(
        f'module demo.util;\n{COMMON}\nfn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}\n',
        encoding='utf-8',
    )
    main.write_text(
        f'module demo.main;\nimport demo.util;\n{COMMON}\nfn run() -> Unit effects() {{ return unit; }}\n',
        encoding='utf-8',
    )
    conflicting = FunctionOwnershipSignature(
        name='demo.util.close_inner',
        param_types=['Ref<Holder>'],
        return_type='Unit',
        effects=['protocol_step'],
        ref_params=[
            RefParamOwnershipSignature(
                param_index=0,
                mode='mut',
                type_name='Holder',
                effects={'other': 'Closed'},
            )
        ],
    )
    _, graph = collect_workspace_ownership_signatures(
        main,
        module_root=tmp_path,
        external_signatures={conflicting.name: conflicting},
    )
    assert any(issue.code == 'E_MODULE_SUMMARY_CONFLICT' for issue in graph.issues)


def test_module_graph_normalizes_relative_module_root_and_entry_paths(tmp_path: Path):
    util = tmp_path / 'demo' / 'util' / 'mod.az'
    main = tmp_path / 'demo' / 'main.az'
    util.parent.mkdir(parents=True)
    util.write_text('module demo.util;\nfn helper() -> Unit effects() { return unit; }\n', encoding='utf-8')
    main.write_text('module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { return unit; }\n', encoding='utf-8')
    graph = load_module_graph(
        tmp_path / 'demo' / '..' / 'demo' / 'main.az',
        module_root=tmp_path / 'demo' / '..',
    )
    assert graph.root == str(tmp_path.resolve())
    assert set(graph.modules) == {'demo.main', 'demo.util'}
    assert not any(issue.level == 'error' for issue in graph.issues)
