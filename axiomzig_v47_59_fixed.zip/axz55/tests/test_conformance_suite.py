"""
test_conformance_suite.py — conformance category coverage

Fills the gaps between current test counts and conformance plan minimums.
Each test function corresponds to exactly one conformance claim from the spec.
Tests are grouped by §5.x category.

Reference: docs/axiomzig_conformance_plan_v1_1.md
"""
from __future__ import annotations
import textwrap
from axiomzig.parser import parse_module
from axiomzig.checker import check_module
from axiomzig.resolve import resolve_module
from axiomzig.typecheck import typecheck_module
from axiomzig.formatter import format_module
from axiomzig.interpreter import Interpreter
from axiomzig.ownership import analyze_ownership


# ─────────────────────────────────────────────────────────────────────────────
# helpers
# ─────────────────────────────────────────────────────────────────────────────

def parse(src: str):
    return parse_module(textwrap.dedent(src).strip())

def check(src: str) -> list:
    return check_module(parse(src))

def errors(src: str) -> list[str]:
    return [i.message for i in check(src) if i.level == "error"]

def codes(src: str) -> list[str]:
    return [i.code for i in check(src) if i.level == "error" and i.code]

def ok(src: str) -> bool:
    return errors(src) == []

def fmt(src: str) -> str:
    return format_module(parse(src))

def interp(src: str) -> Interpreter:
    return Interpreter(parse(src))

def run(src: str, fn: str = "main") -> str:
    i = interp(src)
    return i.render_value(i.call_function(i.functions[fn], []))


# ─────────────────────────────────────────────────────────────────────────────
# §5.2 Parser (target: 35, current: ~23, adding 15)
# ─────────────────────────────────────────────────────────────────────────────

def test_parser_empty_module():
    m = parse("module p;")
    assert m.path == ["p"]
    assert m.decls == []

def test_parser_fn_no_params():
    m = parse("module p; fn f() -> Unit effects() { return unit; }")
    assert len(m.decls) == 1 and m.decls[0].name == "f"

def test_parser_fn_multiple_params():
    m = parse("module p; fn f(a: I64, b: Bool, c: Str) -> Unit effects() { return unit; }")
    assert len(m.decls[0].params) == 3

def test_parser_struct_fields():
    m = parse("module p; struct S { x: I64; y: Bool; }")
    assert len(m.decls[0].fields) == 2

def test_parser_enum_unit_variants():
    m = parse("module p; enum E { A; B; C; }")
    assert len(m.decls[0].variants) == 3

def test_parser_enum_payload_variant():
    m = parse("module p; enum E { Ok { value: I64; }; Err; }")
    ok_v = m.decls[0].variants[0]
    assert ok_v.name == "Ok" and len(ok_v.fields) == 1

def test_parser_error_set():
    m = parse("module p; error_set E { A; B; }")
    assert m.decls[0].name == "E"

def test_parser_protocol_decl():
    src = """
    module p;
    protocol P {
        states { Open, Closed }
        init Open;
        terminal { Closed }
        transitions { close: Open -> Closed; }
    }
    """
    m = parse(src)
    assert m.decls[0].name == "P"

def test_parser_resource_decl():
    src = """
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
    resource R { protocol: P; fields { x: I32; } }
    """
    m = parse(src)
    assert m.decls[1].name == "R"

def test_parser_while_stmt():
    m = parse("module p; fn f() -> Unit effects() { while (true) { break; } return unit; }")
    assert any(type(s).__name__ == "WhileStmt" for s in m.decls[0].body.statements)

def test_parser_for_range_stmt():
    m = parse("module p; fn f() -> Unit effects() { for (i: I64 in 0..5) { } return unit; }")
    assert any(type(s).__name__ == "ForStmt" for s in m.decls[0].body.statements)

def test_parser_match_expr():
    src = "module p; fn f(x: Bool) -> I64 effects() { return match x { true -> 1, false -> 0, }; }"
    m = parse(src)
    assert m.decls[0].name == "f"

def test_parser_nested_block():
    src = "module p; fn f() -> Unit effects() { { let x: I64 = 1; } return unit; }"
    assert ok(src)

def test_parser_try_expr_becomes_postfix():
    src = """
    module p;
    error_set E { Bad; }
    fn g() -> I64!E effects(error) { return E.Bad; }
    fn f() -> I64!E effects(error) { let x: I64 = g()?; return x; }
    """
    assert ok(src)

def test_parser_pub_fn():
    m = parse("module p; pub fn exported() -> Unit effects() { return unit; }")
    assert m.decls[0].is_public is True


# ─────────────────────────────────────────────────────────────────────────────
# §5.3 Formatter (target: 20, current: ~17, adding 5)
# ─────────────────────────────────────────────────────────────────────────────

def test_formatter_idempotent_simple():
    src = "module p; fn f() -> Unit effects() { return unit; }"
    f1 = fmt(src); f2 = fmt(f1)
    assert f1 == f2

def test_formatter_idempotent_match():
    src = "module p; fn f(x: Bool) -> I64 effects() { return match x { true -> 1, false -> 0, }; }"
    f1 = fmt(src); f2 = fmt(f1)
    assert f1 == f2

def test_formatter_idempotent_defer():
    src = "module p; fn cleanup() -> Unit effects() { return unit; } fn f() -> Unit effects() { defer cleanup(); return unit; }"
    f1 = fmt(src); f2 = fmt(f1)
    assert f1 == f2

def test_formatter_idempotent_pub_annotations():
    src = """
    module p;
    @experimental
    pub fn alpha() -> Unit effects() { return unit; }
    """
    f1 = fmt(src); f2 = fmt(f1)
    assert f1 == f2

def test_formatter_normalizes_whitespace():
    messy = "module p;fn f()->Unit effects(){return unit;}"
    f1 = fmt(messy)
    assert "fn f() -> Unit effects() {" in f1


# ─────────────────────────────────────────────────────────────────────────────
# §5.4 Name resolution (target: 20, current: ~10, adding 12)
# ─────────────────────────────────────────────────────────────────────────────

def test_resolve_unbound_name_rejected():
    errs = errors("module p; fn f() -> Unit effects() { let x: I64 = y; return unit; }")
    assert any("unresolved" in e.lower() or "y" in e for e in errs)

def test_resolve_shadowing_rejected():
    errs = errors("module p; fn f() -> Unit effects() { let x: I64 = 1; let x: I64 = 2; return x; }")
    assert any("E_RESOLVE_SHADOW" in c for c in codes("module p; fn f() -> Unit effects() { let x: I64 = 1; let x: I64 = 2; return x; }"))

def test_resolve_duplicate_param_rejected():
    errs = errors("module p; fn f(a: I64, a: I64) -> Unit effects() { return unit; }")
    assert len(errs) > 0

def test_resolve_duplicate_struct_field_rejected():
    errs = errors("module p; struct S { x: I64; x: I64; }")
    assert len(errs) > 0

def test_resolve_duplicate_top_level_rejected():
    errs = errors("module p; fn f() -> Unit effects() { return unit; } fn f() -> Unit effects() { return unit; }")
    assert len(errs) > 0

def test_resolve_unknown_type_rejected():
    errs = errors("module p; fn f() -> Unknown effects() { return unit; }")
    assert len(errs) > 0

def test_resolve_unknown_struct_literal_rejected():
    errs = errors("module p; fn f() -> Unit effects() { let x = NoSuchStruct { x: 1 }; return unit; }")
    assert len(errs) > 0

def test_resolve_enum_variant_correct():
    assert ok("""
    module p;
    enum Color { Red; Green; Blue; }
    fn f() -> Color effects() { return Color.Red; }
    """)

def test_resolve_error_set_tag_correct():
    assert ok("""
    module p;
    error_set E { Bad; }
    fn f() -> I64!E effects(error) { return E.Bad; }
    """)

def test_resolve_defer_control_flow_rejected():
    errs = errors("module p; fn f() -> Unit effects() { defer return unit; return unit; }")
    assert any("control flow" in e for e in errs)

def test_resolve_nested_defer_rejected():
    errs = errors("""
    module p;
    fn c() -> Unit effects() { return unit; }
    fn f() -> Unit effects() { defer defer c(); return unit; }
    """)
    assert any("nested defer" in e for e in errs)

def test_resolve_forward_reference_fn_ok():
    assert ok("""
    module p;
    fn a() -> Unit effects() { return b(); }
    fn b() -> Unit effects() { return unit; }
    """)


# ─────────────────────────────────────────────────────────────────────────────
# §5.5 Typing (target: 50, current: ~33, adding 20)
# ─────────────────────────────────────────────────────────────────────────────

def test_type_integer_arithmetic():
    assert ok("module p; fn f() -> I64 effects() { let x: I64 = 1 + 2 * 3 - 4; return x; }")

def test_type_bool_operators():
    assert ok("module p; fn f() -> Bool effects() { return true and false or not true; }")

def test_type_comparison():
    assert ok("module p; fn f(x: I64) -> Bool effects() { return x > 0 and x < 100; }")

def test_type_mismatch_rejected():
    errs = errors("module p; fn f() -> Bool effects() { return 1; }")
    assert len(errs) > 0

def test_type_return_wrong_type():
    errs = errors("module p; fn f() -> I64 effects() { return true; }")
    assert len(errs) > 0

def test_type_option_some_unwrap():
    assert ok("""
    module p;
    fn f(x: Option<I64>) -> I64 effects() {
        return match x { some(v) -> v, none -> 0, };
    }
    """)

def test_type_option_none_ok():
    assert ok("module p; fn f() -> Option<I64> effects() { return none; }")

def test_type_error_union_ok():
    assert ok("""
    module p;
    error_set E { Bad; }
    fn f() -> I64!E effects(error) { return 42; }
    """)

def test_type_error_union_propagate():
    assert ok("""
    module p;
    error_set E { Bad; }
    fn g() -> I64!E effects(error) { return E.Bad; }
    fn f() -> I64!E effects(error) { let x: I64 = g()?; return x; }
    """)

def test_type_struct_literal_field_types():
    assert ok("""
    module p;
    struct Point { x: I64; y: I64; }
    fn f() -> Point effects() { return Point { x: 1, y: 2 }; }
    """)

def test_type_wrong_arg_count_rejected():
    errs = errors("""
    module p;
    fn add(a: I64, b: I64) -> I64 effects() { return a + b; }
    fn f() -> I64 effects() { return add(1); }
    """)
    assert len(errs) > 0

def test_type_wrong_arg_type_rejected():
    errs = errors("""
    module p;
    fn add(a: I64, b: I64) -> I64 effects() { return a + b; }
    fn f() -> I64 effects() { return add(1, true); }
    """)
    assert len(errs) > 0

def test_type_let_annotation_mismatch():
    errs = errors("module p; fn f() -> Unit effects() { let x: Bool = 42; return unit; }")
    assert "E_TYPE_MISMATCH" in codes("module p; fn f() -> Unit effects() { let x: Bool = 42; return unit; }")

def test_type_assign_to_let_rejected():
    errs = errors("module p; fn f() -> Unit effects() { let x: I64 = 1; x = 2; return unit; }")
    assert len(errs) > 0

def test_type_var_reassign_ok():
    assert ok("module p; fn f() -> I64 effects() { var x: I64 = 1; x = 2; return x; }")

def test_type_match_exhaustive_bool():
    assert ok("module p; fn f(b: Bool) -> I64 effects() { return match b { true -> 1, false -> 0, }; }")

def test_type_match_nonexhaustive_rejected():
    errs = errors("module p; fn f(x: Option<I64>) -> I64 effects() { return match x { some(n) -> n, }; }")
    assert "E_TYPE_NO_EXHAUST" in codes("module p; fn f(x: Option<I64>) -> I64 effects() { return match x { some(n) -> n, }; }")

def test_type_match_arm_type_consistent():
    errs = errors("module p; fn f() -> I64 effects() { return match true { true -> 1, false -> false, }; }")
    assert "E_TYPE_ARM_INCOMPAT" in codes("module p; fn f() -> I64 effects() { return match true { true -> 1, false -> false, }; }")

def test_type_nonunit_discard_rejected():
    errs = errors("module p; fn f() -> I64 effects() { return 1; } fn g() -> Unit effects() { f(); return unit; }")
    assert "E_TYPE_NONUNIT" in codes("module p; fn f() -> I64 effects() { return 1; } fn g() -> Unit effects() { f(); return unit; }")

def test_type_discard_with_underscore_ok():
    assert ok("module p; fn f() -> I64 effects() { return 1; } fn g() -> Unit effects() { _ = f(); return unit; }")


# ─────────────────────────────────────────────────────────────────────────────
# §5.6 Effects (target: 25, current: ~8, adding 17)
# ─────────────────────────────────────────────────────────────────────────────

def test_effect_pure_fn_ok():
    assert ok("module p; fn f(x: I64) -> I64 effects() { return x + 1; }")

def test_effect_alloc_declared():
    assert ok("""
    module p;
    fn uses_alloc() -> Unit effects(alloc) { return unit; }
    fn caller() -> Unit effects(alloc) { return uses_alloc(); }
    """)

def test_effect_missing_alloc_rejected():
    errs = errors("""
    module p;
    fn uses_alloc() -> Unit effects(alloc) { return unit; }
    fn caller() -> Unit effects() { return uses_alloc(); }
    """)
    assert "E_EFFECT_UNDER" in codes("""
    module p;
    fn uses_alloc() -> Unit effects(alloc) { return unit; }
    fn caller() -> Unit effects() { return uses_alloc(); }
    """)

def test_effect_error_declared():
    assert ok("""
    module p;
    error_set E { Bad; }
    fn f() -> I64!E effects(error) { return E.Bad; }
    """)

def test_effect_missing_error_rejected():
    errs = errors("""
    module p;
    error_set E { Bad; }
    fn f() -> I64!E effects(error) { return E.Bad; }
    fn g() -> I64!E effects() { return f()?; }
    """)
    assert len(errs) > 0

def test_effect_trap_declared_is_error():
    errs = errors("module p; fn f() -> Unit effects(trap) { return unit; }")
    assert any("trap" in e for e in errors("module p; fn f() -> Unit effects(trap) { return unit; }"))

def test_effect_protocol_step_declared():
    assert ok("""
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
    resource R { protocol: P; fields { x: I32; } }
    fn do_step(r: R) -> Unit effects(protocol_step) { r.go(); return unit; }
    """)

def test_effect_missing_protocol_step_rejected():
    # Calling a function with protocol_step without declaring it propagates as E_EFFECT_UNDER
    errs = errors("""
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
    resource R { protocol: P; fields { x: I32; } }
    fn do_step(r: R) -> Unit effects(protocol_step) { r.go(); return unit; }
    fn caller() -> Unit effects() { let r: R = R { x: 0 }; do_step(r); }
    """)
    assert "E_EFFECT_UNDER" in codes("""
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
    resource R { protocol: P; fields { x: I32; } }
    fn do_step(r: R) -> Unit effects(protocol_step) { r.go(); return unit; }
    fn caller() -> Unit effects() { let r: R = R { x: 0 }; do_step(r); }
    """)

def test_effect_recurse_declared():
    assert ok("""
    module p;
    fn fib(n: I64) -> I64 effects(recurse) {
        if (n <= 1) { return n; }
        return fib(n - 1) + fib(n - 2);
    }
    """)

def test_effect_missing_recurse_rejected():
    errs = errors("""
    module p;
    fn fib(n: I64) -> I64 effects() {
        if (n <= 1) { return n; }
        return fib(n - 1) + fib(n - 2);
    }
    """)
    assert "E_EFFECT_RECURSE" in codes("""
    module p;
    fn fib(n: I64) -> I64 effects() {
        if (n <= 1) { return n; }
        return fib(n - 1) + fib(n - 2);
    }
    """)

def test_effect_free_declared():
    assert ok("""
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { finish: A -> B; } }
    resource R { protocol: P; fields { x: I32; } }
    fn cleanup(r: R) -> Unit effects(free, protocol_step) { r.finish(); return unit; }
    fn g(r: R) -> Unit effects(free, protocol_step) { return cleanup(r); }
    """)

def test_effect_io_propagates():
    assert ok("""
    module p;
    fn io_fn() -> Unit effects(io) { return unit; }
    fn caller() -> Unit effects(io) { return io_fn(); }
    """)

def test_effect_chain_subset():
    assert ok("""
    module p;
    fn leaf() -> Unit effects(alloc, error) { return unit; }
    fn mid() -> Unit effects(alloc, error) { return leaf(); }
    fn top() -> Unit effects(alloc, error) { return mid(); }
    """)

def test_effect_overapproximate_ok():
    # Declaring more effects than the body uses is allowed (warning, not error)
    assert ok("""
    module p;
    fn f() -> Unit effects(alloc, free, error, io) { return unit; }
    """)

def test_effect_mutual_recursion_both_need_recurse():
    errs = errors("""
    module p;
    fn is_even(n: I64) -> Bool effects() {
        if (n == 0) { return true; }
        return is_odd(n - 1);
    }
    fn is_odd(n: I64) -> Bool effects() {
        if (n == 0) { return false; }
        return is_even(n - 1);
    }
    """)
    assert len(errs) > 0

def test_effect_empty_effects_clause_required():
    from axiomzig.parser import ParseError
    try:
        parse("module p; fn f() -> Unit { return unit; }")
        assert False, "expected ParseError"
    except ParseError:
        pass  # correct: effects clause is mandatory syntax


# ─────────────────────────────────────────────────────────────────────────────
# §5.8 Protocols (target: 30, current: ~10, adding 22)
# ─────────────────────────────────────────────────────────────────────────────

_PROTO_SRC = """
module p;
protocol FileP {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}
resource File { protocol: FileP; fields { fd: I32; } }
"""

def test_protocol_simple_transition_ok():
    assert ok(_PROTO_SRC + "fn f(r: File) -> Unit effects(protocol_step) { r.close(); return unit; }")

def test_protocol_illegal_transition_rejected():
    errs = errors(_PROTO_SRC + """
    fn f(r: File) -> Unit effects(protocol_step) {
        r.close();
        r.close();
        return unit;
    }
    """)
    assert "E_PROTO_TRANSITION" in codes(_PROTO_SRC + """
    fn f(r: File) -> Unit effects(protocol_step) { r.close(); r.close(); return unit; }
    """)

def test_protocol_undischarged_resource_rejected():
    errs = errors(_PROTO_SRC + "fn f() -> Unit effects() { let r: File = File { fd: 0 }; return unit; }")
    assert "E_OWN_UNDISCHARGED" in codes(_PROTO_SRC + "fn f() -> Unit effects() { let r: File = File { fd: 0 }; return unit; }")

def test_protocol_block_scope_undischarged_rejected():
    errs = errors(_PROTO_SRC + """
    fn f() -> Unit effects() {
        { let r: File = File { fd: 0 }; }
        return unit;
    }
    """)
    assert len(errs) > 0

def test_protocol_moved_is_terminal():
    assert ok(_PROTO_SRC + """
    fn consume(r: File) -> Unit effects(protocol_step) { r.close(); return unit; }
    fn f() -> Unit effects(protocol_step) {
        let r: File = File { fd: 0 };
        consume(move r);
        return unit;
    }
    """)

def test_protocol_multi_state_ok():
    assert ok("""
    module p;
    protocol P {
        states { Uninit, Ready, Done }
        init Uninit;
        terminal { Done }
        transitions {
            init: Uninit -> Ready;
            finish: Ready -> Done;
        }
    }
    resource R { protocol: P; fields { x: I32; } }
    fn use_r(r: R) -> Unit effects(protocol_step) {
        r.init();
        r.finish();
        return unit;
    }
    """)

def test_protocol_wrong_init_state_rejected():
    errs = errors("""
    module p;
    protocol P {
        states { Uninit, Ready, Done }
        init Uninit;
        terminal { Done }
        transitions {
            init: Uninit -> Ready;
            finish: Ready -> Done;
        }
    }
    resource R { protocol: P; fields { x: I32; } }
    fn bad(r: R) -> Unit effects(protocol_step) {
        r.finish();
        return unit;
    }
    """)
    assert len(errs) > 0

def test_protocol_through_if_both_branches_ok():
    assert ok(_PROTO_SRC + """
    fn f(cond: Bool) -> Unit effects(protocol_step) {
        let r: File = File { fd: 0 };
        if (cond) { r.close(); } else { r.close(); }
        return unit;
    }
    """)

def test_protocol_through_if_one_branch_rejected():
    errs = errors(_PROTO_SRC + """
    fn f(cond: Bool) -> Unit effects(protocol_step) {
        let r: File = File { fd: 0 };
        if (cond) { r.close(); }
        return unit;
    }
    """)
    assert len(errs) > 0

def test_protocol_via_ref_close_ok():
    assert ok(_PROTO_SRC + """
    fn closer(r: Ref<File>) -> Unit effects(protocol_step) { r.close(); return unit; }
    fn f() -> Unit effects(protocol_step) {
        let r: File = File { fd: 0 };
        { closer(borrow r); }
        return unit;
    }
    """)

def test_protocol_ref_double_close_rejected():
    errs = errors(_PROTO_SRC + """
    fn closer(r: Ref<File>) -> Unit effects(protocol_step) { r.close(); return unit; }
    fn f() -> Unit effects(protocol_step) {
        let r: File = File { fd: 0 };
        { closer(borrow r); }
        r.close();
        return unit;
    }
    """)
    assert len(errs) > 0

def test_protocol_struct_field_resource_tracked():
    errs = errors(_PROTO_SRC + """
    struct Holder { f: File; }
    fn f() -> Unit effects() { let h: Holder = Holder { f: File { fd: 0 } }; return unit; }
    """)
    assert len(errs) > 0

def test_protocol_partial_move_ok():
    assert ok(_PROTO_SRC + """
    struct Pair { a: File; b: File; }
    fn close_f(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
    fn f() -> Unit effects(protocol_step) {
        let p: Pair = Pair { a: File { fd: 0 }, b: File { fd: 1 } };
        close_f(move p.a);
        close_f(move p.b);
        return unit;
    }
    """)

def test_protocol_partial_double_move_rejected():
    errs = errors(_PROTO_SRC + """
    struct Pair { a: File; b: File; }
    fn close_f(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
    fn f() -> Unit effects(protocol_step) {
        let p: Pair = Pair { a: File { fd: 0 }, b: File { fd: 1 } };
        close_f(move p.a);
        close_f(move p.a);
        close_f(move p.b);
        return unit;
    }
    """)
    assert len(errs) > 0


# ─────────────────────────────────────────────────────────────────────────────
# §5.9 Defer / errdefer (target: 25, current: ~8, adding 17)
# ─────────────────────────────────────────────────────────────────────────────

_DEFSRC = _PROTO_SRC + """
fn cleanup(r: File) -> Unit effects(protocol_step) { r.close(); return unit; }
"""

def test_defer_basic_executes():
    assert ok(_DEFSRC + """
    fn f() -> Unit effects(protocol_step) {
        let r: File = File { fd: 0 };
        defer cleanup(move r);
        return unit;
    }
    """)

def test_defer_return_blocked():
    errs = errors("module p; fn f() -> Unit effects() { defer return unit; return unit; }")
    assert "E_DEFER_FLOW" in codes("module p; fn f() -> Unit effects() { defer return unit; return unit; }")

def test_defer_break_blocked():
    errs = errors("""
    module p;
    fn f() -> Unit effects() {
        while (true) { defer break; return unit; }
        return unit;
    }
    """)
    assert len(errs) > 0

def test_defer_continue_blocked():
    errs = errors("""
    module p;
    fn f() -> Unit effects() {
        while (false) { defer continue; }
        return unit;
    }
    """)
    assert len(errs) > 0

def test_defer_nested_blocked():
    errs = errors("""
    module p;
    fn c() -> Unit effects() { return unit; }
    fn f() -> Unit effects() { defer defer c(); return unit; }
    """)
    assert "E_DEFER_NESTED" in codes("""
    module p;
    fn c() -> Unit effects() { return unit; }
    fn f() -> Unit effects() { defer defer c(); return unit; }
    """)

def test_errdefer_control_flow_blocked():
    errs = errors("module p; fn f() -> Unit effects() { errdefer return unit; return unit; }")
    assert len(errs) > 0

def test_errdefer_cleanup_pattern_ok():
    assert ok(_PROTO_SRC + """
    error_set E { Bad; }
    fn fail() -> Unit!E effects(error) { return E.Bad; }
    fn f() -> Unit!E effects(protocol_step, error) {
        let r: File = File { fd: 0 };
        errdefer r.close();
        try fail();
        r.close();
        return unit;
    }
    """)

def test_defer_executes_before_scope_exit():
    assert ok(_DEFSRC + """
    fn f() -> Unit effects(protocol_step) {
        {
            let r: File = File { fd: 0 };
            defer cleanup(move r);
        }
        return unit;
    }
    """)

def test_defer_stack_lifo_ok():
    assert ok("""
    module p;
    fn a() -> Unit effects() { return unit; }
    fn b() -> Unit effects() { return unit; }
    fn f() -> Unit effects() {
        defer a();
        defer b();
        return unit;
    }
    """)

def test_defer_does_not_prevent_normal_flow():
    assert ok(_DEFSRC + """
    fn f() -> Unit effects(protocol_step) {
        let r: File = File { fd: 0 };
        defer cleanup(move r);
        return unit;
    }
    """)

def test_defer_in_loop_body_ok():
    assert ok("""
    module p;
    fn c() -> Unit effects() { return unit; }
    fn f() -> Unit effects() {
        for (i: I64 in 0..3) { defer c(); }
        return unit;
    }
    """)

def test_errdefer_nested_blocked():
    errs = errors("""
    module p;
    fn c() -> Unit effects() { return unit; }
    fn f() -> Unit effects() { errdefer defer c(); return unit; }
    """)
    assert len(errs) > 0

def test_defer_effects_propagate_to_caller():
    assert ok("""
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
    resource R { protocol: P; fields { x: I32; } }
    fn step(r: R) -> Unit effects(protocol_step) { r.go(); return unit; }
    fn f() -> Unit effects(protocol_step) {
        let r: R = R { x: 0 };
        defer step(move r);
        return unit;
    }
    """)


# ─────────────────────────────────────────────────────────────────────────────
# §5.10 Runtime (target: 35, current: ~20, adding 15)
# ─────────────────────────────────────────────────────────────────────────────

def test_runtime_integer_add():
    assert run("module p; fn main() -> I64 effects() { return 3 + 4; }") == "7"

def test_runtime_integer_sub():
    assert run("module p; fn main() -> I64 effects() { return 10 - 3; }") == "7"

def test_runtime_integer_mul():
    assert run("module p; fn main() -> I64 effects() { return 3 * 4; }") == "12"

def test_runtime_integer_div():
    assert run("module p; fn main() -> I64 effects() { return 10 / 2; }") == "5"

def test_runtime_bool_and():
    assert run("module p; fn main() -> Bool effects() { return true and false; }") == "false"

def test_runtime_bool_or():
    assert run("module p; fn main() -> Bool effects() { return false or true; }") == "true"

def test_runtime_bool_not():
    assert run("module p; fn main() -> Bool effects() { return not false; }") == "true"

def test_runtime_if_true_branch():
    assert run("module p; fn main() -> I64 effects() { if (true) { return 1; } return 0; }") == "1"

def test_runtime_if_false_branch():
    assert run("module p; fn main() -> I64 effects() { if (false) { return 1; } return 0; }") == "0"

def test_runtime_match_bool():
    assert run("module p; fn main() -> I64 effects() { return match true { true -> 42, false -> 0, }; }") == "42"

def test_runtime_match_option_some():
    assert run("module p; fn main() -> I64 effects() { return match some(7) { some(n) -> n, none -> 0, }; }") == "7"

def test_runtime_match_option_none():
    assert run("module p; fn main() -> I64 effects() { return match none { some(n) -> n, none -> 99, }; }") == "99"

def test_runtime_var_reassign():
    assert run("module p; fn main() -> I64 effects() { var x: I64 = 1; x = x + 1; return x; }") == "2"

def test_runtime_function_call():
    assert run("module p; fn double(x: I64) -> I64 effects() { return x * 2; } fn main() -> I64 effects() { return double(5); }") == "10"

def test_runtime_nested_calls():
    assert run("""
    module p;
    fn add(a: I64, b: I64) -> I64 effects() { return a + b; }
    fn mul(a: I64, b: I64) -> I64 effects() { return a * b; }
    fn main() -> I64 effects() { return add(mul(2, 3), mul(4, 5)); }
    """) == "26"


# ─────────────────────────────────────────────────────────────────────────────
# §5.11 Canonical round-trip (target: 15, current: ~4, adding 12)
# ─────────────────────────────────────────────────────────────────────────────

def _roundtrip_ok(src: str) -> bool:
    """format(parse(format(parse(src)))) == format(parse(src))"""
    m1 = parse(src); f1 = fmt(src)
    m2 = parse(f1);  f2 = format_module(m2)
    return f1 == f2

def test_roundtrip_simple_fn():
    assert _roundtrip_ok("module p; fn f() -> Unit effects() { return unit; }")

def test_roundtrip_struct():
    assert _roundtrip_ok("module p; struct S { x: I64; y: Bool; }")

def test_roundtrip_enum():
    assert _roundtrip_ok("module p; enum E { A; B { v: I64; }; }")

def test_roundtrip_error_set():
    assert _roundtrip_ok("module p; error_set E { Bad; Missing; }")

def test_roundtrip_protocol():
    assert _roundtrip_ok("""
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
    """)

def test_roundtrip_resource():
    assert _roundtrip_ok("""
    module p;
    protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
    resource R { protocol: P; fields { x: I32; } }
    """)

def test_roundtrip_match_expr():
    assert _roundtrip_ok("""
    module p;
    fn f(x: Bool) -> I64 effects() { return match x { true -> 1, false -> 0, }; }
    """)

def test_roundtrip_if_else():
    assert _roundtrip_ok("""
    module p;
    fn f(b: Bool) -> I64 effects() { if (b) { return 1; } else { return 0; } }
    """)

def test_roundtrip_while():
    assert _roundtrip_ok("""
    module p;
    fn f() -> Unit effects() { while (false) { } return unit; }
    """)

def test_roundtrip_defer():
    assert _roundtrip_ok("""
    module p;
    fn c() -> Unit effects() { return unit; }
    fn f() -> Unit effects() { defer c(); return unit; }
    """)

def test_roundtrip_pub_annotation():
    assert _roundtrip_ok("""
    module p;
    @experimental
    pub fn alpha() -> Unit effects() { return unit; }
    """)

def test_roundtrip_error_propagation():
    assert _roundtrip_ok("""
    module p;
    error_set E { Bad; }
    fn g() -> I64!E effects(error) { return E.Bad; }
    fn f() -> I64!E effects(error) { let x: I64 = g()?; return x; }
    """)
