from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def test_conform_package_interface_exports_declared_module_and_function_surface(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\nfn helper() -> Unit effects() { return unit; }\nfn hidden() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { demo.util.helper(); return unit; }\nfn private_run() -> Unit effects() { return unit; }\n',
    )
    package_interface = _write(
        tmp_path / 'iface.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'package_name': 'demo_pkg',
                'package_version': '2.1.0',
                'public_modules': ['demo.main', 'demo.util'],
                'public_functions': {
                    'demo.main': ['run'],
                    'demo.util': ['demo.util.helper'],
                },
            }
        ),
    )
    out = tmp_path / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(package_interface),
        '--out',
        str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err.strip() == ''
    assert manifest['schema_version'] == 'axiomzig.conformance.v4'
    assert manifest['export_scope'] == 'package_interface'
    assert manifest['package_name'] == 'demo_pkg'
    assert manifest['package_version'] == '2.1.0'
    assert manifest['exported_modules'] == ['demo.main', 'demo.util']
    assert manifest['exported_functions'] == {
        'demo.main': ['demo.main.run'],
        'demo.util': ['demo.util.helper'],
    }
    assert [fn['name'] for fn in manifest['internal_signatures']['demo.main']['functions']] == ['demo.main.run']
    assert [fn['name'] for fn in manifest['internal_signatures']['demo.util']['functions']] == ['demo.util.helper']
    assert manifest['package_interface']['public_modules'] == ['demo.main', 'demo.util']


def test_conform_auto_discovers_axiomzig_package_interface_file(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\nfn helper() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { return unit; }\n',
    )
    _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.util'],
                'public_functions': {'demo.util': ['helper']},
            }
        ),
    )
    out = tmp_path / 'manifest.json'

    rc = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out)])
    capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert manifest['export_scope'] == 'package_interface'
    assert manifest['exported_modules'] == ['demo.util']
    assert manifest['exported_functions'] == {'demo.util': ['demo.util.helper']}
    assert sorted(manifest['internal_signatures']) == ['demo.util']


def test_conform_package_interface_rejects_unknown_public_module_or_function(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nfn run() -> Unit effects() { return unit; }\n',
    )
    bad_interface = _write(
        tmp_path / 'iface.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.main', 'demo.util'],
                'public_functions': {'demo.main': ['missing'], 'demo.util': ['helper']},
            }
        ),
    )

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(bad_interface),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'conformance error:' in captured.err
    assert 'package interface exports non-reachable modules' in captured.err or 'exports unknown functions' in captured.err
