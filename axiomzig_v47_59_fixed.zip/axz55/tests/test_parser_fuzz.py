import random

import pytest

from axiomzig.lexer import LexError, lex
from axiomzig.parser import ParseError, parse_module


VALID_CORPUS = [
    '''
module fuzz.simple;

fn add(x: I64, y: I64) -> I64 effects() {
    return x + y;
}
''',
    '''
module fuzz.matching;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return match s {
        "" -> ParseError.Empty,
        _ -> 0,
    };
}
''',
    '''
module fuzz.composites;

struct Pair {
    left: I64;
    right: I64;
}

enum Choice {
    First;
    Second {
        value: I64;
    };
}

fn make(flag: Bool) -> I64 effects() {
    let pair = Pair { left: 1, right: 2 };
    let value = match flag {
        true -> Choice.Second { value: pair.left }.value,
        false -> pair.right,
    };
    return value;
}
''',
    '''
module fuzz.borrows;

fn touch(x: RefConst<I64>) -> Unit effects() {
    return unit;
}

fn main(flag: Bool) -> Unit effects() {
    var x: I64 = 0;
    if (flag) {
        defer touch(borrow x);
    } else {
        errdefer touch(borrow x);
    }
    for (i: I64 in 0..4) {
        x += i;
    }
    return unit;
}
''',
]


MALFORMED_CASES = [
    (
        'missing match arrow',
        '''
module bad.match_arrow;
fn main(x: Bool) -> Bool effects() {
    return match x {
        true false,
    };
}
''',
    ),
    (
        'empty match arm expression',
        '''
module bad.match_expr;
fn main(x: Bool) -> Bool effects() {
    return match x {
        true ->,
    };
}
''',
    ),
    (
        'broken borrow expression',
        '''
module bad.borrow;
fn main() -> Unit effects() {
    let x = borrow;
    return unit;
}
''',
    ),
    (
        'broken move expression',
        '''
module bad.move;
fn main() -> Unit effects() {
    let x = move;
    return unit;
}
''',
    ),
    (
        'broken copy expression',
        '''
module bad.copy;
fn main() -> Unit effects() {
    let x = copy;
    return unit;
}
''',
    ),
    (
        'malformed range expression',
        '''
module bad.range;
fn main() -> Unit effects() {
    for (i: I64 in 0..) {
        return unit;
    }
}
''',
    ),
    (
        'trailing dotted path',
        '''
module bad.dotted;
fn main() -> Unit effects() {
    let x = value.;
    return unit;
}
''',
    ),
    (
        'broken struct literal',
        '''
module bad.struct_lit;
struct Pair {
    left: I64;
}
fn main() -> Unit effects() {
    let p = Pair { left 1 };
    return unit;
}
''',
    ),
    (
        'broken enum literal',
        '''
module bad.enum_lit;
enum Choice {
    Second {
        value: I64;
    };
}
fn main() -> Unit effects() {
    let c = Choice.Second { value };
    return unit;
}
''',
    ),
    (
        'empty index',
        '''
module bad.index;
fn main(xs: Slice<I64>) -> Unit effects() {
    xs[];
    return unit;
}
''',
    ),
    (
        'bare defer',
        '''
module bad.defer;
fn main() -> Unit effects() {
    defer;
    return unit;
}
''',
    ),
    (
        'bare errdefer',
        '''
module bad.errdefer;
fn main() -> Unit effects() {
    errdefer;
    return unit;
}
''',
    ),
    (
        'trailing comma in struct literal',
        '''
module bad.trailing_comma;
struct Pair {
    left: I64;
}
fn main() -> Unit effects() {
    let p = Pair { left: 1, };
    return unit;
}
''',
    ),
]


ALLOWED_PARSE_FAILURES = (ParseError, LexError)


def assert_no_internal_parser_crash(text: str) -> None:
    try:
        parse_module(text)
    except ALLOWED_PARSE_FAILURES:
        return


def render_token_for_source(tok) -> str:
    if tok.kind == 'STRING':
        value = tok.value
        value = value.replace('\\', '\\\\')
        value = value.replace('"', '\\"')
        value = value.replace('\n', '\\n')
        value = value.replace('\t', '\\t')
        value = value.replace('\r', '\\r')
        value = value.replace('\0', '\\0')
        return f'"{value}"'
    return tok.value


def render_token_sequence(tokens) -> str:
    return ' '.join(render_token_for_source(tok) for tok in tokens)


def lexed_non_eof_tokens(text: str):
    return [tok for tok in lex(text) if tok.kind != 'EOF']


@pytest.mark.parametrize(('label', 'text'), MALFORMED_CASES)
def test_targeted_malformed_inputs_fail_cleanly(label: str, text: str) -> None:
    with pytest.raises(ALLOWED_PARSE_FAILURES):
        parse_module(text)


def test_prefix_truncation_fuzz_never_crashes_parser() -> None:
    for source in VALID_CORPUS:
        cuts = sorted({1, 2, 3, len(source) // 4, len(source) // 2, (3 * len(source)) // 4, len(source) - 1})
        for cut in cuts:
            assert_no_internal_parser_crash(source[:cut])


def mutate_text(rng: random.Random, text: str) -> str:
    punctuation = ['{', '}', '(', ')', '[', ']', ',', ';', '.', '->', '..', '?', '=']
    letters = 'abcdefghijklmnopqrstuvwxyz_'
    mutation = rng.choice(['delete', 'replace', 'insert', 'duplicate'])
    if not text:
        return 'module fuzz.empty;'

    idx = rng.randrange(len(text))
    if mutation == 'delete':
        return text[:idx] + text[idx + 1 :]
    if mutation == 'replace':
        replacement = rng.choice(punctuation + list(letters) + [' ', '\n', '0', '1', '"'])
        return text[:idx] + replacement + text[idx + 1 :]
    if mutation == 'insert':
        insertion = rng.choice(punctuation + list(letters) + [' ', '\n', '0', '1', '"'])
        return text[:idx] + insertion + text[idx:]
    return text[:idx] + text[idx] + text[idx:]


def test_random_character_mutation_fuzz_never_crashes_parser() -> None:
    rng = random.Random(0xA710C)
    for source in VALID_CORPUS:
        mutated = source
        for _ in range(50):
            mutated = mutate_text(rng, mutated)
            assert_no_internal_parser_crash(mutated)


def test_token_sequence_mutation_fuzz_never_crashes_parser() -> None:
    rng = random.Random(0xA710)
    token_pool = []
    corpus_tokens = []
    for source in VALID_CORPUS:
        tokens = lexed_non_eof_tokens(source)
        corpus_tokens.append(tokens)
        token_pool.extend(tokens)

    for _ in range(400):
        seq = list(rng.choice(corpus_tokens))
        for _ in range(rng.randint(1, 4)):
            op = rng.choice(['delete', 'replace', 'insert', 'duplicate', 'swap'])
            if not seq:
                seq = list(rng.choice(corpus_tokens))
            idx = rng.randrange(len(seq))
            if op == 'delete':
                del seq[idx]
                continue
            if op == 'replace':
                seq[idx] = rng.choice(token_pool)
                continue
            if op == 'insert':
                seq.insert(idx, rng.choice(token_pool))
                continue
            if op == 'duplicate':
                seq.insert(idx, seq[idx])
                continue
            if op == 'swap' and len(seq) > 1:
                other = rng.randrange(len(seq))
                seq[idx], seq[other] = seq[other], seq[idx]
        assert_no_internal_parser_crash(render_token_sequence(seq))


def test_token_splice_fuzz_never_crashes_parser() -> None:
    rng = random.Random(0x51EC3)
    corpus_tokens = [lexed_non_eof_tokens(source) for source in VALID_CORPUS]

    for _ in range(120):
        left = list(rng.choice(corpus_tokens))
        right = list(rng.choice(corpus_tokens))
        left_cut = rng.randrange(len(left) + 1)
        right_cut = rng.randrange(len(right) + 1)
        spliced = left[:left_cut] + right[right_cut:]
        assert_no_internal_parser_crash(render_token_sequence(spliced))

EXPR_FRAGMENTS = [
    '0',
    'x',
    'borrow x',
    'copy x',
    'move holder.file',
    'Pair { left: 1, right: 2 }.left',
    'Choice.Second { value: x }.value',
    'xs[0]',
    'xs[0..2]',
    '@cast(I64, 2)',
    'helper(x, 1)',
    'helper_result(x)?',
    'match flag { true -> x, false -> 0, }',
]


STMT_FRAGMENTS = [
    'let y = 0;',
    'var y: I64 = 1;',
    'y = helper(x, 1);',
    'y += 1;',
    'helper(y, 0);',
    'defer helper(y, 0);',
    'errdefer helper(0, 0);',
    'if (flag) { y = 1; } else { y = 2; }',
    'while (flag) { break; }',
    'for (i: I64 in 0..4) { y += i; }',
    'let z = match flag { true -> y, false -> 0, };',
    '{ let inner = y; helper(inner, 0); }',
    'return y;',
]


FRAGMENT_TEMPLATE = """
module fuzz.fragments;

struct Pair {
    left: I64;
    right: I64;
}

enum Choice {
    First;
    Second {
        value: I64;
    };
}

error_set ParseError {
    Empty;
}

resource Holder {
    fields {
        file: I64;
    }
}

fn helper(x: I64, y: I64) -> I64 effects() {
    return x + y;
}

fn helper_result(x: I64) -> I64!ParseError effects(error) {
    return x;
}

fn main(flag: Bool, x: I64, xs: Slice<I64>, holder: Holder) -> I64!ParseError effects(error) {
    var y: I64 = 0;
__BODY__
}
"""


def build_fragment_module(body_lines: list[str]) -> str:
    indented = '\n'.join(f'    {line}' for line in body_lines)
    return FRAGMENT_TEMPLATE.replace('__BODY__', indented)


def mutate_fragment_list(rng: random.Random, items: list[str]) -> list[str]:
    seq = list(items)
    for _ in range(rng.randint(1, 4)):
        op = rng.choice(['delete', 'replace', 'insert', 'duplicate', 'swap'])
        if not seq:
            return list(items)
        idx = rng.randrange(len(seq))
        if op == 'delete':
            del seq[idx]
            continue
        if op == 'replace':
            seq[idx] = rng.choice(items)
            continue
        if op == 'insert':
            seq.insert(idx, rng.choice(items))
            continue
        if op == 'duplicate':
            seq.insert(idx, seq[idx])
            continue
        if op == 'swap' and len(seq) > 1:
            other = rng.randrange(len(seq))
            seq[idx], seq[other] = seq[other], seq[idx]
    return seq


def test_expression_fragment_context_fuzz_never_crashes_parser() -> None:
    rng = random.Random(0xE771)
    for _ in range(180):
        exprs = mutate_fragment_list(rng, EXPR_FRAGMENTS)
        body = [f'let value_{i} = {expr};' for i, expr in enumerate(exprs)]
        body.append('return y;')
        assert_no_internal_parser_crash(build_fragment_module(body))


def test_statement_fragment_context_fuzz_never_crashes_parser() -> None:
    rng = random.Random(0x571A7)
    for _ in range(180):
        stmts = mutate_fragment_list(rng, STMT_FRAGMENTS)
        if not any(stmt.startswith('return') for stmt in stmts):
            stmts.append('return y;')
        assert_no_internal_parser_crash(build_fragment_module(stmts))


def test_fragment_splice_fuzz_never_crashes_parser() -> None:
    rng = random.Random(0xF12A)
    for _ in range(120):
        left = mutate_fragment_list(rng, STMT_FRAGMENTS)
        right = mutate_fragment_list(rng, STMT_FRAGMENTS)
        left_cut = rng.randrange(len(left) + 1)
        right_cut = rng.randrange(len(right) + 1)
        spliced = left[:left_cut] + right[right_cut:]
        if not any(stmt.startswith('return') for stmt in spliced):
            spliced.append('return y;')
        assert_no_internal_parser_crash(build_fragment_module(spliced))
