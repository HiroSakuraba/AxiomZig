from __future__ import annotations

import random
from pathlib import Path

from axiomzig.formatter import format_module
from axiomzig.lexer import lex
from axiomzig.parser import parse_module


EXAMPLE_PATHS = [
    Path("examples/demo_math.az"),
    Path("examples/demo_parse.az"),
    Path("examples/demo_file.az"),
    Path("examples/demo_option.az"),
]


CURATED_MODULES = [
    """
module demo.tryalias;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8!ParseError effects(error) {
    let x: U8 = try parse_one(s);
    return x;
}
""",
    """
module demo.property;

struct Pair {
    left: I64;
    right: I64;
}

enum Choice {
    First;
    Second {
        value: I64;
    };
}

fn select(flag: Bool, pair: Pair) -> I64 effects() {
    let y = match flag {
        true -> Choice.Second { value: pair.left }.value,
        false -> pair.right,
    };
    return y;
}
""",
    """
module demo.deferprop;

protocol FileProto {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProto;
    fields {
        fd: I64;
    }
}

fn main(flag: Bool, f: File) -> Unit effects(protocol_step) {
    defer if (flag) {
        f.close();
        return unit;
    } else {
        return unit;
    }
    return unit;
}
""",
]


TRIVIA_CHOICES = [
    " ",
    "\n",
    "\n\n",
    "\t",
    " \t ",
    "\n// fuzz\n",
]


def render_token_value(tok) -> str:
    if tok.kind == "STRING":
        value = tok.value
        value = value.replace("\\", "\\\\")
        value = value.replace('"', '\\"')
        value = value.replace("\n", "\\n")
        value = value.replace("\t", "\\t")
        value = value.replace("\r", "\\r")
        value = value.replace("\x00", "\\0")
        return f'"{value}"'
    return tok.value


def corpus_sources() -> list[str]:
    return [path.read_text(encoding="utf-8") for path in EXAMPLE_PATHS] + CURATED_MODULES


def render_with_random_trivia(source: str, seed: int) -> str:
    rng = random.Random(seed)
    token_values = [render_token_value(tok) for tok in lex(source) if tok.kind != "EOF"]
    if not token_values:
        return "\n"
    pieces: list[str] = [token_values[0]]
    for value in token_values[1:]:
        pieces.append(rng.choice(TRIVIA_CHOICES))
        pieces.append(value)
    pieces.append("\n")
    return "".join(pieces)


def test_formatter_canonicalizes_trivia_perturbed_modules() -> None:
    for source_index, source in enumerate(corpus_sources()):
        canonical = format_module(parse_module(source))
        for variant_index in range(25):
            perturbed = render_with_random_trivia(source, seed=source_index * 1000 + variant_index)
            reparsed = parse_module(perturbed)
            reformatted = format_module(reparsed)
            assert reformatted == canonical


def test_formatter_output_is_stable_after_trivia_perturbation() -> None:
    for source_index, source in enumerate(corpus_sources()):
        for variant_index in range(10):
            perturbed = render_with_random_trivia(source, seed=0xA710000 + source_index * 100 + variant_index)
            formatted1 = format_module(parse_module(perturbed))
            formatted2 = format_module(parse_module(formatted1))
            assert formatted1 == formatted2


def test_try_alias_still_canonicalizes_under_trivia_fuzz() -> None:
    source = CURATED_MODULES[0]
    canonical = format_module(parse_module(source))
    assert "try parse_one(s)" not in canonical
    assert "parse_one(s)?" in canonical
    for variant_index in range(20):
        perturbed = render_with_random_trivia(source, seed=0xBEEF000 + variant_index)
        reformatted = format_module(parse_module(perturbed))
        assert "try parse_one(s)" not in reformatted
        assert "parse_one(s)?" in reformatted
        assert reformatted == canonical
