from __future__ import annotations

import hashlib
import json
from pathlib import Path

from axiomzig.cli import main


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _manifest_hash(payload: dict) -> str:
    body = {key: value for key, value in payload.items() if key != 'manifest_hash'}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()


def test_conform_manifest_v47_45_includes_hashes_and_source_digests(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\nfn helper() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { return unit; }\n',
    )
    out = tmp_path / 'manifest.json'

    rc = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out)])
    capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert manifest['schema_version'] == 'axiomzig.conformance.v4'
    assert manifest['manifest_hash_algorithm'] == 'sha256'
    assert manifest['source_digest_algorithm'] == 'sha256'
    assert len(manifest['workspace_source_digest']) == 64
    assert manifest['manifest_hash'] == _manifest_hash(manifest)
    assert sorted(manifest['module_graph']) == ['demo.main', 'demo.util']
    for item in manifest['module_graph'].values():
        assert len(item['source_digest']) == 64


def test_conform_manifest_hash_changes_when_workspace_source_changes(tmp_path: Path, capsys) -> None:
    util = _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\nfn helper() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { demo.util.helper(); return unit; }\n',
    )
    out1 = tmp_path / 'manifest1.json'
    out2 = tmp_path / 'manifest2.json'

    rc1 = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out1)])
    capsys.readouterr()
    manifest1 = json.loads(out1.read_text(encoding='utf-8'))

    util.write_text('module demo.util;\nfn helper() -> Unit effects() { var x = 1; return unit; }\n', encoding='utf-8')
    rc2 = main(['conform', str(main_file), '--module-root', str(tmp_path), '--out', str(out2)])
    capsys.readouterr()
    manifest2 = json.loads(out2.read_text(encoding='utf-8'))

    assert rc1 == 0
    assert rc2 == 0
    assert manifest1['workspace_source_digest'] != manifest2['workspace_source_digest']
    assert manifest1['manifest_hash'] != manifest2['manifest_hash']
    assert manifest1['module_graph']['demo.util']['source_digest'] != manifest2['module_graph']['demo.util']['source_digest']


def test_conform_public_only_exports_entry_module_surface_only(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\nfn helper() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { demo.util.helper(); return unit; }\n',
    )
    out = tmp_path / 'manifest.json'

    rc = main(['conform', str(main_file), '--module-root', str(tmp_path), '--public-only', '--out', str(out)])
    capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert manifest['export_scope'] == 'public_only'
    assert manifest['reachable_modules'] == ['demo.main', 'demo.util']
    assert manifest['exported_modules'] == ['demo.main']
    assert sorted(manifest['internal_signatures']) == ['demo.main']
    assert sorted(manifest['module_graph']) == ['demo.main', 'demo.util']


def test_conform_failure_manifest_v47_45_still_emits_hashes(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\nfn helper() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\nfn run() -> Unit effects() { return unit; }\n',
    )
    stale = _write(
        tmp_path / 'stale.json',
        json.dumps(
            {
                'module_path': 'demo.util',
                'functions': [
                    {
                        'name': 'demo.util.helper',
                        'param_types': [],
                        'return_type': 'I32',
                        'effects': [],
                        'ref_params': [],
                    }
                ],
            }
        ),
    )
    out = tmp_path / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--import-ownership',
        str(stale),
        '--out',
        str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 1
    assert 'conformance error:' in captured.err
    assert manifest['status'] == 'error'
    assert manifest['manifest_hash'] == _manifest_hash(manifest)
    assert len(manifest['workspace_source_digest']) == 64
