from axiomzig.checker import check_module
from axiomzig.interpreter import ImportStub, ImportWrite, IntVal, Interpreter, InterpreterUnsupportedError, TrapError, UnitVal
from axiomzig.ownership import analyze_ownership
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature, normalize_imported_contracts
from axiomzig.parser import parse_module


def _sig(name, *, param_types, return_type='Unit', ref_params=None, effects=None):
    return FunctionOwnershipSignature(
        name=name,
        param_types=list(param_types),
        return_type=return_type,
        ref_params=list(ref_params or []),
        effects=list(effects or []),
    )


def test_normalized_contract_is_shared_shape_for_imported_effects():
    sig = _sig(
        'demo.util.reopen_inner',
        param_types=['Ref<Holder>'],
        ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', {'inner': 'Open'})],
        effects=['protocol_step'],
    )
    contract = normalize_imported_contracts({sig.name: sig})[sig.name]
    assert contract.param_types == ('Ref<Holder>',)
    assert contract.paths_for_ref_param(0) == {('inner',)}
    assert contract.ref_effects[0].state == 'Open'


def test_malformed_imported_summary_is_a_clean_checker_diagnostic():
    src = 'module demo.main; import demo.util; fn run() -> Unit effects() { return unit; }'
    sig = _sig(
        'demo.util.bad',
        param_types=['Ref<Holder>'],
        ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', {'[*].inner': 'Open'})],
    )
    issues = check_module(parse_module(src), imported_signatures={sig.name: sig})
    messages = '\n'.join(issue.message for issue in issues)
    assert 'uses unsupported non-literal indexed path(s)' in messages


def test_ownership_and_runtime_consume_same_ref_holder_inner_summary():
    src = '''
module demo.main;
import demo.util;
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; }
fn run() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    demo.util.close_inner(borrow h);
    return unit;
}
'''
    sig = _sig(
        'demo.util.close_inner',
        param_types=['Ref<Holder>'],
        ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', {'inner': 'Closed'})],
        effects=['protocol_step'],
    )
    imported = {sig.name: sig}
    summary = analyze_ownership(parse_module(src), imported_signatures=imported)
    assert [i.message for i in summary.issues if i.level == 'error'] == []
    interp = Interpreter(parse_module(src), imported_signatures=imported, import_stubs={sig.name: ImportStub(return_value=UnitVal())})
    assert isinstance(interp.call_function(interp.functions['run'], []), UnitVal)


def test_stub_resource_write_must_match_normalized_summary_path():
    src = '''
module demo.main;
import demo.util;
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; }
fn run() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    demo.util.bad(borrow h);
    return unit;
}
'''
    sig = _sig('demo.util.bad', param_types=['Ref<Holder>'], ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', {})], effects=['protocol_step'])
    # Ordinary scalar-like writes remain allowed, but resource/ownership writes must be declared.
    from axiomzig.interpreter import ResourceVal
    interp = Interpreter(parse_module(src), imported_signatures={sig.name: sig}, import_stubs={
        sig.name: ImportStub(writes=[ImportWrite(ref_param_index=0, path=('inner',), value=ResourceVal('File','FileProtocol','Open', {'fd': IntVal(2, width=32, signed=True)}))], return_value=UnitVal())
    })
    try:
        interp.call_function(interp.functions['run'], [])
    except (TrapError, InterpreterUnsupportedError) as exc:
        reason = str(exc) if isinstance(exc, InterpreterUnsupportedError) else exc.reason
        assert 'cannot overwrite non-terminal resource' in reason or 'without a matching imported ownership summary' in reason
    else:
        raise AssertionError('expected resource write without summary to trap')
