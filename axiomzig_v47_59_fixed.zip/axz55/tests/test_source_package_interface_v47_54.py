from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main
from axiomzig.formatter import format_module
from axiomzig.parser import parse_module


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def test_parser_and_formatter_roundtrip_source_public_api_annotations() -> None:
    text = '''module demo.main;

@deprecated(reason="use demo.main.run", replacement="demo.main.run")
@since("0.48.0")
pub fn old_run() -> Unit effects() {
    return unit;
}

@experimental
pub fn run() -> Unit effects() {
    return unit;
}
'''
    module = parse_module(text)
    old_run = module.decls[0]
    run = module.decls[1]

    assert old_run.is_public is True
    assert old_run.stability == 'deprecated'
    assert old_run.since == '0.48.0'
    assert old_run.deprecated_reason == 'use demo.main.run'
    assert old_run.replacement == 'demo.main.run'
    assert run.is_public is True
    assert run.stability == 'experimental'

    assert format_module(module) == text


def test_emit_package_interface_derives_public_surface_and_preserves_base_policy(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        'module demo.util;\n\n@experimental\npub fn helper() -> Unit effects() { return unit; }\nfn hidden() -> Unit effects() { return unit; }\n',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\nimport demo.util;\n\npub fn run() -> Unit effects() { demo.util.helper(); return unit; }\n@deprecated(reason="use demo.main.run", replacement="demo.main.run")\n@since("0.48.0")\npub fn old_run() -> Unit effects() { return unit; }\n',
    )
    base_interface = _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'package_name': 'demo_pkg',
                'package_version': '2.1.0',
                'public_modules': ['stale.module'],
                'public_functions': {'stale.module': ['old']},
                'compatibility': {
                    'language_version': 'v1.1',
                    'dependency_version_ranges': {'dep': '^1.2.0'},
                },
            }
        ),
    )
    out = tmp_path / 'emitted.json'

    rc = main([
        'emit-package-interface',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(base_interface),
        '--out',
        str(out),
    ])
    captured = capsys.readouterr()
    rendered = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err == ''
    assert rendered == {
        'schema_version': 'axiomzig.package_interface.v1',
        'package_name': 'demo_pkg',
        'package_version': '2.1.0',
        'public_modules': ['demo.main', 'demo.util'],
        'public_functions': {
            'demo.main': ['demo.main.old_run', 'demo.main.run'],
            'demo.util': ['demo.util.helper'],
        },
        'compatibility': {
            'language_version': 'v1.1',
            'dependency_version_ranges': {'dep': '^1.2.0'},
        },
        'public_function_metadata': {
            'demo.main': {
                'demo.main.old_run': {
                    'stability': 'deprecated',
                    'since': '0.48.0',
                    'deprecated_reason': 'use demo.main.run',
                    'replacement': 'demo.main.run',
                },
            },
            'demo.util': {
                'demo.util.helper': {
                    'stability': 'experimental',
                },
            },
        },
    }


def test_check_package_interface_sync_detects_stale_artifact_then_passes_after_emit(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\n\npub fn run() -> Unit effects() { return unit; }\n',
    )
    interface_path = _write(
        tmp_path / 'axiomzig.package.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.package_interface.v1',
                'public_modules': ['demo.main'],
                'public_functions': {'demo.main': ['demo.main.old_run']},
            }
        ),
    )

    rc = main([
        'check-package-interface-sync',
        str(tmp_path / 'demo' / 'main.az'),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(interface_path),
    ])
    captured = capsys.readouterr()
    assert rc == 1
    assert 'out of sync with source-declared public API' in captured.err

    rc = main([
        'emit-package-interface',
        str(tmp_path / 'demo' / 'main.az'),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(interface_path),
        '--out',
        str(interface_path),
    ])
    capsys.readouterr()
    assert rc == 0

    rc = main([
        'check-package-interface-sync',
        str(tmp_path / 'demo' / 'main.az'),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(interface_path),
    ])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.err == ''


def test_emit_package_interface_rejects_lifecycle_metadata_on_non_public_fn(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        'module demo.main;\n\n@experimental\nfn hidden() -> Unit effects() { return unit; }\n',
    )

    rc = main([
        'emit-package-interface',
        str(main_file),
        '--module-root',
        str(tmp_path),
    ])
    captured = capsys.readouterr()
    assert rc == 1
    assert 'source API metadata on non-public function demo.main.hidden requires pub' in captured.err
