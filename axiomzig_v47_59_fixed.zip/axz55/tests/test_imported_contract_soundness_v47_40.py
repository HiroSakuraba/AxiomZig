from axiomzig.interpreter import BoolVal, ImportStub, ImportWrite, IntVal, Interpreter, InterpreterUnsupportedError, ResourceVal, UnitVal
from axiomzig.ownership import analyze_ownership
from axiomzig.ownership_signatures import (
    FunctionOwnershipSignature,
    RefParamOwnershipSignature,
    canonical_path_to_display_text,
    normalize_imported_contracts,
)
from axiomzig.parser import parse_module


def _sig(name='demo.util.touch', *, effects_map=None):
    return FunctionOwnershipSignature(
        name=name,
        param_types=['Ref<Holder>'],
        return_type='Unit',
        effects=['protocol_step'],
        ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', dict(effects_map or {}))],
    )


def _module(call='demo.util.touch(borrow h);'):
    return parse_module(f'''
module demo.main;
import demo.util;
protocol FileProtocol {{ states {{ Open, Closed }} init Open; terminal {{ Closed }} transitions {{ close: Open -> Closed; reopen: Closed -> Open; }} }}
resource File {{ protocol: FileProtocol; fields {{ fd: I32; }} }}
struct Holder {{ inner: File; other: File; }}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    if (flag) {{
        {call}
    }} else {{
        h.inner.close();
    }}
    return unit;
}}
''')


def test_canonical_path_normalizes_bracket_and_dot_index_to_one_representation():
    sig = _sig(effects_map={'items[0].inner': 'Closed'})
    contract = normalize_imported_contracts({sig.name: sig})[sig.name]
    effect = contract.ref_effects[0]
    assert effect.path == 'items.0.inner'
    assert effect.path_parts == ('items', 0, 'inner')
    assert canonical_path_to_display_text(effect.canonical_path) == 'items[0].inner'


def test_overlapping_imported_paths_are_rejected_during_normalization():
    sig = _sig(effects_map={'inner': 'Closed', 'inner.fd': 'Closed'})
    try:
        normalize_imported_contracts({sig.name: sig})
    except ValueError as exc:
        assert 'overlapping ownership summaries' in str(exc)
    else:
        raise AssertionError('expected overlapping imported ownership paths to be rejected')


def test_conflicting_canonical_imported_paths_are_rejected():
    # These two keys intentionally spell the same path two ways after canonicalization.
    sig = _sig(effects_map={'items.0.inner': 'Closed', 'items[0].inner': 'Open'})
    try:
        normalize_imported_contracts({sig.name: sig})
    except ValueError as exc:
        assert 'conflicting summaries' in str(exc)
    else:
        raise AssertionError('expected conflicting canonical summaries to be rejected')


def test_stub_extra_resource_effect_outside_declared_contract_is_rejected():
    sig = _sig(effects_map={'inner': 'Closed'})
    bad_stub = ImportStub(
        writes=[ImportWrite(
            ref_param_index=0,
            path=('other',),
            value=ResourceVal('File', 'FileProtocol', 'Closed', {'fd': IntVal(3, width=32, signed=True)}),
            allow_live_resource_replace=True,
        )],
        return_value=UnitVal(),
    )
    interp = Interpreter(_module(), imported_signatures={sig.name: sig}, import_stubs={sig.name: bad_stub})
    try:
        interp.call_function(interp.functions['run'], [BoolVal(True)])
    except InterpreterUnsupportedError as exc:
        assert 'without a matching imported ownership summary' in str(exc)
    else:
        raise AssertionError('expected undeclared imported resource write to be rejected')


def test_stub_declared_effect_state_is_audited_after_write():
    sig = _sig(effects_map={'inner': 'Closed'})
    bad_stub = ImportStub(
        writes=[ImportWrite(
            ref_param_index=0,
            path=('inner',),
            value=ResourceVal('File', 'FileProtocol', 'Open', {'fd': IntVal(3, width=32, signed=True)}),
            allow_live_resource_replace=True,
        )],
        return_value=UnitVal(),
    )
    interp = Interpreter(_module(), imported_signatures={sig.name: sig}, import_stubs={sig.name: bad_stub})
    try:
        interp.call_function(interp.functions['run'], [BoolVal(True)])
    except InterpreterUnsupportedError as exc:
        assert 'declared summary requires Closed' in str(exc)
    else:
        raise AssertionError('expected declared-state mismatch to be rejected')


def test_imported_effect_participates_in_branch_join_as_cfg_transition():
    src = '''
module demo.main;
import demo.util;
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; }
fn run(flag: Bool) -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    if (flag) {
        demo.util.touch(borrow h);
    } else {
        h.inner.close();
    }
    return unit;
}
'''
    sig = _sig(effects_map={'inner': 'Closed'})
    summary = analyze_ownership(parse_module(src), imported_signatures={sig.name: sig})
    errors = [issue.message for issue in summary.issues if issue.level == 'error']
    assert errors == []


def test_aliased_mut_refs_to_same_import_remain_rejected():
    src = '''
module demo.main;
import demo.util;
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
fn run() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 }, other: File { fd: 2 } };
    demo.util.two(borrow h, borrow h);
    return unit;
}
'''
    sig = FunctionOwnershipSignature(
        name='demo.util.two',
        param_types=['Ref<Holder>', 'Ref<Holder>'],
        return_type='Unit',
        effects=['protocol_step'],
        ref_params=[
            RefParamOwnershipSignature(0, 'mut', 'Holder', {'inner': 'Closed'}),
            RefParamOwnershipSignature(1, 'mut', 'Holder', {'other': 'Closed'}),
        ],
    )
    summary = analyze_ownership(parse_module(src), imported_signatures={sig.name: sig})
    assert any('aliased reference h' in issue.message for issue in summary.issues)
