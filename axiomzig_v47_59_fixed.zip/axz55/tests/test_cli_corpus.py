from __future__ import annotations

from pathlib import Path

from axiomzig.cli import main
from axiomzig.formatter import format_module
from axiomzig.parser import parse_module


ALL_PARSE_BASED_COMMANDS = [
    "parse",
    "resolve",
    "elaborate",
    "typecheck",
    "lower",
    "cfg",
    "owncheck",
    "format",
    "check",
]

GOOD_ANALYSIS_COMMANDS = [
    "parse",
    "resolve",
    "elaborate",
    "typecheck",
    "lower",
    "cfg",
    "owncheck",
]
EXAMPLE_FILES = sorted(Path("examples").glob("*.az"))


def test_cli_good_examples_accept_full_command_matrix(capsys) -> None:
    assert EXAMPLE_FILES
    for example in EXAMPLE_FILES:
        rc = main(["lex", str(example)])
        captured = capsys.readouterr()
        assert rc == 0, ("lex", example)
        assert captured.out.strip() != ""
        assert captured.err == ""

        for command in GOOD_ANALYSIS_COMMANDS:
            rc = main([command, str(example)])
            captured = capsys.readouterr()
            assert rc == 0, (command, example)
            assert captured.out.strip().startswith("{"), (command, example)
            assert captured.err == ""

        rc = main(["format", str(example)])
        captured = capsys.readouterr()
        assert rc == 0, ("format", example)
        assert captured.err == ""
        expected = format_module(parse_module(example.read_text(encoding="utf-8")))
        assert captured.out == expected

        rc = main(["format", "--check", str(example)])
        captured = capsys.readouterr()
        assert rc == 0, ("format --check", example)
        assert captured.out == ""
        assert captured.err == ""

        rc = main(["check", str(example)])
        captured = capsys.readouterr()
        assert rc == 0, ("check", example)
        assert "Traceback" not in captured.err



def test_cli_malformed_corpus_fails_cleanly_across_commands(tmp_path, capsys) -> None:
    bad_parse = tmp_path / "bad_parse.az"
    bad_parse.write_text(
        "module demo.bad;\nfn main() -> Unit effects() { let x = ; }\n",
        encoding="utf-8",
    )
    bad_lex = tmp_path / "bad_lex.az"
    bad_lex.write_text(
        'module demo.bad;\nfn main() -> Unit effects() { let s = "unterminated; }\n',
        encoding="utf-8",
    )

    rc = main(["lex", str(bad_parse)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.out.strip() != ""
    assert captured.err == ""

    for command in ALL_PARSE_BASED_COMMANDS:
        rc = main([command, str(bad_parse)])
        captured = capsys.readouterr()
        assert rc == 1, (command, bad_parse)
        assert captured.out == ""
        assert "parse error:" in captured.err
        assert "Traceback" not in captured.err

    for command in ["lex", *ALL_PARSE_BASED_COMMANDS]:
        rc = main([command, str(bad_lex)])
        captured = capsys.readouterr()
        assert rc == 1, (command, bad_lex)
        assert captured.out == ""
        assert "parse error:" in captured.err
        assert "Traceback" not in captured.err



def test_cli_checker_error_corpus_has_stable_behavior(tmp_path, capsys) -> None:
    bad_check = tmp_path / "bad_check.az"
    bad_check.write_text(
        """
module demo.badcheck;

fn bad() -> Unit effects() {
    let x: Bool = 1;
    return unit;
}
""",
        encoding="utf-8",
    )

    for command in ["parse", "resolve", "elaborate", "typecheck", "lower", "cfg", "owncheck", "format"]:
        rc = main([command, str(bad_check)])
        captured = capsys.readouterr()
        assert rc == 0, command
        assert "Traceback" not in captured.err

    rc = main(["format", "--check", str(bad_check)])
    captured = capsys.readouterr()
    assert rc == 1
    assert captured.out == ""
    assert captured.err == ""

    rc = main(["check", str(bad_check)])
    captured = capsys.readouterr()
    assert rc == 1
    assert "error:" in captured.out
    assert "Traceback" not in captured.err



def test_cli_in_place_format_normalizes_every_example(tmp_path, capsys) -> None:
    assert EXAMPLE_FILES
    for example in EXAMPLE_FILES:
        src = example.read_text(encoding="utf-8")
        path = tmp_path / example.name
        path.write_text(src, encoding="utf-8")
        rc = main(["format", "--in-place", str(path)])
        captured = capsys.readouterr()
        assert rc == 0, example
        assert captured.out == ""
        assert captured.err == ""
        reparsed = parse_module(path.read_text(encoding="utf-8"))
        assert path.read_text(encoding="utf-8") == format_module(reparsed)


def test_cli_range_for_source_runs_cleanly_through_semantic_commands(tmp_path, capsys) -> None:
    path = tmp_path / "range_for.az"
    path.write_text(
        """
module demo.rangefor;

fn main() -> Unit effects() {
    var total: I64 = 0;
    for (i: I64 in 0..4) {
        total = total + i;
    }
    return unit;
}
""",
        encoding="utf-8",
    )

    for command in GOOD_ANALYSIS_COMMANDS + ["check"]:
        rc = main([command, str(path)])
        captured = capsys.readouterr()
        assert rc == 0, (command, path)
        assert "Traceback" not in captured.err


def test_cli_catch_source_runs_cleanly_through_semantic_commands(tmp_path, capsys) -> None:
    path = tmp_path / "catch_expr.az"
    path.write_text(
        """
module demo.catchcli;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8 effects(error) {
    return parse_one(s) catch 0;
}
""",
        encoding="utf-8",
    )
    from axiomzig.cli import main
    for command in ["parse", "resolve", "elaborate", "typecheck", "lower", "cfg", "owncheck", "format"]:
        capsys.readouterr()
        rc = main([command, str(path)])
        captured = capsys.readouterr()
        assert rc == 0, (command, captured.out, captured.err)
