from __future__ import annotations

from copy import deepcopy

from axiomzig.interpreter import ImportStub, ImportWrite, Interpreter, TrapError, UnitVal
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature
from axiomzig.parser import parse_module


def _sig(name: str, *, param_types: list[str], return_type: str = "Unit", ref_params=None, effects=None) -> FunctionOwnershipSignature:
    return FunctionOwnershipSignature(
        name=name,
        param_types=param_types,
        return_type=return_type,
        ref_params=list(ref_params or []),
        effects=list(effects or []),
    )


def _holder_source(body: str, return_type: str = "Unit") -> str:
    return f"""
module demo.main;
import demo.util;

error_set E {{ Bad; }}

protocol FileProtocol {{
    states {{ Open, Closed }}
    init Open;
    terminal {{ Closed }}
    transitions {{
        close: Open -> Closed;
    }}
}}

resource File {{
    protocol: FileProtocol;
    fields {{
        fd: I32;
    }}
}}

struct Holder {{
    inner: File;
}}

fn make_holder() -> Holder effects() {{
    return Holder {{ inner: File {{ fd: 7 }} }};
}}

{body}
"""


def test_imported_close_causes_errdefer_cleanup_to_be_skipped() -> None:
    src = _holder_source(
        """
fn run() -> Unit!E effects(error, protocol_step) {
    var h = make_holder();
    errdefer h.inner.close();
    demo.util.close_inner(borrow h);
    return E.Bad;
}
"""
    )
    sig = _sig(
        "demo.util.close_inner",
        param_types=["Ref<Holder>"],
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Holder", effects={"inner": "Closed"})],
        effects=["protocol_step"],
        return_type="Unit",
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: ImportStub(return_value=UnitVal())},
    )

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "E.Bad"


def test_imported_close_causes_normal_defer_cleanup_to_be_skipped() -> None:
    src = _holder_source(
        """
fn run() -> Unit effects(protocol_step) {
    var h = make_holder();
    defer h.inner.close();
    demo.util.close_inner(borrow h);
    return unit;
}
"""
    )
    sig = _sig(
        "demo.util.close_inner",
        param_types=["Ref<Holder>"],
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Holder", effects={"inner": "Closed"})],
        effects=["protocol_step"],
        return_type="Unit",
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: ImportStub(return_value=UnitVal())},
    )

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "unit"


def test_imported_reinitialization_updates_defer_cleanup_target() -> None:
    src = _holder_source(
        """
fn run() -> Unit effects(protocol_step) {
    var h = make_holder();
    defer h.inner.close();
    demo.util.recycle_inner(borrow h, 9);
    return unit;
}
"""
    )
    sig = _sig(
        "demo.util.recycle_inner",
        param_types=["Ref<Holder>", "I32"],
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Holder", effects={"inner": "Moved"})],
        effects=["protocol_step"],
        return_type="Unit",
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: ImportStub(return_value=UnitVal())},
    )
    replacement = deepcopy(interp.call_function(interp.functions["make_holder"], []).fields["inner"])
    replacement.fields["fd"].value = 9
    interp.import_stubs[sig.name].writes = [
        ImportWrite(
            ref_param_index=0,
            path=("inner",),
            value=replacement,
        )
    ]

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "unit"


def test_defer_without_duplicate_suppression_still_traps_on_double_close_if_resource_remains_closed_nonterminal() -> None:
    src = _holder_source(
        """
protocol AltFileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Open }
    transitions {
        close: Open -> Closed;
        reopen: Closed -> Open;
    }
}

resource AltFile {
    protocol: AltFileProtocol;
    fields {
        fd: I32;
    }
}

struct AltHolder {
    inner: AltFile;
}

fn make_alt_holder() -> AltHolder effects() {
    return AltHolder { inner: AltFile { fd: 1 } };
}

fn run() -> Unit effects(protocol_step) {
    var h = make_alt_holder();
    defer h.inner.close();
    h.inner.close();
    return unit;
}
"""
    )
    interp = Interpreter(parse_module(src))

    try:
        interp.call_function(interp.functions["run"], [])
    except TrapError as exc:
        assert exc.reason == "invalid protocol transition close from Closed"
    else:
        raise AssertionError("expected second close to trap when the protocol state is not terminal")


def test_local_wrapper_cleanup_is_skipped_after_resource_already_closed() -> None:
    src = _holder_source(
        """
fn cleanup_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}

fn run() -> Unit effects(protocol_step) {
    var h = make_holder();
    defer cleanup_inner(borrow h);
    h.inner.close();
    return unit;
}
"""
    )
    interp = Interpreter(parse_module(src))

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "unit"


def test_imported_wrapper_cleanup_is_skipped_after_resource_already_closed() -> None:
    src = _holder_source(
        """
fn run() -> Unit effects(protocol_step) {
    var h = make_holder();
    defer demo.util.cleanup_inner(borrow h);
    h.inner.close();
    return unit;
}
"""
    )
    sig = _sig(
        "demo.util.cleanup_inner",
        param_types=["Ref<Holder>"],
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Holder", effects={"inner": "Closed"})],
        effects=["protocol_step"],
        return_type="Unit",
    )
    interp = Interpreter(
        parse_module(src),
        imported_signatures={sig.name: sig},
        import_stubs={sig.name: ImportStub(return_value=UnitVal())},
    )

    result = interp.call_function(interp.functions["run"], [])

    assert interp.render_value(result) == "unit"


def test_local_wrapper_cleanup_is_not_suppressed_for_matching_nonterminal_state() -> None:
    src = _holder_source(
        """
protocol AltFileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Open }
    transitions {
        close: Open -> Closed;
        reopen: Closed -> Open;
    }
}

resource AltFile {
    protocol: AltFileProtocol;
    fields {
        fd: I32;
    }
}

struct AltHolder {
    inner: AltFile;
}

fn make_alt_holder() -> AltHolder effects() {
    return AltHolder { inner: AltFile { fd: 1 } };
}

fn cleanup_inner(h: Ref<AltHolder>) -> Unit effects(protocol_step) {
    h.inner.close();
    return unit;
}

fn run() -> Unit effects(protocol_step) {
    var h = make_alt_holder();
    defer cleanup_inner(borrow h);
    h.inner.close();
    return unit;
}
"""
    )
    interp = Interpreter(parse_module(src))

    try:
        interp.call_function(interp.functions["run"], [])
    except TrapError as exc:
        assert exc.reason == "invalid protocol transition close from Closed"
    else:
        raise AssertionError("expected wrapper cleanup to execute and trap for nonterminal duplicate close")


def test_imported_cleanup_helper_without_stub_traps_even_when_target_already_closed() -> None:
    src = _holder_source(
        """
fn run() -> Unit effects(protocol_step) {
    var h = make_holder();
    defer demo.util.cleanup_inner(borrow h);
    h.inner.close();
    return unit;
}
"""
    )
    sig = _sig(
        "demo.util.cleanup_inner",
        param_types=["Ref<Holder>"],
        ref_params=[RefParamOwnershipSignature(param_index=0, mode="mut", type_name="Holder", effects={"inner": "Closed"})],
        effects=["protocol_step"],
        return_type="Unit",
    )
    interp = Interpreter(parse_module(src), imported_signatures={sig.name: sig})

    try:
        interp.call_function(interp.functions["run"], [])
    except TrapError as exc:
        assert exc.reason == "imported cleanup helper demo.util.cleanup_inner has ownership signature but no runtime stub"
    else:
        raise AssertionError("expected opaque imported cleanup helper without a stub to trap")


def test_imported_cleanup_helper_without_signature_traps_even_with_stub() -> None:
    src = _holder_source(
        """
fn run() -> Unit effects(protocol_step) {
    var h = make_holder();
    defer demo.util.cleanup_inner(borrow h);
    h.inner.close();
    return unit;
}
"""
    )
    interp = Interpreter(
        parse_module(src),
        import_stubs={"demo.util.cleanup_inner": ImportStub(return_value=UnitVal())},
    )

    try:
        interp.call_function(interp.functions["run"], [])
    except TrapError as exc:
        assert exc.reason == "imported cleanup helper demo.util.cleanup_inner has no ownership signature"
    else:
        raise AssertionError("expected opaque imported cleanup helper without a signature to trap")
