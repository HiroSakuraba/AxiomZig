from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from axiomzig.formatter import format_module
from axiomzig.parser import parse_module

PROBES = sorted(Path("probes").rglob("*.az"))


def parse_header(path: Path) -> dict[str, list[str] | str]:
    meta: dict[str, list[str] | str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.startswith("// "):
            break
        body = line[3:]
        if ": " not in body:
            continue
        key, value = body.split(": ", 1)
        if key == "CHECK":
            meta.setdefault(key, [])
            assert isinstance(meta[key], list)
            meta[key].append(value)
        else:
            meta[key] = value
    return meta


def run_cli(command: str, path: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "axiomzig.cli", command, str(path)],
        capture_output=True,
        text=True,
        timeout=20,
    )


def test_probe_corpus_headers_are_present() -> None:
    assert PROBES
    for path in PROBES:
        meta = parse_header(path)
        assert meta.get("PROBE") == path.stem
        assert meta.get("AREA")
        assert meta.get("EXPECT")


def test_probe_corpus_behaves_as_expected() -> None:
    assert PROBES
    for path in PROBES:
        meta = parse_header(path)
        expect = meta["EXPECT"]
        checks = meta.get("CHECK", [])
        assert isinstance(expect, str)
        assert isinstance(checks, list)

        if expect == "ok":
            proc = run_cli("check", path)
            assert proc.returncode == 0, (path, proc.stdout, proc.stderr)
            assert "Traceback" not in proc.stdout
            assert "Traceback" not in proc.stderr
        elif expect == "ownership_error":
            proc = run_cli("check", path)
            assert proc.returncode == 1, (path, proc.stdout, proc.stderr)
            assert proc.stderr == "", (path, proc.stderr)
            assert "Traceback" not in proc.stdout
            for needle in checks:
                assert needle in proc.stdout, (path, needle, proc.stdout)
        elif expect == "type_error":
            proc = run_cli("check", path)
            assert proc.returncode == 1, (path, proc.stdout, proc.stderr)
            assert proc.stderr == "", (path, proc.stderr)
            assert "Traceback" not in proc.stdout
            for needle in checks:
                assert needle in proc.stdout, (path, needle, proc.stdout)
        elif expect == "parse_error":
            proc = run_cli("parse", path)
            assert proc.returncode == 1, (path, proc.stdout, proc.stderr)
            assert proc.stdout == ""
            assert "parse error:" in proc.stderr, (path, proc.stderr)
            assert "Traceback" not in proc.stderr
            for needle in checks:
                assert needle in proc.stderr, (path, needle, proc.stderr)
        elif expect == "formatter_fixed_point":
            src = path.read_text(encoding="utf-8")
            once = format_module(parse_module(src))
            twice = format_module(parse_module(once))
            assert once == twice, path
        else:
            raise AssertionError(f"unsupported EXPECT in {path}: {expect}")
