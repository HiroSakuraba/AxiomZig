from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main

COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _build_dependency_manifest(dep_root: Path, capsys) -> Path:
    dep_file = _write(
        dep_root / 'dep' / 'api.az',
        f'''module dep.api;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    out = dep_root / 'dep_manifest.json'
    rc = main(['conform', str(dep_file), '--module-root', str(dep_root), '--public-only', '--out', str(out)])
    capsys.readouterr()
    assert rc == 0
    manifest = json.loads(out.read_text(encoding='utf-8'))
    assert manifest['exported_modules'] == ['dep.api']
    return out


def test_conform_consumes_dependency_manifest_without_dependency_source(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        f'''module app.main;
import dep.api;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ dep.api.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )
    out = consumer_root / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
        '--out',
        str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err.strip() == ''
    assert manifest['status'] == 'ok'
    assert manifest['dependency_modules'] == ['dep.api']
    assert manifest['dependency_imports'] == [
        {'imported_by': ['app.main'], 'kind': 'dependency_manifest', 'name': 'dep.api'}
    ]
    assert manifest['external_imports'] == []
    assert manifest['module_graph']['app.main']['dependency_imports'] == ['dep.api']
    assert manifest['module_graph']['app.main']['external_imports'] == []


def test_owncheck_uses_dependency_manifest_signatures_without_runtime_stub(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        f'''module app.main;
import dep.api;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ dep.api.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
    ])
    captured = capsys.readouterr()
    payload = json.loads(captured.out)

    assert rc == 0
    assert captured.err.strip() == ''
    assert payload['issues'] == []


def test_invalid_dependency_manifest_status_is_rejected(tmp_path: Path, capsys) -> None:
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.api;\nfn run() -> Unit effects() { return unit; }\n',
    )
    bad_manifest = _write(
        tmp_path / 'bad_dep_manifest.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.conformance.v3',
                'package_name': 'bad',
                'package_version': '0',
                'package_id': 'bad@0',
                'manifest_hash_algorithm': 'sha256',
                'manifest_hash': 'deadbeef',
                'status': 'error',
                'internal_signatures': {},
                'exported_modules': ['dep.api'],
            }
        ),
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(bad_manifest),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert "dependency manifest status must be 'ok'" in captured.err


def test_dependency_manifest_hash_mismatch_is_rejected(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    payload = json.loads(dep_manifest.read_text(encoding='utf-8'))
    payload['entry_module'] = 'dep.tampered'
    dep_manifest.write_text(json.dumps(payload), encoding='utf-8')

    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.api;\nfn run() -> Unit effects() { return unit; }\n',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'dependency manifest hash does not match manifest body' in captured.err


def test_public_only_dependency_manifest_exposes_only_exported_modules(tmp_path: Path, capsys) -> None:
    dep_root = tmp_path / 'dep_workspace'
    _write(dep_root / 'dep' / 'helper.az', 'module dep.helper;\nfn helper() -> Unit effects() { return unit; }\n')
    dep_file = _write(
        dep_root / 'dep' / 'api.az',
        'module dep.api;\nimport dep.helper;\nfn run() -> Unit effects() { dep.helper.helper(); return unit; }\n',
    )
    dep_manifest = dep_root / 'dep_manifest.json'
    rc_dep = main(['conform', str(dep_file), '--module-root', str(dep_root), '--public-only', '--out', str(dep_manifest)])
    capsys.readouterr()
    assert rc_dep == 0

    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.helper;\nfn run() -> Unit effects() { return unit; }\n',
    )

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
    ])
    captured = capsys.readouterr()
    manifest = json.loads((consumer_root / 'manifest.json').read_text(encoding='utf-8')) if (consumer_root / 'manifest.json').exists() else None

    # dep.helper is not exported by the dependency manifest, so it remains an opaque external boundary.
    assert rc == 0
    assert 'conformance error:' not in captured.err
    # no output file was requested; inspect stdout JSON instead
    manifest = json.loads(captured.out)
    assert manifest['dependency_modules'] == ['dep.api']
    assert manifest['dependency_imports'] == []
    assert manifest['external_imports'] == [
        {'has_contract': False, 'imported_by': ['app.main'], 'kind': 'opaque_external', 'name': 'dep.helper'}
    ]
