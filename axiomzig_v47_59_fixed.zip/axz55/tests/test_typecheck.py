from axiomzig.parser import parse_module
from axiomzig.typecheck import typecheck_module


def messages(summary):
    return [issue.message for issue in summary.issues]


def test_typecheck_normalizes_option_spellings() -> None:
    module = parse_module(
        """
module demo.optnorm;

fn echo(x: I64?) -> Option<I64> effects() {
    return x;
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []
    fn = summary.functions[0]
    assert fn.declared_return_type == "I64?"


def test_typecheck_rejects_call_arity_and_argument_type_mismatch() -> None:
    module = parse_module(
        """
module demo.calls;

fn add(x: I64, y: I64) -> I64 effects() {
    return x + y;
}

fn bad() -> I64 effects() {
    return add(true);
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "call to add expects 2 arguments but got 1" in joined
    assert "call to add argument 1 expects I64 but got Bool" in joined


def test_typecheck_requires_option_match_exhaustiveness() -> None:
    module = parse_module(
        """
module demo.matches;

fn bad(x: Option<I64>) -> I64 effects() {
    return match x {
        some(v) -> v,
    };
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "match is not exhaustive; missing none" in joined


def test_typecheck_requires_per_tag_error_match_exhaustiveness() -> None:
    module = parse_module(
        """
module demo.resultmatches;

error_set ParseError {
    Empty;
    BadDigit;
    Overflow;
}

fn code(x: I64!ParseError) -> I64 effects(error) {
    return match x {
        ok(v) -> v,
        error(ParseError.Empty) -> 1,
        error(ParseError.BadDigit) -> 2,
    };
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "match is not exhaustive; missing error(ParseError.Overflow)" in joined


def test_typecheck_accepts_result_match_with_error_wildcard() -> None:
    module = parse_module(
        """
module demo.resultmatchwild;

error_set ParseError {
    Empty;
    BadDigit;
}

fn code(x: I64!ParseError) -> I64 effects(error) {
    return match x {
        ok(v) -> v,
        error(_) -> 255,
    };
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []


def test_typecheck_rejects_incompatible_match_arm_types() -> None:
    module = parse_module(
        """
module demo.badmatchtypes;

fn bad(x: Bool) -> I64 effects() {
    return match x {
        true -> 1,
        false -> false,
    };
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "match arms have incompatible types" in joined


def test_typecheck_records_typed_calls_and_match_type() -> None:
    module = parse_module(
        """
module demo.typed;

error_set ParseError {
    Empty;
}

enum Status {
    Ok;
}

fn parse_one(s: Str) -> Status!ParseError effects(error) {
    return match s {
        "" -> ParseError.Empty,
        _ -> Status.Ok,
    };
}

fn main(s: Str) -> Status!ParseError effects(error) {
    return parse_one(s);
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []
    main = next(fn for fn in summary.functions if fn.name == "main")
    assert main.calls[0].callee == "parse_one"
    assert main.calls[0].return_type == "Status!ParseError"
    parse_one = next(fn for fn in summary.functions if fn.name == "parse_one")
    match_records = [rec for rec in parse_one.exprs if rec.text.startswith("match s")]
    assert match_records
    assert match_records[-1].type_text == "Status!ParseError"


def test_typecheck_accepts_borrow_for_refconst_parameter() -> None:
    module = parse_module(
        """
module demo.borrowref;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn peek(f: RefConst<File>) -> I32 effects() {
    return f.fd;
}

fn main(f: File) -> I32 effects() {
    return peek(borrow f);
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []


def test_typecheck_accepts_integer_range_for_for_loop() -> None:
    module = parse_module(
        """
module demo.rangefor;

fn main() -> Unit effects() {
    var total: I64 = 0;
    for (i: I64 in 0..10) {
        total = total + i;
    }
    return unit;
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []


def test_typecheck_rejects_assignment_through_immutable_reference() -> None:
    module = parse_module(
        """
module demo.refconst_assign_bad;

resource File {
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad() -> Unit effects() {
    let f = make_file();
    let c: RefConst<File> = borrow f;
    c.fd = 1;
    return unit;
}
"""
    )
    summary = typecheck_module(module)
    assert 'cannot assign through immutable reference c' in "\n".join(messages(summary))


def test_typecheck_rejects_field_assignment_rooted_at_immutable_binding() -> None:
    module = parse_module(
        """
module demo.immutable_root_assign_bad;

resource File {
    fields {
        fd: I32;
    }
}

struct Holder {
    inner: File;
}

fn make_holder() -> Holder effects() {
    return Holder { inner: File { fd: 0 } };
}

fn bad() -> Unit effects() {
    let h = make_holder();
    h.inner = File { fd: 1 };
    return unit;
}
"""
    )
    summary = typecheck_module(module)
    assert 'assignment target rooted at h is not mutable' in "\n".join(messages(summary))

from axiomzig.ownership import export_ownership_signatures


def test_typecheck_imported_call_uses_exported_param_and_effect_signatures() -> None:
    util_module = parse_module(
        '''
module demo.util;

fn import_add(x: I64, y: I64) -> I64 effects(io) {
    return x + y;
}
'''
    )
    imported = {fn.name: fn for fn in export_ownership_signatures(util_module).functions}
    main_module = parse_module(
        '''
module demo.main;
import demo.util;

fn bad() -> I64 effects() {
    return util.import_add(true, 2);
}
'''
    )
    summary = typecheck_module(main_module, imported_signatures=imported)
    joined = "\n".join(messages(summary))
    assert 'call to demo.util.import_add argument 1 expects I64 but got Bool' in joined
    assert "call to demo.util.import_add requires effects ['io'] not contained in caller bad effects []" in joined


def test_exported_ownership_signature_carries_typing_metadata() -> None:
    module = parse_module(
        '''
module demo.meta;

resource File {
    fields {
        fd: I32;
    }
}

fn take_ref(f: RefConst<File>) -> I32 effects(io) {
    return f.fd;
}
'''
    )
    bundle = export_ownership_signatures(module)
    sig = next(fn for fn in bundle.functions if fn.name == 'demo.meta.take_ref')
    assert sig.param_types == ['RefConst<File>']
    assert sig.return_type == 'I32'
    assert sig.effects == ['io']


def test_typecheck_accepts_catch_on_result_expression() -> None:
    module = parse_module(
        """
module demo.catchok;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8 effects(error) {
    return parse_one(s) catch 0;
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []


def test_typecheck_rejects_catch_on_non_result_expression() -> None:
    module = parse_module(
        """
module demo.catchbad;

fn main() -> I64 effects() {
    return 1 catch 0;
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "catch operator expects a result type, got I64" in joined


def test_typecheck_rejects_catch_with_wrong_fallback_type() -> None:
    module = parse_module(
        """
module demo.catchfallback;

error_set ParseError {
    Empty;
}

fn parse_one(s: Str) -> U8!ParseError effects(error) {
    return ParseError.Empty;
}

fn main(s: Str) -> U8 effects(error) {
    return parse_one(s) catch false;
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "catch fallback expects U8 but got Bool" in joined


def test_typecheck_records_type_facts_for_borrow_and_call_sites() -> None:
    module = parse_module(
        """
module demo.typefacts;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn peek(f: RefConst<File>) -> I32 effects() {
    return f.fd;
}

fn main(f: File) -> I32 effects() {
    return peek(borrow f);
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []
    main = next(fn for fn in summary.functions if fn.name == "main")
    borrow_records = [rec for rec in main.exprs if rec.text == "borrow f"]
    assert borrow_records
    borrow = borrow_records[-1]
    assert borrow.place == "f"
    assert borrow.ref_mode == "const"
    assert borrow.borrow_mode == "const"
    assert borrow.copyable is False
    assert main.calls[0].arg_ref_modes == ["const"]



def test_typecheck_accepts_slice_notation_and_preserves_slice_expr() -> None:
    module = parse_module(
        """
module demo.sliceok;

fn head(s: Slice<I64>, n: U64) -> Slice<I64> effects() {
    return s[0..n];
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []
    fn = summary.functions[0]
    slice_records = [rec for rec in fn.exprs if rec.kind == "SliceExpr"]
    assert slice_records
    assert slice_records[-1].type_text == "Slice<I64>"


def test_typecheck_rejects_slice_on_non_sliceable_value() -> None:
    module = parse_module(
        """
module demo.slicebad;

fn bad(n: I64) -> Slice<I64> effects() {
    return n[0..2];
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "slice on non-sliceable value" in joined


def test_typecheck_allows_discard_sink_assignment() -> None:
    module = parse_module(
        """
module demo.discardok;

fn f() -> I64 effects() {
    return 7;
}

fn main() -> Unit effects() {
    _ = f();
    _ = unit;
    return unit;
}
"""
    )
    summary = typecheck_module(module)
    assert messages(summary) == []


def test_typecheck_rejects_non_unit_expression_statement_and_suggests_discard() -> None:
    module = parse_module(
        """
module demo.discardbad;

fn f() -> I64 effects() {
    return 7;
}

fn main() -> Unit effects() {
    f();
    return unit;
}
"""
    )
    summary = typecheck_module(module)
    joined = "\n".join(messages(summary))
    assert "expression statement has non-Unit type I64; use _ = expr to discard" in joined



def test_typecheck_imported_call_accepts_fully_qualified_module_path() -> None:
    util_module = parse_module(
        """
module demo.util;

fn add(x: I64, y: I64) -> I64 effects() {
    return x + y;
}
"""
    )
    main_module = parse_module(
        """
module demo.main;

import demo.util;

fn main() -> I64 effects() {
    return demo.util.add(2, 3);
}
"""
    )
    from axiomzig.ownership import export_ownership_signatures

    imported = {fn.name: fn for fn in export_ownership_signatures(util_module).functions}
    summary = typecheck_module(main_module, imported_signatures=imported)
    assert messages(summary) == []
