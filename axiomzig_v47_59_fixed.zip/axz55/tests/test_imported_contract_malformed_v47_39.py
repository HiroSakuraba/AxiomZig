from axiomzig.checker import check_module
from axiomzig.interpreter import ImportStub, ImportWrite, IntVal, Interpreter, ResourceVal, UnitVal
from axiomzig.ownership import analyze_ownership
from axiomzig.ownership_signatures import FunctionOwnershipSignature, RefParamOwnershipSignature
from axiomzig.parser import parse_module


def _sig(name='demo.util.touch', *, param_types=None, ref_params=None, return_type='Unit', effects=None):
    return FunctionOwnershipSignature(
        name=name,
        param_types=list(param_types or ['Ref<Holder>']),
        return_type=return_type,
        effects=list(effects or ['protocol_step']),
        ref_params=list(ref_params or []),
    )


def _module():
    return parse_module('''
module demo.main;
import demo.util;
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; }
fn run() -> Unit effects(protocol_step) {
    var h = Holder { inner: File { fd: 1 } };
    demo.util.touch(borrow h);
    return unit;
}
''')


def _messages(issues):
    return [issue.message for issue in issues]


def test_duplicate_ref_param_index_is_clean_import_contract_diagnostic():
    sig = _sig(ref_params=[
        RefParamOwnershipSignature(0, 'mut', 'Holder', {'inner': 'Closed'}),
        RefParamOwnershipSignature(0, 'mut', 'Holder', {'inner': 'Open'}),
    ])
    issues = check_module(_module(), imported_signatures={sig.name: sig})
    assert any('duplicate ref param index 0' in msg for msg in _messages(issues))


def test_out_of_range_ref_param_index_is_clean_import_contract_diagnostic():
    sig = _sig(param_types=['I64'], ref_params=[RefParamOwnershipSignature(1, 'mut', 'Holder', {'inner': 'Closed'})])
    issues = check_module(_module(), imported_signatures={sig.name: sig})
    assert any('ref param 2 exceeds parameter list' in msg for msg in _messages(issues))


def test_ref_param_mode_must_match_declared_parameter_type():
    sig = _sig(param_types=['I64'], ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', {'inner': 'Closed'})])
    issues = check_module(_module(), imported_signatures={sig.name: sig})
    assert any("declared mut but parameter type is 'I64'" in msg for msg in _messages(issues))


def test_dynamic_index_path_is_rejected_consistently_by_checker_and_ownership():
    sig = _sig(ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', {'[*].inner': 'Closed'})])
    checker_messages = _messages(check_module(_module(), imported_signatures={sig.name: sig}))
    ownership_messages = _messages(analyze_ownership(_module(), imported_signatures={sig.name: sig}).issues)
    assert any('uses unsupported non-literal indexed path(s)' in msg for msg in checker_messages)
    assert any('uses unsupported non-literal indexed path(s)' in msg for msg in ownership_messages)


def test_declared_imported_resource_write_succeeds_through_shared_contract():
    sig = _sig(ref_params=[RefParamOwnershipSignature(0, 'mut', 'Holder', {'inner': 'Closed'})])
    stub = ImportStub(
        writes=[ImportWrite(
            ref_param_index=0,
            path=('inner',),
            value=ResourceVal('File', 'FileProtocol', 'Closed', {'fd': IntVal(2, width=32, signed=True)}),
            allow_live_resource_replace=True,
        )],
        return_value=UnitVal(),
    )
    interp = Interpreter(_module(), imported_signatures={sig.name: sig}, import_stubs={sig.name: stub})
    assert isinstance(interp.call_function(interp.functions['run'], []), UnitVal)
