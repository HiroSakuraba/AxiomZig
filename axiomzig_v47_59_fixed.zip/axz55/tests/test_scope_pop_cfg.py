from axiomzig.cfg import build_cfg
from axiomzig.ownership import analyze_ownership
from axiomzig.parser import parse_module


def test_cfg_scope_exit_edge_records_popped_bindings() -> None:
    module = parse_module(
        '''
module demo.scope_pop_cfg;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn use_block() -> Unit effects(protocol_step) {
    {
        let f: File = make_file();
        f.close();
    }
    return unit;
}
'''
    )
    cfg = build_cfg(module)
    fn = next(f for f in cfg.functions if f.name == 'use_block')
    scope_edges = [edge for edge in fn.edges if edge.kind == 'scope_exit' and 'f' in edge.pop_bindings]
    assert scope_edges, 'expected at least one scope_exit edge to pop f'


def test_cfg_ownership_rejects_nonterminal_block_local_resource() -> None:
    module = parse_module(
        '''
module demo.scope_pop_own;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn bad_block() -> Unit effects() {
    {
        let f: File = make_file();
    }
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    messages = [issue.message for issue in summary.issues]
    assert 'resource f: File leaves block scope in non-terminal state Open' in messages


def test_cfg_ownership_accepts_terminal_block_local_resource() -> None:
    module = parse_module(
        '''
module demo.scope_pop_ok;

protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

resource File {
    protocol: FileProtocol;
    fields {
        fd: I32;
    }
}

fn make_file() -> File effects() {
    return File { fd: 0 };
}

fn ok_block() -> Unit effects(protocol_step) {
    {
        let f: File = make_file();
        f.close();
    }
    return unit;
}
'''
    )
    summary = analyze_ownership(module)
    assert [issue.message for issue in summary.issues] == []
