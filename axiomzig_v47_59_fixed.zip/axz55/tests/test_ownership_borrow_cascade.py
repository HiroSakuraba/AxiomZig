"""
test_ownership_borrow_cascade.py — v47.59 fix

When E_OWN_BORROW_LIVE blocks a terminal transition, the resource remains
non-terminal at scope exit but E_OWN_UNDISCHARGED must NOT cascade.
The discharge_blocked flag on ResourceState carries this signal through
clone_state so the exit checker can suppress the secondary diagnostic.
"""
from __future__ import annotations
import io, contextlib, re, tempfile
from pathlib import Path
import pytest
from axiomzig.cli import main as cli_main


def _owncheck(src: str) -> tuple[int, list[str]]:
    p = Path(tempfile.mktemp(suffix=".az"))
    p.write_text(src, encoding="utf-8")
    out, err = io.StringIO(), io.StringIO()
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            rc = cli_main(["owncheck", str(p), "--no-workspace-discovery"])
    except SystemExit as e:
        rc = int(e.code) if isinstance(e.code, int) else 1
    except Exception:
        rc = 1
    p.unlink(missing_ok=True)
    combined = out.getvalue() + "\n" + err.getvalue()
    return rc, sorted(set(re.findall(r"\b[ER]_[A-Z0-9_]+\b", combined)))


_DECL = """\
protocol FileP { states { Open, Closed } init Open; terminal { Closed }
    transitions { close: Open -> Closed; } }
resource File { protocol: FileP; fields { fd: I32; } }
fn make_f() -> File effects() { return File { fd: 0 }; }"""


def test_borrow_live_suppresses_undischarged() -> None:
    """
    Core fix: borrow still live when close is called → E_OWN_BORROW_LIVE only,
    not also E_OWN_UNDISCHARGED.
    """
    src = f"""\
module t.bc0;
{_DECL}
fn peek(r: RefConst<File>) -> Unit effects() {{ return unit; }}
fn run() -> Unit effects(protocol_step) {{
    let f = make_f();
    let r: RefConst<File> = borrow f;
    peek(r);
    f.close();
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 1
    assert "E_OWN_BORROW_LIVE" in codes, f"expected BORROW_LIVE; got {codes}"
    assert "E_OWN_UNDISCHARGED" not in codes, (
        f"UNDISCHARGED must be suppressed when close was blocked by BORROW_LIVE; got {codes}"
    )


def test_scoped_borrow_then_close_passes() -> None:
    """Borrow in inner block, close after block — no errors."""
    src = f"""\
module t.bc1;
{_DECL}
fn peek(r: RefConst<File>) -> Unit effects() {{ return unit; }}
fn run() -> Unit effects(protocol_step) {{
    let f = make_f();
    {{ let r: RefConst<File> = borrow f; peek(r); }}
    f.close();
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 0, f"expected pass; got rc={rc} codes={codes}"


def test_undischarged_fires_when_no_close_attempted() -> None:
    """No close at all → E_OWN_UNDISCHARGED must still fire."""
    src = f"""\
module t.bc2;
{_DECL}
fn run() -> Unit effects() {{
    let f = make_f();
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 1
    assert "E_OWN_UNDISCHARGED" in codes, f"UNDISCHARGED must fire; got {codes}"


def test_branch_miss_still_fires_undischarged() -> None:
    """False branch skips close → UNDISCHARGED must fire."""
    src = f"""\
module t.bc3;
{_DECL}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    let f = make_f();
    if (flag) {{ f.close(); }} else {{ }}
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 1
    assert "E_OWN_UNDISCHARGED" in codes


def test_double_close_no_undischarged() -> None:
    """Double close → PROTO_TRANSITION, not UNDISCHARGED."""
    src = f"""\
module t.bc4;
{_DECL}
fn run() -> Unit effects(protocol_step) {{
    let f = make_f();
    f.close();
    f.close();
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 1
    assert "E_PROTO_TRANSITION" in codes
    assert "E_OWN_UNDISCHARGED" not in codes


def test_two_resources_selective_suppression() -> None:
    """
    f1: borrow live at close → BORROW_LIVE suppressed, no UNDISCHARGED for f1.
    f2: never closed → UNDISCHARGED fires for f2.
    Both correct simultaneously.
    """
    src = f"""\
module t.bc5;
{_DECL}
fn peek(r: RefConst<File>) -> Unit effects() {{ return unit; }}
fn run() -> Unit effects(protocol_step) {{
    let f1 = make_f();
    let f2 = make_f();
    let r: RefConst<File> = borrow f1;
    peek(r);
    f1.close();
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 1
    assert "E_OWN_BORROW_LIVE" in codes, "f1 must produce BORROW_LIVE"
    assert "E_OWN_UNDISCHARGED" in codes, "f2 (never closed) must produce UNDISCHARGED"


def test_move_still_produces_own_moved() -> None:
    src = f"""\
module t.bc6;
{_DECL}
fn run() -> Unit effects(protocol_step) {{
    let f = make_f();
    let g: File = move f;
    f.close();
    g.close();
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 1
    assert "E_OWN_MOVED" in codes


@pytest.mark.parametrize("proto_key,res,cl,fd", [
    ("socket", "Sock", "abort", 2),
    ("txn",    "Txn",  "commit", 6),
])
def test_borrow_live_suppression_across_protocol_types(proto_key, res, cl, fd) -> None:
    """Suppression applies for any resource protocol, not only File."""
    if proto_key == "socket":
        decl = f"""\
protocol SockP {{ states {{ Created, Connected, Closed }} init Created; terminal {{ Closed }}
    transitions {{ connect: Created -> Connected; abort: Created -> Closed; close: Connected -> Closed; }} }}
resource {res} {{ protocol: SockP; fields {{ fd: I32; }} }}
fn make_s() -> {res} effects() {{ return {res} {{ fd: {fd} }}; }}"""
        make_call = "make_s()"
    else:
        decl = f"""\
protocol TxnP {{ states {{ Begun, Committed }} init Begun; terminal {{ Committed }}
    transitions {{ commit: Begun -> Committed; }} }}
resource {res} {{ protocol: TxnP; fields {{ id: I64; }} }}
fn make_t() -> {res} effects() {{ return {res} {{ id: {fd} }}; }}"""
        make_call = "make_t()"

    src = f"""\
module t.bc_{proto_key};
{decl}
fn peek(r: RefConst<{res}>) -> Unit effects() {{ return unit; }}
fn run() -> Unit effects(protocol_step) {{
    let v = {make_call};
    let r: RefConst<{res}> = borrow v;
    peek(r);
    v.{cl}();
    return unit;
}}"""
    rc, codes = _owncheck(src)
    assert rc == 1
    assert "E_OWN_BORROW_LIVE" in codes
    assert "E_OWN_UNDISCHARGED" not in codes, (
        f"{proto_key}: UNDISCHARGED must be suppressed; got {codes}"
    )
