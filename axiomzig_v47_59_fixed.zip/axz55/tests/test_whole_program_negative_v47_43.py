from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main


COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _write_stale_close_inner_bundle(path: Path, *, state_path: str = 'other') -> Path:
    path.write_text(
        json.dumps(
            {
                'module_path': 'demo.util',
                'functions': [
                    {
                        'name': 'demo.util.close_inner',
                        'param_types': ['Ref<Holder>'],
                        'return_type': 'Unit',
                        'effects': ['protocol_step'],
                        'ref_params': [
                            {
                                'param_index': 0,
                                'mode': 'mut',
                                'type_name': 'Holder',
                                'effects': {state_path: 'Closed'},
                            }
                        ],
                    }
                ],
            }
        ),
        encoding='utf-8',
    )
    return path


def test_whole_program_module_a_export_wrong_summary_conflict_fails_fast(tmp_path: Path, capsys) -> None:
    util = _write(
        tmp_path / 'demo' / 'util.az',
        f'''module demo.util;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        f'''module demo.main;
import demo.util;
{COMMON}
fn run() -> Unit effects() {{ return unit; }}
''',
    )
    stale = _write_stale_close_inner_bundle(tmp_path / 'stale_import_ownership.json')

    rc = main(['owncheck', str(main_file), '--module-root', str(tmp_path), '--import-ownership', str(stale)])
    captured = capsys.readouterr()
    assert util.is_file()
    assert rc == 1
    assert 'module error: ownership summary conflict for demo.util.close_inner' in captured.err
    assert captured.out.strip() == ''



def test_whole_program_module_b_consuming_stale_summary_is_rejected(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        f'''module demo.util;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    _write(
        tmp_path / 'demo' / 'mid.az',
        f'''module demo.mid;
import demo.util;
{COMMON}
fn forward_close(h: Ref<Holder>) -> Unit effects(protocol_step) {{ demo.util.close_inner(h); return unit; }}
''',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        f'''module demo.main;
import demo.mid;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    if (flag) {{ demo.mid.forward_close(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )
    stale = _write_stale_close_inner_bundle(tmp_path / 'stale_import_ownership.json')

    rc = main(['owncheck', str(main_file), '--module-root', str(tmp_path), '--import-ownership', str(stale)])
    captured = capsys.readouterr()
    assert rc == 1
    assert 'module error: ownership summary conflict for demo.util.close_inner' in captured.err
    assert captured.out.strip() == ''



def test_whole_program_unresolved_external_import_remains_opaque(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        '''module demo.main;
import vendor.crypto;
fn run() -> Unit effects() { return unit; }
''',
    )

    rc = main(['owncheck', str(main_file), '--module-root', str(tmp_path)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.err.strip() == ''
    assert '"level": "error"' not in captured.out



def test_whole_program_internal_module_import_does_not_require_runtime_stub_for_owncheck(tmp_path: Path, capsys) -> None:
    _write(
        tmp_path / 'demo' / 'util.az',
        f'''module demo.util;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        f'''module demo.main;
import demo.util;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ demo.util.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )

    rc = main(['owncheck', str(main_file), '--module-root', str(tmp_path)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.err.strip() == ''
    assert '"level": "error"' not in captured.out
