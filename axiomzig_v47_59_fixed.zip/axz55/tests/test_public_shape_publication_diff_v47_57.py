from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from axiomzig.cli import main
from axiomzig.publication_diff import diff_publication_manifests


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _base_publication() -> dict:
    return {
        'schema_version': 'axiomzig.publication_manifest.v1',
        'package_name': 'demo',
        'package_version': '1.0.0',
        'package_id': 'demo@1.0.0',
        'exported_modules': ['demo.main'],
        'exported_functions': {'demo.main': []},
        'exported_resources': {'demo.main': ['demo.main.File']},
        'exported_protocols': {'demo.main': ['demo.main.Readable']},
        'internal_signatures': {},
        'public_resource_shapes': {
            'demo.main': {
                'demo.main.File': {
                    'protocol': 'demo.main.Readable',
                    'fields': [
                        {'name': 'fd', 'type': 'Int'},
                        {'name': 'name', 'type': 'Str'},
                    ],
                }
            }
        },
        'public_protocol_shapes': {
            'demo.main': {
                'demo.main.Readable': {
                    'states': ['Closed', 'Open'],
                    'init': 'Open',
                    'terminal': ['Closed'],
                    'transitions': [
                        {'name': 'close', 'source': 'Open', 'target': 'Closed'},
                    ],
                }
            }
        },
        'manifest_hash': 'old',
    }


def test_emit_package_interface_and_publication_include_resource_protocol_shapes(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        '''module demo.main;

pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions {
        close: Open -> Closed;
    }
}

pub resource File {
    protocol: Readable;
    fields {
        fd: Int;
        name: Str;
    }
}
''',
    )
    iface = tmp_path / 'axiomzig.package.json'
    rc = main(['emit-package-interface', str(main_file), '--module-root', str(tmp_path), '--out', str(iface)])
    capsys.readouterr()
    rendered = json.loads(iface.read_text(encoding='utf-8'))

    assert rc == 0
    assert rendered['public_resource_shapes']['demo.main']['demo.main.File'] == {
        'protocol': 'demo.main.Readable',
        'fields': [{'name': 'fd', 'type': 'Int'}, {'name': 'name', 'type': 'Str'}],
    }
    assert rendered['public_protocol_shapes']['demo.main']['demo.main.Readable'] == {
        'states': ['Closed', 'Open'],
        'init': 'Open',
        'terminal': ['Closed'],
        'transitions': [{'name': 'close', 'source': 'Open', 'target': 'Closed'}],
    }

    publication = tmp_path / 'publication.json'
    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(tmp_path),
        '--package-interface',
        str(iface),
        '--publication-out',
        str(publication),
    ])
    capsys.readouterr()
    pub = json.loads(publication.read_text(encoding='utf-8'))
    assert rc == 0
    assert pub['public_resource_shapes'] == rendered['public_resource_shapes']
    assert pub['public_protocol_shapes'] == rendered['public_protocol_shapes']


def test_pubdiff_classifies_protocol_shape_changes() -> None:
    old = _base_publication()
    new = deepcopy(old)
    shape = new['public_protocol_shapes']['demo.main']['demo.main.Readable']
    shape['states'] = ['Broken', 'Closed', 'Open']
    shape['terminal'] = ['Broken', 'Closed']
    shape['transitions'] = [
        {'name': 'close', 'source': 'Open', 'target': 'Broken'},
        {'name': 'repair', 'source': 'Broken', 'target': 'Open'},
    ]

    result = diff_publication_manifests(old, new)
    codes = {issue['code'] for issue in result['issues']}

    assert result['classification'] == 'incompatible'
    assert 'C_PUBLIC_PROTOCOL_STATE_ADDED' in codes
    assert 'C_PUBLIC_PROTOCOL_TERMINAL_ADDED' in codes
    assert 'C_PUBLIC_PROTOCOL_TRANSITION_ADDED' in codes
    assert 'E_PUBLIC_PROTOCOL_TRANSITION_CHANGED' in codes
    assert result['categories']['protocol_shape'] == 4


def test_pubdiff_classifies_resource_shape_changes() -> None:
    old = _base_publication()
    new = deepcopy(old)
    shape = new['public_resource_shapes']['demo.main']['demo.main.File']
    shape['protocol'] = 'demo.main.OtherProtocol'
    shape['fields'] = [
        {'name': 'fd', 'type': 'U64'},
        {'name': 'extra', 'type': 'Bool'},
    ]

    result = diff_publication_manifests(old, new)
    codes = {issue['code'] for issue in result['issues']}

    assert result['classification'] == 'incompatible'
    assert 'E_PUBLIC_RESOURCE_PROTOCOL_CHANGED' in codes
    assert 'E_PUBLIC_RESOURCE_FIELD_REMOVED' in codes
    assert 'E_PUBLIC_RESOURCE_FIELD_TYPE_CHANGED' in codes
    assert 'C_PUBLIC_RESOURCE_FIELD_ADDED' in codes
    assert result['categories']['resource_shape'] == 4


def test_sync_diagnostics_mentions_shape_sections(tmp_path: Path, capsys) -> None:
    main_file = _write(
        tmp_path / 'demo' / 'main.az',
        '''module demo.main;

pub protocol Readable {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}

pub resource File { protocol: Readable; fields { fd: Int; } }
''',
    )
    iface = tmp_path / 'axiomzig.package.json'
    rc = main(['emit-package-interface', str(main_file), '--module-root', str(tmp_path), '--out', str(iface)])
    capsys.readouterr()
    assert rc == 0
    stale = json.loads(iface.read_text(encoding='utf-8'))
    stale.pop('public_resource_shapes')
    stale['public_protocol_shapes']['demo.main']['demo.main.Readable']['states'] = ['Open']
    iface.write_text(json.dumps(stale, sort_keys=True), encoding='utf-8')

    rc = main(['check-package-interface-sync', str(main_file), '--module-root', str(tmp_path), '--package-interface', str(iface)])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'resource shapes' in captured.err
    assert 'protocol shapes' in captured.err
