from __future__ import annotations

from pathlib import Path

from axiomzig.checker import check_module
from axiomzig.module_graph import collect_workspace_ownership_signatures, load_module_graph
from axiomzig.ownership import analyze_ownership
from axiomzig.parser import parse_module

COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def write_workspace(tmp_path: Path, util_body: str, main_body: str) -> tuple[Path, Path]:
    util = tmp_path / 'demo' / 'util.az'
    main = tmp_path / 'demo' / 'main.az'
    util.parent.mkdir(parents=True)
    util.write_text(f'module demo.util;\n{COMMON}\n{util_body}\n', encoding='utf-8')
    main.write_text(f'module demo.main;\nimport demo.util;\n{COMMON}\n{main_body}\n', encoding='utf-8')
    return main, util


def test_module_graph_exports_cross_module_ref_summary_and_main_consumes_it(tmp_path: Path):
    main, _ = write_workspace(
        tmp_path,
        '''fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) { h.inner.close(); return unit; }''',
        '''fn run(flag: Bool) -> Unit effects(protocol_step) {
               var h = Holder { inner: File { fd: 1 }, other: File { fd: 2 } };
               h.other.close();
               if (flag) { demo.util.close_inner(borrow h); } else { h.inner.close(); }
               return unit;
           }''',
    )
    imported, graph = collect_workspace_ownership_signatures(main, module_root=tmp_path)
    assert [i for i in graph.issues if i.level == 'error'] == []
    assert 'demo.util.close_inner' in imported
    assert imported['demo.util.close_inner'].ref_params[0].effects == {'inner': 'Closed'}
    summary = analyze_ownership(parse_module(main.read_text()), imported_signatures=imported)
    assert [i.message for i in summary.issues if i.level == 'error'] == []


def test_cross_module_partial_mutation_does_not_overclose_whole_holder(tmp_path: Path):
    main, _ = write_workspace(
        tmp_path,
        '''fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) { h.inner.close(); return unit; }''',
        '''fn run() -> Unit effects(protocol_step) {
               var h = Holder { inner: File { fd: 1 }, other: File { fd: 2 } };
               demo.util.close_inner(borrow h);
               return unit;
           }''',
    )
    imported, _ = collect_workspace_ownership_signatures(main, module_root=tmp_path)
    summary = analyze_ownership(parse_module(main.read_text()), imported_signatures=imported)
    messages = '\n'.join(i.message for i in summary.issues if i.level == 'error')
    assert 'other=Open' in messages
    assert 'inner=Closed' in messages


def test_cross_module_aliased_mut_refs_are_rejected_without_host_execution(tmp_path: Path):
    main, _ = write_workspace(
        tmp_path,
        '''fn close_both(a: Ref<Holder>, b: Ref<Holder>) -> Unit effects(protocol_step) {
               a.inner.close();
               b.other.close();
               return unit;
           }''',
        '''fn run() -> Unit effects(protocol_step) {
               var h = Holder { inner: File { fd: 1 }, other: File { fd: 2 } };
               demo.util.close_both(borrow h, borrow h);
               return unit;
           }''',
    )
    imported, _ = collect_workspace_ownership_signatures(main, module_root=tmp_path)
    summary = analyze_ownership(parse_module(main.read_text()), imported_signatures=imported)
    messages = '\n'.join(i.message for i in summary.issues if i.level == 'error')
    assert 'passes aliased reference h to incompatible ref parameters 1 and 2' in messages


def test_unresolved_import_remains_opaque_external(tmp_path: Path):
    main = tmp_path / 'demo' / 'main.az'
    main.parent.mkdir(parents=True)
    main.write_text('''
module demo.main;
import vendor.external;
fn run() -> Unit effects() { return unit; }
''', encoding='utf-8')
    graph = load_module_graph(main, module_root=tmp_path)
    assert any(i.code == 'W_MODULE_OPAQUE' and i.context == 'vendor.external' for i in graph.issues)
    assert [i for i in graph.issues if i.level == 'error'] == []
