from __future__ import annotations

import json
from pathlib import Path

from axiomzig.cli import main

COMMON = '''
protocol FileProtocol { states { Open, Closed } init Open; terminal { Closed } transitions { close: Open -> Closed; } }
resource File { protocol: FileProtocol; fields { fd: I32; } }
struct Holder { inner: File; other: File; }
'''


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
    return path


def _build_dependency_manifest(dep_root: Path, capsys, *, package_name: str | None = None, package_version: str | None = None) -> Path:
    dep_file = _write(
        dep_root / 'dep' / 'api.az',
        f'''module dep.api;
{COMMON}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{ h.inner.close(); return unit; }}
''',
    )
    out = dep_root / 'dep_manifest.json'
    argv = ['conform', str(dep_file), '--module-root', str(dep_root), '--public-only', '--out', str(out)]
    if package_name is not None:
        argv.extend(['--package-name', package_name])
    if package_version is not None:
        argv.extend(['--package-version', package_version])
    rc = main(argv)
    capsys.readouterr()
    assert rc == 0
    return out


def _lock_for_manifest(path: Path) -> dict:
    manifest = json.loads(path.read_text(encoding='utf-8'))
    return {
        'schema_version': 'axiomzig.dependency_lock.v1',
        'dependencies': [
            {
                'package_name': manifest['package_name'],
                'package_version': manifest['package_version'],
                'package_id': manifest['package_id'],
                'manifest_hash': manifest['manifest_hash'],
                'modules': manifest['exported_modules'],
            }
        ],
    }


def test_conform_manifest_exports_package_identity_fields(tmp_path: Path, capsys) -> None:
    root = tmp_path / 'pkg'
    main_file = _write(root / 'app' / 'main.az', 'module app.main;\nfn run() -> Unit effects() { return unit; }\n')
    out = root / 'manifest.json'

    rc = main([
        'conform',
        str(main_file),
        '--module-root',
        str(root),
        '--package-name',
        'app_pkg',
        '--package-version',
        '1.2.3',
        '--out',
        str(out),
    ])
    captured = capsys.readouterr()
    manifest = json.loads(out.read_text(encoding='utf-8'))

    assert rc == 0
    assert captured.err.strip() == ''
    assert manifest['schema_version'] == 'axiomzig.conformance.v4'
    assert manifest['package_name'] == 'app_pkg'
    assert manifest['package_version'] == '1.2.3'
    assert manifest['package_id'] == 'app_pkg@1.2.3'
    assert manifest['manifest_hash_algorithm'] == 'sha256'
    assert manifest['manifest_hash']


def test_dependency_manifest_missing_package_identity_is_rejected(tmp_path: Path, capsys) -> None:
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.api;\nfn run() -> Unit effects() { return unit; }\n',
    )
    bad_manifest = _write(
        tmp_path / 'bad_dep_manifest.json',
        json.dumps(
            {
                'schema_version': 'axiomzig.conformance.v4',
                'status': 'ok',
                'internal_signatures': {},
                'exported_modules': ['dep.api'],
                'manifest_hash_algorithm': 'sha256',
                'manifest_hash': 'deadbeef',
            }
        ),
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(bad_manifest),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'dependency manifest is missing package_name' in captured.err


def test_dependency_manifest_missing_hash_is_rejected(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    payload = json.loads(dep_manifest.read_text(encoding='utf-8'))
    payload.pop('manifest_hash')
    dep_manifest.write_text(json.dumps(payload), encoding='utf-8')

    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.api;\nfn run() -> Unit effects() { return unit; }\n',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'dependency manifest is missing manifest_hash' in captured.err


def test_dependency_lock_pins_manifest_identity_and_hash(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(
        tmp_path / 'dep_workspace',
        capsys,
        package_name='dep_pkg',
        package_version='2.0.0',
    )
    lock_path = _write(tmp_path / 'deps.lock.json', json.dumps(_lock_for_manifest(dep_manifest)))
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        f'''module app.main;
import dep.api;
{COMMON}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 1 }}, other: File {{ fd: 2 }} }};
    h.other.close();
    if (flag) {{ dep.api.close_inner(borrow h); }} else {{ h.inner.close(); }}
    return unit;
}}
''',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
        '--dependency-lock',
        str(lock_path),
    ])
    captured = capsys.readouterr()
    payload = json.loads(captured.out)

    assert rc == 0
    assert captured.err.strip() == ''
    assert payload['issues'] == []


def test_dependency_lock_hash_mismatch_is_rejected(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    lock = _lock_for_manifest(dep_manifest)
    lock['dependencies'][0]['manifest_hash'] = '0' * 64
    lock_path = _write(tmp_path / 'deps.lock.json', json.dumps(lock))
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.api;\nfn run() -> Unit effects() { return unit; }\n',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
        '--dependency-lock',
        str(lock_path),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'hash does not match locked hash' in captured.err


def test_dependency_lock_requires_all_pinned_manifests(tmp_path: Path, capsys) -> None:
    dep_manifest = _build_dependency_manifest(tmp_path / 'dep_workspace', capsys)
    lock = _lock_for_manifest(dep_manifest)
    lock['dependencies'].append(
        {
            'package_name': 'extra_pkg',
            'package_version': '1',
            'package_id': 'extra_pkg@1',
            'manifest_hash': '1' * 64,
            'modules': ['extra.api'],
        }
    )
    lock_path = _write(tmp_path / 'deps.lock.json', json.dumps(lock))
    consumer_root = tmp_path / 'consumer_workspace'
    main_file = _write(
        consumer_root / 'app' / 'main.az',
        'module app.main;\nimport dep.api;\nfn run() -> Unit effects() { return unit; }\n',
    )

    rc = main([
        'owncheck',
        str(main_file),
        '--module-root',
        str(consumer_root),
        '--dependency-manifest',
        str(dep_manifest),
        '--dependency-lock',
        str(lock_path),
    ])
    captured = capsys.readouterr()

    assert rc == 1
    assert 'dependency lock expects manifests for packages' in captured.err
