from __future__ import annotations

import subprocess
import sys
import textwrap
from pathlib import Path

from axiomzig.cli import main


def _write(tmp_path: Path, name: str, src: str) -> Path:
    path = tmp_path / name
    path.write_text(textwrap.dedent(src).lstrip(), encoding="utf-8")
    return path


def _run_subprocess(command: str, path: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "axiomzig.cli", command, str(path)],
        capture_output=True,
        text=True,
        timeout=20,
    )


def test_golden_parse_error_message_is_stable(tmp_path: Path) -> None:
    bad = _write(
        tmp_path,
        "bad_parse.az",
        """
        module demo.bad;
        fn main() -> Unit effects() { let x = ; }
        """,
    )
    proc = _run_subprocess("parse", bad)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "parse error: expected primary expression, got ;(';')@2:39\n"
    assert "Traceback" not in proc.stderr


def test_golden_check_warning_for_non_core_effect(tmp_path: Path, capsys) -> None:
    path = _write(
        tmp_path,
        "non_core_effect.az",
        """
        module demo.fx;

        fn main() -> Unit effects(custom_fx) {
            return unit;
        }
        """,
    )
    rc = main(["check", str(path)])
    captured = capsys.readouterr()
    assert rc == 0
    assert captured.err == ""
    assert captured.out.splitlines() == [
        "warning: function main uses non-core effect tag custom_fx",
    ]


def test_golden_check_protocol_diagnostics(tmp_path: Path, capsys) -> None:
    path = _write(
        tmp_path,
        "protocol_bad.az",
        """
        module demo.proto;

        protocol P {
            states { A }
            init B;
            terminal { C }
            transitions {
                t: A -> D;
            }
        }
        """,
    )
    rc = main(["check", str(path)])
    captured = capsys.readouterr()
    assert rc == 1
    assert captured.err == ""
    assert captured.out.splitlines() == [
        "error: protocol P init state B not in states",
        "error: protocol P terminal state C not in states",
        "error: protocol P transition t target D not in states",
    ]


def test_golden_check_type_diagnostics_bundle(tmp_path: Path, capsys) -> None:
    path = _write(
        tmp_path,
        "types_bad.az",
        """
        module demo.types;

        fn add(x: I64, y: I64) -> I64 effects() {
            return x + y;
        }

        fn main(x: Option<I64>) -> I64 effects() {
            let flag: Bool = 1;
            return match x {
                some(v) -> add(true),
            };
        }
        """,
    )
    rc = main(["check", str(path)])
    captured = capsys.readouterr()
    assert rc == 1
    assert captured.err == ""
    assert captured.out.splitlines() == [
        "error: let flag annotated as Bool but got I64 [E_TYPE_MISMATCH]",
        "error: call to add expects 2 arguments but got 1 [E_TYPE_MISMATCH]",
        "error: call to add argument 1 expects I64 but got Bool [E_TYPE_MISMATCH]",
        "error: match is not exhaustive; missing none [E_TYPE_NO_EXHAUST]",
    ]


def test_golden_check_ownership_use_after_move(tmp_path: Path, capsys) -> None:
    path = _write(
        tmp_path,
        "use_after_move.az",
        """
        module demo.uam;

        protocol FileProtocol {
            states { Open, Closed }
            init Open;
            terminal { Closed }
            transitions {
                close: Open -> Closed;
            }
        }

        resource File {
            protocol: FileProtocol;
            fields {
                fd: I32;
            }
        }

        fn sink(f: File) -> Unit effects(protocol_step) {
            f.close();
            return unit;
        }

        fn main(f: File) -> Unit effects(protocol_step) {
            sink(move f);
            f.close();
            return unit;
        }
        """,
    )
    rc = main(["check", str(path)])
    captured = capsys.readouterr()
    assert rc == 1
    assert captured.err == ""
    assert captured.out.splitlines() == [
        "error: cannot call f.close on moved resource [E_OWN_MOVED]",
    ]


def test_golden_check_borrow_conflict_fails_cleanly_without_traceback(tmp_path: Path) -> None:
    path = _write(
        tmp_path,
        "borrow_conflict.az",
        """
        module demo.bc;

        protocol FileProtocol {
            states { Open, Closed }
            init Open;
            terminal { Closed }
            transitions {
                close: Open -> Closed;
            }
        }

        resource File {
            protocol: FileProtocol;
            fields {
                fd: I32;
            }
        }

        fn poke(f: Ref<File>) -> Unit effects() {
            return unit;
        }

        fn peek(f: RefConst<File>) -> Unit effects() {
            return unit;
        }

        fn main(f: File) -> Unit effects() {
            poke(borrow f);
            peek(borrow f);
            return unit;
        }
        """,
    )
    proc = _run_subprocess("check", path)
    assert proc.returncode == 1
    assert proc.stderr == ""
    assert proc.stdout.splitlines() == [
        "error: cannot immutably borrow resource f while mutable borrow is live [E_OWN_BORROW_EXCL]",
        "error: resource f: File leaves scope in non-terminal state Open [E_OWN_UNDISCHARGED]",
    ]
    assert "Traceback" not in proc.stdout
    assert "Traceback" not in proc.stderr


def test_golden_match_block_arm_parse_error_is_clean(tmp_path: Path) -> None:
    bad = _write(
        tmp_path,
        "bad_match_block_arm.az",
        """
        module demo.bad;
        fn main(flag: Bool) -> I64 effects() {
            return match flag {
                true -> { let y = 1; y },
                false -> 0,
            };
        }
        """,
    )
    proc = _run_subprocess("parse", bad)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "parse error: expected primary expression, got {(\'{\')@4:17\n"
    assert "Traceback" not in proc.stderr
