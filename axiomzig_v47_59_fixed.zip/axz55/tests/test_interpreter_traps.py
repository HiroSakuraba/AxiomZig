"""
test_interpreter_traps.py — runtime trap coverage (spec §12, conformance §5.10)

The spec promises: overflow, div-by-zero, out-of-bounds, invalid protocol
transition, and cast-out-of-range all abort with a TrapError.  These tests
pin every path through the interpreter that produces a TrapError to a
specific, stable reason string so that:

  1. The interpreter is a reliable test oracle for the spec.
  2. The conformance plan's §5.10 runtime minimum (35 tests) is met.
  3. Any future change that silently swallows a trap is caught immediately.
"""
from __future__ import annotations

import pytest

from axiomzig.interpreter import (
    ArrayVal,
    BoolVal,
    IntVal,
    Interpreter,
    InterpreterUnsupportedError,
    NoneVal,
    OkVal,
    ErrVal,
    ResourceVal,
    RuntimePlace,
    SliceVal,
    TrapError,
    UnitVal,
)
from axiomzig.parser import parse_module


# ─────────────────────────────────────────────────────────────────────────────
# helpers
# ─────────────────────────────────────────────────────────────────────────────

def _interp(src: str) -> Interpreter:
    return Interpreter(parse_module(src))


def _run(src: str, entry: str = "main") -> object:
    return _interp(src).interpret(entry)


def _i(n: int, *, width: int = 64, signed: bool = True) -> IntVal:
    return IntVal(n, width=width, signed=signed)


def _traps(src: str, *, entry: str = "main") -> str:
    """Assert the program traps and return the reason string."""
    with pytest.raises(TrapError) as exc_info:
        _run(src, entry=entry)
    return exc_info.value.reason


# ─────────────────────────────────────────────────────────────────────────────
# §12.1 — Integer overflow traps
# ─────────────────────────────────────────────────────────────────────────────

def test_trap_i64_add_overflow():
    reason = _traps("""
module t;
fn main() -> I64 effects() {
    let a: I64 = 9223372036854775807;
    let b: I64 = 1;
    return a + b;
}
""")
    assert "overflow" in reason


def test_trap_i64_sub_underflow():
    reason = _traps("""
module t;
fn main() -> I64 effects() {
    let a: I64 = -9223372036854775808;
    let b: I64 = 1;
    return a - b;
}
""")
    assert "overflow" in reason


def test_trap_i64_mul_overflow():
    reason = _traps("""
module t;
fn main() -> I64 effects() {
    let a: I64 = 9223372036854775807;
    let b: I64 = 2;
    return a * b;
}
""")
    assert "overflow" in reason


def test_trap_i32_add_overflow():
    reason = _traps("""
module t;
fn main() -> I32 effects() {
    let a: I32 = @cast(I32, 2147483647);
    let b: I32 = @cast(I32, 1);
    return a + b;
}
""")
    assert "overflow" in reason


def test_trap_u64_add_overflow():
    reason = _traps("""
module t;
fn main() -> U64 effects() {
    let a: U64 = @cast(U64, 18446744073709551615);
    let b: U64 = @cast(U64, 1);
    return a + b;
}
""")
    assert "overflow" in reason


def test_trap_u8_sub_underflow():
    reason = _traps("""
module t;
fn main() -> U8 effects() {
    let a: U8 = @cast(U8, 0);
    let b: U8 = @cast(U8, 1);
    return a - b;
}
""")
    assert "overflow" in reason


def test_trap_unary_minus_overflow():
    reason = _traps("""
module t;
fn main() -> I64 effects() {
    let a: I64 = -9223372036854775808;
    return -a;
}
""")
    assert "overflow" in reason


def test_no_trap_i64_add_in_range():
    result = _run("""
module t;
fn main() -> I64 effects() {
    let a: I64 = 9223372036854775806;
    let b: I64 = 1;
    return a + b;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 9223372036854775807


# ─────────────────────────────────────────────────────────────────────────────
# §12.2 — Division by zero and modulo by zero
# ─────────────────────────────────────────────────────────────────────────────

def test_trap_div_by_zero():
    reason = _traps("""
module t;
fn main() -> I64 effects() {
    let a: I64 = 10;
    let b: I64 = 0;
    return a / b;
}
""")
    assert reason == "division by zero"


def test_trap_mod_by_zero():
    reason = _traps("""
module t;
fn main() -> I64 effects() {
    let a: I64 = 10;
    let b: I64 = 0;
    return a % b;
}
""")
    assert reason == "division by zero"


def test_trap_div_by_zero_negative_dividend():
    reason = _traps("""
module t;
fn main() -> I64 effects() {
    let a: I64 = -7;
    let b: I64 = 0;
    return a / b;
}
""")
    assert reason == "division by zero"


def test_no_trap_div_by_nonzero():
    result = _run("""
module t;
fn main() -> I64 effects() {
    let a: I64 = 10;
    let b: I64 = 3;
    return a / b;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 3


def test_div_sign_follows_dividend():
    """Spec: sign of remainder follows dividend (C99 semantics)."""
    result = _run("""
module t;
fn main() -> I64 effects() {
    let a: I64 = -7;
    let b: I64 = 2;
    return a % b;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == -1  # -7 = (-3)*2 + (-1)


# ─────────────────────────────────────────────────────────────────────────────
# §12.3 — Array and slice index out of bounds
# ─────────────────────────────────────────────────────────────────────────────

def test_trap_array_index_oob_direct():
    interp = _interp("module t; fn f() -> Unit effects() { return unit; }")
    cell = interp.allocate_cell(ArrayVal([_i(1), _i(2)]))
    with pytest.raises(TrapError) as exc_info:
        interp.read_runtime_place(RuntimePlace(cell, (2,)))
    assert exc_info.value.reason == "index out of bounds"


def test_trap_array_index_oob_source():
    """Array index out of bounds via direct interpreter API."""
    interp = _interp("module t; fn f() -> Unit effects() { return unit; }")
    cell = interp.allocate_cell(ArrayVal([_i(10), _i(20)]))
    with pytest.raises(TrapError) as exc_info:
        interp.read_runtime_place(RuntimePlace(cell, (5,)))
    assert "bounds" in exc_info.value.reason or "index" in exc_info.value.reason


def test_trap_slice_index_oob():
    """Slice index out of bounds via API."""
    interp = _interp("module t; fn f() -> Unit effects() { return unit; }")
    cell = interp.allocate_cell(ArrayVal([_i(1), _i(2)]))
    slc = SliceVal(cell, 0, 2)
    slc_cell = interp.allocate_cell(slc)
    with pytest.raises(TrapError) as exc_info:
        interp.read_runtime_place(RuntimePlace(slc_cell, (5,)))
    assert "bounds" in exc_info.value.reason or "index" in exc_info.value.reason


def test_trap_slice_start_oob():
    interp = _interp("module t; fn f() -> Unit effects() { return unit; }")
    cell = interp.allocate_cell(ArrayVal([_i(1), _i(2)]))
    arr = SliceVal(cell, 0, 2)
    # Slice from 3 to 2 — start > length
    with pytest.raises(TrapError) as exc_info:
        interp.make_slice_view(None, arr, 3, 2)
    assert "bounds" in exc_info.value.reason or "slice" in exc_info.value.reason


def test_no_trap_array_index_last_element():
    """Last valid index does not trap."""
    interp = _interp("module t; fn f() -> Unit effects() { return unit; }")
    cell = interp.allocate_cell(ArrayVal([_i(1), _i(2), _i(3)]))
    result = interp.read_runtime_place(RuntimePlace(cell, (2,)))
    assert isinstance(result, IntVal)
    assert result.value == 3


# ─────────────────────────────────────────────────────────────────────────────
# §12.4 — Invalid protocol transition
# ─────────────────────────────────────────────────────────────────────────────

_PROTO_SRC = """
module t;
protocol P {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}
resource R { protocol: P; fields { x: I32; } }
"""


def test_trap_double_close():
    reason = _traps(_PROTO_SRC + """
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.close();
    r.close();
    return unit;
}
""")
    assert "transition" in reason or "Closed" in reason


def test_trap_invalid_transition_name():
    interp = _interp(_PROTO_SRC + "fn f() -> Unit effects() { return unit; }")
    cell = interp.allocate_cell(
        ResourceVal("R", "P", "Open", {"x": _i(0, width=32)})
    )
    place = RuntimePlace(cell, ())
    resource = interp.read_runtime_place(place)
    with pytest.raises((TrapError, InterpreterUnsupportedError)) as exc_info:
        interp.apply_resource_transition(place, resource, "nonexistent")
    assert "transition" in str(exc_info.value) or "unknown" in str(exc_info.value)


def test_trap_transition_from_closed():
    interp = _interp(_PROTO_SRC + "fn f() -> Unit effects() { return unit; }")
    cell = interp.allocate_cell(
        ResourceVal("R", "P", "Closed", {"x": _i(0, width=32)})
    )
    place = RuntimePlace(cell, ())
    resource = interp.read_runtime_place(place)
    with pytest.raises(TrapError) as exc_info:
        interp.apply_resource_transition(place, resource, "close")
    assert "Closed" in exc_info.value.reason


def test_no_trap_valid_single_close():
    result = _run(_PROTO_SRC + """
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.close();
    return unit;
}
""")
    assert isinstance(result, UnitVal)


def test_multi_state_protocol_valid_path():
    result = _run("""
module t;
protocol P {
    states { A, B, C }
    init A;
    terminal { C }
    transitions { step1: A -> B; step2: B -> C; }
}
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.step1();
    r.step2();
    return unit;
}
""")
    assert isinstance(result, UnitVal)


def test_multi_state_skip_step_traps():
    reason = _traps("""
module t;
protocol P {
    states { A, B, C }
    init A;
    terminal { C }
    transitions { step1: A -> B; step2: B -> C; }
}
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.step2();
    return unit;
}
""")
    assert "transition" in reason


# ─────────────────────────────────────────────────────────────────────────────
# §12.5 — Cast out of range
# ─────────────────────────────────────────────────────────────────────────────

def test_trap_cast_i64_to_i8_overflow():
    reason = _traps("""
module t;
fn main() -> I8 effects() {
    let x: I64 = 200;
    return @cast(I8, x);
}
""")
    assert "cast" in reason or "out of range" in reason or "overflow" in reason


def test_trap_cast_i64_to_u8_overflow():
    reason = _traps("""
module t;
fn main() -> U8 effects() {
    let x: I64 = 300;
    return @cast(U8, x);
}
""")
    assert "cast" in reason or "out of range" in reason or "overflow" in reason


def test_trap_cast_i64_negative_to_u64():
    reason = _traps("""
module t;
fn main() -> U64 effects() {
    let x: I64 = -1;
    return @cast(U64, x);
}
""")
    assert "cast" in reason or "out of range" in reason or "overflow" in reason


def test_no_trap_cast_i64_to_i32_valid():
    result = _run("""
module t;
fn main() -> I32 effects() {
    let x: I64 = 42;
    return @cast(I32, x);
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 42


def test_no_trap_cast_i64_to_u8_boundary():
    result = _run("""
module t;
fn main() -> U8 effects() {
    let x: I64 = 255;
    return @cast(U8, x);
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 255


def test_no_trap_cast_negative_to_i8():
    result = _run("""
module t;
fn main() -> I8 effects() {
    let x: I64 = -128;
    return @cast(I8, x);
}
""")
    assert isinstance(result, IntVal)
    assert result.value == -128


# ─────────────────────────────────────────────────────────────────────────────
# §12.6 — Move semantics traps
# ─────────────────────────────────────────────────────────────────────────────

def test_trap_read_of_moved_value():
    interp = _interp("module t; fn f() -> Unit effects() { return unit; }")
    from axiomzig.interpreter import MovedVal
    cell = interp.allocate_cell(MovedVal())
    with pytest.raises(TrapError) as exc_info:
        interp.read_runtime_place(RuntimePlace(cell, ()))
    assert exc_info.value.reason == "read of moved value"


def test_trap_live_resource_overwrite():
    interp = _interp(_PROTO_SRC + "fn f() -> Unit effects() { return unit; }")
    original = ResourceVal("R", "P", "Open", {"x": _i(0, width=32)})
    replacement = ResourceVal("R", "P", "Open", {"x": _i(1, width=32)})
    cell = interp.allocate_cell(original)
    with pytest.raises(TrapError) as exc_info:
        interp.write_runtime_place(RuntimePlace(cell, ()), replacement)
    assert "non-terminal" in exc_info.value.reason or "cannot overwrite" in exc_info.value.reason


# ─────────────────────────────────────────────────────────────────────────────
# §12.7 — defer execution order under normal and error exit
# ─────────────────────────────────────────────────────────────────────────────

def test_defer_runs_on_normal_exit():
    result = _run("""
module t;
struct Box { n: I64; }
fn get(b: RefConst<Box>) -> I64 effects() { return b.n; }
fn set(b: Ref<Box>, v: I64) -> Unit effects() { b.n = v; return unit; }
fn main() -> I64 effects() {
    var b = Box { n: 0 };
    defer set(borrow b, 99);
    return get(borrow b);
}
""")
    # The defer runs after main's body but the return already captured the old value
    # verify main itself ran without error
    assert isinstance(result, IntVal)


def test_defer_lifo_order():
    result = _run("""
module t;
struct Acc { n: I64; }
fn push(a: Ref<Acc>, v: I64) -> Unit effects() {
    a.n = a.n * 10 + v;
    return unit;
}
fn main() -> I64 effects() {
    var acc = Acc { n: 0 };
    defer push(borrow acc, 1);
    defer push(borrow acc, 2);
    defer push(borrow acc, 3);
    return acc.n;
}
""")
    # Defers fire 3 then 2 then 1 (LIFO): acc = 0 → 3 → 32 → 321
    assert isinstance(result, IntVal)
    assert result.value == 0  # return value captured before defers run


def test_errdefer_fires_on_error_exit():
    """errdefer body executes when the scope exits via an error."""
    # Use the conformance test pattern: defer + errdefer mix
    result = _run("""
module t;
error_set E { Bad; }
struct Box { n: I64; }
fn get(b: RefConst<Box>) -> I64 effects() { return b.n; }
fn fail_and_set(b: Ref<Box>) -> I64!E effects(error) {
    defer b.n = 1;
    errdefer b.n = 11;
    return E.Bad;
}
fn main() -> I64 effects(error) {
    var b = Box { n: 0 };
    let y: I64 = fail_and_set(borrow b) catch 100;
    return get(borrow b) + y;
}
""")
    # On error exit, LIFO: errdefer(b.n=11) fires first (registered later),
    # then defer(b.n=1) fires (registered earlier). Final b.n = 1.
    # catch returns 100; get(b) = 1; total = 101.
    assert isinstance(result, IntVal)
    assert result.value == 101


def test_errdefer_does_not_fire_on_success():
    result = _run("""
module t;
struct Box { n: I64; }
fn get(b: RefConst<Box>) -> I64 effects() { return b.n; }
fn set(b: Ref<Box>, v: I64) -> Unit effects() { b.n = v; return unit; }
fn succeed(b: Ref<Box>) -> I64 effects() {
    errdefer set(borrow b, 99);
    return 42;
}
fn main() -> I64 effects() {
    var b = Box { n: 0 };
    let result: I64 = succeed(borrow b);
    return get(borrow b);
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 0  # errdefer did not fire


# ─────────────────────────────────────────────────────────────────────────────
# §12.8 — Error propagation (? operator)
# ─────────────────────────────────────────────────────────────────────────────

def test_error_propagates_through_question():
    result = _run("""
module t;
error_set E { Bad; }
fn fail() -> I64!E effects(error) { return E.Bad; }
fn main() -> I64!E effects(error) {
    let x: I64 = fail()?;
    return x;
}
""")
    assert isinstance(result, ErrVal)
    assert result.tag == "E.Bad"


def test_ok_unwrapped_through_question():
    result = _run("""
module t;
error_set E { Bad; }
fn succeed() -> I64!E effects(error) { return 42; }
fn main() -> I64!E effects(error) {
    let x: I64 = succeed()?;
    return x;
}
""")
    assert isinstance(result, (IntVal, OkVal))
    if isinstance(result, OkVal):
        assert isinstance(result.inner, IntVal)
        assert result.inner.value == 42
    else:
        assert result.value == 42


def test_catch_provides_fallback_on_error():
    result = _run("""
module t;
error_set E { Bad; }
fn fail() -> I64!E effects(error) { return E.Bad; }
fn main() -> I64 effects(error) { return fail() catch 17; }
""")
    assert isinstance(result, IntVal)
    assert result.value == 17


def test_catch_not_used_on_success():
    result = _run("""
module t;
error_set E { Bad; }
fn succeed() -> I64!E effects(error) { return 5; }
fn main() -> I64 effects(error) { return succeed() catch 99; }
""")
    assert isinstance(result, IntVal)
    assert result.value == 5


# ─────────────────────────────────────────────────────────────────────────────
# §12.9 — Control flow: while, for-range, break, continue
# ─────────────────────────────────────────────────────────────────────────────

def test_while_loop_executes_n_times():
    result = _run("""
module t;
fn main() -> I64 effects() {
    var i: I64 = 0;
    var acc: I64 = 0;
    while (i < 5) {
        acc = acc + i;
        i = i + 1;
    }
    return acc;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 10  # 0+1+2+3+4


def test_for_range_sum():
    result = _run("""
module t;
fn main() -> I64 effects() {
    var total: I64 = 0;
    for (i: I64 in 0..5) {
        total = total + i;
    }
    return total;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 10


def test_for_range_empty():
    result = _run("""
module t;
fn main() -> I64 effects() {
    var total: I64 = 0;
    for (i: I64 in 5..5) {
        total = total + 1;
    }
    return total;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 0


def test_break_exits_loop():
    result = _run("""
module t;
fn main() -> I64 effects() {
    var i: I64 = 0;
    while (true) {
        if (i == 3) { break; }
        i = i + 1;
    }
    return i;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 3


def test_continue_skips_iteration():
    result = _run("""
module t;
fn main() -> I64 effects() {
    var total: I64 = 0;
    for (i: I64 in 0..6) {
        if (i % 2 == 0) { continue; }
        total = total + i;
    }
    return total;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 9  # 1+3+5


# ─────────────────────────────────────────────────────────────────────────────
# §12.10 — Option and match runtime semantics
# ─────────────────────────────────────────────────────────────────────────────

def test_match_some_arm():
    result = _run("""
module t;
fn main() -> I64 effects() {
    return match some(7) { some(n) -> n, none -> 0, };
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 7


def test_match_none_arm():
    result = _run("""
module t;
fn main() -> I64 effects() {
    let x: Option<I64> = none;
    return match x { some(n) -> n, none -> 99, };
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 99


def test_match_enum_all_arms():
    src = """
module t;
enum Color { Red; Green; Blue; }
fn to_int(c: Color) -> I64 effects() {
    return match c {
        Color.Red -> 1,
        Color.Green -> 2,
        Color.Blue -> 3,
    };
}
"""
    interp = _interp(src)
    from axiomzig.interpreter import EnumVal
    for tag, expected in [("Red", 1), ("Green", 2), ("Blue", 3)]:
        val = EnumVal("Color", tag, {})
        result = interp.call_function(interp.functions["to_int"], [val])
        assert isinstance(result, IntVal)
        assert result.value == expected, f"Color.{tag} → expected {expected}, got {result.value}"


def test_match_wildcard_arm():
    result = _run("""
module t;
fn main() -> I64 effects() {
    return match 42 { _ -> 99, };
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 99


# ─────────────────────────────────────────────────────────────────────────────
# §12.11 — Conformance ledger: wrap-up completeness probes
# ─────────────────────────────────────────────────────────────────────────────

def test_runtime_struct_field_read_write():
    result = _run("""
module t;
struct Point { x: I64; y: I64; }
fn main() -> I64 effects() {
    var p = Point { x: 3, y: 4 };
    p.x = p.x + 1;
    return p.x + p.y;
}
""")
    assert isinstance(result, IntVal)
    assert result.value == 8


def test_runtime_nested_function_calls():
    result = _run("""
module t;
fn double(x: I64) -> I64 effects() { return x * 2; }
fn quadruple(x: I64) -> I64 effects() { return double(double(x)); }
fn main() -> I64 effects() { return quadruple(3); }
""")
    assert isinstance(result, IntVal)
    assert result.value == 12


def test_runtime_recursive_fibonacci():
    result = _run("""
module t;
fn fib(n: I64) -> I64 effects(recurse) {
    if (n <= 1) { return n; }
    return fib(n - 1) + fib(n - 2);
}
fn main() -> I64 effects(recurse) { return fib(7); }
""")
    assert isinstance(result, IntVal)
    assert result.value == 13


def test_runtime_bool_short_circuit():
    # 'and' should not evaluate right side if left is false
    result = _run("""
module t;
fn explode() -> Bool effects() {
    let x: I64 = 1 / 0;
    return true;
}
fn main() -> Bool effects() {
    return false and explode();
}
""")
    # Would trap if explode() were evaluated; passes if short-circuit works
    assert isinstance(result, BoolVal)
    assert result.value is False


def test_runtime_string_literal_type():
    result = _run("""
module t;
fn f(s: Str) -> Str effects() { return s; }
fn main() -> Str effects() { return f("hello"); }
""")
    assert hasattr(result, '__class__')
    assert 'Str' in type(result).__name__ or hasattr(result, 'value')


# ─────────────────────────────────────────────────────────────────────────────
# v47.59+1 — discharge_blocked suppresses cascading E_OWN_UNDISCHARGED
# ─────────────────────────────────────────────────────────────────────────────

def _make_file_protocol() -> str:
    return """\
protocol FileP { states { Open, Closed } init Open; terminal { Closed }
    transitions { close: Open -> Closed; } }
resource File { protocol: FileP; fields { fd: I32; } }
fn make_f() -> File effects() { return File { fd: 0 }; }"""


def _owncheck_codes(src: str) -> tuple[int, list[str]]:
    import re as _re, tempfile as _tmp, pathlib as _pl, io as _io
    import contextlib as _cl
    from axiomzig.cli import main as _main
    p = _pl.Path(_tmp.mktemp(suffix=".az"))
    p.write_text(src, encoding="utf-8")
    out, err = _io.StringIO(), _io.StringIO()
    try:
        with _cl.redirect_stdout(out), _cl.redirect_stderr(err):
            rc = _main(["owncheck", str(p), "--no-workspace-discovery"])
    except SystemExit as e:
        rc = int(e.code) if isinstance(e.code, int) else 1
    except Exception:
        rc = 1
    p.unlink(missing_ok=True)
    combined = out.getvalue() + "\n" + err.getvalue()
    codes = sorted(set(_re.findall(r"\b[ER]_[A-Z0-9_]+\b", combined)))
    return rc, codes


class TestBorrowLiveNoCascade:
    """
    When a transition is blocked by E_OWN_BORROW_LIVE, the resource remains
    in a non-terminal state at scope exit but E_OWN_UNDISCHARGED must NOT
    be emitted.  The programmer attempted the discharge; the root cause
    (live borrow) has already been reported.
    """

    def test_borrow_live_suppresses_undischarged(self):
        src = f"""\
module t.borrow_cascade_0;
{_make_file_protocol()}
fn peek(r: RefConst<File>) -> Unit effects() {{ return unit; }}
fn run() -> Unit effects(protocol_step) {{
    let f = make_f();
    let r: RefConst<File> = borrow f;
    peek(r);
    f.close();
    return unit;
}}"""
        rc, codes = _owncheck_codes(src)
        assert rc == 1
        assert "E_OWN_BORROW_LIVE" in codes, f"expected BORROW_LIVE, got {codes}"
        assert "E_OWN_UNDISCHARGED" not in codes, (
            f"E_OWN_UNDISCHARGED must be suppressed when blocked by BORROW_LIVE; got {codes}"
        )

    def test_scoped_borrow_then_close_passes(self):
        """Block ends → borrow gone → close succeeds: no errors."""
        src = f"""\
module t.borrow_cascade_1;
{_make_file_protocol()}
fn peek(r: RefConst<File>) -> Unit effects() {{ return unit; }}
fn run() -> Unit effects(protocol_step) {{
    let f = make_f();
    {{ let r: RefConst<File> = borrow f; peek(r); }}
    f.close();
    return unit;
}}"""
        rc, codes = _owncheck_codes(src)
        assert rc == 0, f"expected pass, got rc={rc} codes={codes}"

    def test_undischarged_still_fires_when_no_attempt(self):
        """No close at all → E_OWN_UNDISCHARGED must still fire."""
        src = f"""\
module t.borrow_cascade_2;
{_make_file_protocol()}
fn run() -> Unit effects() {{
    let f = make_f();
    return unit;
}}"""
        rc, codes = _owncheck_codes(src)
        assert rc == 1
        assert "E_OWN_UNDISCHARGED" in codes, f"E_OWN_UNDISCHARGED must fire; got {codes}"

    def test_branch_miss_still_fires_undischarged(self):
        """False branch misses close → E_OWN_UNDISCHARGED must still fire."""
        src = f"""\
module t.borrow_cascade_3;
{_make_file_protocol()}
fn run(flag: Bool) -> Unit effects(protocol_step) {{
    let f = make_f();
    if (flag) {{ f.close(); }} else {{ }}
    return unit;
}}"""
        rc, codes = _owncheck_codes(src)
        assert rc == 1
        assert "E_OWN_UNDISCHARGED" in codes, f"branch-miss must still emit UNDISCHARGED; got {codes}"

    def test_double_close_emits_proto_transition_not_undischarged(self):
        """Double close → E_PROTO_TRANSITION, not UNDISCHARGED."""
        src = f"""\
module t.borrow_cascade_4;
{_make_file_protocol()}
fn run() -> Unit effects(protocol_step) {{
    let f = make_f();
    f.close();
    f.close();
    return unit;
}}"""
        rc, codes = _owncheck_codes(src)
        assert rc == 1
        assert "E_PROTO_TRANSITION" in codes
        assert "E_OWN_UNDISCHARGED" not in codes

    def test_multiple_protocols_each_get_own_flag(self):
        """
        Two resources: one with live borrow at close, one with no attempt.
        Only the borrow-blocked one gets suppression.
        """
        src = """\
module t.borrow_cascade_5;
protocol FP { states { Open, Closed } init Open; terminal { Closed }
    transitions { close: Open -> Closed; } }
resource File { protocol: FP; fields { fd: I32; } }
fn make_f() -> File effects() { return File { fd: 0 }; }
fn peek(r: RefConst<File>) -> Unit effects() { return unit; }
fn run() -> Unit effects(protocol_step) {
    let f1 = make_f();
    let f2 = make_f();
    let r: RefConst<File> = borrow f1;
    peek(r);
    f1.close();
    return unit;
}"""
        rc, codes = _owncheck_codes(src)
        assert rc == 1
        assert "E_OWN_BORROW_LIVE" in codes
        assert "E_OWN_UNDISCHARGED" in codes, (
            "f2 was never closed so E_OWN_UNDISCHARGED must still fire for it"
        )
        # Only one UNDISCHARGED (for f2), not two (not also for f1)
        # Can't count occurrences from code set; just assert both present
