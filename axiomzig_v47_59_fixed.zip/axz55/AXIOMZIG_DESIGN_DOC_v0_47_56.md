# AxiomZig v0.47.56 Design Note — Sectioned Package-Interface Sync Diagnostics

## Design decision

`check-package-interface-sync` remains a strict equality check between the checked-in package-interface artifact and the deterministic artifact emitted from source annotations plus preserved package policy fields.

v0.47.56 changes only the diagnostic surface. Instead of reporting a single generic mismatch, the command classifies top-level mismatches by section.

## Rationale

After v0.47.55, package-interface drift can occur independently in several domains:

- function surface
- resource surface
- protocol surface
- function/resource/protocol lifecycle metadata
- package identity/compatibility policy
- extra fields not preserved by canonical emission

A generic “out of sync” message is no longer enough for efficient debugging. The user needs to know whether to inspect source `pub` annotations, lifecycle annotations, package policy, or non-canonical local fields.

## Classification policy

The sync mismatch classifier is intentionally shallow and deterministic. It compares top-level canonical package-interface fields and maps them to stable user-facing labels:

- `public_functions` -> `functions`
- `public_resources` -> `resources`
- `public_protocols` -> `protocols`
- `public_function_metadata` -> `function lifecycle metadata`
- `public_resource_metadata` -> `resource lifecycle metadata`
- `public_protocol_metadata` -> `protocol lifecycle metadata`
- `compatibility` -> `package compatibility`
- `package_name` / `package_version` -> `package metadata`

Unknown fields are reported as extra or missing fields.

## Non-goals

v0.47.56 does not perform semantic diffs inside protocol/resource shapes, change package-interface schema, preserve unknown package-interface fields, relax sync equality, or make conformance parse raw source visibility annotations directly.

## Next design step

The next design step is protocol-shape publication diffing. Once protocol states/transitions are emitted into publication artifacts, `pubdiff` should classify incompatible removals separately from lifecycle metadata changes.
