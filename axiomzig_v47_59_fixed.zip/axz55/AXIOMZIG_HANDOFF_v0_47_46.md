# AxiomZig v0.47.46 Handoff — Dependency Manifest Consumption

## Status

v0.47.46 teaches the static analysis pipeline to consume previously exported package manifests as dependency inputs.

The main new command surface is still centered on:

```text
axiomzig conform <entry.az> --module-root <workspace> [--import-ownership <bundle.json> ...] [--dependency-manifest <manifest.json> ...] [--public-only] [--out <manifest.json>]
```

The same `--dependency-manifest` input is also accepted by:

- `check`
- `typecheck`
- `cfg`
- `owncheck`
- `ownsig`
- `interpret`

This remains a **static dependency-summary feature**. Dependency manifests supply ownership summaries; they do not cause dependency source execution or host-side runtime loading.

## What changed in v0.47.46

### 1. Exported package manifests can now be consumed directly

A previously exported conformance manifest can now stand in for dependency source ownership derivation.

That means a consumer workspace can import a dependency module such as `dep.api`, provide:

```text
--dependency-manifest dep_manifest.json
```

and analyze successfully even when the dependency source tree is not present under the consumer `--module-root`.

### 2. Dependency manifests are validated before use

Dependency manifests are now checked for:

- `schema_version` beginning with `axiomzig.conformance.`
- `status == "ok"`
- presence of `internal_signatures`
- `manifest_hash` matching the manifest body when the hash is present

Malformed, failed, or tampered dependency manifests now fail fast with a clean import/conformance error.

### 3. Dependency-backed imports are distinct from opaque externals

Module-graph resolution now distinguishes three cases for non-workspace imports:

1. **dependency manifest import**
   - exact imported module is exported by a supplied dependency manifest
   - treated as statically satisfied by manifest-derived summaries

2. **external contract import**
   - no dependency manifest module, but imported ownership signatures cover it

3. **opaque external import**
   - unresolved and unsummarized boundary

Dependency-backed imports no longer generate opaque-import warnings.

### 4. Conformance manifests now record dependency imports explicitly

The exported conformance artifact now includes:

- `dependency_modules`
- `dependency_imports`
- per-module `module_graph[...].dependency_imports`

and keeps those imports out of per-module/top-level `external_imports`.

## Files changed

Primary implementation:

- `axiomzig/cli.py`
- `axiomzig/module_graph.py`
- `axiomzig/ownership_signatures.py`

New tests:

- `tests/test_dependency_manifests_v47_46.py`

Updated docs:

- `AXIOMZIG_HANDOFF_CURRENT.md`
- `AXIOMZIG_DESIGN_DOC_CURRENT.md`
- `AXIOMZIG_INTERPRETER_PROGRESS_CURRENT.md`
- `NEXT_STEPS_v47_46.md`
- versioned `v0.47.46` handoff/design notes

## Validation performed

- `python -m py_compile axiomzig/*.py tests/test_dependency_manifests_v47_46.py`
- `pytest -q tests/test_dependency_manifests_v47_46.py tests/test_conformance_export_v47_44.py tests/test_conformance_manifest_stabilization_v47_45.py tests/test_whole_program_negative_v47_43.py tests/test_module_graph_hardening_v47_42.py tests/test_module_graph_v47_41.py`
  - result: `27 passed`

## Important boundary rules

1. **Workspace internal modules** are still summarized from source.
2. **Dependency manifests** provide static dependency summaries without re-deriving dependency source.
3. **Opaque externals** still remain explicit unresolved boundaries.
4. **Runtime stubs are not required** for static whole-program dependency consumption.
5. **Dependency manifest exports are exact-module boundaries** under the current model.
6. **`--public-only` dependency manifests expose only their exported module set**.

## Known limitations

v0.47.46 still does not implement:

- signature-level trust policy beyond manifest self-hash validation
- source digest pinning of dependencies against out-of-band expectations
- dependency versioning / package identity rules beyond module names
- downstream manifest linking/merging as a separate package manager concept
- cyclic fixed-point solving across source modules
- explicit language-level public/export visibility declarations

## Recommended next step

Stabilize dependency consumption and then tighten package-interface policy.

Recommended v0.47.47 scope:

1. dependency-manifest regression locking across all static commands
2. duplicate/conflicting dependency manifest detection
3. explicit trust/pinning fields for dependency manifests
4. start separating package publication policy from debug/CI manifest policy
