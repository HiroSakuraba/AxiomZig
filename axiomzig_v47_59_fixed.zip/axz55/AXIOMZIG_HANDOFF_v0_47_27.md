# AxiomZig Front-End Handoff — v0.47.27

**Date:** 2026-04-25  
**Replaces:** `AXIOMZIG_HANDOFF_v0_47_26.md`  
**Repo snapshot:** v0.47.26 baseline plus static imported dotted-call support for fully qualified module paths

---

## 1. State of play

The awkward `interpret`-only imported-call tolerance is gone.

Fully qualified imported call surfaces like:

```text
demo.util.add(...)
```

now pass through the normal front-end when the module imports `demo.util`.

That means the CLI runtime imported-call lane is now aligned with the checker instead of relying on a tactical filter.

---

## 2. What actually changed

### 2.1 Resolver now recognizes full imported module prefixes

`resolve.py` no longer requires the first dotted segment to be the local import alias.

If a dotted expression matches an imported module path or one of its members, it is classified as `import_member`.

### 2.2 Elaborator and typechecker now agree with that rule

The same fully qualified imported-path recognition was added to:

- `elaborate.py`
- `typecheck.py`

Typechecking also now maps fully qualified imported call surfaces onto the supplied imported ownership/type signatures.

### 2.3 The CLI no longer filters unresolved imported dotted-name errors

The helper that used to suppress imported unresolved-name errors inside `axiomzig interpret` has been removed.

That is important because it means imported runtime execution now depends on a real front-end capability, not on a subcommand-specific waiver.

---

## 3. Tests added in this slice

### Resolution

- `tests/test_resolution.py::test_resolution_accepts_fully_qualified_import_member_path`

### Typecheck

- `tests/test_typecheck.py::test_typecheck_imported_call_accepts_fully_qualified_module_path`

### CLI

- `tests/test_cli.py::test_cli_check_accepts_fully_qualified_import_call_without_interpret_tolerance`
- `tests/test_cli.py::test_cli_interpret_fully_qualified_import_call_without_tolerance`

---

## 4. Validation notes

Validated here:

- focused suite → 92 passed
- `python -m compileall -q axiomzig tests` passed

Focused suite used:

- `tests/test_resolution.py`
- `tests/test_typecheck.py`
- `tests/test_cli.py`
- `tests/test_interpreter_runtime.py`
- `tests/test_interpreter_conformance.py`
- `tests/test_interpreter_imported_calls_v47_23.py`
- `tests/test_interpreter_imported_summaries.py`
- `tests/test_interpreter_imported_cleanup.py`
- `tests/test_interpreter_conformance_ledger.py`

---

## 5. Remaining best work

The next best step is **not** more imported-path parsing. That seam is fixed.

The next best step is to move harder imported ownership cases into source-level coverage, especially:

1. imported move/reinitialize-through-`Ref<Holder>` via CLI bundles,
2. imported resource replacement cases that interact with later local protocol steps,
3. continued pressure against any drift between runtime place semantics and imported ownership summaries.
