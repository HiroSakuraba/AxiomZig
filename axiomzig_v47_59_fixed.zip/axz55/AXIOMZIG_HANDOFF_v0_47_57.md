# AxiomZig v0.47.57 Handoff — Public Resource/Protocol Shape Publication

## Current status

v0.47.57 completes the remaining source-publication steps after v0.47.55/v0.47.56 by making the public resource/protocol surface shape explicit in the package-interface and publication manifests.

The source-publication invariant remains unchanged:

```text
.az source annotations -> canonical package-interface emitter -> conformance/publication/pubdiff tooling
```

Conformance and publication tooling still consume `axiomzig.package.json` / emitted artifacts rather than reinterpreting raw source visibility.

## What changed

### Package-interface shape fields

`axiomzig.package.json` can now include:

- `public_resource_shapes`
- `public_protocol_shapes`

A public resource shape records:

- protocol binding, if any
- ordered public field list with stable type text

A public protocol shape records:

- states
- initial state
- terminal states
- named transitions with source/target states

### Publication manifest shape fields

Conformance manifests and publication manifests now carry the same shape fields when a package interface exports public resources/protocols.

### `pubdiff` shape classification

`pubdiff` now separates shape changes from declaration-presence and lifecycle changes.

Protocol-shape policy:

- removed state: incompatible
- added state: compatible
- init state changed: incompatible
- removed terminal state: incompatible
- added terminal state: compatible
- removed transition: incompatible
- added transition: compatible
- transition source/target changed: incompatible

Resource-shape policy:

- protocol binding changed: incompatible
- field removed: incompatible
- field added: compatible
- field type changed: incompatible

### Sync diagnostics

`check-package-interface-sync` now reports stale shape sections as:

- `resource shapes`
- `protocol shapes`

## Files changed

Primary implementation:

- `axiomzig/module_graph.py`
- `axiomzig/publication_diff.py`
- `axiomzig/cli.py`

New tests:

- `tests/test_public_shape_publication_diff_v47_57.py`

Updated docs:

- `AXIOMZIG_HANDOFF_CURRENT.md`
- `AXIOMZIG_HANDOFF_v0_47_57.md`
- `AXIOMZIG_DESIGN_DOC_CURRENT.md`
- `AXIOMZIG_DESIGN_DOC_v0_47_57.md`
- `NEXT_STEPS_v47_57.md`

## Validation record

Completed here:

```text
python -S compile checks for:
  axiomzig/cli.py
  axiomzig/module_graph.py
  axiomzig/publication_diff.py
  tests/test_public_shape_publication_diff_v47_57.py
  tests/test_public_resource_protocol_interface_v47_55.py
  tests/test_package_interface_sync_diagnostics_v47_56.py
```

Manual validation completed for:

- package-interface emission including shape fields
- publication manifest emission including shape fields
- protocol-shape pubdiff classification
- resource-shape pubdiff classification

`pytest` still hangs in this container before returning, so targeted and full pytest should be rerun locally.

## Remaining deferred work

- module-level `pub`
- `export`
- `pub struct`
- transitive dependency compatibility closure
- signed publication manifests
- stronger CI fixture for full `check-package-interface-sync` over mixed function/resource/protocol packages
