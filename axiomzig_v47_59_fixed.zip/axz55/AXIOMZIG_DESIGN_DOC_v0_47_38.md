# AxiomZig v0.47.38 Design Note — Canonical Imported Function Contract

## Principle

Every imported function signature must be normalized exactly once. Downstream systems consume the normalized contract instead of reparsing paths, revalidating indexes, or independently interpreting `ref_params`.

## Contract shape

A normalized imported function contract contains:

- function name,
- positional parameter type texts,
- return type text,
- declared effects,
- raw ref-param declarations for compatibility,
- flattened normalized ref effects:
  - ref parameter index,
  - mode,
  - root type,
  - original path text,
  - parsed path tuple,
  - target state text.

## Boundary rules

The normalizer is the single enforcement point for imported path syntax:

- empty path means whole referenced object,
- dotted field paths are accepted,
- numeric array indexes are accepted as concrete tuple indexes,
- dynamic or wildcard indexes are rejected,
- duplicate ref-param indexes are rejected,
- ref-param indexes outside the parameter list are rejected,
- mut summaries must correspond to `Ref<T>` parameters,
- const summaries must correspond to `Ref<T>` or `RefConst<T>` parameters.

## Current downstream consumers

- TypeChecker reports malformed contracts as clean diagnostics.
- Ownership analysis consumes normalized ref effects for imported summaries.
- Interpreter uses normalized paths for stub resource-write policy and imported ref-effect application.

## Remaining cleanup

v47.38 intentionally preserves the existing public `FunctionOwnershipSignature` API. A later cleanup can move CFG/typecheck/interpreter call sites to pass `NormalizedImportedFunctionContract` directly, but this release establishes the canonical representation first.
