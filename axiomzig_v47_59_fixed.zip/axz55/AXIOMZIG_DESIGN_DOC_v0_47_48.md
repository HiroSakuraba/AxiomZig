# AxiomZig Design Note v0.47.48 — Dependency Trust Policy

## Goal

v0.47.46 made conformance manifests usable as dependency-summary inputs.
v0.47.47 made that input set deterministic and conflict-checked.
v0.47.48 adds an explicit trust policy so dependency manifests are not accepted as anonymous blobs.

The design goal of this slice is:

> Make dependency-summary consumption depend on explicit package identity and exact manifest integrity, with an optional pinned dependency set.

## Design decisions in v0.47.48

### 1. Package identity is now part of the manifest contract

Conformance manifests now export:

- `package_name`
- `package_version`
- `package_id`

The invariant is:

```text
package_id == f"{package_name}@{package_version}"
```

Dependency consumption now validates that invariant rather than treating package identity as absent or advisory.

### 2. Manifest hashes are mandatory for dependency consumption

Earlier versions allowed dependency manifests to omit `manifest_hash` and still be accepted.
That is no longer allowed.

Current rule:

- `manifest_hash_algorithm` must be `sha256`
- `manifest_hash` must be present
- `manifest_hash` must match the manifest body

This gives dependency consumers a stable integrity check instead of “best effort” validation.

### 3. Dependency locks pin package identity + manifest hash + exported modules

The new lock schema is intentionally small:

- package identity
- manifest hash
- exported module list

That is enough to pin:

1. **who** the provider claims to be
2. **what exact manifest body** is being trusted
3. **which module surface** is expected from that provider

This is a static trust artifact, not a runtime artifact.

### 4. Lockfiles are exact-set constraints, not loose hints

If a dependency lock is provided, the current implementation requires:

- every provided dependency manifest appears in the lock
- every locked package is provided
- each manifest hash matches the locked hash
- each manifest exports exactly the locked module set

This is intentionally strict. The purpose is to make dependency acceptance deterministic, not permissive.

### 5. Runtime behavior remains outside the dependency trust model

Even with dependency manifests and dependency locks:

- static ownership/type/import checking may succeed
- runtime interpreter execution still requires explicit import stubs

That separation remains intentional:

- dependency manifest = static ownership contract
- dependency lock = trust/pinning policy for those contracts
- import stub = runtime executable behavior

## What v0.47.48 verifies

In addition to v0.47.47 behavior, this slice now verifies:

1. conformance manifests export package identity fields
2. dependency manifests missing package identity are rejected
3. dependency manifests missing manifest hashes are rejected
4. dependency locks can pin accepted dependency manifests successfully
5. dependency-lock hash mismatches fail explicitly
6. dependency locks requiring additional packages fail explicitly

## Non-goals in v0.47.48

This version still does not implement:

- signed manifests or trust roots
- semantic-version compatibility ranges
- selective/provider preference among multiple packages exporting overlapping modules
- public API publication separate from current manifest export policy
- automatic lock generation from a package manifest language surface

## Why this version matters

Without package identity and exact hash pinning, dependency manifests are still only “trusted by file path.”
That is not enough once whole-program ownership summaries become reusable package artifacts.

v0.47.48 makes dependency-summary acceptance explicit enough to support reproducible downstream analysis.

## Next design step

The next design step is publication/interface policy and dependency metadata refinement:

1. decide whether a separate package manifest should define public exports explicitly
2. decide whether conformance/export manifests should expose compatibility metadata beyond ownership summaries
3. decide whether lockfiles should be generated automatically from a higher-level package spec
4. decide whether identical duplicate providers can ever be legalized under explicit package identity rules
