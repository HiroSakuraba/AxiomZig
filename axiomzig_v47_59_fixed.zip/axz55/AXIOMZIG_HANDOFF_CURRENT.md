# AxiomZig Handoff — v0.47.58

## What v0.47.58 adds

v0.47.58 hardens the publication artifact track in two places:

1. **Mixed end-to-end publication fixture**
   - exercises `emit-package-interface`
   - checks `check-package-interface-sync`
   - runs `conform --publication-out`
   - runs `pubdiff`
   - includes public functions, public resources, public protocols, lifecycle metadata, resource/protocol shapes, and dependency metadata

2. **Transitive dependency publication closure**
   - publication/conformance manifests now carry `dependency_publication_closure`
   - closure records include direct and transitive dependency pins
   - records include `package_name`, `package_version`, `package_id`, `manifest_hash`, `modules`, `export_scope`, `direct`, `depth`, `required_by`, `public_surface_digest`, and when available a compact `public_surface`
   - `pubdiff` compares closure public surfaces and reports transitive dependency API movement separately from direct dependency lock/policy changes

The artifact invariant remains:

```text
source annotations -> package-interface artifact -> conformance manifest -> publication manifest -> pubdiff
```

No downstream publication tool re-parses raw `.az` source to recover public API facts.

## Files changed

- `axiomzig/ownership_signatures.py`
  - added dependency public-surface extraction
  - added deterministic dependency public-surface digest
  - added `dependency_publication_closure_from_manifest_inputs`

- `axiomzig/module_graph.py`
  - added `dependency_publication_closure` to conformance manifests
  - copied closure into publication manifests
  - extended dependency compatibility checks so declared ranges can match transitive closure packages when available

- `axiomzig/cli.py`
  - computes dependency closure during `conform`
  - passes closure into compatibility and manifest construction
  - improves `check-package-interface-sync` fallback behavior for stale checked-in interfaces that have become internally invalid

- `axiomzig/publication_diff.py`
  - added closure comparison
  - added transitive dependency public-surface comparison
  - emits `dependency_closure` and `dependency_closure_api` categories

- `tests/test_dependency_closure_v47_58.py`
  - direct + transitive closure emission
  - transitive API movement diff
  - transitive range enforcement
  - mixed publication pipeline fixture

## New diff behavior

`pubdiff` now separates:

- direct dependency refs / lock changes
- dependency compatibility policy changes
- dependency closure pin changes
- dependency closure public API changes

A transitive dependency public API removal is classified as incompatible through a `dependency_closure_api` issue, e.g. `DEP_E_PUBLIC_FUNCTION_REMOVED`.

## Validation

Passed:

```bash
pytest -q tests/test_dependency_closure_v47_58.py \
  tests/test_public_shape_publication_diff_v47_57.py \
  tests/test_public_resource_protocol_interface_v47_55.py \
  tests/test_package_interface_sync_diagnostics_v47_56.py \
  tests/test_publication_diff_v47_53.py \
  tests/test_publication_metadata_v47_51.py \
  tests/test_dependency_compatibility_v47_52.py
```

Result: `27 passed`.

Compile checks passed for touched modules.

Full `pytest -q` was attempted, but the environment timed out after passing beyond the 50% mark. Rerun full pytest locally.

## Important design note

The closure can classify transitive API movement precisely only when dependency manifests carry `public_surface`. v0.47.58 publications do. Older dependency manifests still contribute pin/ref closure data, but may not provide enough embedded surface detail for API-level classification.
