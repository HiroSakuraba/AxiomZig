# AxiomZig v0.47.57 Next Steps

## Immediate validation

1. Re-run targeted pytest locally:
   - `tests/test_public_shape_publication_diff_v47_57.py`
   - `tests/test_public_resource_protocol_interface_v47_55.py`
   - `tests/test_package_interface_sync_diagnostics_v47_56.py`
   - `tests/test_publication_diff_v47_53.py`
2. Re-run the full pytest suite locally. This container still hangs during pytest invocation.
3. Add a CI fixture that runs `emit-package-interface`, `check-package-interface-sync`, `conform --publication-out`, and `pubdiff` over a mixed package containing public functions, resources, protocols, lifecycle metadata, and shape changes.

## Next implementation candidates

1. **Transitive dependency compatibility closure**
   - current compatibility checks are still essentially direct-dependency checks
   - next step is to walk dependency publication refs transitively and detect incompatible dependency API movement

2. **Signed publication manifests**
   - add a detached/signature-ready manifest digest contract
   - keep signing optional and out of the core language runtime

3. **Module-level publicness design only**
   - do not implement yet
   - first write down whether `pub module` means "module listed as public" or "all declarations public by default"

4. **`pub struct` design only**
   - decide whether public structs are part of the same shape-policy surface as resources
   - avoid adding syntax before artifact semantics are explicit

## Deferred

- `export`
- host-dependent imported execution
- non-deterministic publication metadata
- weakening package-interface sync equality
