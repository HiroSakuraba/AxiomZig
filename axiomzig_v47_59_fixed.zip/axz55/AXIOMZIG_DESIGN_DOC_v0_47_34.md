# AxiomZig Front-End Design Doc — v0.47.34

**Date:** 2026-04-25  
**Replaces:** `AXIOMZIG_DESIGN_DOC_v0_47_31.md`  
**Repo snapshot:** v0.47.31 baseline plus corrected non-literal indexed-path boundary

---

## 1. Current architecture

The front-end still runs as:

```text
lexer -> parser -> resolve -> elaborate -> typecheck -> cfg -> ownership -> checker
```

The interpreter still runs only after that gate:

```text
checked module -> interpreter.py -> rendered result / trap
```

This slice does not broaden the indexed ownership model. It locks the boundary introduced by the v47.31 design notes: exact literal indexed paths are supported, abstract/dynamic indexed paths are not.

---

## 2. Corrective note on v47.31 → v47.33

The v47.31 handoff recommended source-level negative coverage for non-literal indexed imported paths. v47.33 implemented that goal, but also added undocumented recursive nested merge diagnostics for arrays/containers.

That diagnostic expansion may be useful later, but it changes observable checker output and should not ride along with the boundary patch. v47.34 restores the version discipline:

- semantic boundary changes go in this slice
- container diagnostic expansion is deferred to a separate reviewed slice

---

## 3. Indexed-path policy

Current policy:

1. Literal fixed-size array indices are supported for tracked ownership paths.
2. Non-literal indices are represented diagnostically as `[*]`.
3. A `Ref<T>` imported/reference ownership summary may not target a referent path containing `[*]`.
4. Imported summary effect paths may not contain wildcard/non-literal index components such as `[*].inner`.
5. Future abstract-index ownership must be designed explicitly; it should not be inferred from current exact-index machinery.

Reason: `hs[i]` can alias any element. Treating it as one concrete element is unsound; treating it as all elements requires a real abstract-index kill/join rule that does not yet exist.

---

## 4. New coverage

Regression coverage now exists for:

- non-literal indexed referent paths passed to imported `Ref<T>` summaries
- wildcard indexed paths inside imported ownership summary effects
- source-level CLI `check` diagnostics for both cases

The diagnostic-only array/container expansion from v47.33 is intentionally not part of this design slice.

---

## 5. Next best steps

### Step 1 — Opaque imported cleanup-helper policy

Define and implement one of these policies:

- **strict policy:** imported cleanup helpers require both an ownership summary and a runtime stub; otherwise cleanup replay traps with a clean diagnostic
- **limited builtin policy:** allow only registered deterministic cleanup builtins with typed argument/result coercion and ownership-summary authorization

Recommended: strict policy first, because it is smaller, easier to audit, and matches the current no-hidden-host-execution rule.

### Step 2 — Imported whole-resource replacement audit

Keep whole-resource replacement exact-path authorized. Do not allow broad replacement through dynamic/wildcard paths. Add regressions for:

- allowed exact whole-resource replacement through `Ref<Holder>`
- rejected dynamic-index whole-resource replacement through `Ref<Array<Holder, N>>`
- rejected wildcard summary replacement

### Step 3 — Array/container diagnostics as a separate slice

If nested diagnostics are wanted, reintroduce them deliberately with a documented contract:

- whether root diagnostics are always emitted
- whether nested field diagnostics are additional or replacing root diagnostics
- whether output ordering is stable
- how golden tests should tolerate path-specific detail

### Step 4 — Runtime/conformance ledger update

Only advance the conformance ledger when runtime behavior changes. This v47.34 slice is primarily static/checker behavior, so the v47.31 runtime ledger remains valid unless a later cleanup-helper policy changes interpreter behavior.

### Step 5 — Defer abstract-index ownership

Do not implement `hs[i]` ownership semantics yet. The sound implementation would require an abstract element state such as `[*]`, conservative aliasing against every literal element, and join/kill semantics across calls and branches. That is larger than the current interpreter stabilization track.
