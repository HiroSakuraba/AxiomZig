# AxiomZig Front-End Handoff — v0.47.24

**Date:** 2026-04-25  
**Replaces:** `AXIOMZIG_HANDOFF_v0_47_23.md`  
**Repo snapshot:** v0.47.23 baseline plus imported-call cleanup replay fixes and direct conformance tests

---

## 1. State of play

The interpreter now handles the first important `imported call` × `cleanup replay` seam correctly.

What is now real:

- imported calls can discharge a resource before a later `defer` / `errdefer` cleanup,
- deferred transition-method cleanups are skipped when the target has already been discharged,
- imported move/reinitialize flows update the runtime place so cleanup acts on the replacement resource,
- repeated deferred transitions still trap when the target state is non-terminal and the repetition should remain semantically visible.

This closes a real runtime hole rather than just adding tests.

---

## 2. Most important implementation facts

### 2.1 Duplicate cleanup suppression is now runtime behavior

The new interpreter helpers are centered around cleanup-target inspection before replay:

- identify whether a deferred stmt is a transition-method cleanup,
- resolve its runtime target place,
- inspect the current value at replay time,
- skip only when the target is already discharged.

The key point is **replay-time inspection**. Suppression is not baked in when the `defer` is registered.

### 2.2 “Already discharged” is intentionally narrow

Current skip conditions:

- target place reads as `Moved`, or
- target is a `ResourceVal` already in the transition target state and that target state is terminal.

This is conservative on purpose. It prevents the runtime from silently suppressing visible semantic errors in non-terminal states.

### 2.3 Imported reinitialization and cleanup now compose correctly

The important ordering remains:

1. imported summaries mutate ownership/resource state,
2. declarative stub writes perform replacement writes,
3. later cleanup replay reads the current runtime place.

Do not weaken that by caching cleanup targets or by snapshotting values at `defer` registration time.

---

## 3. Tests added in v0.47.24

New file:

```text
tests/test_interpreter_imported_cleanup.py
```

Coverage:

1. imported close causes `errdefer` cleanup skip;
2. imported close causes normal `defer` cleanup skip;
3. imported move/reinitialize updates the later deferred cleanup target;
4. repeated deferred transition still traps when the repeated target state is not terminal.

Regression validation also re-ran:

- `tests/test_interpreter_imported_calls_v47_23.py`
- `tests/test_interpreter_imported_summaries.py`
- `tests/test_interpreter_conformance.py`
- `tests/test_interpreter_runtime.py`

---

## 4. Validation notes

Validated in this environment:

- targeted interpreter runtime suite → 33 passed
- `python -m compileall -q axiomzig tests` passed

Command shape used here:

```bash
PYTHONPATH=. PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 /opt/pyvenv/bin/python -m pytest -q -p no:cacheprovider ...
```

---

## 5. Next best work

The next slice should **not** be more ad hoc interpreter features. It should be a coverage/control slice:

```text
v47.25 — runtime conformance ledger
```

Concrete targets:

1. enumerate every claimed interpreter feature,
2. map each one to exact direct-runtime and source-level tests,
3. mark remaining narrow/unsupported cases explicitly,
4. then decide whether cleanup suppression needs broader forms.
