# AxiomZig v0.47.56 Handoff — Package-Interface Sync Diagnostics

## Current status

v0.47.56 continues the source-publication bridge work by improving diagnostics for `check-package-interface-sync`.

The previous behavior reported a generic out-of-sync error whenever the checked-in `axiomzig.package.json` differed from the deterministic source-emitted package interface. This version keeps the same canonical artifact model but reports which manifest sections disagree.

## What changed

`check-package-interface-sync` now reports mismatched package-interface sections, including:

- `public modules`
- `functions`
- `resources`
- `protocols`
- `function lifecycle metadata`
- `resource lifecycle metadata`
- `protocol lifecycle metadata`
- `package metadata`
- `package compatibility`
- unknown extra/missing fields

Example diagnostic:

```text
package interface sync error: axiomzig.package.json is out of sync with source-declared public API; mismatched sections: functions, resources, protocols; run emit-package-interface
```

## Files changed

Primary implementation:

- `axiomzig/cli.py`

New tests:

- `tests/test_package_interface_sync_diagnostics_v47_56.py`

Updated docs:

- `AXIOMZIG_HANDOFF_CURRENT.md`
- `AXIOMZIG_HANDOFF_v0_47_56.md`
- `AXIOMZIG_DESIGN_DOC_CURRENT.md`
- `AXIOMZIG_DESIGN_DOC_v0_47_56.md`
- `NEXT_STEPS_v47_56.md`

## Validation record

Completed here:

```text
python -S -m py_compile axiomzig/cli.py tests/test_package_interface_sync_diagnostics_v47_56.py
```

Pytest invocation intermittently hung in this container before producing output, so targeted pytest and full-suite pytest should be re-run locally.

## Boundary rules preserved

1. `axiomzig.package.json` remains the canonical emitted artifact.
2. Source annotations still feed the emitter; conformance/publication tools consume artifacts.
3. Sync diagnostics are reporting-only. They do not relax or change the equality check.
4. Unknown extra fields remain sync mismatches because canonical emission does not preserve them.

## Next best work

The next implementation slice should be protocol-shape publication diffs: publish enough protocol structure to distinguish harmless lifecycle/API metadata changes from incompatible changes to public protocol states and transitions.
