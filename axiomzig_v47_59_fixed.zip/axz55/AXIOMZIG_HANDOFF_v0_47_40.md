# AxiomZig v0.47.40 Handoff — Imported Contract Soundness Completion

## Status

v0.47.40 completes the imported-contract soundness pass requested after the v47.39 stabilization bundle.  The work intentionally does not add new language features.  It tightens the imported ownership/runtime boundary so the checker, CFG ownership analysis, and interpreter consume one normalized contract model.

## Implemented in this slice

### 1. Canonical imported path normalization

Imported ownership paths now normalize through a single representation:

```python
CanonicalPath = tuple[PathSegment, ...]
PathSegment(kind='field', value='inner')
PathSegment(kind='index', value=0)
```

Text and tuple forms are parsed at the boundary only.  Consumers derive display text or runtime tuple paths from the canonical form instead of re-parsing ad hoc strings.

Accepted literal-index spellings such as `items[0].inner` and `items.0.inner` normalize to the same canonical path.  Dynamic indexes, wildcards, slices, empty segments, and negative indexes remain rejected.

### 2. Summary overlap/conflict rejection

The imported summary normalizer now rejects:

- duplicate canonical paths with conflicting states
- overlapping parent/child summaries such as `inner` plus `inner.fd`
- dynamic/wildcard/disguised non-literal indexed paths

This prevents ownership analysis and runtime from interpreting a summary differently after normalization.

### 3. Stub effect auditing

Interpreter stubs now audit resource/ownership writes against the declared imported contract:

- a resource-bearing write outside the declared summary is rejected
- a declared stub write must leave the affected resource in the declared state
- scalar-only writes remain allowed without ownership summaries
- no arbitrary host callbacks are introduced

This closes the remaining hole where a stub could be registered but perform a resource effect not represented in the imported ownership summary.

### 4. Imported effects as fixed-point transitions

Imported reference effects continue to be installed into `_function_ref_effect_summaries` and are applied during CFG ownership analysis through the same call-ref transition machinery used for local summaries.  v47.40 adds an explicit adversarial test proving an imported effect participates in a branch join as a first-class transition.

### 5. Adversarial tests

New test file:

```text
tests/test_imported_contract_soundness_v47_40.py
```

Coverage includes:

- bracket/dot literal index canonicalization
- overlapping summary rejection
- conflicting canonical path rejection
- undeclared stub resource effect rejection
- declared-state mismatch auditing
- imported effect propagation through branch joins
- aliased mutable references across imported calls

## Changed files

```text
axiomzig/ownership_signatures.py
axiomzig/interpreter.py
tests/test_imported_contract_soundness_v47_40.py
AXIOMZIG_HANDOFF_v0_47_40.md
AXIOMZIG_DESIGN_DOC_v0_47_40.md
AXIOMZIG_INTERPRETER_PROGRESS_v47_40.md
```

`AXIOMZIG_HANDOFF_CURRENT.md`, `AXIOMZIG_DESIGN_DOC_CURRENT.md`, and `AXIOMZIG_INTERPRETER_PROGRESS_CURRENT.md` should point to the v47.40 documents in this bundle.

## Validation performed

Because the default pytest environment still hangs in this container, validation used `python -S` direct execution where possible.

Passed:

```text
python -S -m py_compile axiomzig/*.py tests/test_imported_contract_soundness_v47_40.py
```

Direct focused test execution passed:

```text
tests/test_imported_contract_soundness_v47_40.py: 7 passed
tests/test_imported_contract_unification_v47_38.py: 4 passed
tests/test_imported_contract_malformed_v47_39.py: 5 passed
```

Total directly executed focused tests: 16 passed.

## Known limits

- Full pytest still needs a clean local run outside this container.
- Whole-program ownership across real multi-module import graphs is not implemented yet.
- Imported contracts are still supplied externally; module graph discovery and summary serialization remain future work.

## Recommended next step

Proceed to **v47.41 — Whole-program imported ownership across module graphs** only after a clean local full-suite run of v47.40.

Scope for v47.41:

1. import graph resolution
2. signature bundle loading per module
3. cross-module summary lookup by fully qualified function name
4. deterministic failure for missing/stale module summaries
5. regression tests for multi-module ownership propagation
