# AxiomZig v0.47.58 Next Steps

## Immediate validation

1. Rerun full pytest locally:

```bash
pytest -q
```

The implementation environment timed out after passing beyond the 50% mark.

2. Run the targeted v47.58 and publication-track suite:

```bash
pytest -q tests/test_dependency_closure_v47_58.py \
  tests/test_public_shape_publication_diff_v47_57.py \
  tests/test_public_resource_protocol_interface_v47_55.py \
  tests/test_package_interface_sync_diagnostics_v47_56.py \
  tests/test_publication_diff_v47_53.py \
  tests/test_publication_metadata_v47_51.py \
  tests/test_dependency_compatibility_v47_52.py
```

## Next implementation candidate

### v0.47.59: signature-ready publication digest contract

Add:

- canonical publication digest command
- detached signature placeholder fields
- verification-ready schema without requiring actual signing keys
- stable digest over canonical JSON excluding signature fields

Do not make signing required yet.

## Design-only items still deferred

- `pub module`
- `pub struct`
- `export`
- dependency source syntax
- host-dependent imported execution

## Follow-up hardening

- Consider whether `dependency_publication_refs` should also embed `manifest_hash`; v0.47.58 leaves the existing direct refs shape stable and puts richer data in `dependency_publication_closure`.
- Add a fixture with diamond dependencies to exercise closure deduplication/conflict reporting.
- Decide whether dependency closure removal should remain incompatible or become compatible when no public API consumer evidence exists.
