# AxiomZig Front-End Design Doc — v0.47.27

**Date:** 2026-04-25  
**Replaces:** `AXIOMZIG_DESIGN_DOC_v0_47_26.md`  
**Repo snapshot:** v0.47.26 baseline plus static imported dotted-call resolution for fully qualified module paths

---

## 1. Current architecture

The static front-end still runs as:

```text
lexer -> parser -> resolve -> elaborate -> typecheck -> cfg -> ownership -> checker
```

The interpreter still runs as a runtime oracle after the front-end gate:

```text
checked module -> interpreter.py -> rendered result / trap
```

The important change in this slice is that imported dotted-call handling is now part of the normal front-end path rather than an `interpret`-only exception.

---

## 2. What changed in v0.47.27

### 2.1 Fully qualified imported call paths are now recognized statically

The front-end now accepts imported call surfaces written as fully qualified module paths, for example:

```text
demo.util.add(2, 3)
```

when the module contains:

```text
import demo.util;
```

This recognition now exists in the normal static layers instead of being deferred to runtime.

### 2.2 Resolver now classifies full imported module paths as import members

`resolve.py` previously only recognized imported dotted expressions when the first segment matched the local import alias, such as `util.add(...)`.

It now also recognizes dotted expressions whose full prefix matches an imported module path, so `demo.util.add` is classified as `import_member` instead of `unresolved`.

### 2.3 Elaborator and typechecker now follow the same imported-path rule

`elaborate.py` and `typecheck.py` now use the same basic imported-path recognition rule:

- alias-rooted imported calls like `util.add(...)` still work,
- fully qualified imported calls like `demo.util.add(...)` now also work,
- imported dotted names without a matching ownership signature still remain `import member`, not silently local names.

For typechecking, imported signature lookup now accepts both surfaces when they map to the same imported function name.

### 2.4 CLI interpret no longer needs a special unresolved-import tolerance

The temporary `interpret`-only filter for errors such as:

```text
unresolved dotted name demo.util.add
```

has been removed.

`axiomzig interpret` now relies on the ordinary checker result, because the checker itself understands these imported dotted-call surfaces.

That is the correct design boundary: runtime imported execution should depend on the same imported-call understanding as `check`, not on a CLI exception.

---

## 3. Interpreter / CLI status after this slice

### 3.1 CLI imported runtime support is now front-end aligned

The existing CLI imported runtime lane from v0.47.26 remains in place:

- `--import-ownership <json>`
- `--import-stubs <json>`

But it now runs through a cleaner front-end contract because fully qualified imported calls pass static checking directly.

### 3.2 Source-level imported coverage widened slightly

This slice adds explicit source-level regression coverage for:

- resolution of fully qualified imported call paths,
- typechecking of fully qualified imported call paths with imported ownership signatures,
- `check` acceptance of fully qualified imported call paths,
- `interpret` execution of fully qualified imported call paths without any CLI tolerance layer.

---

## 4. Strategic state

This removes one of the more awkward seams in the interpreter stack.

Previously, the system could execute certain imported calls correctly only because `axiomzig interpret` ignored a front-end error class in narrow cases. That meant the static/import boundary and the runtime/import boundary were not actually the same model.

After v0.47.27, that specific seam is gone. Imported dotted-call handling for fully qualified module paths is now a normal front-end feature.

The remaining imported-runtime weakness is no longer path recognition. It is source-level coverage for the harder ownership-sensitive imported cases, especially move/reinitialize flows through `Ref<Holder>`.

---

## 5. Recommended next work

1. Add source-level CLI coverage for imported move/reinitialize-through-`Ref<Holder>` flows.
2. Keep cleanup suppression summary-driven; do not widen it to opaque helpers without explicit ownership/effect summaries.
3. Consider unifying imported callable recognition in a dedicated helper shared across `resolve`, `elaborate`, and `typecheck` so the rule does not drift again.
