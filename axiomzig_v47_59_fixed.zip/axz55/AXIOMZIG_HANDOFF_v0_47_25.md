# AxiomZig Front-End Handoff — v0.47.25

**Date:** 2026-04-25  
**Replaces:** `AXIOMZIG_HANDOFF_v0_47_24.md`  
**Repo snapshot:** v0.47.24 baseline plus runtime conformance ledger artifacts and ledger self-check test coverage

---

## 1. State of play

The main change in this slice is control and auditability, not a new interpreter mechanism.

There is now a canonical runtime conformance ledger:

- `docs/interpreter_runtime_conformance_ledger_v47_25.json`
- `docs/interpreter_runtime_conformance_ledger_v47_25.md`

That ledger is now the place to look first before claiming that an interpreter feature is supported.

---

## 2. What is now explicit instead of implicit

The ledger distinguishes:

- broad support,
- tested but intentionally narrow support,
- and the exact source-level/direct-runtime tests that justify each claim.

Examples of broad support currently recorded:

- local calls,
- arithmetic/traps,
- `Option` / `Result` / `match` / `try` / `catch`,
- lexical cleanup,
- runtime borrow/move,
- runtime `Ref` / `RefConst` fidelity,
- protocol transitions,
- string indexing/slicing,
- nested resource replacement,
- local receiver-method dispatch.

Examples of narrow support currently recorded:

- arrays/slices are mostly direct-runtime coverage,
- imported calls require deterministic stubs,
- imported nested summary behavior is direct-runtime coverage,
- imported cleanup replay is only for transition-method cleanup calls,
- duplicate-cleanup suppression does not cover arbitrary wrappers.

---

## 3. New test/control mechanism

New file:

```text
tests/test_interpreter_conformance_ledger.py
```

This test enforces three useful invariants:

1. the ledger has the expected schema,
2. every supported entry cites at least one test,
3. every cited `tests/...::test_...` target really exists.

That means future updates that add or rename tests without updating the ledger will fail visibly.

---

## 4. Validation notes

Validated in this environment:

- `tests/test_interpreter_conformance_ledger.py` → 2 passed
- targeted interpreter runtime suite rerun → total 35 passed
- `python -m compileall -q axiomzig tests` passed

Command shape used here:

```bash
PYTHONPATH=. PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 /opt/pyvenv/bin/python -m pytest -q -p no:cacheprovider ...
```

---

## 5. Next best work

The next slice should be one decision, not three mixed together.

### Option A — generalize cleanup suppression carefully

Do this only if you are willing to introduce a canonical cleanup-target abstraction. Do **not** keep expanding one-off defer special cases.

### Option B — widen imported runtime source-level coverage

Add CLI-facing plumbing for imported signatures/stubs so imported runtime behavior stops being mostly direct-interpreter coverage.

If forced to choose one, I would do **Option B first** unless a concrete wrapper-cleanup bug is already in hand.
