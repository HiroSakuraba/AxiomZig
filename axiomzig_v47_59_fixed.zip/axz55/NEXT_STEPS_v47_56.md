# AxiomZig v0.47.56 Next Steps

## Immediate validation

1. Re-run targeted pytest for the sync-diagnostics slice in a local environment:
   - `tests/test_package_interface_sync_diagnostics_v47_56.py`
   - `tests/test_source_package_interface_v47_54.py`
   - `tests/test_public_resource_protocol_interface_v47_55.py`
2. Re-run the full pytest suite locally. This environment intermittently hung when invoking pytest, although `py_compile` completed.
3. Exercise `check-package-interface-sync` in CI against a package with mixed public functions/resources/protocols and stale lifecycle metadata.

## Next implementation candidates

1. **Protocol-shape publication diffs**
   - represent public protocol state/transition shape in `axiomzig.package.json`
   - classify removed states/transitions as incompatible
   - decide whether additive states/transitions are compatible, compatible-with-warning, or incompatible

2. **Resource-shape publication diffs**
   - decide whether public resource fields are API
   - decide whether protocol binding changes are resource API changes
   - emit shape metadata only after the compatibility policy is explicit

3. **Full docs rebasing**
   - collapse the accumulated v47.49-v47.56 append-only current docs into a clean chronological narrative
   - keep the versioned handoff/design files as audit trail

## Still deferred

- module-level `pub`
- `export`
- `pub struct`
- transitive dependency compatibility closure
- signed publication manifests
