# AxiomZig Design Doc — v0.47.58 Dependency Closure

## Goal

Add a deterministic artifact-level representation of direct and transitive dependency publication state so compatibility tooling can detect dependency API movement without re-parsing dependency source.

## New manifest field

Conformance and publication manifests may include:

```json
{
  "dependency_publication_closure": [
    {
      "package_name": "leaf",
      "package_version": "1.0.0",
      "package_id": "leaf@1.0.0",
      "manifest_hash": "...",
      "modules": ["leaf.api"],
      "export_scope": "package_interface",
      "direct": false,
      "depth": 2,
      "required_by": ["mid@1.0.0"],
      "public_surface_digest": "...",
      "public_surface": {
        "exported_modules": ["leaf.api"],
        "exported_functions": {"leaf.api": ["leaf.api.ping"]},
        "internal_signatures": {}
      }
    }
  ]
}
```

## Closure construction

For every direct dependency manifest input:

1. validate the dependency manifest
2. add the direct package record at depth `1`
3. extract its compact public surface
4. include `public_surface_digest`
5. import any nested `dependency_publication_closure` records
6. fall back to older `dependency_publication_refs` if no closure exists
7. merge duplicate records deterministically
8. reject same-package-id conflicts with different manifest hashes or public-surface digests

## Compatibility ranges

`compatibility.dependency_version_ranges` still applies to package names. v0.47.58 extends the lookup set from direct lock entries to the dependency closure when available.

This allows a top-level package to declare a bound on a transitive dependency such as:

```json
{
  "compatibility": {
    "dependency_version_ranges": {
      "leaf": "^1.0"
    }
  }
}
```

and have that checked even when only `mid` is passed as the direct dependency manifest.

## Diff classification

`pubdiff` compares dependency closure by package name.

Categories:

- `dependency_closure`
  - package added/removed
  - pin/digest changed

- `dependency_closure_api`
  - public function/resource/protocol changes inside dependency public surfaces
  - resource/protocol shape changes inside dependency public surfaces
  - dependency ownership-signature changes when present in public surface

Classification precedence remains:

```text
incompatible > compatible > metadata-only
```

A removed public API member inside a transitive dependency is incompatible.

## Backward compatibility

Older manifests without `dependency_publication_closure` are still accepted. They contribute `dependency_publication_refs` as closure-like pin data, but API-level surface classification is only possible when `public_surface` is present.

## Non-goals

v0.47.58 does not add:

- signature verification
- detached signing
- source-level dependency syntax
- module-level `pub`
- `pub struct`
- `export`
