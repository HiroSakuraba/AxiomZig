# AxiomZig v0.47.42 Handoff — Module Graph Hardening

## Status

v0.47.42 is a stabilization pass over the v0.47.41 whole-program module ownership layer. The primary goal was to harden module-graph correctness without changing ownership semantics.

The key policy change is:

> Imports that look like workspace-internal modules but are missing from `--module-root` are now hard errors.

Opaque external imports still exist, but only for imports outside the workspace namespace or imports backed by explicitly supplied external ownership contracts.

## Implemented

### 1. Import-name and path normalization

`axiomzig/module_graph.py` now normalizes dotted module identities before graph resolution. This removes drift between:

- entry paths with `..` / relative segments
- root paths with `..` / relative segments
- file-path candidates (`util.az`, `util.axz`, `util/mod.az`, `util/module.az`)
- declared module names inside source files

The graph now consistently uses one canonical dotted identity per module.

### 2. Missing internal module detection

The resolver now distinguishes:

1. **workspace-internal imports** — same top-level namespace as the entry module
2. **external imports** — different namespace, or explicitly covered by external ownership summaries

If an internal import cannot be found under `--module-root` and there is no external contract covering it, the graph emits:

- `E_MODULE_MISSING`

If the import is external/unresolved, the graph still emits:

- `W_MODULE_OPAQUE`

### 3. Duplicate module candidate detection

If an import name resolves to more than one file candidate, for example both:

- `demo/util.az`
- `demo/util/module.az`

then the graph now emits:

- `E_MODULE_DUPLICATE_CANDIDATE`

and stops using that import.

### 4. Duplicate declared module-name detection

If different files encountered through graph traversal both declare the same module path, the graph now emits:

- `E_MODULE_DUPLICATE`

This guards against silent accidental reuse of a module identity.

### 5. Stronger cycle diagnostics

Cycle errors now report the full cycle chain, for example:

```text
import cycle detected: demo.a -> demo.b -> demo.a
```

Code:

- `E_MODULE_CYCLE`

### 6. Workspace summary conflict detection

`collect_workspace_ownership_signatures(...)` now checks workspace-exported summaries against any preexisting imported/external summary of the same function name.

If they disagree semantically, the graph emits:

- `E_MODULE_SUMMARY_CONFLICT`

Comparison uses normalized imported-function contracts where possible, so equivalent summaries with different path text formatting do not spuriously conflict.

## Tests added

New file:

- `tests/test_module_graph_hardening_v47_42.py`

Coverage:

- missing internal module -> error
- unresolved external module -> opaque warning
- cycle detection with full cycle chain
- duplicate module candidate files
- workspace summary conflict against external contract
- relative-path / module-root normalization smoke case

Updated file:

- `tests/test_module_graph_v47_41.py`

The unresolved-import test now uses a foreign namespace import so it remains a genuine opaque-external case.

## Validation performed

- `python -m py_compile axiomzig/*.py tests/test_module_graph_v47_41.py tests/test_module_graph_hardening_v47_42.py`
- `python -m pytest -q tests/test_module_graph_v47_41.py tests/test_module_graph_hardening_v47_42.py`
  - result: `10 passed`
- CLI smoke test:
  - `python -m axiomzig.cli owncheck <entry> --module-root <workspace>`

## Important boundary

v0.47.42 still does **not** implement cyclic whole-program fixed-point solving. Cycles are diagnosed and rejected at the graph layer.

It also does not add package-manager search paths or visibility rules. The import model is still a small workspace resolver.

## Recommended next step

v0.47.43 should add a whole-program conformance/export mode:

1. walk the workspace graph from an entry module
2. validate graph soundness
3. emit a stable ownership-summary artifact for the workspace
4. optionally separate internal summaries, external-compatible summaries, or both
