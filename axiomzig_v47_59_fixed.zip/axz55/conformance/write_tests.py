"""
write_tests.py — generate all conformance test files.

Run once from the repo root:
    python conformance/write_tests.py
"""
import json
from pathlib import Path

ROOT = Path(__file__).parent

def t(category: str, name: str, source: str, meta: dict) -> None:
    d = ROOT / category
    (d / f"{name}.az").write_text(source, encoding="utf-8")
    (d / f"{name}.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")

# ─── PARSER ──────────────────────────────────────────────────────────────────

t("parser", "fn_no_params", """\
module parser.fn_no_params;
fn f() -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "fn_multiple_params", """\
module parser.fn_multiple_params;
fn f(a: I64, b: Bool, c: Str) -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "struct_decl", """\
module parser.struct_decl;
struct Point { x: I64; y: I64; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "enum_unit_variants", """\
module parser.enum_unit_variants;
enum Color { Red; Green; Blue; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "enum_payload_variant", """\
module parser.enum_payload_variant;
enum Shape { Circle { r: I64; }; Rect { w: I64; h: I64; }; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "error_set_decl", """\
module parser.error_set_decl;
error_set E { Bad; Missing; Timeout; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "protocol_decl", """\
module parser.protocol_decl;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
""", {"phase": "parse", "expect": "pass"})

t("parser", "resource_decl", """\
module parser.resource_decl;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
""", {"phase": "parse", "expect": "pass"})

t("parser", "if_else", """\
module parser.if_else;
fn f(b: Bool) -> I64 effects() { if (b) { return 1; } else { return 0; } }
""", {"phase": "parse", "expect": "pass"})

t("parser", "while_loop", """\
module parser.while_loop;
fn f() -> Unit effects() { while (false) { } return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "for_range", """\
module parser.for_range;
fn f() -> I64 effects() { var t: I64 = 0; for (i: I64 in 0..5) { t = t + i; } return t; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "match_expr", """\
module parser.match_expr;
fn f(x: Bool) -> I64 effects() { return match x { true -> 1, false -> 0, }; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "defer_stmt", """\
module parser.defer_stmt;
fn cleanup() -> Unit effects() { return unit; }
fn f() -> Unit effects() { defer cleanup(); return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "errdefer_stmt", """\
module parser.errdefer_stmt;
fn cleanup() -> Unit effects() { return unit; }
fn f() -> Unit effects() { errdefer cleanup(); return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "pub_fn", """\
module parser.pub_fn;
pub fn exported() -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "experimental_annotation", """\
module parser.experimental_annotation;
@experimental
pub fn alpha() -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "deprecated_annotation", """\
module parser.deprecated_annotation;
@deprecated(reason="use new_fn", replacement="new_fn")
pub fn old_fn() -> Unit effects() { return unit; }
pub fn new_fn() -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "since_annotation", """\
module parser.since_annotation;
@since("1.0.0")
pub fn stable_fn() -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "try_expr_postfix", """\
module parser.try_expr_postfix;
error_set E { Bad; }
fn g() -> I64!E effects(error) { return E.Bad; }
fn f() -> I64!E effects(error) { let x: I64 = g()?; return x; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "missing_effects_clause", """\
module parser.missing_effects_clause;
fn f() -> Unit { return unit; }
""", {"phase": "parse", "expect": "fail",
      "diagnostic": "E_PARSE_EXPECTED",
      "notes": "effects clause is mandatory syntax"})

t("parser", "duplicate_lifecycle_annotations", """\
module parser.duplicate_lifecycle_annotations;
@experimental
@deprecated(reason="old", replacement="other")
pub fn confused() -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "fail",
      "diagnostic": "E_PARSE_EXPECTED",
      "notes": "conflicting lifecycle annotations rejected at parse"})

t("parser", "duplicate_since", """\
module parser.duplicate_since;
@since("1.0")
@since("2.0")
pub fn f() -> Unit effects() { return unit; }
""", {"phase": "parse", "expect": "fail",
      "diagnostic": "E_PARSE_EXPECTED",
      "notes": "duplicate @since rejected at parse"})

t("parser", "nested_block", """\
module parser.nested_block;
fn f() -> Unit effects() { { let x: I64 = 1; } return unit; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "break_continue", """\
module parser.break_continue;
fn f() -> Unit effects() {
    while (true) { break; }
    for (i: I64 in 0..3) { if (i == 1) { continue; } }
    return unit;
}
""", {"phase": "parse", "expect": "pass"})

# ─── FORMATTER ───────────────────────────────────────────────────────────────

def fmt(name: str, messy: str, canonical: str) -> None:
    t("formatter", name, messy,
      {"phase": "format", "expect": "format", "output": canonical})

fmt("normalize_whitespace",
    "module test;fn f()->Unit effects(){return unit;}",
    "module test;\n\nfn f() -> Unit effects() {\n    return unit;\n}\n")

fmt("try_rewrites_to_postfix",
    "module test;\nerror_set E { Bad; }\nfn g() -> I64!E effects(error) { return E.Bad; }\nfn f() -> I64!E effects(error) { return try g(); }\n",
    "module test;\n\nerror_set E {\n    Bad;\n}\n\nfn g() -> I64!E effects(error) {\n    return E.Bad;\n}\n\nfn f() -> I64!E effects(error) {\n    return g()?;\n}\n")

t("formatter", "idempotent_simple",
  "module test;\n\nfn f() -> Unit effects() {\n    return unit;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module test;\n\nfn f() -> Unit effects() {\n    return unit;\n}\n"})

t("formatter", "idempotent_struct",
  "module test;\n\nstruct S {\n    x: I64;\n    y: Bool;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module test;\n\nstruct S {\n    x: I64;\n    y: Bool;\n}\n"})

t("formatter", "idempotent_enum",
  "module test;\n\nenum E {\n    A;\n    B { v: I64; };\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module test;\n\nenum E {\n    A;\n    B { v: I64; };\n}\n"})

t("formatter", "idempotent_match",
  "module test;\n\nfn f(x: Bool) -> I64 effects() {\n    return match x {\n        true -> 1,\n        false -> 0,\n    };\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module test;\n\nfn f(x: Bool) -> I64 effects() {\n    return match x {\n        true -> 1,\n        false -> 0,\n    };\n}\n"})

t("formatter", "idempotent_pub_annotations",
  "module test;\n\n@experimental\npub fn alpha() -> Unit effects() {\n    return unit;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module test;\n\n@experimental\npub fn alpha() -> Unit effects() {\n    return unit;\n}\n"})

t("formatter", "idempotent_protocol",
  "module test;\n\nprotocol P {\n    states { A, B }\n    init A;\n    terminal { B }\n    transitions {\n        go: A -> B;\n    }\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module test;\n\nprotocol P {\n    states { A, B }\n    init A;\n    terminal { B }\n    transitions {\n        go: A -> B;\n    }\n}\n"})

t("formatter", "idempotent_error_union",
  "module test;\n\nerror_set E {\n    Bad;\n}\n\nfn g() -> I64!E effects(error) {\n    return E.Bad;\n}\n\nfn f() -> I64!E effects(error) {\n    let x: I64 = g()?;\n    return x;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module test;\n\nerror_set E {\n    Bad;\n}\n\nfn g() -> I64!E effects(error) {\n    return E.Bad;\n}\n\nfn f() -> I64!E effects(error) {\n    let x: I64 = g()?;\n    return x;\n}\n"})

# ─── NAME RESOLUTION ─────────────────────────────────────────────────────────

t("name_resolution", "shadowing_rejected", """\
module nr.shadow;
fn f() -> Unit effects() { let x: I64 = 1; let x: I64 = 2; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_SHADOW"})

t("name_resolution", "duplicate_params_rejected", """\
module nr.dup_params;
fn f(a: I64, a: I64) -> Unit effects() { return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_DUPLICATE"})

t("name_resolution", "duplicate_top_level_rejected", """\
module nr.dup_top;
fn f() -> Unit effects() { return unit; }
fn f() -> Unit effects() { return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_DUPLICATE"})

t("name_resolution", "duplicate_struct_field_rejected", """\
module nr.dup_field;
struct S { x: I64; x: I64; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_DUPLICATE"})

t("name_resolution", "unknown_type_rejected", """\
module nr.unknown_type;
fn f() -> Unknown effects() { return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_UNKNOWN_TYPE"})

t("name_resolution", "unresolved_name_rejected", """\
module nr.unresolved;
fn f() -> Unit effects() { let x: I64 = y; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_UNBOUND"})

t("name_resolution", "unknown_struct_literal_rejected", """\
module nr.unknown_struct;
fn f() -> Unit effects() { let x = NoSuch { a: 1 }; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_UNKNOWN_TYPE"})

t("name_resolution", "defer_return_rejected", """\
module nr.defer_return;
fn f() -> Unit effects() { defer return unit; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_FLOW"})

t("name_resolution", "defer_nested_rejected", """\
module nr.defer_nested;
fn c() -> Unit effects() { return unit; }
fn f() -> Unit effects() { defer defer c(); return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_NESTED"})

t("name_resolution", "forward_ref_ok", """\
module nr.forward_ref;
fn a() -> Unit effects() { return b(); }
fn b() -> Unit effects() { return unit; }
""", {"phase": "check", "expect": "pass"})

t("name_resolution", "enum_variant_ok", """\
module nr.enum_variant;
enum Color { Red; Green; }
fn f() -> Color effects() { return Color.Red; }
""", {"phase": "check", "expect": "pass"})

t("name_resolution", "error_tag_ok", """\
module nr.error_tag;
error_set E { Bad; }
fn f() -> I64!E effects(error) { return E.Bad; }
""", {"phase": "check", "expect": "pass"})

# ─── TYPING ──────────────────────────────────────────────────────────────────

t("typing", "arithmetic_ok", """\
module ty.arith;
fn f() -> I64 effects() { return 1 + 2 * 3 - 4; }
""", {"phase": "check", "expect": "pass"})

t("typing", "return_type_mismatch", """\
module ty.return_mismatch;
fn f() -> Bool effects() { return 1; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "arg_count_wrong", """\
module ty.arg_count;
fn add(a: I64, b: I64) -> I64 effects() { return a + b; }
fn g() -> I64 effects() { return add(1); }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "arg_type_wrong", """\
module ty.arg_type;
fn add(a: I64, b: I64) -> I64 effects() { return a + b; }
fn g() -> I64 effects() { return add(1, true); }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "let_annotation_mismatch", """\
module ty.let_ann;
fn f() -> Unit effects() { let x: Bool = 42; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "assign_to_let_rejected", """\
module ty.assign_let;
fn f() -> Unit effects() { let x: I64 = 1; x = 2; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_ASSIGN_LVALUE"})

t("typing", "var_reassign_ok", """\
module ty.var_reassign;
fn f() -> I64 effects() { var x: I64 = 1; x = 2; return x; }
""", {"phase": "check", "expect": "pass"})

t("typing", "match_arm_type_incompat", """\
module ty.match_arm_incompat;
fn f() -> I64 effects() { return match true { true -> 1, false -> false, }; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_ARM_INCOMPAT"})

t("typing", "match_exhaustive_bool_ok", """\
module ty.match_bool_ok;
fn f(b: Bool) -> I64 effects() { return match b { true -> 1, false -> 0, }; }
""", {"phase": "check", "expect": "pass"})

t("typing", "match_nonexhaustive_option", """\
module ty.match_no_exhaust;
fn f(x: Option<I64>) -> I64 effects() { return match x { some(n) -> n, }; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_NO_EXHAUST"})

t("typing", "match_exhaustive_error_all_tags", """\
module ty.match_error_exhaust;
error_set E { A; B; C; }
fn g() -> I64!E effects(error) { return E.A; }
fn f() -> I64 effects(error) {
    return match g() { ok(n) -> n, error(E.A) -> 1, error(E.B) -> 2, error(E.C) -> 3, };
}
""", {"phase": "check", "expect": "pass"})

t("typing", "nonunit_expr_stmt_rejected", """\
module ty.nonunit_stmt;
fn g() -> I64 effects() { return 1; }
fn f() -> Unit effects() { g(); return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_NONUNIT"})

t("typing", "discard_with_underscore_ok", """\
module ty.discard_ok;
fn g() -> I64 effects() { return 1; }
fn f() -> Unit effects() { _ = g(); return unit; }
""", {"phase": "check", "expect": "pass"})

t("typing", "option_some_ok", """\
module ty.option_some;
fn f() -> Option<I64> effects() { return some(42); }
""", {"phase": "check", "expect": "pass"})

t("typing", "option_none_ok", """\
module ty.option_none;
fn f() -> Option<I64> effects() { return none; }
""", {"phase": "check", "expect": "pass"})

t("typing", "error_union_ok", """\
module ty.error_union;
error_set E { Bad; }
fn f() -> I64!E effects(error) { return 42; }
""", {"phase": "check", "expect": "pass"})

t("typing", "struct_literal_ok", """\
module ty.struct_lit;
struct Point { x: I64; y: I64; }
fn f() -> Point effects() { return Point { x: 1, y: 2 }; }
""", {"phase": "check", "expect": "pass"})

t("typing", "bool_operators_ok", """\
module ty.bool_ops;
fn f() -> Bool effects() { return true and false or not true; }
""", {"phase": "check", "expect": "pass"})

t("typing", "comparison_ok", """\
module ty.compare;
fn f(x: I64) -> Bool effects() { return x > 0 and x < 100; }
""", {"phase": "check", "expect": "pass"})

t("typing", "error_propagation_ok", """\
module ty.err_prop;
error_set E { Bad; }
fn g() -> I64!E effects(error) { return E.Bad; }
fn f() -> I64!E effects(error) { let x: I64 = g()?; return x; }
""", {"phase": "check", "expect": "pass"})

# ─── EFFECTS ─────────────────────────────────────────────────────────────────

t("effects", "pure_fn_ok", """\
module eff.pure;
fn f(x: I64) -> I64 effects() { return x + 1; }
""", {"phase": "check", "expect": "pass"})

t("effects", "alloc_declared_ok", """\
module eff.alloc_ok;
fn leaf() -> Unit effects(alloc) { return unit; }
fn caller() -> Unit effects(alloc) { return leaf(); }
""", {"phase": "check", "expect": "pass"})

t("effects", "missing_alloc_rejected", """\
module eff.missing_alloc;
fn leaf() -> Unit effects(alloc) { return unit; }
fn caller() -> Unit effects() { return leaf(); }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_UNDER"})

t("effects", "missing_error_rejected", """\
module eff.missing_error;
error_set E { Bad; }
fn g() -> I64!E effects(error) { return E.Bad; }
fn f() -> I64!E effects() { return g()?; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_UNDER"})

t("effects", "trap_declared_rejected", """\
module eff.trap_declared;
fn f() -> Unit effects(trap) { return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_TRAP"})

t("effects", "recurse_declared_ok", """\
module eff.recurse_ok;
fn fib(n: I64) -> I64 effects(recurse) {
    if (n <= 1) { return n; }
    return fib(n - 1) + fib(n - 2);
}
""", {"phase": "check", "expect": "pass"})

t("effects", "missing_recurse_rejected", """\
module eff.missing_recurse;
fn fib(n: I64) -> I64 effects() {
    if (n <= 1) { return n; }
    return fib(n - 1) + fib(n - 2);
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_RECURSE"})

t("effects", "overapproximate_ok", """\
module eff.overapprox;
fn f() -> Unit effects(alloc, free, error, io) { return unit; }
""", {"phase": "check", "expect": "pass",
      "notes": "declaring more effects than body uses is allowed"})

t("effects", "io_propagates_ok", """\
module eff.io_propagate;
fn leaf() -> Unit effects(io) { return unit; }
fn mid() -> Unit effects(io) { return leaf(); }
fn top() -> Unit effects(io) { return mid(); }
""", {"phase": "check", "expect": "pass"})

t("effects", "protocol_step_propagates_ok", """\
module eff.proto_step;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
fn step(r: R) -> Unit effects(protocol_step) { r.go(); return unit; }
fn caller(r: R) -> Unit effects(protocol_step) { return step(r); }
""", {"phase": "check", "expect": "pass"})

t("effects", "mutual_recursion_missing_recurse", """\
module eff.mutual_recurse;
fn is_even(n: I64) -> Bool effects() {
    if (n == 0) { return true; }
    return is_odd(n - 1);
}
fn is_odd(n: I64) -> Bool effects() {
    if (n == 0) { return false; }
    return is_even(n - 1);
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_RECURSE"})

t("effects", "effect_subset_chain_ok", """\
module eff.subset_chain;
fn leaf() -> Unit effects(alloc, error) { return unit; }
fn mid() -> Unit effects(alloc, error) { return leaf(); }
fn top() -> Unit effects(alloc, error) { return mid(); }
""", {"phase": "check", "expect": "pass"})

# ─── OWNERSHIP ───────────────────────────────────────────────────────────────

_PROTO = """\
protocol FileP {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}
resource File { protocol: FileP; fields { fd: I32; } }
"""

t("ownership", "use_after_move", """\
module own.uam;
""" + _PROTO + """
fn sink(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
fn main(f: File) -> Unit effects(protocol_step) {
    sink(move f);
    f.close();
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_MOVED"})

t("ownership", "undischarged_resource", """\
module own.undischarged;
""" + _PROTO + """
fn main() -> Unit effects() { let f: File = File { fd: 0 }; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

t("ownership", "properly_discharged_ok", """\
module own.discharged;
""" + _PROTO + """
fn main() -> Unit effects(protocol_step) { let f: File = File { fd: 0 }; f.close(); return unit; }
""", {"phase": "check", "expect": "pass"})

t("ownership", "move_discharges_ok", """\
module own.move_discharge;
""" + _PROTO + """
fn take(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    take(move f);
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("ownership", "double_move_rejected", """\
module own.double_move;
""" + _PROTO + """
fn take(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    take(move f);
    take(move f);
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_MOVED"})

t("ownership", "borrow_conflict_excl", """\
module own.borrow_conflict;
""" + _PROTO + """
fn poke(r: Ref<File>) -> Unit effects() { return unit; }
fn peek(r: RefConst<File>) -> Unit effects() { return unit; }
fn main(f: File) -> Unit effects(protocol_step) {
    poke(borrow f);
    peek(borrow f);
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_BORROW_EXCL"})

t("ownership", "shared_borrows_ok", """\
module own.shared_ok;
""" + _PROTO + """
fn peek(r: RefConst<File>) -> Unit effects() { return unit; }
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    { let r1: RefConst<File> = borrow f; let r2: RefConst<File> = borrow f; peek(r1); peek(r2); }
    f.close();
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("ownership", "struct_containing_resource_tracked", """\
module own.struct_resource;
""" + _PROTO + """
struct Holder { f: File; }
fn main() -> Unit effects() { let h: Holder = Holder { f: File { fd: 0 } }; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

t("ownership", "partial_move_ok", """\
module own.partial_move;
""" + _PROTO + """
struct Pair { a: File; b: File; }
fn close_f(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let p: Pair = Pair { a: File { fd: 0 }, b: File { fd: 1 } };
    close_f(move p.a);
    close_f(move p.b);
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("ownership", "partial_double_move_rejected", """\
module own.partial_double;
""" + _PROTO + """
struct Pair { a: File; b: File; }
fn close_f(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let p: Pair = Pair { a: File { fd: 0 }, b: File { fd: 1 } };
    close_f(move p.a);
    close_f(move p.a);
    close_f(move p.b);
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_MOVED"})

t("ownership", "ref_alias_transfer_ok", """\
module own.ref_alias_transfer;
""" + _PROTO + """
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    let r1: Ref<File> = borrow f;
    let r2: Ref<File> = r1;
    r2.close();
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("ownership", "mut_alias_double_close_rejected", """\
module own.mut_alias_double;
""" + _PROTO + """
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    let r1: Ref<File> = borrow f;
    let r2: Ref<File> = r1;
    r2.close();
    r1.close();
    return unit;
}
""", {"phase": "check", "expect": "fail"})

t("ownership", "unannotated_let_resource_tracked", """\
module own.unann_let;
""" + _PROTO + """
fn make() -> File effects() { return File { fd: 0 }; }
fn main() -> Unit effects() { let f = make(); return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

# ─── PROTOCOLS ───────────────────────────────────────────────────────────────

t("protocols", "simple_transition_ok", """\
module proto.simple;
""" + _PROTO + """
fn main(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
""", {"phase": "check", "expect": "pass"})

t("protocols", "double_close_rejected", """\
module proto.double_close;
""" + _PROTO + """
fn main(f: File) -> Unit effects(protocol_step) { f.close(); f.close(); return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_PROTO_TRANSITION"})

t("protocols", "undischarged_at_exit", """\
module proto.undischarged;
""" + _PROTO + """
fn main() -> Unit effects() { let f: File = File { fd: 0 }; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

t("protocols", "both_branches_close_ok", """\
module proto.both_branches;
""" + _PROTO + """
fn main(cond: Bool) -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    if (cond) { f.close(); } else { f.close(); }
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "one_branch_misses_close", """\
module proto.one_branch;
""" + _PROTO + """
fn main(cond: Bool) -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    if (cond) { f.close(); }
    return unit;
}
""", {"phase": "check", "expect": "fail"})

t("protocols", "via_ref_ok", """\
module proto.via_ref;
""" + _PROTO + """
fn closer(r: Ref<File>) -> Unit effects(protocol_step) { r.close(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    { closer(borrow f); }
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "via_ref_double_close_rejected", """\
module proto.via_ref_double;
""" + _PROTO + """
fn closer(r: Ref<File>) -> Unit effects(protocol_step) { r.close(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    { closer(borrow f); }
    f.close();
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_PROTO_TRANSITION"})

t("protocols", "multi_state_full_path_ok", """\
module proto.multi_state;
protocol P { states { A, B, C } init A; terminal { C }
    transitions { step1: A -> B; step2: B -> C; } }
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.step1();
    r.step2();
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "multi_state_skip_rejected", """\
module proto.multi_skip;
protocol P { states { A, B, C } init A; terminal { C }
    transitions { step1: A -> B; step2: B -> C; } }
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.step2();
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_PROTO_TRANSITION"})

t("protocols", "defer_cleanup_ok", """\
module proto.defer_cleanup;
""" + _PROTO + """
fn close_f(f: File) -> Unit effects(protocol_step) { f.close(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let f: File = File { fd: 0 };
    defer close_f(move f);
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "struct_field_tracked", """\
module proto.struct_field;
""" + _PROTO + """
struct Holder { f: File; }
fn main() -> Unit effects() { let h: Holder = Holder { f: File { fd: 0 } }; return unit; }
""", {"phase": "check", "expect": "fail"})

# ─── DEFER ───────────────────────────────────────────────────────────────────

t("defer", "basic_defer_ok", """\
module defer.basic;
fn c() -> Unit effects() { return unit; }
fn main() -> Unit effects() { defer c(); return unit; }
""", {"phase": "check", "expect": "pass"})

t("defer", "defer_return_rejected", """\
module defer.ret;
fn main() -> Unit effects() { defer return unit; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_FLOW"})

t("defer", "defer_break_rejected", """\
module defer.brk;
fn main() -> Unit effects() { while (true) { defer break; return unit; } return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_FLOW"})

t("defer", "defer_continue_rejected", """\
module defer.cont;
fn main() -> Unit effects() { while (false) { defer continue; } return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_FLOW"})

t("defer", "errdefer_return_rejected", """\
module defer.errdefer_ret;
fn main() -> Unit effects() { errdefer return unit; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_FLOW"})

t("defer", "nested_defer_rejected", """\
module defer.nested;
fn c() -> Unit effects() { return unit; }
fn main() -> Unit effects() { defer defer c(); return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_NESTED"})

t("defer", "errdefer_in_defer_rejected", """\
module defer.errdefer_in_defer;
fn c() -> Unit effects() { return unit; }
fn main() -> Unit effects() { errdefer defer c(); return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_NESTED"})

t("defer", "errdefer_cleanup_pattern_ok", """\
module defer.errdefer_pattern;
error_set E { Bad; }
protocol FileP { states { Open, Closed } init Open; terminal { Closed }
    transitions { close: Open -> Closed; } }
resource File { protocol: FileP; fields { fd: I32; } }
fn fail() -> Unit!E effects(error) { return E.Bad; }
fn main() -> Unit!E effects(protocol_step, error) {
    let f: File = File { fd: 0 };
    errdefer f.close();
    try fail();
    f.close();
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("defer", "defer_effects_propagate", """\
module defer.effects;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
fn step(r: R) -> Unit effects(protocol_step) { r.go(); return unit; }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    defer step(move r);
    return unit;
}
""", {"phase": "check", "expect": "pass"})

# ─── RUNTIME ─────────────────────────────────────────────────────────────────

t("runtime", "div_zero_traps", """\
module rt.divzero;
fn main() -> I64 effects() { let x: I64 = 10; let y: I64 = 0; return x / y; }
""", {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_DIV_ZERO"})

t("runtime", "i64_overflow_traps", """\
module rt.overflow;
fn main() -> I64 effects() {
    let a: I64 = 9223372036854775807;
    let b: I64 = 1;
    return a + b;
}
""", {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_OVERFLOW"})

t("runtime", "cast_oob_traps", """\
module rt.cast_oob;
fn main() -> I8 effects() { let x: I64 = 200; return @cast(I8, x); }
""", {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_CAST"})

t("runtime", "basic_arithmetic", """\
module rt.arith;
fn main() -> I64 effects() { return 3 + 4 * 2 - 1; }
""", {"phase": "interpret", "expect": "output", "output": "10"})

t("runtime", "while_sum", """\
module rt.while_sum;
fn main() -> I64 effects() {
    var i: I64 = 0; var t: I64 = 0;
    while (i < 5) { t = t + i; i = i + 1; }
    return t;
}
""", {"phase": "interpret", "expect": "output", "output": "10"})

t("runtime", "for_range_sum", """\
module rt.for_range;
fn main() -> I64 effects() {
    var t: I64 = 0;
    for (i: I64 in 0..5) { t = t + i; }
    return t;
}
""", {"phase": "interpret", "expect": "output", "output": "10"})

t("runtime", "fibonacci", """\
module rt.fib;
fn fib(n: I64) -> I64 effects(recurse) {
    if (n <= 1) { return n; }
    return fib(n - 1) + fib(n - 2);
}
fn main() -> I64 effects(recurse) { return fib(7); }
""", {"phase": "interpret", "expect": "output", "output": "13"})

t("runtime", "match_bool", """\
module rt.match_bool;
fn main() -> I64 effects() { return match true { true -> 42, false -> 0, }; }
""", {"phase": "interpret", "expect": "output", "output": "42"})

t("runtime", "match_option_some", """\
module rt.match_some;
fn main() -> I64 effects() { return match some(7) { some(n) -> n, none -> 0, }; }
""", {"phase": "interpret", "expect": "output", "output": "7"})

t("runtime", "match_option_none", """\
module rt.match_none;
fn main() -> I64 effects() { return match none { some(n) -> n, none -> 99, }; }
""", {"phase": "interpret", "expect": "output", "output": "99"})

t("runtime", "error_propagation", """\
module rt.err_prop;
error_set E { Bad; }
fn fail() -> I64!E effects(error) { return E.Bad; }
fn main() -> I64 effects(error) { return fail() catch 17; }
""", {"phase": "interpret", "expect": "output", "output": "17"})

t("runtime", "bool_short_circuit", """\
module rt.short_circuit;
fn main() -> Bool effects() { return false and (1 / 0 == 0); }
""", {"phase": "interpret", "expect": "output", "output": "false"})

# ─── CANONICAL ROUNDTRIP ─────────────────────────────────────────────────────

for name, src in [
    ("simple_fn", "module rt.simple;\n\nfn f() -> Unit effects() {\n    return unit;\n}\n"),
    ("struct", "module rt.struct;\n\nstruct S {\n    x: I64;\n    y: Bool;\n}\n"),
    ("enum", "module rt.enum;\n\nenum E {\n    A;\n    B { v: I64; };\n}\n"),
    ("error_set", "module rt.err;\n\nerror_set E {\n    Bad;\n    Missing;\n}\n"),
    ("protocol", "module rt.proto;\n\nprotocol P {\n    states { A, B }\n    init A;\n    terminal { B }\n    transitions {\n        go: A -> B;\n    }\n}\n"),
    ("resource", "module rt.res;\n\nprotocol P {\n    states { A, B }\n    init A;\n    terminal { B }\n    transitions {\n        go: A -> B;\n    }\n}\n\nresource R {\n    protocol: P;\n    fields {\n        x: I32;\n    }\n}\n"),
    ("match", "module rt.match;\n\nfn f(x: Bool) -> I64 effects() {\n    return match x {\n        true -> 1,\n        false -> 0,\n    };\n}\n"),
    ("if_else", "module rt.if;\n\nfn f(b: Bool) -> I64 effects() {\n    if (b) {\n        return 1;\n    } else {\n        return 0;\n    }\n}\n"),
    ("while", "module rt.while;\n\nfn f() -> Unit effects() {\n    while (false) {\n    }\n    return unit;\n}\n"),
    ("defer", "module rt.defer;\n\nfn c() -> Unit effects() {\n    return unit;\n}\n\nfn f() -> Unit effects() {\n    defer c();\n    return unit;\n}\n"),
    ("pub_annotation", "module rt.pub;\n\n@experimental\npub fn alpha() -> Unit effects() {\n    return unit;\n}\n"),
    ("error_propagation", "module rt.prop;\n\nerror_set E {\n    Bad;\n}\n\nfn g() -> I64!E effects(error) {\n    return E.Bad;\n}\n\nfn f() -> I64!E effects(error) {\n    let x: I64 = g()?;\n    return x;\n}\n"),
]:
    t("canonical_roundtrip", f"roundtrip_{name}", src,
      {"phase": "format", "expect": "format", "output": src,
       "notes": "format(parse(src)) == src and is idempotent"})

# ─── DIAGNOSTICS ─────────────────────────────────────────────────────────────

t("diagnostics", "e_resolve_shadow", """\
module diag.shadow;
fn f() -> Unit effects() { let x: I64 = 1; let x: I64 = 2; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_RESOLVE_SHADOW"})

t("diagnostics", "e_type_no_exhaust", """\
module diag.exhaust;
fn f(x: Option<I64>) -> I64 effects() { return match x { some(n) -> n, }; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_NO_EXHAUST"})

t("diagnostics", "e_own_undischarged", """\
module diag.undischarged;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects() { let r: R = R { x: 0 }; return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

t("diagnostics", "e_effect_recurse", """\
module diag.recurse;
fn f(n: I64) -> I64 effects() {
    if (n <= 0) { return 0; }
    return f(n - 1);
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_RECURSE"})

t("diagnostics", "e_defer_nested", """\
module diag.defer_nested;
fn c() -> Unit effects() { return unit; }
fn f() -> Unit effects() { defer defer c(); return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_DEFER_NESTED"})

t("diagnostics", "e_effect_trap", """\
module diag.trap_effect;
fn f() -> Unit effects(trap) { return unit; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_TRAP"})

t("diagnostics", "r_trap_div_zero", """\
module diag.div_zero;
fn main() -> I64 effects() { return 1 / 0; }
""", {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_DIV_ZERO"})

t("diagnostics", "r_trap_overflow", """\
module diag.overflow;
fn main() -> I64 effects() {
    let a: I64 = 9223372036854775807;
    return a + 1;
}
""", {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_OVERFLOW"})

t("diagnostics", "r_trap_cast", """\
module diag.cast;
fn main() -> U8 effects() { let x: I64 = 300; return @cast(U8, x); }
""", {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_CAST"})

print("All conformance tests written.")

# Count
for cat in sorted(ROOT.iterdir()):
    if cat.is_dir() and cat.name != "__pycache__":
        azfiles = list(cat.glob("*.az"))
        print(f"  {cat.name}: {len(azfiles)} tests")

