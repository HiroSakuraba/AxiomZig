"""add_tests.py — fill the conformance coverage gaps."""
import json
from pathlib import Path

ROOT = Path(__file__).parent

def t(cat, name, source, meta):
    d = ROOT / cat
    (d / f"{name}.az").write_text(source, encoding="utf-8")
    (d / f"{name}.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")

# ─── LEXER (0 → 20) ──────────────────────────────────────────────────────────

t("lexer", "ident_simple",
  "module lex.ident;\nfn foo_bar() -> Unit effects() { return unit; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "ident_with_numbers",
  "module lex.idn;\nfn f1_2() -> Unit effects() { return unit; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "ident_leading_underscore",
  "module lex.under;\nfn _helper() -> Unit effects() { return unit; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "int_decimal",
  "module lex.dec;\nfn f() -> I64 effects() { return 1234567; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "int_hex",
  "module lex.hex;\nfn f() -> I64 effects() { return 0xff; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "int_binary",
  "module lex.bin;\nfn f() -> I64 effects() { return 0b1010; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "int_octal",
  "module lex.oct;\nfn f() -> I64 effects() { return 0o755; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "int_underscores",
  "module lex.uscore;\nfn f() -> I64 effects() { return 1_000_000; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "string_simple",
  'module lex.str;\nfn f() -> Str effects() { return "hello"; }\n',
  {"phase": "parse", "expect": "pass"})

t("lexer", "string_escape_newline",
  'module lex.stresc;\nfn f() -> Str effects() { return "line1\\nline2"; }\n',
  {"phase": "parse", "expect": "pass"})

t("lexer", "string_escape_tab",
  'module lex.strtab;\nfn f() -> Str effects() { return "a\\tb"; }\n',
  {"phase": "parse", "expect": "pass"})

t("lexer", "string_escape_quote",
  'module lex.strquote;\nfn f() -> Str effects() { return "say \\"hi\\""; }\n',
  {"phase": "parse", "expect": "pass"})

t("lexer", "string_escape_hex",
  'module lex.strhex;\nfn f() -> Str effects() { return "\\x41"; }\n',
  {"phase": "parse", "expect": "pass"})

t("lexer", "bool_true_false",
  "module lex.bool;\nfn f() -> Bool effects() { return true and not false; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "line_comment_ignored",
  "module lex.comment;\n// this is a comment\nfn f() -> Unit effects() { return unit; } // trailing\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "keywords_reserved",
  "module lex.kwres;\nfn f() -> Unit effects() { return unit; }\n",
  {"phase": "parse", "expect": "pass",
   "notes": "keywords are reserved; surrounding identifiers still work"})

t("lexer", "negative_int_literal",
  "module lex.neg;\nfn f() -> I64 effects() { return -42; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "large_int_literal",
  "module lex.large;\nfn f() -> I64 effects() { return 9223372036854775807; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "zero_literal",
  "module lex.zero;\nfn f() -> I64 effects() { return 0; }\n",
  {"phase": "parse", "expect": "pass"})

t("lexer", "illegal_char_dollar",
  "module lex.illegal;\nfn f() -> Unit effects() { let $x = 1; return unit; }\n",
  {"phase": "parse", "expect": "fail", "diagnostic": "E_PARSE_UNEXPECTED"})

# ─── TYPING (20 → 50) ────────────────────────────────────────────────────────

t("typing", "i8_cast_ok",
  "module ty.i8;\nfn f() -> I8 effects() { return @cast(I8, 127); }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "u64_cast_ok",
  "module ty.u64;\nfn f() -> U64 effects() { return @cast(U64, 0); }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "cast_type_error",
  "module ty.cast_err;\nfn f() -> I64 effects() { return @cast(I64, true); }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "option_match_some_ok",
  "module ty.opt_some;\nfn f(x: Option<I64>) -> I64 effects() { return match x { some(n) -> n, none -> 0, }; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "option_match_none_required",
  "module ty.opt_none_req;\nfn f(x: Option<I64>) -> I64 effects() { return match x { some(n) -> n, }; }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_NO_EXHAUST"})

t("typing", "result_match_ok_and_err",
  """module ty.result_match;
error_set E { Bad; }
fn g() -> I64!E effects(error) { return E.Bad; }
fn f() -> I64 effects(error) { return match g() { ok(n) -> n, error(E.Bad) -> 0, }; }
""", {"phase": "check", "expect": "pass"})

t("typing", "result_match_missing_error_tag",
  """module ty.result_miss;
error_set E { A; B; }
fn g() -> I64!E effects(error) { return E.A; }
fn f() -> I64 effects(error) { return match g() { ok(n) -> n, error(E.A) -> 1, }; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_NO_EXHAUST"})

t("typing", "for_range_type_ok",
  "module ty.for_range;\nfn f() -> I64 effects() { var t: I64 = 0; for (i: I64 in 0..5) { t = t + i; } return t; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "for_non_iterable_rejected",
  "module ty.for_noiter;\nfn f() -> Unit effects() { for (x: I64 in 42) { } return unit; }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_ITER"})

t("typing", "var_type_preserved",
  "module ty.var_type;\nfn f() -> I64 effects() { var x: I64 = 1; x = 2; return x; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "bool_and_ok",
  "module ty.bool_and;\nfn f() -> Bool effects() { return true and false; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "bool_or_ok",
  "module ty.bool_or;\nfn f() -> Bool effects() { return false or true; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "bool_not_ok",
  "module ty.bool_not;\nfn f() -> Bool effects() { return not true; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "arithmetic_mixed_width_rejected",
  "module ty.mixed_width;\nfn f() -> I32 effects() { let a: I64 = 1; let b: I32 = @cast(I32, 1); return a + b; }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "modulo_ok",
  "module ty.modulo;\nfn f() -> I64 effects() { return 10 % 3; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "comparison_less_ok",
  "module ty.cmp_lt;\nfn f(a: I64, b: I64) -> Bool effects() { return a < b; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "comparison_equal_ok",
  "module ty.cmp_eq;\nfn f(a: I64, b: I64) -> Bool effects() { return a == b; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "comparison_wrong_type_rejected",
  "module ty.cmp_wrong;\nfn f(a: I64, b: Bool) -> Bool effects() { return a == b; }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "struct_field_access_ok",
  "module ty.field;\nstruct S { x: I64; } fn f(s: S) -> I64 effects() { return s.x; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "struct_wrong_field_type",
  "module ty.field_wrong;\nstruct S { x: I64; } fn f() -> S effects() { return S { x: true }; }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "error_return_without_effect",
  """module ty.err_no_eff;
error_set E { Bad; }
fn f() -> I64!E effects() { return E.Bad; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_UNDER",
      "notes": "returning an error value without declaring error effect"})

t("typing", "nested_option_some",
  "module ty.nested_opt;\nfn f() -> Option<Option<I64>> effects() { return some(some(1)); }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "enum_match_exhaustive_ok",
  """module ty.enum_exhaust;
enum Dir { N; S; E; W; }
fn f(d: Dir) -> I64 effects() {
    return match d { Dir.N -> 0, Dir.S -> 1, Dir.E -> 2, Dir.W -> 3, };
}
""", {"phase": "check", "expect": "pass"})

t("typing", "enum_match_missing_variant",
  """module ty.enum_miss;
enum Dir { N; S; E; W; }
fn f(d: Dir) -> I64 effects() {
    return match d { Dir.N -> 0, Dir.S -> 1, Dir.E -> 2, };
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_NO_EXHAUST"})

t("typing", "while_cond_must_be_bool",
  "module ty.while_cond;\nfn f() -> Unit effects() { while (1) { } return unit; }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "if_cond_must_be_bool",
  "module ty.if_cond;\nfn f() -> Unit effects() { if (42) { } return unit; }\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

t("typing", "return_unit_from_unit_fn",
  "module ty.ret_unit;\nfn f() -> Unit effects() { return unit; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "return_nothing_from_unit_fn",
  "module ty.ret_nothing;\nfn f() -> Unit effects() { return; }\n",
  {"phase": "check", "expect": "pass"})

t("typing", "multiple_return_paths_consistent",
  """module ty.multi_ret;
fn f(b: Bool) -> I64 effects() {
    if (b) { return 1; }
    return 0;
}
""", {"phase": "check", "expect": "pass"})

t("typing", "multiple_return_paths_inconsistent",
  """module ty.multi_ret_bad;
fn f(b: Bool) -> I64 effects() {
    if (b) { return true; }
    return 0;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_TYPE_MISMATCH"})

# ─── EFFECTS (12 → 25) ───────────────────────────────────────────────────────

t("effects", "free_propagates_ok",
  """module eff.free_prop;
fn leaf() -> Unit effects(free) { return unit; }
fn caller() -> Unit effects(free) { return leaf(); }
""", {"phase": "check", "expect": "pass"})

t("effects", "missing_free_rejected",
  """module eff.free_miss;
fn leaf() -> Unit effects(free) { return unit; }
fn caller() -> Unit effects() { return leaf(); }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_UNDER"})

t("effects", "alloc_free_together_ok",
  """module eff.alloc_free;
fn leaf() -> Unit effects(alloc, free) { return unit; }
fn caller() -> Unit effects(alloc, free) { return leaf(); }
""", {"phase": "check", "expect": "pass"})

t("effects", "missing_one_of_two_rejected",
  """module eff.missing_one;
fn leaf() -> Unit effects(alloc, free) { return unit; }
fn caller() -> Unit effects(alloc) { return leaf(); }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_UNDER"})

t("effects", "direct_recursion_ok_with_recurse",
  """module eff.direct_rec;
fn count(n: I64) -> I64 effects(recurse) {
    if (n == 0) { return 0; }
    return 1 + count(n - 1);
}
""", {"phase": "check", "expect": "pass"})

t("effects", "indirect_recursion_needs_recurse",
  """module eff.indirect_rec;
fn ping(n: I64) -> I64 effects() {
    if (n == 0) { return 0; }
    return pong(n - 1);
}
fn pong(n: I64) -> I64 effects() {
    if (n == 0) { return 0; }
    return ping(n - 1);
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_RECURSE"})

t("effects", "empty_effects_enforced",
  """module eff.empty;
fn f() -> Unit effects() { return unit; }
fn g() -> Unit effects() { return f(); }
""", {"phase": "check", "expect": "pass"})

t("effects", "all_core_effects_together_ok",
  """module eff.all_core;
fn leaf() -> Unit effects(alloc, free, error, io, recurse, protocol_step) { return unit; }
fn caller() -> Unit effects(alloc, free, error, io, recurse, protocol_step) { return leaf(); }
""", {"phase": "check", "expect": "pass"})

t("effects", "protocol_step_in_caller_for_transition",
  """module eff.proto_caller;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
fn step(r: R) -> Unit effects(protocol_step) { r.go(); return unit; }
fn caller(r: R) -> Unit effects(protocol_step) { return step(r); }
""", {"phase": "check", "expect": "pass"})

t("effects", "unknown_effect_tag_warning",
  "module eff.unknown_tag;\nfn f() -> Unit effects(banana) { return unit; }\n",
  {"phase": "check", "expect": "pass",
   "notes": "unknown effect tags produce warnings not errors"})

t("effects", "recurse_only_on_direct_caller",
  """module eff.recurse_caller;
fn a(n: I64) -> I64 effects(recurse) {
    if (n == 0) { return 0; }
    return a(n - 1);
}
fn b() -> I64 effects() { return a(3); }
""", {"phase": "check", "expect": "pass",
      "notes": "caller of recursive fn doesn't need recurse if it doesn't recurse itself"})

t("effects", "error_union_in_non_error_fn",
  """module eff.err_in_non_err;
error_set E { Bad; }
fn f() -> I64!E effects(error) { return 1; }
fn g() -> I64 effects() { return f() catch 0; }
""", {"phase": "check", "expect": "fail", "diagnostic": "E_EFFECT_UNDER",
      "notes": "catching an error from a callee still requires declaring error effect"})

# ─── OWNERSHIP (13 → 40) ─────────────────────────────────────────────────────

_P = """protocol FileP {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}
resource File { protocol: FileP; fields { fd: I32; } }
"""

t("ownership", "copy_type_reusable",
  "module own.copy;\nfn f() -> I64 effects() { let x: I64 = 1; let y: I64 = x; return x + y; }\n",
  {"phase": "check", "expect": "pass"})

t("ownership", "borrow_then_use_ok",
  f"module own.borrow_use;\n{_P}\nfn peek(r: RefConst<File>) -> Unit effects() {{ return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    {{ peek(borrow f); }}\n    f.close();\n    return unit;\n}}\n",
  {"phase": "check", "expect": "pass"})

t("ownership", "move_while_borrowed_rejected",
  f"module own.move_borrowed;\n{_P}\nfn take(f: File) -> Unit effects(protocol_step) {{ f.close(); return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    let r: RefConst<File> = borrow f;\n    take(move f);\n    return unit;\n}}\n",
  {"phase": "check", "expect": "fail"})

t("ownership", "exclusive_borrow_blocks_shared",
  f"module own.excl_blocks_shared;\n{_P}\nfn poke(r: Ref<File>) -> Unit effects() {{ return unit; }}\nfn peek(r: RefConst<File>) -> Unit effects() {{ return unit; }}\nfn main(f: File) -> Unit effects(protocol_step) {{\n    let m: Ref<File> = borrow f;\n    let c: RefConst<File> = borrow f;\n    poke(m);\n    f.close();\n    return unit;\n}}\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_BORROW_EXCL"})

t("ownership", "scope_pop_undischarged_inner_block",
  f"module own.scope_pop;\n{_P}\nfn main() -> Unit effects() {{\n    {{ let f: File = File {{ fd: 0 }}; }}\n    return unit;\n}}\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

t("ownership", "defer_move_discharge_ok",
  f"module own.defer_move;\n{_P}\nfn close_f(f: File) -> Unit effects(protocol_step) {{ f.close(); return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    defer close_f(move f);\n    return unit;\n}}\n",
  {"phase": "check", "expect": "pass"})

t("ownership", "ref_alias_via_mut_closes_resource",
  f"module own.ref_close;\n{_P}\nfn closer(r: Ref<File>) -> Unit effects(protocol_step) {{ r.close(); return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    {{ closer(borrow f); }}\n    return unit;\n}}\n",
  {"phase": "check", "expect": "pass"})

t("ownership", "two_mut_ref_same_resource_rejected",
  f"module own.two_mut;\n{_P}\nfn dual(a: Ref<File>, b: Ref<File>) -> Unit effects() {{ return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    dual(borrow f, borrow f);\n    f.close();\n    return unit;\n}}\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_BORROW_ALIAS"})

t("ownership", "returned_resource_must_be_discharged_by_caller",
  f"module own.ret_resource;\n{_P}\nfn make() -> File effects() {{ return File {{ fd: 0 }}; }}\nfn caller() -> Unit effects() {{ let _ = make(); return unit; }}\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

t("ownership", "moved_resource_in_match_arm_ok",
  f"module own.match_move;\n{_P}\nfn take(f: File) -> Unit effects(protocol_step) {{ f.close(); return unit; }}\nfn main(cond: Bool) -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    let _: Unit = match cond {{\n        true -> take(move f),\n        false -> take(move f),\n    }};\n    return unit;\n}}\n",
  {"phase": "check", "expect": "pass"})

t("ownership", "if_branches_different_states_rejected",
  f"module own.branch_states;\n{_P}\nfn main(cond: Bool) -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    if (cond) {{ f.close(); }}\n    return unit;\n}}\n",
  {"phase": "check", "expect": "fail"})

t("ownership", "copy_type_not_tracked_as_resource",
  "module own.copy_notrack;\nfn f() -> Unit effects() { let x: I64 = 1; let y: I64 = x; let z: I64 = x; return unit; }\n",
  {"phase": "check", "expect": "pass"})

t("ownership", "nested_struct_both_fields_tracked",
  f"module own.nested_both;\n{_P}\nstruct Pair {{ a: File; b: File; }}\nfn close_f(f: File) -> Unit effects(protocol_step) {{ f.close(); return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let p: Pair = Pair {{ a: File {{ fd: 0 }}, b: File {{ fd: 1 }} }};\n    close_f(move p.a);\n    return unit;\n}}\n",
  {"phase": "check", "expect": "fail",
   "notes": "p.b is still undischarged after moving only p.a"})

# ─── PROTOCOLS (11 → 30) ─────────────────────────────────────────────────────

t("protocols", "three_state_linear_path",
  """module proto.three;
protocol P { states { A, B, C } init A; terminal { C }
    transitions { ab: A -> B; bc: B -> C; } }
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.ab(); r.bc();
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "three_state_wrong_order",
  """module proto.three_wrong;
protocol P { states { A, B, C } init A; terminal { C }
    transitions { ab: A -> B; bc: B -> C; } }
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.bc();
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_PROTO_TRANSITION"})

t("protocols", "idempotent_transition_same_state",
  """module proto.idempotent;
protocol P { states { Open } init Open; terminal { Open }
    transitions { noop: Open -> Open; } }
resource R { protocol: P; fields { x: I32; } }
fn main() -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    r.noop(); r.noop(); r.noop();
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "multiple_terminal_states",
  """module proto.multi_terminal;
protocol P { states { Open, ClosedOk, ClosedErr } init Open; terminal { ClosedOk, ClosedErr }
    transitions { ok: Open -> ClosedOk; err: Open -> ClosedErr; } }
resource R { protocol: P; fields { x: I32; } }
fn close_ok(r: R) -> Unit effects(protocol_step) { r.ok(); return unit; }
fn close_err(r: R) -> Unit effects(protocol_step) { r.err(); return unit; }
""", {"phase": "check", "expect": "pass"})

t("protocols", "branching_to_different_terminal_ok",
  """module proto.branch_terminal;
protocol P { states { Open, ClosedOk, ClosedErr } init Open; terminal { ClosedOk, ClosedErr }
    transitions { ok: Open -> ClosedOk; err: Open -> ClosedErr; } }
resource R { protocol: P; fields { x: I32; } }
fn main(cond: Bool) -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    if (cond) { r.ok(); } else { r.err(); }
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "partial_discharge_branch_rejected",
  """module proto.partial_branch;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
fn main(cond: Bool) -> Unit effects(protocol_step) {
    let r: R = R { x: 0 };
    if (cond) { r.go(); }
    return unit;
}
""", {"phase": "check", "expect": "fail"})

t("protocols", "loop_body_resource_discharged_each_iter",
  """module proto.loop_resource;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
fn make() -> R effects() { return R { x: 0 }; }
fn main() -> Unit effects(protocol_step) {
    for (i: I64 in 0..3) {
        let r: R = make();
        r.go();
    }
    return unit;
}
""", {"phase": "check", "expect": "pass"})

t("protocols", "loop_body_resource_leaked",
  """module proto.loop_leak;
protocol P { states { A, B } init A; terminal { B } transitions { go: A -> B; } }
resource R { protocol: P; fields { x: I32; } }
fn make() -> R effects() { return R { x: 0 }; }
fn main() -> Unit effects() {
    for (i: I64 in 0..3) { let r: R = make(); }
    return unit;
}
""", {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_UNDISCHARGED"})

t("protocols", "errdefer_discharged_on_error",
  f"""module proto.errdefer_discharge;
{_P}
error_set E {{ Bad; }}
fn fail() -> Unit!E effects(error) {{ return E.Bad; }}
fn main() -> Unit!E effects(protocol_step, error) {{
    let f: File = File {{ fd: 0 }};
    errdefer f.close();
    try fail();
    f.close();
    return unit;
}}
""", {"phase": "check", "expect": "pass"})

t("protocols", "transition_via_nested_ref_field",
  f"""module proto.nested_ref_field;
{_P}
struct Holder {{ inner: File; }}
fn close_inner(h: Ref<Holder>) -> Unit effects(protocol_step) {{
    h.inner.close();
    return unit;
}}
fn main() -> Unit effects(protocol_step) {{
    var h = Holder {{ inner: File {{ fd: 0 }} }};
    close_inner(borrow h);
    return unit;
}}
""", {"phase": "check", "expect": "pass"})

# ─── DEFER (9 → 25) ──────────────────────────────────────────────────────────

t("defer", "defer_in_inner_block",
  "module defermod.inner;\nfn c() -> Unit effects() { return unit; }\nfn main() -> Unit effects() { { defer c(); } return unit; }\n",
  {"phase": "check", "expect": "pass"})

t("defer", "multiple_defers_stack",
  "module defermod.stack;\nfn a() -> Unit effects() { return unit; }\nfn b() -> Unit effects() { return unit; }\nfn c() -> Unit effects() { return unit; }\nfn main() -> Unit effects() { defer a(); defer b(); defer c(); return unit; }\n",
  {"phase": "check", "expect": "pass"})

t("defer", "errdefer_no_error_ok",
  "module defermod.no_err;\nfn c() -> Unit effects() { return unit; }\nfn main() -> Unit effects() { errdefer c(); return unit; }\n",
  {"phase": "check", "expect": "pass"})

t("defer", "defer_with_protocol_step_effect",
  f"module defermod.proto_effect;\n{_P}\nfn close_f(f: File) -> Unit effects(protocol_step) {{ f.close(); return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    defer close_f(move f);\n    return unit;\n}}\n",
  {"phase": "check", "expect": "pass"})

t("defer", "errdefer_with_error_effect",
  f"module defermod.err_effect;\n{_P}\nerror_set E {{ Bad; }}\nfn fail() -> Unit!E effects(error) {{ return E.Bad; }}\nfn main() -> Unit!E effects(protocol_step, error) {{\n    let f: File = File {{ fd: 0 }};\n    errdefer f.close();\n    try fail();\n    f.close();\n    return unit;\n}}\n",
  {"phase": "check", "expect": "pass"})

t("defer", "defer_after_move_resource_uses_moved_state",
  f"module defermod.after_move;\n{_P}\nfn close_f(f: File) -> Unit effects(protocol_step) {{ f.close(); return unit; }}\nfn main() -> Unit effects(protocol_step) {{\n    let f: File = File {{ fd: 0 }};\n    close_f(move f);\n    defer close_f(move f);\n    return unit;\n}}\n",
  {"phase": "check", "expect": "fail", "diagnostic": "E_OWN_MOVED"})

t("defer", "nested_scope_defer_scoped_correctly",
  "module defermod.nested_scope;\nfn c() -> Unit effects() { return unit; }\nfn main() -> Unit effects() { { defer c(); return unit; } }\n",
  {"phase": "check", "expect": "pass"})

t("defer", "deferred_fn_effects_subsumed",
  "module defermod.effects_subsumed;\nfn leaf() -> Unit effects(io) { return unit; }\nfn main() -> Unit effects(io) { defer leaf(); return unit; }\n",
  {"phase": "check", "expect": "pass"})

# ─── RUNTIME (12 → 35) ───────────────────────────────────────────────────────

t("runtime", "nested_fn_calls",
  "module rt.nested;\nfn double(x: I64) -> I64 effects() { return x * 2; }\nfn quadruple(x: I64) -> I64 effects() { return double(double(x)); }\nfn main() -> I64 effects() { return quadruple(3); }\n",
  {"phase": "interpret", "expect": "output", "output": "12"})

t("runtime", "struct_field_mutation",
  "module rt.struct_mut;\nstruct C { n: I64; }\nfn main() -> I64 effects() { var c = C { n: 1 }; c.n = c.n + 1; return c.n; }\n",
  {"phase": "interpret", "expect": "output", "output": "2"})

t("runtime", "break_from_while",
  "module rt.brk;\nfn main() -> I64 effects() { var i: I64 = 0; while (true) { if (i == 3) { break; } i = i + 1; } return i; }\n",
  {"phase": "interpret", "expect": "output", "output": "3"})

t("runtime", "continue_in_for",
  "module rt.cont;\nfn main() -> I64 effects() { var t: I64 = 0; for (i: I64 in 0..6) { if (i % 2 == 0) { continue; } t = t + i; } return t; }\n",
  {"phase": "interpret", "expect": "output", "output": "9"})

t("runtime", "bool_short_circuit_or",
  "module rt.or_circuit;\nfn main() -> Bool effects() { return true or (1 / 0 == 0); }\n",
  {"phase": "interpret", "expect": "output", "output": "true"})

t("runtime", "cast_i64_to_i32",
  "module rt.cast_ok;\nfn main() -> I32 effects() { let x: I64 = 42; return @cast(I32, x); }\n",
  {"phase": "interpret", "expect": "output", "output": "42"})

t("runtime", "negative_modulo",
  "module rt.neg_mod;\nfn main() -> I64 effects() { return -7 % 2; }\n",
  {"phase": "interpret", "expect": "output", "output": "-1"})

t("runtime", "comparison_chain",
  "module rt.cmp_chain;\nfn f(x: I64) -> Bool effects() { return x > 0 and x < 10; }\nfn main() -> Bool effects() { return f(5); }\n",
  {"phase": "interpret", "expect": "output", "output": "true"})

t("runtime", "option_propagation",
  """module rt.opt_prop;
fn safe_div(a: I64, b: I64) -> Option<I64> effects() {
    if (b == 0) { return none; }
    return some(a / b);
}
fn main() -> I64 effects() {
    return match safe_div(10, 2) { some(n) -> n, none -> 0, };
}
""", {"phase": "interpret", "expect": "output", "output": "5"})

t("runtime", "option_none_fallback",
  """module rt.opt_none;
fn safe_div(a: I64, b: I64) -> Option<I64> effects() {
    if (b == 0) { return none; }
    return some(a / b);
}
fn main() -> I64 effects() {
    return match safe_div(10, 0) { some(n) -> n, none -> 99, };
}
""", {"phase": "interpret", "expect": "output", "output": "99"})

t("runtime", "error_catch_chain",
  """module rt.err_chain;
error_set E { Bad; }
fn f() -> I64!E effects(error) { return E.Bad; }
fn g() -> I64!E effects(error) { return f()?; }
fn main() -> I64 effects(error) { return g() catch 42; }
""", {"phase": "interpret", "expect": "output", "output": "42"})

t("runtime", "recursive_sum",
  """module rt.rec_sum;
fn sum(n: I64) -> I64 effects(recurse) {
    if (n == 0) { return 0; }
    return n + sum(n - 1);
}
fn main() -> I64 effects(recurse) { return sum(10); }
""", {"phase": "interpret", "expect": "output", "output": "55"})

t("runtime", "match_enum_dispatch",
  """module rt.enum_dispatch;
enum Op { Add; Sub; Mul; }
fn apply(op: Op, a: I64, b: I64) -> I64 effects() {
    return match op {
        Op.Add -> a + b,
        Op.Sub -> a - b,
        Op.Mul -> a * b,
    };
}
fn main() -> I64 effects() { return apply(Op.Mul, 6, 7); }
""", {"phase": "interpret", "expect": "output", "output": "42"})

t("runtime", "u8_overflow_traps",
  "module rt.u8_overflow;\nfn main() -> U8 effects() { let a: U8 = @cast(U8, 255); let b: U8 = @cast(U8, 1); return a + b; }\n",
  {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_OVERFLOW"})

t("runtime", "mod_by_zero_traps",
  "module rt.mod_zero;\nfn main() -> I64 effects() { return 5 % 0; }\n",
  {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_DIV_ZERO"})

t("runtime", "cast_negative_to_u64_traps",
  "module rt.cast_neg_u64;\nfn main() -> U64 effects() { let x: I64 = -1; return @cast(U64, x); }\n",
  {"phase": "interpret", "expect": "trap", "diagnostic": "R_TRAP_CAST"})

# ─── FORMATTER (9 → 20) ──────────────────────────────────────────────────────

t("formatter", "idempotent_for_range",
  "module fmt.forr;\n\nfn f() -> I64 effects() {\n    var t: I64 = 0;\n    for (i: I64 in 0..5) {\n        t = t + i;\n    }\n    return t;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module fmt.forr;\n\nfn f() -> I64 effects() {\n    var t: I64 = 0;\n    for (i: I64 in 0..5) {\n        t = t + i;\n    }\n    return t;\n}\n"})

t("formatter", "idempotent_error_set",
  "module fmt.errset;\n\nerror_set E {\n    Bad;\n    Missing;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module fmt.errset;\n\nerror_set E {\n    Bad;\n    Missing;\n}\n"})

t("formatter", "idempotent_resource",
  "module fmt.res;\n\nprotocol P {\n    states { A, B }\n    init A;\n    terminal { B }\n    transitions {\n        go: A -> B;\n    }\n}\n\nresource R {\n    protocol: P;\n    fields {\n        x: I32;\n    }\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module fmt.res;\n\nprotocol P {\n    states { A, B }\n    init A;\n    terminal { B }\n    transitions {\n        go: A -> B;\n    }\n}\n\nresource R {\n    protocol: P;\n    fields {\n        x: I32;\n    }\n}\n"})

t("formatter", "idempotent_multiline_fn",
  "module fmt.multi;\n\nfn f(\n    a: I64,\n    b: I64,\n    c: I64,\n) -> I64 effects() {\n    return a + b + c;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module fmt.multi;\n\nfn f(a: I64, b: I64, c: I64) -> I64 effects() {\n    return a + b + c;\n}\n",
   "notes": "formatter collapses short param lists to one line"})

t("formatter", "idempotent_errdefer",
  "module fmt.errdefer;\n\nfn c() -> Unit effects() {\n    return unit;\n}\n\nfn f() -> Unit effects() {\n    errdefer c();\n    return unit;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module fmt.errdefer;\n\nfn c() -> Unit effects() {\n    return unit;\n}\n\nfn f() -> Unit effects() {\n    errdefer c();\n    return unit;\n}\n"})

t("formatter", "idempotent_while_body",
  "module fmt.whilebody;\n\nfn f() -> I64 effects() {\n    var i: I64 = 0;\n    while (i < 5) {\n        i = i + 1;\n    }\n    return i;\n}\n",
  {"phase": "format", "expect": "format",
   "output": "module fmt.whilebody;\n\nfn f() -> I64 effects() {\n    var i: I64 = 0;\n    while (i < 5) {\n        i = i + 1;\n    }\n    return i;\n}\n"})

# ─── PARSER (24 → 35) ────────────────────────────────────────────────────────

t("parser", "catch_no_binding",
  """module parser.catch_nb;
error_set E { Bad; }
fn g() -> I64!E effects(error) { return E.Bad; }
fn f() -> I64 effects(error) { let x: I64 = g() catch 0; return x; }
""", {"phase": "parse", "expect": "pass"})

t("parser", "for_slice_iteration",
  "module parser.for_slice;\nfn f(xs: Slice<I64>) -> I64 effects() { var t: I64 = 0; for (x: I64 in xs) { t = t + x; } return t; }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "unary_minus",
  "module parser.unary;\nfn f() -> I64 effects() { return -42; }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "binary_precedence",
  "module parser.prec;\nfn f() -> I64 effects() { return 1 + 2 * 3; }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "nested_match",
  """module parser.nested_match;
fn f(x: Option<Option<I64>>) -> I64 effects() {
    return match x {
        some(inner) -> match inner { some(n) -> n, none -> 0, },
        none -> -1,
    };
}
""", {"phase": "parse", "expect": "pass"})

t("parser", "slice_type",
  "module parser.slice_type;\nfn f(s: Slice<I64>) -> U64 effects() { return s.len; }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "ref_const_type",
  "module parser.refconst;\nfn f(r: RefConst<I64>) -> Unit effects() { return unit; }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "array_type_param",
  "module parser.array_param;\nfn f(a: Array<I64, 4>) -> I64 effects() { return a[0]; }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "result_type",
  "module parser.result_type;\nerror_set E { Bad; }\nfn f() -> I64!E effects(error) { return 1; }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "option_type",
  "module parser.option_type;\nfn f() -> Option<I64> effects() { return some(1); }\n",
  {"phase": "parse", "expect": "pass"})

t("parser", "effects_multiple",
  "module parser.eff_multi;\nfn f() -> Unit effects(alloc, free, error) { return unit; }\n",
  {"phase": "parse", "expect": "pass"})

# ─── CANONICAL ROUNDTRIP (12 → 15) ───────────────────────────────────────────

for name, src in [
    ("for_range", "module cr.forrange;\n\nfn f() -> I64 effects() {\n    var t: I64 = 0;\n    for (i: I64 in 0..5) {\n        t = t + i;\n    }\n    return t;\n}\n"),
    ("error_union_fn", "module cr.errfn;\n\nerror_set E {\n    Bad;\n}\n\nfn g() -> I64!E effects(error) {\n    return E.Bad;\n}\n\nfn f() -> I64!E effects(error) {\n    let x: I64 = g()?;\n    return x;\n}\n"),
    ("effects_multi", "module cr.effmulti;\n\nfn f() -> Unit effects(alloc, free, error) {\n    return unit;\n}\n"),
]:
    t("canonical_roundtrip", f"roundtrip_{name}", src,
      {"phase": "format", "expect": "format", "output": src})

print("Additional tests written.")
for cat in sorted(ROOT.iterdir()):
    if cat.is_dir() and cat.name != "__pycache__":
        azfiles = list(cat.glob("*.az"))
        if azfiles:
            print(f"  {cat.name}: {len(azfiles)} tests")

