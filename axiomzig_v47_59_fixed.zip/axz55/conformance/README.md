# AxiomZig v1.1 Conformance Suite

Structured per `docs/axiomzig_conformance_plan_v1_1.md`.

## Layout

```
conformance/<category>/<test_name>.az      — source under test
conformance/<category>/<test_name>.json    — metadata sidecar
```

## Sidecar schema

```json
{
  "phase":      "check" | "parse" | "format" | "interpret",
  "expect":     "pass" | "fail" | "trap" | "format",
  "diagnostic": "E_*" | "R_TRAP_*",   (required when expect=fail or trap)
  "output":     "...",                  (required when expect=format or output)
  "notes":      "..."                   (optional)
}
```

## Running

```bash
# All conformance tests
pytest tests/test_conformance_runner.py

# With coverage report
pytest tests/test_conformance_runner.py -v
```

## Adding tests

1. Write the `.az` source file.
2. Create the `.json` sidecar with `phase`, `expect`, and `diagnostic`.
3. Run `pytest tests/test_conformance_runner.py` — it auto-discovers.

## Coverage status

| Category          | Pass | Fail | Total | Plan min |
|-------------------|-----:|-----:|------:|---------:|
| lexer             |    — |    — |     — |       20 |
| parser            |    — |    — |     — |       35 |
| formatter         |    — |    — |     — |       20 |
| name_resolution   |    — |    — |     — |       20 |
| typing            |    — |    — |     — |       50 |
| effects           |    — |    — |     — |       25 |
| ownership         |    — |    — |     — |       40 |
| protocols         |    — |    — |     — |       30 |
| defer             |    — |    — |     — |       25 |
| runtime           |    — |    — |     — |       35 |
| canonical_roundtrip |  — |    — |     — |       15 |
| diagnostics       |    — |    — |     — |        — |

(Updated by test run.)
