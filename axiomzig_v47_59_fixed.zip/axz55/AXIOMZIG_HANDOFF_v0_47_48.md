# AxiomZig v0.47.48 Handoff — Dependency Trust Policy

## Status

v0.47.48 is a trust-boundary hardening pass on top of v0.47.47.

The goals of this slice were:

1. make dependency-manifest integrity fields mandatory
2. add explicit package identity/version metadata to conformance manifests
3. add a lockfile-style pinned dependency set for static CLI consumers
4. preserve the existing static/runtime boundary for imported execution

This is still a **static dependency-summary feature**. Dependency manifests and dependency locks constrain what summaries are accepted; they do not execute dependency source and they do not replace runtime stubs during interpretation.

## What changed in v0.47.48

### 1. Conformance manifests now carry explicit package identity

Whole-program conformance/export manifests now include:

- `package_name`
- `package_version`
- `package_id = "<package_name>@<package_version>"`

The CLI supports explicit export control through:

- `axiomzig conform ... --package-name <name> --package-version <version>`

If omitted, the current implementation derives:

- `package_name` from the workspace root directory name
- `package_version` as `"0"`

This keeps manifests self-identifying even in local development.

### 2. Dependency manifests now require integrity metadata

Dependency-manifest acceptance is now stricter.
A consumed dependency manifest must now have:

- a conformance-manifest schema
- `status == "ok"`
- `internal_signatures`
- `package_name`
- `package_version`
- `package_id`
- `manifest_hash_algorithm == "sha256"`
- `manifest_hash`

The manifest hash is no longer optional for dependency consumption.

### 3. Dependency locks are now supported across static CLI consumers

The following commands now accept:

- `--dependency-lock <path>`

alongside `--dependency-manifest`:

- `check`
- `typecheck`
- `cfg`
- `owncheck`
- `ownsig`
- `interpret`
- `conform`

Current lock schema:

```json
{
  "schema_version": "axiomzig.dependency_lock.v1",
  "dependencies": [
    {
      "package_name": "dep_pkg",
      "package_version": "2.0.0",
      "package_id": "dep_pkg@2.0.0",
      "manifest_hash": "<sha256>",
      "modules": ["dep.api"]
    }
  ]
}
```

### 4. Dependency locks pin both identity and exact manifest content

When a dependency lock is supplied, each consumed dependency manifest must:

- match a pinned `package_id`
- match the pinned `manifest_hash`
- export exactly the pinned module list

Also:

- every pinned dependency package must be provided
- unexpected dependency packages are rejected
- duplicate dependency providers are still rejected

This makes the trust boundary explicit rather than inferred only from exported module names.

## Files changed

Primary implementation:

- `axiomzig/cli.py`
- `axiomzig/module_graph.py`
- `axiomzig/ownership_signatures.py`

New tests:

- `tests/test_dependency_trust_policy_v47_48.py`

Updated tests:

- `tests/test_conformance_manifest_stabilization_v47_45.py`
- `tests/test_dependency_manifests_v47_46.py`

Updated docs:

- `AXIOMZIG_HANDOFF_CURRENT.md`
- `AXIOMZIG_DESIGN_DOC_CURRENT.md`
- `AXIOMZIG_INTERPRETER_PROGRESS_CURRENT.md`
- `NEXT_STEPS_v47_48.md`
- versioned `v0.47.48` handoff/design notes

## Validation performed

- `python -m py_compile axiomzig/*.py tests/test_dependency_trust_policy_v47_48.py tests/test_dependency_manifest_hardening_v47_47.py tests/test_dependency_manifests_v47_46.py tests/test_conformance_manifest_stabilization_v47_45.py`
- `pytest -q tests/test_conformance_manifest_stabilization_v47_45.py tests/test_dependency_manifests_v47_46.py tests/test_dependency_manifest_hardening_v47_47.py tests/test_dependency_trust_policy_v47_48.py`
  - result: `19 passed`
- `pytest -q tests/test_module_graph_v47_41.py tests/test_module_graph_hardening_v47_42.py tests/test_whole_program_negative_v47_43.py tests/test_conformance_export_v47_44.py tests/test_conformance_manifest_stabilization_v47_45.py tests/test_dependency_manifests_v47_46.py tests/test_dependency_manifest_hardening_v47_47.py tests/test_dependency_trust_policy_v47_48.py`
  - result: `37 passed`

## Important boundary rules

1. **Workspace internal modules** are still summarized from source.
2. **Dependency manifests** provide static dependency summaries without re-deriving dependency source.
3. **Dependency manifests now require identity + hash metadata** to be accepted.
4. **Dependency locks pin package identity and exact manifest content**, not just module names.
5. **Opaque externals** remain explicit unresolved boundaries.
6. **Runtime stubs are still required** for interpreter execution of imported functions.
7. **Dependency manifest exports are still module-surface boundaries** under the current model.

## Known limitations

v0.47.48 still does not implement:

- signed manifest trust roots
- compatibility/version-range negotiation
- explicit package publication semantics distinct from debug manifests
- identical duplicate providers legalized under package identity policy
- cyclic source-module fixed-point solving
- lockfile generation from higher-level package metadata
