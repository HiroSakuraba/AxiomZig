# corpus009_ownership_moves_v47_59_dechunked_v3

S3 ownership/moves — dechunked v3 with minimal-semantic-edit pairs.

7 semantic families × 8 surface variants (4 protocol types × 2 variable names).
Each pair differs by exactly one semantic condition.

Records: 96  |  Chunk risk: **pass**
