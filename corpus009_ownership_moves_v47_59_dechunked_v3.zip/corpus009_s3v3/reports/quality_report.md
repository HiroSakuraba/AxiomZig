# S3 Dechunked v3 Quality Report

Records: 96  |  Documents: 192  |  Negative: 41.7%
Chunk risk: **pass**  |  Template MI: 0.0752 bits  |  Surface MI: 0.0752 bits

Diagnostics:
- `E_OWN_BORROW_ALIAS`: 8
- `E_OWN_BORROW_LIVE`: 1
- `E_OWN_MOVED`: 8
- `E_OWN_UNDISCHARGED`: 16
- `E_PROTO_TRANSITION`: 8