# Expansion Strategy

Next: add imported ownership-summary cases and multi-resource programs. Keep chunk-risk gate mandatory.
