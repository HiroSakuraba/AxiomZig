# axiomzig_prepretrain_corpus_0003

A numbered AxiomZig pre-pretraining corpus bundle generated from the uploaded Claude lifecycle corpus generator lineage and expanded with stricter schema, validation, and additional generator families.

## Contents

- `src/` — validated `.az` source files.
- `labels/` — one schema-v2 label sidecar per source file.
- `ledger/ledger.jsonl` and `ledger/ledger.csv` — machine-readable corpus ledger.
- `validation/validation_report.json` — strict validation summary.
- `schemas/` — label and manifest JSON schemas.
- `tools/claude_axiomzig_corpus_gen_seed.py` — the uploaded Claude seed generator.
- `tools/axiomzig_corpus_gen_v0003.py` — compact v0003 generator/extension harness.
- `tools/validate_corpus_v0003.py` — standalone validator.
- `package_labs/pubdiff/` — publication-diff manifest labs.

## Validation headline

- Source files: **787**
- Label files: **787**
- Parse OK: **787 / 787**
- Formatter idempotent: **787 / 787**
- Duplicate source hashes: **0**
- Duplicate formatted hashes: **0**
- Rejected generated candidates: **24**

## Distribution

Area counts:

```json
{
  "effects": 140,
  "formatter": 47,
  "ownership": 147,
  "protocols": 80,
  "publication": 20,
  "runtime": 182,
  "typing": 171
}
```

Phase counts:

```json
{
  "check": 558,
  "format": 47,
  "interpret": 182
}
```

Expected outcome counts:

```json
{
  "fail": 244,
  "output": 172,
  "pass": 361,
  "trap": 10
}
```

## Validator

From an environment with the AxiomZig v47.59 package on `PYTHONPATH`:

```bash
PYTHONPATH=/path/to/axz55 python tools/validate_corpus_v0003.py .
```

The validator checks labels, parser acceptance, checker outcomes, formatter idempotence, interpreter outputs/traps, and SHA-256 hashes.
