# Expansion strategy after axiomzig_prepretrain_corpus_0003

The current bundle is deliberately medium-sized: large enough to train on, small enough to audit.

Next numbered bundles should be generated, not hand-authored:

1. `0004`: whole-program/import-summary corpus with multi-file module roots.
2. `0005`: adversarial branch-join corpus, with systematic state-lattice perturbations.
3. `0006`: package-publication compatibility corpus with old/new manifests and source packages.
4. `0007`: runtime corpus with interpreter stub registries and imported function stubs.
5. `0008`: near-duplicate contrastive pairs: one-token semantic flips that change validity.

Recommended per-turn target remains 500–900 validated `.az` files. Above that, validation and labeling become the bottleneck, not source generation.
