# Quality report — axiomzig_prepretrain_corpus_0003

## Strict validation policy

A source file was included only if all of the following held:

1. The file parses under the v47.59 parser.
2. The formatter output parses and is idempotent on the second formatting pass.
3. For `check` examples, current checker outcome matches the label's expected `pass`/`fail`.
4. For `interpret` examples, the checker first accepts the source, then the interpreter output or trap family matches the label.
5. Exact source SHA-256 and formatted SHA-256 are unique across the corpus.

## Counts

- Total validated `.az` files: **787**
- Check-phase examples: **558**
- Interpret-phase examples: **182**
- Format-phase examples: **47**
- Positive examples: **533**
- Negative/trap examples: **254**

## Known rejected candidates

The generator rejected 24 candidates before packaging. The largest rejected class was check-time type mismatch in struct-by-value interpreter examples; those files were not included.

```json
{
  "interpret source did not check: ['E_TYPE_MISMATCH']": 24
}
```

## Runtime trap normalization

Claude's seed corpus used symbolic trap categories such as `R_TRAP_DIV_ZERO`. The v47.59 interpreter emits human-readable trap reasons such as `division by zero`. Labels in this bundle preserve trap-family metadata while recording the actual emitted trap string.
