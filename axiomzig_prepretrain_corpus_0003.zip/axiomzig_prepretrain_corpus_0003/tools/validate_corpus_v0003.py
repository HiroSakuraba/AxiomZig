#!/usr/bin/env python3
"""
Validate axiomzig_prepretrain_corpus_0003 against an AxiomZig checkout.

Usage:
  PYTHONPATH=/path/to/axz55 python tools/validate_corpus_v0003.py /path/to/axiomzig_prepretrain_corpus_0003

The script verifies:
  - every label points to an existing source file
  - every source parses
  - check-phase expected pass/fail matches current checker
  - format-phase examples are formatter-idempotent
  - interpret-phase output/trap examples match label metadata
  - source SHA-256 and formatted SHA-256 match labels
"""
from __future__ import annotations
import hashlib, json, pathlib, sys
from axiomzig.parser import parse_module
from axiomzig.checker import check_module
from axiomzig.formatter import format_module
from axiomzig.interpreter import Interpreter, TrapError, InterpreterUnsupportedError

def trap_matches(expected_family, actual_reason):
    if not expected_family:
        return True
    ef = str(expected_family).lower()
    ar = str(actual_reason).lower()
    mapping = {
        "r_trap_div_zero": "division by zero",
        "r_trap_overflow": "integer overflow",
        "r_trap_cast": "cast value",
    }
    return mapping.get(ef, ef) in ar

def main(root: str) -> int:
    rootp = pathlib.Path(root)
    labels = sorted((rootp / "labels").rglob("*.label.json"))
    failures = []
    for lp in labels:
        label = json.loads(lp.read_text(encoding="utf-8"))
        sp = rootp / label["relative_source_path"]
        if not sp.exists():
            failures.append((str(lp), "missing source"))
            continue
        src = sp.read_text(encoding="utf-8")
        if hashlib.sha256(src.encode()).hexdigest() != label["hashes"]["source_sha256"]:
            failures.append((str(lp), "source sha mismatch"))
            continue
        try:
            mod = parse_module(src)
            issues = check_module(mod)
            errors = [i for i in issues if i.level == "error"]
            formatted = format_module(mod)
            formatted2 = format_module(parse_module(formatted))
        except Exception as exc:
            failures.append((str(lp), f"frontend exception: {type(exc).__name__}: {exc}"))
            continue
        if hashlib.sha256(formatted.encode()).hexdigest() != label["hashes"]["formatted_sha256"]:
            failures.append((str(lp), "formatted sha mismatch"))
        if formatted != formatted2:
            failures.append((str(lp), "formatter not idempotent"))
        phase = label["task"]["phase"]
        expected = label["task"]["expected_outcome"]
        if phase == "check":
            actual = "fail" if errors else "pass"
            if actual != expected:
                failures.append((str(lp), f"check expected {expected}, got {actual}"))
        elif phase == "format":
            if expected != "pass":
                failures.append((str(lp), "format labels must expect pass"))
        elif phase == "interpret":
            if errors:
                failures.append((str(lp), f"interpret source has check errors: {[i.code or i.message for i in errors]}"))
                continue
            try:
                interp = Interpreter(mod)
                value = interp.interpret(entry="main")
                out = interp.render_value(value)
                if expected != "output" or str(label["task"].get("expected_output")) != str(out):
                    failures.append((str(lp), f"interpret expected {label['task'].get('expected_output')}, got {out}"))
            except TrapError as exc:
                if expected != "trap" or not trap_matches(label["task"].get("expected_trap_family"), str(exc.reason)):
                    failures.append((str(lp), f"trap mismatch: {exc.reason}"))
            except InterpreterUnsupportedError as exc:
                failures.append((str(lp), f"interpreter unsupported: {exc}"))
    print(json.dumps({"labels": len(labels), "failures": failures[:20], "failure_count": len(failures)}, indent=2))
    return 1 if failures else 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
