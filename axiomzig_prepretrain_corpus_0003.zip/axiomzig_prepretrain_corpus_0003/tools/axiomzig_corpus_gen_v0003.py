#!/usr/bin/env python3
"""
AxiomZig corpus generator v0003.

This is the upgraded generator lineage used for axiomzig_prepretrain_corpus_0003.
It intentionally starts from the uploaded Claude seed generator design:
  - protocol dictionary
  - generated .az + .json sidecars
  - hash ledger
Then v0003 adds:
  - label schema v2
  - strict validation against the v47.59 frontend/interpreter
  - split/difficulty/concept metadata
  - formatted-source SHA-256 dedupe
  - publication/pubdiff lab generation

The complete generated output is stored in this zip.  For reproducible extension,
use this file together with:
  tools/protocol_specs.json
  tools/generation_manifest.json
  tools/validate_corpus_v0003.py

The intentionally compact script below demonstrates the extension mechanism.
The full v0003 bundle was generated programmatically from the same family/template
model; no files were hand-authored one by one.
"""
from __future__ import annotations
import json, pathlib, hashlib, textwrap

def load_protocols(root: pathlib.Path) -> dict:
    return json.loads((root / "tools" / "protocol_specs.json").read_text())

def shortest_terminal_path(protocol: dict):
    init = protocol["init"]
    terminal = set(protocol["terminal"])
    transitions = protocol["transitions"]
    best = None
    def dfs(state, visited, path):
        nonlocal best
        if state in terminal and path:
            if best is None or len(path) < len(best):
                best = list(path)
        for name, (source, target) in transitions.items():
            if source == state and target not in visited:
                dfs(target, visited | {state}, path + [(name, source, target)])
    dfs(init, set(), [])
    return best or []

def render_valid_simple(module_name: str, protocol_name: str, protocol: dict) -> str:
    res = protocol["resource"]
    steps = "\n".join(f"    r.{name}();" for name, _, _ in shortest_terminal_path(protocol))
    return textwrap.dedent(f"""
    module {module_name};

    {protocol["decl"]}

    fn main(r: {res}) -> Unit effects(protocol_step) {{
    {steps}
        return unit;
    }}
    """).strip() + "\n"

def main() -> None:
    root = pathlib.Path(__file__).resolve().parents[1]
    protocols = load_protocols(root)
    sample_dir = root / "tools" / "generator_samples"
    sample_dir.mkdir(exist_ok=True)
    for name, protocol in protocols.items():
        src = render_valid_simple(f"sample.v0003.{name}", name, protocol)
        h = hashlib.sha256(src.encode()).hexdigest()
        (sample_dir / f"sample_valid_simple_{name}.az").write_text(src)
        (sample_dir / f"sample_valid_simple_{name}.json").write_text(json.dumps({
            "family": "protocol_lifecycle",
            "template_id": "valid_simple_path",
            "source_sha256": h,
        }, indent=2) + "\n")
    print(f"wrote {len(protocols)} sample protocol programs to {sample_dir}")

if __name__ == "__main__":
    main()
