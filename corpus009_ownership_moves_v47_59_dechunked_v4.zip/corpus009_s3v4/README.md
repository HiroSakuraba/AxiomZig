# corpus009_ownership_moves_v47_59_dechunked_v4

Records: 62  |  Chunk risk: **pass**  |  Taxonomy coverage: 8/22
