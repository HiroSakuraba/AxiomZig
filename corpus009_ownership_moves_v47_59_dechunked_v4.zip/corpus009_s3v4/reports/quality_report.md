# Quality Report — corpus009_ownership_moves_v47_59_dechunked_v4

**Records:** 62  |  **Documents:** 124
**Negative ratio:** 22/62 (35%)
**Chunk risk:** pass
  Template MI: 0.0983 bits
  Surface MI:  0.0983 bits
  Max diag %:  40.0%
**Distinct codes:** 4

### Diagnostic distribution
- `E_OWN_MERGE_CONFLICT`: 14
- `E_OWN_MOVED`: 8
- `E_OWN_UNDISCHARGED`: 12
- `E_PROTO_TRANSITION`: 1

### Taxonomy coverage
- Covered: 8/22 nodes (36.4%)
  ✓ ownership/branch_state/both_same_state
  ✓ ownership/branch_state/merge_conflict
  ✓ ownership/branch_state/two_terminal_routes
  ✓ ownership/loop/carried_external
  ✓ ownership/loop/closed_in_body
  ✓ ownership/loop/per_iteration_create_close
  ✓ ownership/reinit/rebind_after_move
  ✓ ownership/reinit/use_before_rebind
  ✗ ownership/alias/same_ref_twice
  ✗ ownership/alias/two_distinct_refs
  ✗ ownership/borrow/live_at_close
  ✗ ownership/borrow/scope_boundary
  ✗ ownership/branch/both_close
  ✗ ownership/branch/one_misses
  ✗ ownership/defer/defer_discharges
  ✗ ownership/defer/missing_discharge
  ✗ ownership/errdefer/covers_error_path
  ✗ ownership/errdefer/missing_errdefer
  ✗ ownership/move/close_moved_target
  ✗ ownership/move/use_after_move
  ✗ ownership/transition/double_close
  ✗ ownership/transition/single_close

### Complexity profile
- easy: 0.0%
- medium: 59.7%
- hard: 40.3%