# Expansion Strategy

0005 should focus on branch joins, imported whole-program summaries, and longer package-interface pipelines.

0006 should focus on source-to-publication-manifest examples.

0007 should be runtime/imported-stub heavy.
