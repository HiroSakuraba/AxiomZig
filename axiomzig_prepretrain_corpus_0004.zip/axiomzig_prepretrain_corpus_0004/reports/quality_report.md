# Quality Report: corpus 0004

- `.az` files: 631
- duplicate source hashes: 0
- runtime trap fraction: 72/172 = 41.86%
- contrastive pairs: 70
- long compositional programs: 30
- import-contract sidecars: 20
- package/pubdiff labs: 8

This is a repaired downloadable build written directly to a zip archive to avoid the prior missing-file issue.
