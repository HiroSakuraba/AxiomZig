# axiomzig_prepretrain_corpus_0004

Numbered AxiomZig pre-pretraining corpus bundle.

This bundle targets the critique of corpus 0003:
- stronger diagnostic-code coverage,
- runtime trap coverage near/above 35% of runtime examples,
- contrastive valid/invalid pairs,
- fewer constant-only near-duplicates,
- longer compositional programs,
- import-contract sidecars,
- package/pubdiff labs.

Important paths:
- `src/` — AxiomZig source examples
- `labels/` — label-v2 JSON sidecars
- `ledgers/ledger.jsonl`
- `ledgers/ledger.csv`
- `validation/validation_report.json`
- `tools/validate_corpus_v0004.py`
