import re
"""
AxiomZig Lifecycle Corpus Generator
Produces numbered zip files of .az + .json sidecar pairs for AI pre-pretraining.
Each program is unique along multiple diversity dimensions.
"""
import json, hashlib, itertools, textwrap, zipfile, pathlib, sys
from dataclasses import dataclass, field
from typing import Iterator

OUT_DIR = pathlib.Path("/mnt/user-data/outputs")
LEDGER_PATH = OUT_DIR / "corpus_ledger.json"
FILES_PER_ZIP = 300

# ─────────────────────────────────────────────────────────────────────────────
# Ledger
# ─────────────────────────────────────────────────────────────────────────────

def load_ledger() -> dict:
    if LEDGER_PATH.exists():
        return json.loads(LEDGER_PATH.read_text())
    return {"zips_produced": 0, "total_files": 0, "categories": {}, "hashes": []}

def save_ledger(ledger: dict) -> None:
    LEDGER_PATH.write_text(json.dumps(ledger, indent=2))

# ─────────────────────────────────────────────────────────────────────────────
# Protocol definitions (the "zoo")
# ─────────────────────────────────────────────────────────────────────────────

PROTOCOLS = {
    "file": {
        "decl": """\
protocol FileProtocol {
    states { Open, Closed }
    init Open;
    terminal { Closed }
    transitions { close: Open -> Closed; }
}
resource File { protocol: FileProtocol; fields { fd: I32; } }""",
        "resource": "File",
        "protocol": "FileProtocol",
        "transitions": {"close": ("Open", "Closed")},
        "terminal": ["Closed"],
        "init": "Open",
    },
    "socket": {
        "decl": """\
protocol SocketProtocol {
    states { Created, Connected, Closed }
    init Created;
    terminal { Closed }
    transitions {
        connect: Created -> Connected;
        close: Connected -> Closed;
        abort: Created -> Closed;
    }
}
resource Socket { protocol: SocketProtocol; fields { fd: I32; } }""",
        "resource": "Socket",
        "protocol": "SocketProtocol",
        "transitions": {
            "connect": ("Created", "Connected"),
            "close": ("Connected", "Closed"),
            "abort": ("Created", "Closed"),
        },
        "terminal": ["Closed"],
        "init": "Created",
    },
    "transaction": {
        "decl": """\
protocol TxnProtocol {
    states { Begun, Prepared, Committed, RolledBack }
    init Begun;
    terminal { Committed, RolledBack }
    transitions {
        prepare: Begun -> Prepared;
        commit: Prepared -> Committed;
        rollback: Begun -> RolledBack;
        rollback_prepared: Prepared -> RolledBack;
    }
}
resource Txn { protocol: TxnProtocol; fields { id: I64; } }""",
        "resource": "Txn",
        "protocol": "TxnProtocol",
        "transitions": {
            "prepare": ("Begun", "Prepared"),
            "commit": ("Prepared", "Committed"),
            "rollback": ("Begun", "RolledBack"),
            "rollback_prepared": ("Prepared", "RolledBack"),
        },
        "terminal": ["Committed", "RolledBack"],
        "init": "Begun",
    },
    "lock": {
        "decl": """\
protocol LockProtocol {
    states { Unlocked, Locked }
    init Unlocked;
    terminal { Unlocked }
    transitions {
        acquire: Unlocked -> Locked;
        release: Locked -> Unlocked;
    }
}
resource Lock { protocol: LockProtocol; fields { id: I32; } }""",
        "resource": "Lock",
        "protocol": "LockProtocol",
        "transitions": {
            "acquire": ("Unlocked", "Locked"),
            "release": ("Locked", "Unlocked"),
        },
        "terminal": ["Unlocked"],
        "init": "Unlocked",
    },
    "stream": {
        "decl": """\
protocol StreamProtocol {
    states { Open, Drained, Closed }
    init Open;
    terminal { Closed }
    transitions {
        drain: Open -> Drained;
        close: Drained -> Closed;
        close_early: Open -> Closed;
    }
}
resource Stream { protocol: StreamProtocol; fields { fd: I32; } }""",
        "resource": "Stream",
        "protocol": "StreamProtocol",
        "transitions": {
            "drain": ("Open", "Drained"),
            "close": ("Drained", "Closed"),
            "close_early": ("Open", "Closed"),
        },
        "terminal": ["Closed"],
        "init": "Open",
    },
    "gpu_buffer": {
        "decl": """\
protocol GpuBufProtocol {
    states { Allocated, Bound, Released }
    init Allocated;
    terminal { Released }
    transitions {
        bind: Allocated -> Bound;
        release: Bound -> Released;
        release_unbound: Allocated -> Released;
    }
}
resource GpuBuf { protocol: GpuBufProtocol; fields { handle: I64; } }""",
        "resource": "GpuBuf",
        "protocol": "GpuBufProtocol",
        "transitions": {
            "bind": ("Allocated", "Bound"),
            "release": ("Bound", "Released"),
            "release_unbound": ("Allocated", "Released"),
        },
        "terminal": ["Released"],
        "init": "Allocated",
    },
    "arena": {
        "decl": """\
protocol ArenaProtocol {
    states { Active, Freed }
    init Active;
    terminal { Freed }
    transitions { free: Active -> Freed; }
}
resource Arena { protocol: ArenaProtocol; fields { base: I64; } }""",
        "resource": "Arena",
        "protocol": "ArenaProtocol",
        "transitions": {"free": ("Active", "Freed")},
        "terminal": ["Freed"],
        "init": "Active",
    },
    "tls_socket": {
        "decl": """\
protocol TlsProtocol {
    states { Connected, Handshaken, Closed }
    init Connected;
    terminal { Closed }
    transitions {
        handshake: Connected -> Handshaken;
        close: Handshaken -> Closed;
        abort: Connected -> Closed;
    }
}
resource TlsSocket { protocol: TlsProtocol; fields { fd: I32; } }""",
        "resource": "TlsSocket",
        "protocol": "TlsProtocol",
        "transitions": {
            "handshake": ("Connected", "Handshaken"),
            "close": ("Handshaken", "Closed"),
            "abort": ("Connected", "Closed"),
        },
        "terminal": ["Closed"],
        "init": "Connected",
    },
}

def _first_field(p: dict) -> str:
    """Extract the first field name from a protocol resource declaration."""
    m = re.search(r'fields\s*\{([^}]+)\}', p["decl"])
    if m:
        fm = re.match(r'(\w+)\s*:', m.group(1).strip())
        if fm: return fm.group(1)
    return "fd"



# ─────────────────────────────────────────────────────────────────────────────
# Error sets for error-propagation programs
# ─────────────────────────────────────────────────────────────────────────────

ERROR_SETS = {
    "IoError": ["Interrupted", "TimedOut", "BrokenPipe"],
    "NetError": ["Refused", "Unreachable", "HostNotFound"],
    "TxnError": ["Deadlock", "Serialization", "Aborted"],
    "ParseError": ["Invalid", "Truncated", "Overflow"],
    "CryptoError": ["BadMac", "BadPadding", "KeyExpired"],
}

# ─────────────────────────────────────────────────────────────────────────────
# Program generators
# ─────────────────────────────────────────────────────────────────────────────

def _mod(category: str, variant: str) -> str:
    return f"corpus.{category}.{variant}".replace("-", "_")

def _meta(phase, expect, diag=None, area=None, notes=None):
    m = {"phase": phase, "expect": expect}
    if diag: m["diagnostic"] = diag
    if area: m["area"] = area
    if notes: m["notes"] = notes
    return m

# ── VALID: simple open → terminal ────────────────────────────────────────────

def gen_valid_simple_discharge(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """All terminal transitions reachable in a single straight-line path."""
    res = p["resource"]
    init = p["init"]
    # Find a path from init to any terminal
    transitions = p["transitions"]
    terminal = set(p["terminal"])

    def find_path(state, visited=None):
        if visited is None: visited = set()
        if state in terminal: return []
        for name, (frm, to) in transitions.items():
            if frm == state and to not in visited:
                rest = find_path(to, visited | {state})
                if rest is not None:
                    return [(name, frm, to)] + rest
        return None

    path = find_path(init)
    if path is None:
        return
    steps = "\n".join(f"    r.{t}();" for t, _, _ in path)
    slug = f"valid__simple_discharge__{p_name}"
    mod = _mod("valid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn main(r: {res}) -> Unit effects(protocol_step) {{
{steps}
    return unit;
}}
"""
    yield slug, src, _meta("check", "pass", area="ownership",
                            notes=f"{p_name}: straight-line discharge to terminal state")


def gen_valid_errdefer_cleanup(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """errdefer closes resource on error path; normal path closes explicitly."""
    res = p["resource"]
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    def find_terminal_transition():
        for name, (frm, to) in transitions.items():
            if frm == init and to in terminal:
                return name
        return None

    closer = find_terminal_transition()
    if closer is None:
        return

    for err_name, err_tags in list(ERROR_SETS.items())[:2]:
        tag = err_tags[0]
        slug = f"valid__errdefer_cleanup__{p_name}__{err_name.lower()}"
        mod = _mod("valid", slug)
        src = f"""\
module {mod};

{p["decl"]}
error_set {err_name} {{ {tag}; }}

fn risky() -> Unit!{err_name} effects(error) {{ return {err_name}.{tag}; }}

fn main(r: {res}) -> Unit!{err_name} effects(protocol_step, error) {{
    errdefer r.{closer}();
    try risky();
    r.{closer}();
    return unit;
}}
"""
        yield slug, src, _meta("check", "pass", area="ownership",
                                notes=f"{p_name}: errdefer discharges on error, explicit on success")


def gen_valid_branched_discharge(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """Both branches of an if discharge the resource."""
    res = p["resource"]
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers:
        return
    closer = closers[0]
    slug = f"valid__branched_discharge__{p_name}"
    mod = _mod("valid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn main(r: {res}, cond: Bool) -> Unit effects(protocol_step) {{
    if (cond) {{ r.{closer}(); }} else {{ r.{closer}(); }}
    return unit;
}}
"""
    yield slug, src, _meta("check", "pass", area="protocols",
                            notes=f"{p_name}: both if-branches discharge resource")


def gen_valid_move_discharge(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """Caller moves resource to a helper that discharges it."""
    if p["init"] in set(p["terminal"]): return
    res = p["resource"]
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    def find_path(state, visited=None):
        if visited is None: visited = set()
        if state in terminal: return []
        for name, (frm, to) in transitions.items():
            if frm == state and to not in visited:
                rest = find_path(to, visited | {state})
                if rest is not None:
                    return [(name, frm, to)] + rest
        return None

    path = find_path(init)
    if path is None: return
    steps = "\n".join(f"    r.{t}();" for t, _, _ in path)
    slug = f"valid__move_discharge__{p_name}"
    mod = _mod("valid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn discharge(r: {res}) -> Unit effects(protocol_step) {{
{steps}
    return unit;
}}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {_first_field(p)}: 0 }};
    discharge(move r);
    return unit;
}}
"""
    yield slug, src, _meta("check", "pass", area="ownership",
                            notes=f"{p_name}: moved to helper which discharges")


def gen_valid_ref_discharge(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """Ref<T> helper closes resource through borrow."""
    if p["init"] in set(p["terminal"]): return
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    def find_path(state, visited=None):
        if visited is None: visited = set()
        if state in terminal: return []
        for name, (frm, to) in transitions.items():
            if frm == state and to not in visited:
                rest = find_path(to, visited | {state})
                if rest is not None:
                    return [(name, frm, to)] + rest
        return None

    path = find_path(init)
    if path is None: return
    steps = "\n".join(f"    r.{t}();" for t, _, _ in path)
    slug = f"valid__ref_discharge__{p_name}"
    mod = _mod("valid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn close_via_ref(r: Ref<{res}>) -> Unit effects(protocol_step) {{
{steps}
    return unit;
}}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    {{ close_via_ref(borrow r); }}
    return unit;
}}
"""
    yield slug, src, _meta("check", "pass", area="ownership",
                            notes=f"{p_name}: Ref<T> helper closes via borrow")


def gen_valid_loop_discharge(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """Each loop iteration creates and discharges a fresh resource."""
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"valid__loop_discharge__{p_name}"
    mod = _mod("valid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn make() -> {res} effects() {{ return {res} {{ {ff}: 0 }}; }}

fn main() -> Unit effects(protocol_step) {{
    for (i: I64 in 0..5) {{
        let r: {res} = make();
        r.{closer}();
    }}
    return unit;
}}
"""
    yield slug, src, _meta("check", "pass", area="protocols",
                            notes=f"{p_name}: loop creates and discharges each iteration")


def gen_valid_multi_step_path(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """Multi-step protocol path exercises all intermediate states."""
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    def find_longest_path(state, visited=None):
        if visited is None: visited = set()
        best = []
        for name, (frm, to) in transitions.items():
            if frm == state and to not in visited:
                sub = find_longest_path(to, visited | {state})
                candidate = [(name, frm, to)] + sub
                if len(candidate) > len(best):
                    best = candidate
        if not best and state in terminal:
            return []
        return best

    path = find_longest_path(init)
    if not path or path[-1][2] not in terminal: return
    if len(path) < 2: return  # only interesting if >= 2 steps

    steps = "\n".join(f"    r.{t}();" for t, _, _ in path)
    slug = f"valid__multi_step_path__{p_name}"
    mod = _mod("valid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn full_lifecycle(r: {res}) -> Unit effects(protocol_step) {{
{steps}
    return unit;
}}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    full_lifecycle(move r);
    return unit;
}}
"""
    yield slug, src, _meta("check", "pass", area="protocols",
                            notes=f"{p_name}: full multi-step lifecycle to terminal")


def gen_valid_struct_wrap(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """Resource wrapped in struct; both struct fields discharged."""
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"valid__struct_wrap__{p_name}"
    mod = _mod("valid", slug)
    src = f"""\
module {mod};

{p["decl"]}

struct Pair {{ a: {res}; b: {res}; }}

fn close_r(r: {res}) -> Unit effects(protocol_step) {{ r.{closer}(); return unit; }}

fn main() -> Unit effects(protocol_step) {{
    let p: Pair = Pair {{ a: {res} {{ {ff}: 0 }}, b: {res} {{ {ff}: 1 }} }};
    close_r(move p.a);
    close_r(move p.b);
    return unit;
}}
"""
    yield slug, src, _meta("check", "pass", area="ownership",
                            notes=f"{p_name}: struct wrapping two resources, both discharged")


# ── INVALID programs ──────────────────────────────────────────────────────────

def gen_invalid_use_after_move(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"invalid__use_after_move__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn take(r: {res}) -> Unit effects(protocol_step) {{ r.{closer}(); return unit; }}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    take(move r);
    r.{closer}();
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", "E_OWN_MOVED", area="ownership",
                            notes=f"{p_name}: use after move — E_OWN_MOVED")


def gen_invalid_double_transition(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"invalid__double_transition__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    r.{closer}();
    r.{closer}();
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", "E_PROTO_TRANSITION", area="protocols",
                            notes=f"{p_name}: double transition — E_PROTO_TRANSITION")


def gen_invalid_undischarged(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    if p["init"] in set(p["terminal"]): return
    res = p["resource"]
    ff = _first_field(p)
    slug = f"invalid__undischarged__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn main() -> Unit effects() {{
    let r: {res} = {res} {{ {ff}: 0 }};
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", "E_OWN_UNDISCHARGED", area="ownership",
                            notes=f"{p_name}: resource never discharged — E_OWN_UNDISCHARGED")


def gen_invalid_one_branch_misses(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"invalid__one_branch_misses__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn main(cond: Bool) -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    if (cond) {{ r.{closer}(); }}
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", area="protocols",
                            notes=f"{p_name}: false branch misses discharge")


def gen_invalid_borrow_conflict(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"invalid__borrow_conflict__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn poke(r: Ref<{res}>) -> Unit effects() {{ return unit; }}
fn peek(r: RefConst<{res}>) -> Unit effects() {{ return unit; }}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    poke(borrow r);
    peek(borrow r);
    r.{closer}();
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", "E_OWN_BORROW_EXCL", area="ownership",
                            notes=f"{p_name}: shared borrow while exclusive borrow live")


def gen_invalid_missing_effect(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    res = p["resource"]
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"invalid__missing_protocol_step__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn step_fn(r: {res}) -> Unit effects(protocol_step) {{
    r.{closer}();
    return unit;
}}

fn caller(r: {res}) -> Unit effects() {{ step_fn(r); return unit; }}
"""
    yield slug, src, _meta("check", "fail", "E_EFFECT_UNDER", area="effects",
                            notes=f"{p_name}: caller missing protocol_step — E_EFFECT_UNDER")


def gen_invalid_transition_skip(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    """Try to skip an intermediate state."""
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    # Find a transition NOT from init but to terminal
    skip_targets = [
        (n, f, t) for n, (f, t) in transitions.items()
        if f != init and t in terminal
    ]
    if not skip_targets: return
    name, frm, to = skip_targets[0]
    slug = f"invalid__skip_intermediate_state__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    r.{name}();
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", "E_PROTO_TRANSITION", area="protocols",
                            notes=f"{p_name}: skip intermediate state — transition from wrong state")


def gen_invalid_double_move(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    res = p["resource"]
    ff = _first_field(p)
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    slug = f"invalid__double_move__{p_name}"
    mod = _mod("invalid", slug)
    src = f"""\
module {mod};

{p["decl"]}

fn take(r: {res}) -> Unit effects(protocol_step) {{ r.{closer}(); return unit; }}

fn main() -> Unit effects(protocol_step) {{
    let r: {res} = {res} {{ {ff}: 0 }};
    take(move r);
    take(move r);
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", "E_OWN_MOVED", area="ownership",
                            notes=f"{p_name}: double move to same consumer")


def gen_invalid_missing_recurse(p_name: str, p: dict) -> Iterator[tuple[str,str,dict]]:
    slug = f"invalid__missing_recurse__{p_name}"
    mod = _mod("invalid", slug)
    res = p["resource"]
    transitions = p["transitions"]
    terminal = set(p["terminal"])
    init = p["init"]

    closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
    if not closers: return
    closer = closers[0]
    src = f"""\
module {mod};

{p["decl"]}

fn discharge_all(n: I64, r: {res}) -> Unit effects(protocol_step) {{
    if (n <= 0) {{ r.{closer}(); return unit; }}
    discharge_all(n - 1, r);
    return unit;
}}
"""
    yield slug, src, _meta("check", "fail", "E_EFFECT_RECURSE", area="effects",
                            notes=f"{p_name}: recursive fn missing recurse effect")


# ── ALGORITHMS (runtime validation) ──────────────────────────────────────────

def gen_algorithm_programs() -> Iterator[tuple[str,str,dict]]:
    algorithms = [
        ("factorial", """\
module algo.factorial;
fn factorial(n: I64) -> I64 effects(recurse) {
    if (n <= 1) { return 1; }
    return n * factorial(n - 1);
}
fn main() -> I64 effects(recurse) { return factorial(10); }
""", "interpret", "output", "3628800"),
        ("fibonacci_7", """\
module algo.fib7;
fn fib(n: I64) -> I64 effects(recurse) {
    if (n <= 1) { return n; }
    return fib(n - 1) + fib(n - 2);
}
fn main() -> I64 effects(recurse) { return fib(7); }
""", "interpret", "output", "13"),
        ("fibonacci_10", """\
module algo.fib10;
fn fib(n: I64) -> I64 effects(recurse) {
    if (n <= 1) { return n; }
    return fib(n - 1) + fib(n - 2);
}
fn main() -> I64 effects(recurse) { return fib(10); }
""", "interpret", "output", "55"),
        ("gcd_48_18", """\
module algo.gcd;
fn gcd(a: I64, b: I64) -> I64 effects(recurse) {
    if (b == 0) { return a; }
    return gcd(b, a % b);
}
fn main() -> I64 effects(recurse) { return gcd(48, 18); }
""", "interpret", "output", "6"),
        ("sum_1_to_100", """\
module algo.sum100;
fn main() -> I64 effects() {
    var t: I64 = 0;
    for (i: I64 in 1..101) { t = t + i; }
    return t;
}
""", "interpret", "output", "5050"),
        ("power_2_10", """\
module algo.pow;
fn pow(b: I64, e: I64) -> I64 effects(recurse) {
    if (e == 0) { return 1; }
    return b * pow(b, e - 1);
}
fn main() -> I64 effects(recurse) { return pow(2, 10); }
""", "interpret", "output", "1024"),
        ("collatz_6", """\
module algo.collatz;
fn collatz_steps(n: I64) -> I64 effects(recurse) {
    if (n == 1) { return 0; }
    if (n % 2 == 0) { return 1 + collatz_steps(n / 2); }
    return 1 + collatz_steps(n * 3 + 1);
}
fn main() -> I64 effects(recurse) { return collatz_steps(6); }
""", "interpret", "output", "8"),
        ("sum_of_squares_5", """\
module algo.sumsq;
fn main() -> I64 effects() {
    var t: I64 = 0;
    for (i: I64 in 1..6) { t = t + i * i; }
    return t;
}
""", "interpret", "output", "55"),
        ("count_evens_10", """\
module algo.evens;
fn main() -> I64 effects() {
    var cnt: I64 = 0;
    for (i: I64 in 0..10) { if (i % 2 == 0) { cnt = cnt + 1; } }
    return cnt;
}
""", "interpret", "output", "5"),
        ("max_of_three", """\
module algo.max3;
fn max3(a: I64, b: I64, c: I64) -> I64 effects() {
    var m: I64 = a;
    if (b > m) { m = b; }
    if (c > m) { m = c; }
    return m;
}
fn main() -> I64 effects() { return max3(7, 3, 11); }
""", "interpret", "output", "11"),
        ("abs_value", """\
module algo.absval;
fn absval(x: I64) -> I64 effects() {
    if (x < 0) { return -x; }
    return x;
}
fn main() -> I64 effects() { return absval(-42); }
""", "interpret", "output", "42"),
        ("bool_and_short_circuit", """\
module algo.short_and;
fn main() -> Bool effects() { return false and (1 / 0 == 0); }
""", "interpret", "output", "false"),
        ("bool_or_short_circuit", """\
module algo.short_or;
fn main() -> Bool effects() { return true or (1 / 0 == 0); }
""", "interpret", "output", "true"),
        ("match_enum_dispatch", """\
module algo.enumatch;
enum Dir { N; S; E; W; }
fn to_int(d: Dir) -> I64 effects() {
    return match d { Dir.N -> 1, Dir.S -> 2, Dir.E -> 3, Dir.W -> 4, };
}
fn main() -> I64 effects() { return to_int(Dir.W); }
""", "interpret", "output", "4"),
        ("option_chain", """\
module algo.optchain;
fn safe_div(a: I64, b: I64) -> Option<I64> effects() {
    if (b == 0) { return none; }
    return some(a / b);
}
fn main() -> I64 effects() {
    return match safe_div(10, 2) { some(n) -> n, none -> 0, };
}
""", "interpret", "output", "5"),
        ("error_catch_chain", """\
module algo.errchain;
error_set E { Bad; }
fn fail() -> I64!E effects(error) { return E.Bad; }
fn g() -> I64!E effects(error) { return fail()?; }
fn main() -> I64 effects(error) { return g() catch 42; }
""", "interpret", "output", "42"),
        ("while_countdown", """\
module algo.countdown;
fn main() -> I64 effects() {
    var n: I64 = 10;
    var steps: I64 = 0;
    while (n > 0) { n = n - 1; steps = steps + 1; }
    return steps;
}
""", "interpret", "output", "10"),
        ("nested_loops", """\
module algo.nested;
fn main() -> I64 effects() {
    var t: I64 = 0;
    for (i: I64 in 0..4) {
        for (j: I64 in 0..4) { t = t + 1; }
    }
    return t;
}
""", "interpret", "output", "16"),
        ("break_at_first_negative", """\
module algo.breakneg;
fn first_neg_pos(n: I64) -> I64 effects(recurse) {
    var i: I64 = 0;
    var cur: I64 = n;
    while (cur > 0) {
        cur = cur - 3;
        i = i + 1;
    }
    return i;
}
fn main() -> I64 effects(recurse) { return first_neg_pos(10); }
""", "interpret", "output", "4"),
        ("div_zero_traps", """\
module algo.divzero;
fn main() -> I64 effects() { let x: I64 = 1; let y: I64 = 0; return x / y; }
""", "interpret", "trap", "R_TRAP_DIV_ZERO"),
        ("overflow_traps", """\
module algo.overflow;
fn main() -> I64 effects() {
    let a: I64 = 9223372036854775807;
    return a + 1;
}
""", "interpret", "trap", "R_TRAP_OVERFLOW"),
        ("cast_oob_traps", """\
module algo.castoob;
fn main() -> I8 effects() { let x: I64 = 200; return @cast(I8, x); }
""", "interpret", "trap", "R_TRAP_CAST"),
        ("u8_overflow_traps", """\
module algo.u8overflow;
fn main() -> U8 effects() {
    let a: U8 = @cast(U8, 255);
    let b: U8 = @cast(U8, 1);
    return a + b;
}
""", "interpret", "trap", "R_TRAP_OVERFLOW"),
    ]
    for (name, src, phase, expect, output_or_diag) in algorithms:
        if expect == "output":
            meta = {"phase": phase, "expect": expect, "output": output_or_diag, "area": "runtime"}
        else:
            meta = {"phase": phase, "expect": expect, "diagnostic": output_or_diag, "area": "runtime"}
        yield f"algo__{name}", src, meta


# ── FORMATTING ROUNDTRIP programs ─────────────────────────────────────────────

def gen_format_roundtrip_programs() -> Iterator[tuple[str,str,dict]]:
    for p_name, p in PROTOCOLS.items():
        res = p["resource"]
        transitions = p["transitions"]
        terminal = set(p["terminal"])
        init = p["init"]

        closers = [n for n, (f, t) in transitions.items() if f == init and t in terminal]
        if not closers: continue
        closer = closers[0]

        slug = f"fmt_roundtrip__{p_name}"
        src = f"""\
module fmt.{p_name};

{p["decl"]}

fn discharge(r: {res}) -> Unit effects(protocol_step) {{
    r.{closer}();
    return unit;
}}
"""
        yield slug, src, {"phase": "format", "expect": "pass", "area": "formatter",
                          "notes": f"formatter idempotence on {p_name} protocol"}


# ── EFFECT PROPAGATION programs ───────────────────────────────────────────────

def gen_effect_programs() -> Iterator[tuple[str,str,dict]]:
    effects = ["alloc", "free", "io", "error", "protocol_step"]
    for eff in effects:
        # valid: propagates correctly
        slug = f"effect__propagates__{eff.replace('_', '')}"
        src = f"""\
module eff.prop_{eff.replace('.','_')};
fn leaf() -> Unit effects({eff}) {{ return unit; }}
fn mid() -> Unit effects({eff}) {{ return leaf(); }}
fn top() -> Unit effects({eff}) {{ return mid(); }}
"""
        yield slug, src, _meta("check", "pass", area="effects",
                                notes=f"{eff} propagates through call chain")

        # invalid: caller missing effect
        slug2 = f"effect__caller_missing__{eff.replace('_', '')}"
        src2 = f"""\
module eff.miss_{eff.replace('.','_')};
fn leaf() -> Unit effects({eff}) {{ return unit; }}
fn caller() -> Unit effects() {{ return leaf(); }}
"""
        yield slug2, src2, _meta("check", "fail", "E_EFFECT_UNDER", area="effects",
                                  notes=f"caller missing {eff} — E_EFFECT_UNDER")


# ── ERROR PROPAGATION programs ────────────────────────────────────────────────

def gen_error_programs() -> Iterator[tuple[str,str,dict]]:
    for err_name, tags in ERROR_SETS.items():
        for i, tag in enumerate(tags[:2]):
            # catch |e| binding form
            slug = f"err__catch_binding__{err_name.lower()}_{i}"
            src = f"""\
module err.catch_{err_name.lower()}_{i};
error_set {err_name} {{ {"; ".join(tags)}; }}
fn risky() -> I64!{err_name} effects(error) {{ return {err_name}.{tag}; }}
fn main() -> I64 effects(error) {{
    let result: I64 = risky() catch |e| {{
        return 0;
    }};
    return result;
}}
"""
            yield slug, src, _meta("check", "pass", area="effects",
                                    notes=f"catch |e| binding with {err_name}.{tag}")

            # ? propagation
            slug2 = f"err__question_mark__{err_name.lower()}_{i}"
            src2 = f"""\
module err.qmark_{err_name.lower()}_{i};
error_set {err_name} {{ {"; ".join(tags)}; }}
fn risky() -> I64!{err_name} effects(error) {{ return {err_name}.{tag}; }}
fn main() -> I64!{err_name} effects(error) {{
    let x: I64 = risky()?;
    return x;
}}
"""
            yield slug2, src2, _meta("check", "pass", area="effects",
                                      notes=f"? propagation with {err_name}.{tag}")


# ── OPTION programs ───────────────────────────────────────────────────────────

def gen_option_programs() -> Iterator[tuple[str,str,dict]]:
    for typ, val, bad_val, expected in [
        ("I64", "42", "0", "42"),
        ("Bool", "true", "false", "true"),
    ]:
        slug = f"opt__some_match__{typ.lower()}"
        src = f"""\
module opt.some_{typ.lower()};
fn main() -> {typ} effects() {{
    let x: Option<{typ}> = some({val});
    return match x {{ some(v) -> v, none -> {bad_val}, }};
}}
"""
        yield slug, src, _meta("check", "pass", area="typing")

        slug2 = f"opt__none_match__{typ.lower()}"
        src2 = f"""\
module opt.none_{typ.lower()};
fn main() -> {typ} effects() {{
    let x: Option<{typ}> = none;
    return match x {{ some(v) -> v, none -> {bad_val}, }};
}}
"""
        yield slug2, src2, _meta("check", "pass", area="typing")


# ── ENUM DISPATCH programs ────────────────────────────────────────────────────

def gen_enum_programs() -> Iterator[tuple[str,str,dict]]:
    enums = [
        ("Color", ["Red", "Green", "Blue"]),
        ("Direction", ["North", "South", "East", "West"]),
        ("Status", ["Ok", "Warn", "Err"]),
        ("Priority", ["Low", "Medium", "High", "Critical"]),
    ]
    for enum_name, variants in enums:
        arms = ", ".join(f"{enum_name}.{v} -> {i}" for i, v in enumerate(variants))
        slug = f"enum__dispatch__{enum_name.lower()}"
        src = f"""\
module enm.dispatch_{enum_name.lower()};
enum {enum_name} {{ {"; ".join(variants)}; }}
fn to_int(x: {enum_name}) -> I64 effects() {{
    return match x {{ {arms}, }};
}}
fn main() -> I64 effects() {{ return to_int({enum_name}.{variants[-1]}); }}
"""
        yield slug, src, _meta("check", "pass", area="typing",
                                notes=f"enum dispatch exhaustive match on {enum_name}")


# ── STRUCT programs ───────────────────────────────────────────────────────────

def gen_struct_programs() -> Iterator[tuple[str,str,dict]]:
    structs = [
        ("Point", [("x", "I64"), ("y", "I64")], "x + y", "3"),
        ("Counter", [("n", "I64"), ("max", "I64")], "n + max", "15"),
        ("Bounds", [("lo", "I64"), ("hi", "I64")], "hi - lo", "7"),
    ]
    for name, fields, body_expr, expected in structs:
        field_decls = "; ".join(f"{fn}: {ft}" for fn, ft in fields)
        field_inits = ", ".join(f"{fn}: {i+1}" for i, (fn, ft) in enumerate(fields))
        first_fn = fields[0][0]
        init_pairs = ", ".join(f"{fn}: {i+1}" for i, (fn, ft) in enumerate(fields))
        slug = f"struct__access__{name.lower()}"
        src = f"""\
module strct.access_{name.lower()};
struct {name} {{ {field_decls}; }}
fn get_first(s: {name}) -> I64 effects() {{ return s.{first_fn}; }}
fn main() -> I64 effects() {{
    let s: {name} = {name} {{ {init_pairs} }};
    return get_first(s);
}}
"""
        yield slug, src, _meta("check", "pass", area="typing",
                                notes=f"struct field access on {name}")


# ── RECURSION effect programs ─────────────────────────────────────────────────

def gen_recurse_programs() -> Iterator[tuple[str,str,dict]]:
    fns = [
        ("sum_n", "fn sum_n(n: I64) -> I64 effects(recurse) {\n    if (n == 0) { return 0; }\n    return n + sum_n(n - 1);\n}", "sum_n(5)", "15"),
        ("count_down", "fn count_down(n: I64) -> I64 effects(recurse) {\n    if (n <= 0) { return 0; }\n    return 1 + count_down(n - 1);\n}", "count_down(7)", "7"),
    ]
    for slug_suffix, fn_body, call, expected in fns:
        # valid
        slug = f"recurse__valid__{slug_suffix}"
        src = f"""\
module rec.valid_{slug_suffix};
{fn_body}
fn main() -> I64 effects(recurse) {{ return {call}; }}
"""
        yield slug, src, _meta("check", "pass", area="effects")

        # invalid: missing recurse
        slug2 = f"recurse__missing_effect__{slug_suffix}"
        fn_bad = fn_body.replace("effects(recurse)", "effects()")
        src2 = f"""\
module rec.miss_{slug_suffix};
{fn_bad}
fn main() -> I64 effects(recurse) {{ return {call}; }}
"""
        yield slug2, src2, _meta("check", "fail", "E_EFFECT_RECURSE", area="effects")


# ─────────────────────────────────────────────────────────────────────────────
# Master generator
# ─────────────────────────────────────────────────────────────────────────────

def all_programs() -> Iterator[tuple[str,str,dict]]:
    """Yield (slug, source, metadata) for every program in the corpus."""
    for p_name, p in PROTOCOLS.items():
        yield from gen_valid_simple_discharge(p_name, p)
        yield from gen_valid_errdefer_cleanup(p_name, p)
        yield from gen_valid_branched_discharge(p_name, p)
        yield from gen_valid_move_discharge(p_name, p)
        yield from gen_valid_ref_discharge(p_name, p)
        yield from gen_valid_loop_discharge(p_name, p)
        yield from gen_valid_multi_step_path(p_name, p)
        yield from gen_valid_struct_wrap(p_name, p)
        yield from gen_invalid_use_after_move(p_name, p)
        yield from gen_invalid_double_transition(p_name, p)
        yield from gen_invalid_undischarged(p_name, p)
        yield from gen_invalid_one_branch_misses(p_name, p)
        yield from gen_invalid_borrow_conflict(p_name, p)
        yield from gen_invalid_missing_effect(p_name, p)
        yield from gen_invalid_transition_skip(p_name, p)
        yield from gen_invalid_double_move(p_name, p)
        yield from gen_invalid_missing_recurse(p_name, p)
    yield from gen_algorithm_programs()
    yield from gen_format_roundtrip_programs()
    yield from gen_effect_programs()
    yield from gen_error_programs()
    yield from gen_option_programs()
    yield from gen_enum_programs()
    yield from gen_struct_programs()
    yield from gen_recurse_programs()


# ─────────────────────────────────────────────────────────────────────────────
# Build one zip
# ─────────────────────────────────────────────────────────────────────────────

def build_zip(zip_num: int, programs: list[tuple[str,str,dict]], ledger: dict) -> pathlib.Path:
    zip_path = OUT_DIR / f"axiomzig_corpus_{zip_num:03d}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for slug, src, meta in programs:
            # deduplicate by content hash
            h = hashlib.sha256(src.encode()).hexdigest()[:16]
            if h in ledger["hashes"]:
                continue
            ledger["hashes"].append(h)
            zf.writestr(f"{slug}.az", src)
            zf.writestr(f"{slug}.json", json.dumps(meta, indent=2))
            cat = meta.get("area", "general")
            ledger["categories"][cat] = ledger["categories"].get(cat, 0) + 1
            ledger["total_files"] += 1
    return zip_path


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    n_zips = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    ledger = load_ledger()
    programs = list(all_programs())
    print(f"Total unique programs generated: {len(programs)}")

    # Chunk into zips
    chunks = [programs[i:i+FILES_PER_ZIP] for i in range(0, len(programs), FILES_PER_ZIP)]

    produced = []
    for chunk in chunks[:n_zips]:
        ledger["zips_produced"] += 1
        zip_num = ledger["zips_produced"]
        zp = build_zip(zip_num, chunk, ledger)
        produced.append(zp)
        print(f"  zip {zip_num:03d}: {zp.name} ({zp.stat().st_size // 1024}KB)")

    save_ledger(ledger)
    print(f"\nLedger: {ledger['total_files']} total files across {ledger['zips_produced']} zips")
    print(f"Categories: {ledger['categories']}")
