#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, sys
root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
bad = []
seen = set()
for line in (root / "ledgers/ledger.jsonl").read_text().splitlines():
    r = json.loads(line)
    p = root / r["source_path"]
    h = hashlib.sha256(p.read_bytes()).hexdigest()
    if h != r["sha256"]:
        bad.append((r["example_id"], "hash_mismatch"))
    if h in seen:
        bad.append((r["example_id"], "duplicate_hash"))
    seen.add(h)
print(json.dumps({"records": len(seen), "problems": bad}, indent=2))
raise SystemExit(1 if bad else 0)
