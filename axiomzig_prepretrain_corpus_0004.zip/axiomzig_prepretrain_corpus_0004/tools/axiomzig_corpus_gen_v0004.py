# Generated from Claude seed plus diagnostic/trap/contrastive expansion.
