# corpus008_ownership_moves_v47_59_dechunked_v2

Dechunked S3 ownership/moves bundle per chunky-post-training analysis.

Records: 101
Documents: 202
Chunk risk: **pass**
Distinct diagnostics: 4
Negative ratio: 44.6%
