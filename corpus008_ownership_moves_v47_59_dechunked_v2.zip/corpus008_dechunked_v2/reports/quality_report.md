# S3 Dechunked v2 Quality Report

**Records:** 101  |  **Documents:** 202
**Negative ratio:** 44.6%
**Chunk risk:** pass
**Distinct diagnostic codes:** 4
**Max single diagnostic %:** 39.6%

```json
{
  "E_OWN_UNDISCHARGED": 21,
  "E_OWN_MOVED": 16,
  "E_OWN_BORROW_LIVE": 8,
  "E_OWN_BORROW_ALIAS": 8
}
```
