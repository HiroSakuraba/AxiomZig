#!/usr/bin/env python3
"""
make_s3v5_corpus010_v47_60.py — Corpus010 balanced 50-example S3 ownership tranche.

Purpose:
  Produce a small, reliable, compiler-grounded continuation corpus with exactly
  50 accepted source examples:
    - 5 semantic families
    - 5 contrastive pairs per family
    - 25 pass / 25 fail
    - 5 diagnostic-code classes, balanced enough to pass chunk-risk gates
    - zero post-filter drops in the intended build

Families:
  1. move target closed vs source used after move
  2. explicit terminal discharge vs missing discharge
  3. inner borrow scope ends vs borrow live at transition
  4. multi-step protocol path vs wrong-state transition
  5. same-state branch join vs merge conflict

Requires the v47.60 corpusfix framework and compiler. If this script is placed
inside a bundle's tools/ directory, it imports tools/az_corpus_framework.py.
If run beside az_corpus_framework_v47_60_corpusfix1.py, it imports that first.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

try:
    from az_corpus_framework_v47_60_corpusfix1 import (
        CorpusFramework,
        Example,
        SemanticFamily,
        TaxonomyNode,
    )
except ImportError:
    from az_corpus_framework import (
        CorpusFramework,
        Example,
        SemanticFamily,
        TaxonomyNode,
    )

CORPUS_ID        = "axiomzig_prepretrain_corpus_0010"
BUNDLE_NAME      = "corpus010_ownership_moves_v47_60_balanced50"
ROOT_PREFIX      = "corpus010_s3_balanced50"
COMPILER_VERSION = "v47.60"

TAXONOMY = [
    TaxonomyNode("ownership/move/target_closed_after_move",
                 "moved-to binding is discharged through callee"),
    TaxonomyNode("ownership/move/use_after_move",
                 "moved-from binding is used after move"),
    TaxonomyNode("ownership/discharge/explicit_close",
                 "resource explicitly reaches terminal transition"),
    TaxonomyNode("ownership/discharge/missing_close",
                 "resource leaves scope non-terminal"),
    TaxonomyNode("ownership/borrow/inner_scope_ends",
                 "borrow is contained in inner lexical block before close"),
    TaxonomyNode("ownership/borrow/live_at_transition",
                 "resource transition attempted while immutable borrow remains live"),
    TaxonomyNode("ownership/protocol/multi_step_valid",
                 "multi-step protocol reaches terminal state"),
    TaxonomyNode("ownership/protocol/wrong_state_transition",
                 "transition invoked from wrong protocol state"),
    TaxonomyNode("ownership/branch_state/same_state_join",
                 "if branches leave resource in same nonterminal state before close"),
    TaxonomyNode("ownership/branch_state/merge_conflict",
                 "if branches leave resource in incompatible states at join"),
]

VARIANTS = [
    ("file",  "File",  "f",  "make_f",  0),
    ("arena", "Arena", "a",  "make_a",  1),
    ("txn",   "Txn",   "t",  "make_t",  2),
    ("pipe",  "Pipe",  "p",  "make_p",  3),
    ("file",  "File",  "fp", "make_fp", 4),
]

SOCK_VARIANTS = [
    ("sock", "Sock", "s",    "make_s",    10),
    ("sock", "Sock", "sk",   "make_sk",   11),
    ("sock", "Sock", "sock", "make_sock", 12),
    ("sock", "Sock", "conn", "make_conn", 13),
    ("sock", "Sock", "chan", "make_chan", 14),
]


def proto_decl(pk: str, res: str, mfn: str, fd: int) -> tuple[str, str, str]:
    """Return (declaration_text, terminal_transition, connect_transition_or_empty)."""
    pname = f"{res}P"
    if pk == "file":
        return (
            f"protocol {pname} {{ states {{ Open, Closed }} init Open; terminal {{ Closed }} "
            f"transitions {{ close: Open -> Closed; }} }}\n"
            f"resource {res} {{ protocol: {pname}; fields {{ fd: I32; }} }}\n"
            f"fn {mfn}() -> {res} effects() {{ return {res} {{ fd: {fd} }}; }}",
            "close",
            "",
        )
    if pk == "arena":
        return (
            f"protocol {pname} {{ states {{ Active, Freed }} init Active; terminal {{ Freed }} "
            f"transitions {{ free: Active -> Freed; }} }}\n"
            f"resource {res} {{ protocol: {pname}; fields {{ base: I64; }} }}\n"
            f"fn {mfn}() -> {res} effects() {{ return {res} {{ base: {fd} }}; }}",
            "free",
            "",
        )
    if pk == "txn":
        return (
            f"protocol {pname} {{ states {{ Begun, Committed }} init Begun; terminal {{ Committed }} "
            f"transitions {{ commit: Begun -> Committed; }} }}\n"
            f"resource {res} {{ protocol: {pname}; fields {{ id: I64; }} }}\n"
            f"fn {mfn}() -> {res} effects() {{ return {res} {{ id: {fd} }}; }}",
            "commit",
            "",
        )
    if pk == "pipe":
        return (
            f"protocol {pname} {{ states {{ Ready, Closed }} init Ready; terminal {{ Closed }} "
            f"transitions {{ seal: Ready -> Closed; }} }}\n"
            f"resource {res} {{ protocol: {pname}; fields {{ fd: I32; }} }}\n"
            f"fn {mfn}() -> {res} effects() {{ return {res} {{ fd: {fd} }}; }}",
            "seal",
            "",
        )
    if pk == "sock":
        return (
            f"protocol {pname} {{ states {{ Created, Connected, Closed }} init Created; terminal {{ Closed }} "
            f"transitions {{ connect: Created -> Connected; abort: Created -> Closed; "
            f"close: Connected -> Closed; }} }}\n"
            f"resource {res} {{ protocol: {pname}; fields {{ fd: I32; }} }}\n"
            f"fn {mfn}() -> {res} effects() {{ return {res} {{ fd: {fd} }}; }}",
            "abort",
            "connect",
        )
    raise ValueError(pk)


def make_src(slug: str, pk: str, res: str, mfn: str, fd: int, body: str) -> str:
    decl, _, _ = proto_decl(pk, res, mfn, fd)
    return f"module corpus010.own.{slug};\n\n{decl}\n\n{body}\n"


def gen_move_family() -> SemanticFamily:
    examples: list[Example] = []
    for i, (pk, res, var, mfn, fd) in enumerate(VARIANTS):
        _, close, _ = proto_decl(pk, res, mfn, fd)
        pair = f"c010_move_{i}"

        body_v = (
            f"fn sink_{i}(x: {res}) -> Unit effects(protocol_step) {{ x.{close}(); return unit; }}\n"
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    let g{i}: {res} = move {var};\n"
            f"    sink_{i}(move g{i});\n"
            f"    return unit;\n"
            f"}}"
        )
        body_i = (
            f"fn sink_{i}(x: {res}) -> Unit effects(protocol_step) {{ x.{close}(); return unit; }}\n"
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    let g{i}: {res} = move {var};\n"
            f"    {var}.{close}();\n"
            f"    g{i}.{close}();\n"
            f"    return unit;\n"
            f"}}"
        )
        examples.append(Example(
            desc=f"move_target_closed_v_{i}",
            template_id="s3c010_move_target",
            family="move_target_closed",
            role="valid_target_closed_after_move",
            src=make_src(f"move_target_closed_v_{i}", pk, res, mfn, fd, body_v),
            concepts=["move", "moved_to_binding", "callee_discharge"],
            difficulty="medium",
            pair=pair,
            taxonomy_nodes=["ownership/move/target_closed_after_move"],
        ))
        examples.append(Example(
            desc=f"move_target_closed_i_{i}",
            template_id="s3c010_move_target",
            family="move_target_closed",
            role="invalid_source_used_after_move",
            src=make_src(f"move_target_closed_i_{i}", pk, res, mfn, fd, body_i),
            concepts=["move", "use_after_move", "E_OWN_MOVED"],
            difficulty="medium",
            pair=pair,
            taxonomy_nodes=["ownership/move/use_after_move"],
        ))
    return SemanticFamily("s3c010_move_target", "move_target_closed", examples)


def gen_discharge_family() -> SemanticFamily:
    examples: list[Example] = []
    for i, (pk, res, var, mfn, fd) in enumerate(VARIANTS):
        _, close, _ = proto_decl(pk, res, mfn, fd)
        pair = f"c010_discharge_{i}"

        body_v = (
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    {var}.{close}();\n"
            f"    return unit;\n"
            f"}}"
        )
        body_i = (
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    return unit;\n"
            f"}}"
        )
        examples.append(Example(
            desc=f"explicit_discharge_v_{i}",
            template_id="s3c010_explicit_discharge",
            family="explicit_discharge",
            role="valid_explicit_terminal_transition",
            src=make_src(f"explicit_discharge_v_{i}", pk, res, mfn, fd, body_v),
            concepts=["discharge", "terminal_transition"],
            difficulty="easy",
            pair=pair,
            taxonomy_nodes=["ownership/discharge/explicit_close"],
        ))
        examples.append(Example(
            desc=f"explicit_discharge_i_{i}",
            template_id="s3c010_explicit_discharge",
            family="explicit_discharge",
            role="invalid_missing_terminal_transition",
            src=make_src(f"explicit_discharge_i_{i}", pk, res, mfn, fd, body_i),
            concepts=["discharge", "missing_close", "E_OWN_UNDISCHARGED"],
            difficulty="easy",
            pair=pair,
            taxonomy_nodes=["ownership/discharge/missing_close"],
        ))
    return SemanticFamily("s3c010_explicit_discharge", "explicit_discharge", examples)


def gen_borrow_family() -> SemanticFamily:
    examples: list[Example] = []
    for i, (pk, res, var, mfn, fd) in enumerate(VARIANTS):
        _, close, _ = proto_decl(pk, res, mfn, fd)
        pair = f"c010_borrow_scope_{i}"

        body_v = (
            f"fn peek_{i}(r: RefConst<{res}>) -> Unit effects() {{ return unit; }}\n"
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    {{ let hold{i}: RefConst<{res}> = borrow {var}; peek_{i}(hold{i}); }}\n"
            f"    {var}.{close}();\n"
            f"    return unit;\n"
            f"}}"
        )
        body_i = (
            f"fn peek_{i}(r: RefConst<{res}>) -> Unit effects() {{ return unit; }}\n"
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    let hold{i}: RefConst<{res}> = borrow {var};\n"
            f"    {var}.{close}();\n"
            f"    peek_{i}(hold{i});\n"
            f"    return unit;\n"
            f"}}"
        )
        examples.append(Example(
            desc=f"borrow_scope_v_{i}",
            template_id="s3c010_borrow_scope",
            family="borrow_scope",
            role="valid_inner_borrow_ends_before_close",
            src=make_src(f"borrow_scope_v_{i}", pk, res, mfn, fd, body_v),
            concepts=["borrow", "lexical_scope", "inner_scope"],
            difficulty="medium",
            pair=pair,
            taxonomy_nodes=["ownership/borrow/inner_scope_ends"],
        ))
        examples.append(Example(
            desc=f"borrow_scope_i_{i}",
            template_id="s3c010_borrow_scope",
            family="borrow_scope",
            role="invalid_borrow_live_at_transition",
            src=make_src(f"borrow_scope_i_{i}", pk, res, mfn, fd, body_i),
            concepts=["borrow", "live_at_transition", "E_OWN_BORROW_LIVE"],
            difficulty="medium",
            pair=pair,
            taxonomy_nodes=["ownership/borrow/live_at_transition"],
        ))
    return SemanticFamily("s3c010_borrow_scope", "borrow_scope", examples)


def gen_protocol_family() -> SemanticFamily:
    examples: list[Example] = []
    for i, (pk, res, var, mfn, fd) in enumerate(SOCK_VARIANTS):
        _, terminal, connect = proto_decl(pk, res, mfn, fd)
        assert terminal == "abort" and connect == "connect"
        pair = f"c010_protocol_{i}"

        body_v = (
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    {var}.{connect}();\n"
            f"    {var}.close();\n"
            f"    return unit;\n"
            f"}}"
        )
        body_i = (
            f"fn run_{i}() -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    {var}.close();\n"
            f"    return unit;\n"
            f"}}"
        )
        examples.append(Example(
            desc=f"protocol_path_v_{i}",
            template_id="s3c010_protocol_path",
            family="protocol_path",
            role="valid_connect_then_close",
            src=make_src(f"protocol_path_v_{i}", pk, res, mfn, fd, body_v),
            concepts=["protocol", "multi_step", "connect_then_close"],
            difficulty="medium",
            pair=pair,
            taxonomy_nodes=["ownership/protocol/multi_step_valid"],
        ))
        examples.append(Example(
            desc=f"protocol_path_i_{i}",
            template_id="s3c010_protocol_path",
            family="protocol_path",
            role="invalid_close_from_created",
            src=make_src(f"protocol_path_i_{i}", pk, res, mfn, fd, body_i),
            concepts=["protocol", "wrong_state_transition", "E_PROTO_TRANSITION"],
            difficulty="medium",
            pair=pair,
            taxonomy_nodes=["ownership/protocol/wrong_state_transition"],
        ))
    return SemanticFamily("s3c010_protocol_path", "protocol_path", examples)


def gen_branch_merge_family() -> SemanticFamily:
    examples: list[Example] = []
    for i, (pk, res, var, mfn, fd) in enumerate(SOCK_VARIANTS):
        _, terminal, connect = proto_decl(pk, res, mfn, fd)
        assert terminal == "abort" and connect == "connect"
        pair = f"c010_merge_{i}"

        body_v = (
            f"fn run_{i}(flag: Bool) -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    if (flag) {{ {var}.{connect}(); }} else {{ {var}.{connect}(); }}\n"
            f"    {var}.close();\n"
            f"    return unit;\n"
            f"}}"
        )
        body_i = (
            f"fn run_{i}(flag: Bool) -> Unit effects(protocol_step) {{\n"
            f"    let {var} = {mfn}();\n"
            f"    if (flag) {{ {var}.{connect}(); }}\n"
            f"    {var}.{terminal}();\n"
            f"    return unit;\n"
            f"}}"
        )
        examples.append(Example(
            desc=f"branch_merge_v_{i}",
            template_id="s3c010_branch_merge",
            family="branch_merge",
            role="valid_same_state_at_join",
            src=make_src(f"branch_merge_v_{i}", pk, res, mfn, fd, body_v),
            concepts=["branch_join", "same_state_at_join"],
            difficulty="hard",
            pair=pair,
            taxonomy_nodes=["ownership/branch_state/same_state_join"],
        ))
        examples.append(Example(
            desc=f"branch_merge_i_{i}",
            template_id="s3c010_branch_merge",
            family="branch_merge",
            role="invalid_merge_conflict",
            src=make_src(f"branch_merge_i_{i}", pk, res, mfn, fd, body_i),
            concepts=["branch_join", "state_disagreement", "E_OWN_MERGE_CONFLICT"],
            difficulty="hard",
            pair=pair,
            taxonomy_nodes=["ownership/branch_state/merge_conflict"],
        ))
    return SemanticFamily("s3c010_branch_merge", "branch_merge", examples)


def all_families() -> list[SemanticFamily]:
    return [
        gen_move_family(),
        gen_discharge_family(),
        gen_borrow_family(),
        gen_protocol_family(),
        gen_branch_merge_family(),
    ]


MIX_YAML = """\
mix_name: axiomzig_v47_60_corpus010_balanced50
streams:
  - name: s3_ownership_moves_corpus010
    documents: documents/ownership_moves/**/*.jsonl.gz
    attributes: [axiomzig_validator_v1, axiomzig_skeleton_v1]
    filter:
      include:
        - "$.attributes[?(@.axiomzig_validator_v1.label_agreement.agreement == 'full')]"
        - "$.attributes[?(@.axiomzig_validator_v1.validation_status == 'current_v47_60')]"
      exclude:
        - "$.attributes[?(@.axiomzig_skeleton_v1.cluster_size > 8)]"
"""


def build(compiler_root: Path, out_zip: Path, workdir: Path) -> dict:
    fw = CorpusFramework(
        corpus_id=CORPUS_ID,
        bundle_name=BUNDLE_NAME,
        compiler_root=compiler_root,
        workdir=workdir,
        root_prefix=ROOT_PREFIX,
        compiler_version=COMPILER_VERSION,
        source_name="axiomzig_prepretrain_v47_60",
    )
    fw.set_taxonomy(TAXONOMY)

    families = all_families()
    total = sum(len(f.examples) for f in families)
    print(f"Candidates: {total} across {len(families)} families", flush=True)

    for family in families:
        for ex in family.examples:
            fw.process_example(ex, phase="owncheck", skel_cap=8)

    print(f"After compile: {len(fw._ledger)} records, {len(fw._rejected)} rejected", flush=True)

    dropped_uniform = fw.filter_uniform_templates()
    print(f"After uniform-template filter: {len(fw._ledger)} records (dropped {dropped_uniform})", flush=True)

    dropped_skew = fw.reduce_diagnostic_skew(max_pct=0.40)
    print(f"After diagnostic-skew reducer: {len(fw._ledger)} records (dropped {dropped_skew})", flush=True)

    script_text = Path(__file__).read_text(encoding="utf-8")
    result = fw.finalize(out_zip, script_text=script_text, mix_yaml=MIX_YAML)

    print(json.dumps(result, indent=2, sort_keys=True), flush=True)
    return result


def main() -> int:
    ap = argparse.ArgumentParser(description="Build Corpus010 balanced 50-example AxiomZig ownership corpus")
    ap.add_argument("--compiler-root", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--workdir", default="/tmp/corpus010_s3_balanced50")
    args = ap.parse_args()

    result = build(
        compiler_root=Path(args.compiler_root),
        out_zip=Path(args.out),
        workdir=Path(args.workdir),
    )
    return 0 if result.get("accepted") else 1


if __name__ == "__main__":
    raise SystemExit(main())
