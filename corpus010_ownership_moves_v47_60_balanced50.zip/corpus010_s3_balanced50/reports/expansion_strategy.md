# Expansion Strategy

Next: continue building S3 taxonomy coverage. Uncovered nodes (see taxonomy_coverage.json) should be targeted first.
