# Quality Report — corpus010_ownership_moves_v47_60_balanced50

**Records:** 50  |  **Documents:** 100
**Negative ratio:** 25/50 (50%)
**Chunk risk:** pass
  Template MI: 0.0000 bits
  Surface MI:  0.0000 bits
  Max diag %:  33.3%
**Distinct codes:** 5

### Diagnostic distribution
- `E_OWN_BORROW_LIVE`: 5
- `E_OWN_MERGE_CONFLICT`: 5
- `E_OWN_MOVED`: 5
- `E_OWN_UNDISCHARGED`: 10
- `E_PROTO_TRANSITION`: 5

### Taxonomy coverage
- Covered: 10/10 nodes (100.0%)
  ✓ ownership/borrow/inner_scope_ends
  ✓ ownership/borrow/live_at_transition
  ✓ ownership/branch_state/merge_conflict
  ✓ ownership/branch_state/same_state_join
  ✓ ownership/discharge/explicit_close
  ✓ ownership/discharge/missing_close
  ✓ ownership/move/target_closed_after_move
  ✓ ownership/move/use_after_move
  ✓ ownership/protocol/multi_step_valid
  ✓ ownership/protocol/wrong_state_transition

### Complexity profile
- easy: 20.0%
- medium: 60.0%
- hard: 20.0%