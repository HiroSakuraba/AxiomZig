# corpus010_ownership_moves_v47_60_balanced50

Records: 50  |  Chunk risk: **pass**  |  Taxonomy coverage: 10/10
