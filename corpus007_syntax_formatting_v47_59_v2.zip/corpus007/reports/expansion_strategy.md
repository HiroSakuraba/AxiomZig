# Expansion Strategy

Next: S2 types/resolution, S3 ownership, and S6 runtime traps.
