# Corpus 0007 Quality Report

```json
{
  "acceptance_notes": "S1 syntax/formatting bundle; parse/format grounded against v47.59; semantic skeleton cap enforced at <=20.",
  "accepted": true,
  "attribute_records": 232,
  "bundle_name": "corpus007_syntax_formatting_v47_59",
  "compiler_version": "v47.59",
  "corpus_id": "axiomzig_prepretrain_corpus_0007",
  "created_utc": "2026-04-27T04:48:42Z",
  "deduplication": {
    "exact_duplicates_rejected": 0,
    "formatted_duplicates_rejected": 0,
    "max_semantic_skeleton_cluster_size": 20,
    "semantic_skeleton_cluster_sizes": {
      "14": 8,
      "20": 6
    },
    "semantic_skeleton_clusters": 14
  },
  "document_records": 464,
  "format": {
    "fail_or_skipped": 132,
    "pass": 100
  },
  "label_agreement": {
    "full": 232,
    "mismatch": 0
  },
  "outcome_counts": {
    "fail": 132,
    "pass": 100
  },
  "parse": {
    "fail": 132,
    "pass": 100
  },
  "phase_counts": {
    "format": 100,
    "parse": 132
  },
  "source_records": 232,
  "split_counts": {
    "heldout": 12,
    "train": 208,
    "validation": 12
  }
}
```
