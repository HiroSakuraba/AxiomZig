# corpus007_syntax_formatting_v47_59

S1 syntax + formatting bundle generated against v47.59.

Source records: 232
Document records: 464
Attribute records: 232
