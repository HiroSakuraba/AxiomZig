# Corpus 0006 v47.59 Repaired Quality Report

```json
{
  "category_counts": {
    "contrastive_pairs": 200,
    "long_examples": 50,
    "package_graphs": 80,
    "pubdiff_lab": 120,
    "source_to_interface": 260
  },
  "corpus_id": "axiomzig_prepretrain_corpus_0006_v47_59_repaired2",
  "created_utc": "2026-04-27T03:26:39Z",
  "ledger_records_total": 710,
  "outcome_counts": {
    "compatible": 60,
    "incompatible": 48,
    "metadata-only": 12,
    "pass": 590
  },
  "phase_counts": {
    "conform": 590,
    "pubdiff": 120
  },
  "repair_notes": [
    "Replaced package-style source with v47.59 module syntax.",
    "Publication manifests use schema_version axiomzig.publication_manifest.v1.",
    "Pubdiff expected classifications generated using v47.59 publication_diff."
  ],
  "source_records": 590
}
```
