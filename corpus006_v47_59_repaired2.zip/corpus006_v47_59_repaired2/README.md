# AxiomZig Corpus 0006 v47.59 Repaired

This is a repaired current-syntax derivative of corpus006.

Source records: 590
Pubdiff labs: 120
