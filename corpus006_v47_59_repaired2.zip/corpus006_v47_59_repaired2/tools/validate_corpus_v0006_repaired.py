#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(".")
errors=[]
for lab in root.glob("labels/**/*.label.json"):
    data=json.loads(lab.read_text())
    src=root/data["source_path"]
    if not src.exists(): errors.append(f"missing {src}")
    elif hashlib.sha256(src.read_text().encode()).hexdigest()!=data["source_sha256"]: errors.append(f"hash {src}")
print(json.dumps({"labels":len(list(root.glob("labels/**/*.label.json"))),"pubdiff_tasks":len(list(root.glob("packages/**/pubdiff_task.json"))),"errors":errors,"ok":not errors},indent=2))
sys.exit(1 if errors else 0)
